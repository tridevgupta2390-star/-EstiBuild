"""M&M EstiBuild - subscription web app.
User accounts + database (saved estimates) + plan limits + branded exports."""
import io
import json
import os
import re
import threading
from functools import wraps

from flask import (Flask, render_template_string, request, send_file, redirect,
                   url_for, session)

try:
    import pymupdf as fitz
except Exception:
    import fitz  # pragma: no cover

from modules.registry import LANDING, SCHED
from brand import COMPANY, TAGLINE, CONTACT, SHORT
import country_rates
from country_rates import COUNTRIES
import ai_reader
import db
from db import PLANS
import schedule_fw
from schedule_fw import parse as sched_parse, default_schedule, enrich_schedule, _cols as fw_cols
from report_excel import build_module_excel, build_structural_excel, build_combined_excel
import input_templates
try:
    from report_pdf import build_module_pdf, build_structural_pdf
    _PDF_OK = True
except Exception:
    _PDF_OK = False
from structural.engine import estimate_structural, DEFAULT_SCHEDULE as STRUCT_DEFAULT
from structural_ui import parse_form as parse_struct_form, HTML as STRUCT_HTML, BEAM_KINDS

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 25 * 1024 * 1024
app.secret_key = os.environ.get('SECRET_KEY', 'mm-estibuild-secret-2026')
app.config['SESSION_COOKIE_SAMESITE'] = 'None'
# Secure cookies require HTTPS (Render/Railway = fine). For LOCAL http testing set COOKIE_SECURE=0
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('COOKIE_SECURE', '1') == '1'
app.jinja_env.globals.update(COMPANY=COMPANY, SHORT=SHORT, TAGLINE=TAGLINE, CONTACT=CONTACT)
db.init_db()
_lock = threading.Lock()
_store = {'struct': {}, 'sched': {}}   # struct: {(uid, project): res}, sched: {(sid, project, uid): res}


_db_ready = {'ok': False}


@app.before_request
def _ensure_db():
    # init once per worker process (not every request) - the CREATE IF NOT EXISTS
    # script on every request added avoidable DB work under load.
    if not _db_ready['ok']:
        db.init_db()   # idempotent - recreates tables if db file is missing
        _db_ready['ok'] = True
    # Multi-worker safe: re-apply THIS user's country rates on every request so the
    # correct market rates are used regardless of which gunicorn worker serves it.
    # Defaults to NEPAL so first-time visitors and returning users always see the
    # same (key-rate) Nepal pricing — never the raw import-state defaults.
    _c = session.get('country') or (country_rates.get_country() if DEMO else None) or 'NEPAL'
    country_rates.apply_rates(_c)

_OCR_OK = False
try:
    import pytesseract
    from PIL import Image
    _OCR_OK = True
except Exception:
    _OCR_OK = False


DEMO = os.environ.get('DEMO', '0') == '1'   # DEMO=1 bypasses login (for preview); DEMO=0 = real accounts (production)
DEMO_USER = {'id': 0, 'firm': 'Demo User', 'plan': 'pro', 'email': 'demo', 'phone': ''}


def current_user():
    if DEMO:
        return DEMO_USER
    uid = session.get('uid')
    return db.get_user(uid) if uid else None


def active_country():
    """Country for the current user. Stored per-user in the session so it survives
    restarts and works correctly across multiple gunicorn workers. Falls back to the
    in-memory global (for the single-process demo preview) if no session is set."""
    return session.get('country') or country_rates.get_country()


app.jinja_env.globals['current_user'] = current_user
app.jinja_env.globals['last_proj'] = lambda: session.get('last_proj_name', '')
app.jinja_env.globals['PLANS'] = PLANS
app.jinja_env.globals['current_country'] = lambda: COUNTRIES.get(active_country(), {})
app.jinja_env.globals['ai_enabled'] = ai_reader.is_ai_enabled


def login_required(f):
    @wraps(f)
    def wrap(*a, **kw):
        if DEMO:
            return f(*a, **kw)
        if not session.get('uid'):
            return redirect(url_for('login'))
        return f(*a, **kw)
    return wrap


def read_pdf_text(pdf_bytes):
    text = ''
    try:
        doc = fitz.open(stream=pdf_bytes, filetype='pdf')
        for page in doc:
            text += page.get_text('text') + '\n'
        if len(text.strip()) < 40 and _OCR_OK:
            ocr = ''
            for i, page in enumerate(doc):
                if i >= 8:
                    break
                try:
                    pix = page.get_pixmap(dpi=250)
                    img = Image.open(io.BytesIO(pix.tobytes('png')))
                    ocr += pytesseract.image_to_string(img, config='--psm 6') + '\n'
                except Exception:
                    pass
            if len(ocr.strip()) > len(text.strip()):
                text = ocr
        doc.close()
    except Exception as e:
        text = f'(PDF read error: {e})'
    return text


def _uid():
    return current_user()['id'] if not DEMO else 0


def _last_calc_project(module):
    """Project name under which this module was LAST calculated (any project)."""
    try:
        return db.last_calc_project(_uid(), module) or ''
    except Exception:
        return ''


def _active_project():
    """Project context for this user's calculations (set on the Project Total page).
    Empty string = single unnamed project (default, same behaviour as before)."""
    return session.get('proj_name', '') or ''



def _dump(filename, data):
    """Save a copy of generated reports next to the app (or /home/user in the
    preview sandbox). Failure is non-fatal - downloads work regardless."""
    for d in ('/home/user', os.path.dirname(os.path.abspath(__file__))):
        try:
            with open(os.path.join(d, filename), 'wb') as f:
                f.write(data)
            return
        except Exception:
            continue


def _save_result(res, module, proj=None):
    """Keep the last calculation BOTH in memory (fast path) and in the DB
    (shared across all gunicorn workers) so downloads work first try.
    Saved under the PROJECT NAME the user typed in the form."""
    proj = (proj if proj is not None else _active_project()) or ''
    if proj and not (res.get('project') or {}).get('name'):
        res.setdefault('project', {})['name'] = proj
    res.setdefault('country_code', active_country())   # currency context of THIS estimate
    try:
        db.save_export(_uid(), module, json.dumps(res), proj)
    except Exception:
        pass
    return proj


def _load_result(module, proj=None):
    """Latest calculation for a project: memory first (keyed by USER - never
    cross-contaminates between accounts), then the shared DB."""
    proj = (proj if proj is not None else _active_project()) or ''
    uid = _uid()
    if module == 'structural':
        with _lock:
            res = _store.get('struct', {}).get((uid, proj))
        if res:
            return res
    else:
        with _lock:
            res = _store['sched'].get((module, proj, uid))
        if res:
            return res
    try:
        raw = db.get_export(_uid(), module, proj)
        if not raw:
            return None
        res = json.loads(raw)
        # JSON turns int dia keys into strings - restore for the BBS builders
        for k in ('steel_by_dia', 'steel_bars12'):
            if isinstance(res.get(k), dict):
                res[k] = {int(d) if str(d).isdigit() else d: v for d, v in res[k].items()}
        return res
    except Exception:
        return None


def _plan():
    u = current_user()
    return u['plan'] if u else 'free'


def _save_excel_module(res, title):
    try:
        data = build_module_excel(res, title, watermark=PLANS[_plan()]['watermark'])
        _dump(f"{title}_BOQ.xlsx", data)
        res['saved_file'] = f"{title}_BOQ.xlsx"
    except Exception:
        res['saved_file'] = None


def _save_excel_struct(res):
    try:
        data = build_structural_excel(res, watermark=PLANS[_plan()]['watermark'])
        _dump("RCC_Structure_BOQ.xlsx", data)
        res['saved_file'] = "RCC_Structure_BOQ.xlsx"
    except Exception:
        res['saved_file'] = None


# ============================================================ AUTH
AUTH_CSS = "body{margin:0;font-family:'Segoe UI',Arial,sans-serif;background:linear-gradient(135deg,#1F3B57,#2E86ab);min-height:100vh;display:flex;align-items:center;justify-content:center}" \
    ".b{background:#fff;padding:30px 34px;border-radius:14px;width:340px;box-shadow:0 12px 40px rgba(0,0,0,.25)}" \
    ".b h1{margin:0 0 4px;font-size:20px;color:#1F3B57}.b p{color:#7a8693;font-size:12px;margin:0 0 16px}" \
    "label{display:block;font-size:11px;font-weight:600;color:#556;margin:8px 0 3px}input{width:100%;padding:9px 10px;border:1px solid #d7e0ea;border-radius:7px;font-size:13px;box-sizing:border-box}" \
    ".btn{background:#1f9d55;color:#fff;border:none;padding:11px;border-radius:8px;font-size:14px;font-weight:700;width:100%;margin-top:14px;cursor:pointer}" \
    ".err{color:#c0392b;font-size:12px;margin-top:8px}.alt{text-align:center;margin-top:14px;font-size:12px}.alt a{color:#2E86ab}"

LOGIN_HTML = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login - {{{{SHORT}}}}</title><style>{AUTH_CSS}</style></head><body>
<div class="b"><div style="text-align:center;font-size:30px">🏗️</div>
<h1 style="text-align:center">{{{{SHORT}}}}</h1><p style="text-align:center">Sign in to your estimation workspace</p>
<form method="post" action="{{{{url_for('login')}}}}">
<label>Email</label><input name="email" type="email" required>
<label>Password</label><input name="password" type="password" required>
<button class="btn">Sign In</button>
{{% if err %}}<div class="err">{{{{err}}}}</div>{{% endif %}}
</form><div class="alt">No account? <a href="{{{{url_for('register')}}}}">Create one free</a></div></div></body></html>"""

REGISTER_HTML = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign up - {{{{SHORT}}}}</title><style>{AUTH_CSS}</style></head><body>
<div class="b"><div style="text-align:center;font-size:30px">🏗️</div>
<h1 style="text-align:center">Create account</h1><p style="text-align:center">Free plan: 3 saved estimates, all modules</p>
<form method="post" action="{{{{url_for('register')}}}}">
<label>Firm / your name</label><input name="firm" required>
<label>Email</label><input name="email" type="email" required>
<label>Phone</label><input name="phone">
<label>Password</label><input name="password" type="password" required>
<button class="btn">Create Free Account</button>
{{% if err %}}<div class="err">{{{{err}}}}</div>{{% endif %}}
</form><div class="alt">Already have an account? <a href="{{{{url_for('login')}}}}">Sign in</a></div></div></body></html>"""


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        uid = db.create_user(request.form.get('email', ''), request.form.get('password', ''),
                             request.form.get('firm', ''), request.form.get('phone', ''))
        if uid is None:
            return render_template_string(REGISTER_HTML, err='Email already registered. Please sign in.')
        session['uid'] = uid
        return redirect(url_for('dashboard'))
    return render_template_string(REGISTER_HTML, err=None)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        u = db.verify_user(request.form.get('email', ''), request.form.get('password', ''))
        if not u:
            return render_template_string(LOGIN_HTML, err='Wrong email or password.')
        session['uid'] = u['id']
        return redirect(url_for('dashboard'))
    return render_template_string(LOGIN_HTML, err=None)


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


COUNTRY_HTML = r"""<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Select Country - EstiBuild</title><style>*{margin:0;font-family:'Segoe UI',Arial,sans-serif;box-sizing:border-box}body{background:linear-gradient(135deg,#1F3B57,#2E86ab);min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column}h1{color:#fff;font-size:26px;margin-bottom:6px}.sub{color:#cfe8ff;font-size:14px;margin-bottom:30px}.cards{display:flex;gap:20px;flex-wrap:wrap;justify-content:center;max-width:800px}.card{background:#fff;border-radius:16px;padding:30px 40px;text-align:center;text-decoration:none;color:#223;transition:transform .2s,box-shadow .2s;width:200px}.card:hover{transform:translateY(-6px);box-shadow:0 12px 36px rgba(0,0,0,.3)}.card .flag{font-size:48px}.card .name{font-size:18px;font-weight:700;color:#1F3B57;margin-top:8px}.card .cur{font-size:13px;color:#7a8693;margin-top:4px}.foot{color:#9db8d0;font-size:12px;margin-top:30px}</style></head><body><h1>🏗️ EstiBuild</h1><p class="sub">Select your country to load local market rates</p><div class="cards">{%for code,c in COUNTRIES.items()%}<a class="card" href="{{url_for('select_country',code=code)}}"><div class="flag">{{c.flag}}</div><div class="name">{{c.name}}</div><div class="cur">Currency: {{c.currency}} ({{c.symbol}})</div></a>{%endfor%}</div><p class="foot">All rates editable per item. More countries coming. · EstiBuild</p></body></html>"""


@app.route('/select')
def select():
    return render_template_string(COUNTRY_HTML, COUNTRIES=COUNTRIES)


@app.route('/select_country/<code>')
def select_country(code):
    session['country'] = code        # persist per-user (survives restart + works on any worker)
    if DEMO:
        country_rates.set_country(code)   # cookie-less preview fallback (iframe blocks cookies)
    country_rates.apply_rates(code)
    return redirect(url_for('landing'))


# ============================================================ DASHBOARD
DASH_HTML = r"""
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard - {{SHORT}}</title>
<style>*{box-sizing:border-box;margin:0;font-family:'Segoe UI',Arial,sans-serif}body{background:#f4f7fa;color:#223}
.top{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center}
.top a{color:#cfe8ff;text-decoration:none;font-size:13px;margin-left:14px}
.wrap{max-width:1000px;margin:18px auto;padding:0 16px}
.card{background:#fff;border:1px solid #d7e0ea;border-radius:12px;padding:16px 18px;margin-bottom:16px}
.sec{font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:#2E86ab;font-weight:700;margin-bottom:10px}
.planbox{display:flex;gap:12px;flex-wrap:wrap}.plan{flex:1;min-width:130px;background:#f1f6fb;border:1px solid #cfe0ef;border-radius:10px;padding:12px;text-align:center}
.plan .pn{font-weight:700;color:#1F3B57}.plan .pp{font-size:11px;color:#7a8693}.cur{border:2px solid #1f9d55;background:#eafaf0}
.btn{background:#1f9d55;color:#fff;border:none;padding:9px 18px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-block}
.btn.g{background:#6c757d}.btn.s{background:#2E86ab}
table{width:100%;border-collapse:collapse;font-size:13px}th{background:#1F3B57;color:#fff;padding:8px;text-align:left}td{padding:7px 8px;border-bottom:1px solid #e6edf4}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:8px}
.mod{background:#fff;border:1px solid #d7e0ea;border-radius:10px;padding:14px;text-align:center;text-decoration:none;color:#223}
.mod:hover{box-shadow:0 6px 18px rgba(31,59,87,.12)}.mod .ic{font-size:28px}.mod .t{font-weight:700;color:#1F3B57;margin-top:4px}
.none{color:#7a8693;text-align:center;padding:20px;font-size:13px}
</style></head><body>
<div class="top"><div><b>🏗️ EstiBuild</b> <span style="opacity:.7;font-size:12px">· Hi {{current_user().firm}}</span></div>
<div><a href="{{url_for('landing')}}">+ New estimate</a> <a href="{{url_for('logout')}}">Logout</a></div></div>
<div class="wrap">
<div class="card"><div class="sec">Subscription plan</div>
<div class="planbox">{%for pk,pv in PLANS.items()%}
<div class="plan {%if current_user().plan==pk%}cur{%endif%}"><div class="pn">{{pv.name}}</div><div class="pp">{{pv.price}}</div>
{%if current_user().plan!=pk%}<a class="btn s" style="font-size:11px;padding:5px 10px;margin-top:6px" href="{{url_for('upgrade',plan=pk)}}">Switch</a>{%else%}<div style="font-size:11px;color:#1f9d55;font-weight:700;margin-top:6px">✓ Current</div>{%endif%}
</div>{%endfor%}</div>
<div style="font-size:12px;color:#7a8693;margin-top:10px">You've used <b>{{usage}}</b> of {{PLANS[current_user().plan].max_projects if PLANS[current_user().plan].max_projects<9999 else '∞'}} saved estimates.
{%if current_user().plan=='free'%}Pro removes the watermark & unlimited saves.{%endif%}</div></div>

<div class="card"><div class="sec">Start a new estimate</div>
<div class="grid">{%for m in LANDING%}
{%if m.detailed%}<a class="mod" href="{{url_for('structural')}}"><div class="ic">{{m.icon}}</div><div class="t">{{m.title}}</div></a>
{%else%}<a class="mod" href="{{url_for('sched',sid=m.id)}}"><div class="ic">{{m.icon}}</div><div class="t">{{m.title}}</div></a>{%endif%}
{%endfor%}</div></div>

<div class="card"><div class="sec">Saved estimates ({{projects|length}})</div>
{%if projects%}
<table><tr><th>Name</th><th>Module</th><th>Amount (NPR)</th><th>Date</th><th></th></tr>
{%for p in projects%}<tr>
<td><a href="{{url_for('open_project',pid=p.id)}}"><b>{{p.name}}</b></a></td>
<td>{{p.module}}</td>
<td>{{"{:,.0f}".format(p.grand_total)}}</td>
<td>{{p.created|datetimeformat}}</td>
<td><a class="btn g" style="font-size:11px;padding:4px 9px" href="{{url_for('open_project',pid=p.id)}}">Open</a>
<a class="btn" style="font-size:11px;padding:4px 9px;background:#c0392b" href="{{url_for('del_project',pid=p.id)}}">Del</a></td>
</tr>{%endfor%}</table>
{%else%}<div class="none">No saved estimates yet. Start a new one above, then click "Save" after calculating.</div>{%endif%}
</div></div></body></html>"""


@app.template_filter('datetimeformat')
def _dt(t):
    import datetime
    try:
        return datetime.datetime.fromtimestamp(t).strftime('%Y-%m-%d %H:%M')
    except Exception:
        return ''


@app.route('/dashboard')
@login_required
def dashboard():
    u = current_user()
    return render_template_string(DASH_HTML, LANDING=LANDING,
                                  projects=db.list_projects(u['id']), usage=db.count_projects(u['id']))


@app.route('/upgrade/<plan>')
@login_required
def upgrade(plan):
    if plan in PLANS:
        if not DEMO:
            db.set_plan(current_user()['id'], plan)
        else:
            DEMO_USER['plan'] = plan
    return redirect(url_for('dashboard'))


# labour-rate labels used by the schedule module templates
from modules.common import LABOUR_LABELS
app.jinja_env.globals['LABOUR_LABELS'] = LABOUR_LABELS


@app.route('/project/<int:pid>')
@login_required
def open_project(pid):
    u = current_user()
    p = db.get_project(pid, u['id'])
    if not p:
        return redirect(url_for('dashboard'))
    import json
    data = json.loads(p['data'])
    if p['module'] == 'structural':
        return render_template_string(STRUCT_HTML, s=data, result=None, notes=None, BEAM_KINDS=BEAM_KINDS)
    mod = SCHED[p['module']]['mod']
    # older saved estimates may lack tables added later -> inject empty lists so the form renders
    for t in mod.SPEC['tables']:
        data.setdefault('tables', {}).setdefault(t['id'], [])
    return render_template_string(schedule_fw.TEMPLATE, spec=mod.SPEC, sc=data, result=None, notes=None, fw_cols=fw_cols)


@app.route('/project/<int:pid>/delete')
@login_required
def del_project(pid):
    db.delete_project(pid, current_user()['id'])
    return redirect(url_for('dashboard'))


# ============================================================ LANDING
LANDING_HTML = r"""
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EstiBuild - Construction Estimation Platform</title>
<style>*{box-sizing:border-box;margin:0;font-family:'Segoe UI',Arial,sans-serif}body{background:linear-gradient(180deg,#eef3f8,#f7fafc);color:#223;min-height:100vh}
header{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:22px 24px}
.bar{max-width:1100px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;font-size:13px}
.bar a{color:#cfe8ff;text-decoration:none;margin-left:14px}
.hd{max-width:1000px;margin:0 auto;display:flex;align-items:center;gap:16px;padding-top:14px}
.hd img{height:56px;max-width:120px;object-fit:contain}.hd h1{font-size:22px}.hd p{font-size:13px;opacity:.9}
.wrap{max-width:1100px;margin:-20px auto 60px;padding:0 16px}
.intro{background:#fff;border:1px solid #d7e0ea;border-radius:14px;padding:16px 22px;margin-bottom:18px;box-shadow:0 6px 18px rgba(31,59,87,.08);text-align:center;font-size:14px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}
.card{background:#fff;border:1px solid #d7e0ea;border-radius:14px;overflow:hidden;text-decoration:none;color:#223;transition:transform .15s,box-shadow .15s;display:block}
.card:hover{transform:translateY(-4px);box-shadow:0 10px 26px rgba(31,59,87,.16)}
.card .top{padding:16px;color:#fff;position:relative}.card .no{position:absolute;top:8px;right:12px;font-size:30px;font-weight:800;opacity:.25}
.card .ic{font-size:30px}.card .t{font-weight:700;margin-top:2px}
.card .body{padding:12px 16px 16px}.card .d{font-size:12px;color:#5b6a7a;line-height:1.5}.card .go{margin-top:10px;font-weight:700;font-size:12px}
</style></head><body>
<header><div class="bar"><div><b>🏗️ EstiBuild</b> <span style="opacity:.65;font-size:12px">Construction Estimation Platform</span></div><div>
<a href="{{url_for('project_dashboard')}}">🧾 Project Total</a> <a href="{{url_for('dashboard')}}">📊 Dashboard</a> <a href="{{url_for('select')}}">🌍 {{current_country().flag}} {{current_country().currency}}</a> <a href="{{url_for('logout')}}">Logout</a></div></div>
<div class="hd"><img src="{{url_for('logo_img')}}" alt="logo"><div><h1>EstiBuild</h1>
<p style="font-size:15px;font-weight:700;color:#ffd700;margin-top:4px">🏗️ EstiBuild — Smart Construction Estimation Platform</p>
<p>{{TAGLINE}} · {{CONTACT}}</p></div></div></header>
<div class="wrap"><div class="intro">Welcome to <b>EstiBuild</b> — Nepal's smart construction estimation platform. Upload <b>PDFs</b>, build a detailed schedule, get instant BOQ + materials, then <b>Save</b> or <b>Download Excel</b>. <b>Plan: {{PLANS[current_user().plan].name}}</b></div>
<div class="grid">
{%for m in LANDING%}
<a class="card" href="{{url_for(m.id) if m.detailed else url_for('sched',sid=m.id)}}">
<div class="top" style="background:{{m.color}}"><span class="no">{{m.no}}</span><div class="ic">{{m.icon}}</div><div class="t">{{m.title}}</div></div>
<div class="body"><div class="d">{{m.desc}}</div><div class="go">Open →</div></div></a>
{%endfor%}
</div></div></body></html>"""


@app.route('/')
@login_required
def landing():
    if not active_country():
        return redirect(url_for('select'))
    return render_template_string(LANDING_HTML, LANDING=LANDING)


@app.route('/logo.png')
def logo_img():
    return send_file('logo.png', mimetype='image/png')


# ============================================================ STRUCTURAL
@app.route('/structural', methods=['GET', 'POST'])
@login_required
def structural():
    if request.method == 'POST':
        sch = parse_struct_form(request.form)
        res = estimate_structural(sch)
        if request.form.get('action') == 'save':
            u = current_user()
            nm = request.form.get('proj_name') or request.form.get('project_name') or 'Structural estimate'
            if db.count_projects(u['id']) >= PLANS[u['plan']]['max_projects']:
                res['save_error'] = 'Project limit reached — upgrade your plan to save more.'
            else:
                db.save_project(u['id'], nm, 'structural', sch, res['grand_total'])
                res['saved_ok'] = nm
        _save_excel_struct(res)
        _proj = (request.form.get('project_name') or '').strip()[:80]
        if _proj in ('RCC Structural Estimate', 'Detailed RCC Structural Estimate'):
            _proj = ''                      # untouched defaults -> unnamed project
        if _proj:
            session['last_proj_name'] = _proj
        _save_result(res, 'structural', _proj)
        with _lock:
            _store.setdefault('struct', {})[(_uid(), _proj or '')] = res
        return render_template_string(STRUCT_HTML, s=sch, result=res, notes=None, BEAM_KINDS=BEAM_KINDS)
    return render_template_string(STRUCT_HTML, s=STRUCT_DEFAULT, result=None, notes=None, BEAM_KINDS=BEAM_KINDS)


@app.route('/structural/upload', methods=['POST'])
@login_required
def structural_upload():
    import copy, re
    files = [f for f in request.files.getlist('pdfs') if f and f.filename]
    if not files:
        return render_template_string(STRUCT_HTML, s=STRUCT_DEFAULT, result=None, notes=['No file received.'], BEAM_KINDS=BEAM_KINDS)
    first = files[0]
    fname = (first.filename or '').lower()
    try:
        if fname.endswith('.json'):
            data = json.loads(first.read())
            s = input_templates.json_to_structural(data)
            return render_template_string(STRUCT_HTML, s=s, result=None,
                                          notes=['📋 Template data loaded - review & click Calculate.'], BEAM_KINDS=BEAM_KINDS)
        if fname.endswith('.xlsx'):
            s = input_templates.xlsx_to_structural(first.read())
            return render_template_string(STRUCT_HTML, s=s, result=None,
                                          notes=['📋 Excel template loaded - review & click Calculate.'], BEAM_KINDS=BEAM_KINDS)
        if fname.endswith(('.html', '.htm')):
            data = input_templates.html_to_data(first.read().decode('utf-8', 'replace'))
            data['module'] = 'structural'
            s = input_templates.json_to_structural(data)
            return render_template_string(STRUCT_HTML, s=s, result=None,
                                          notes=['📋 HTML data file loaded - review & click Calculate.'], BEAM_KINDS=BEAM_KINDS)
    except Exception as e:
        return render_template_string(STRUCT_HTML, s=STRUCT_DEFAULT, result=None,
                                      notes=[f'Could not read template file: {e}'], BEAM_KINDS=BEAM_KINDS)
    blobs = [f.read() for f in files]
    text = '\n'.join(read_pdf_text(b) for b in blobs); low = text.lower()
    s = copy.deepcopy(STRUCT_DEFAULT); notes = []
    # typed schedule tables (exact, zero AI cost)
    try:
        import table_reader
        tbl, _tn = table_reader.parse_schedules(blobs)
        if tbl.get('footings'):
            s['footings'] = [{'id': r.get('mark') or f'F{i+1}', 'kind': r.get('type') or r.get('kind') or 'isolated',
                              'count': int(r.get('count') or 1), 'L': r.get('L') or r.get('length') or 1500,
                              'W': r.get('W') or r.get('width') or 1500, 't': r.get('t') or 450,
                              'depth': r.get('depth') or 1500, 'mesh': r.get('mesh') or '12-150',
                              'grade': r.get('grade') or 'M25'} for i, r in enumerate(tbl['footings'])]
            notes.append(f"📋 Footing schedule read: {len(s['footings'])} types")
        if tbl.get('columns'):
            s['columns'] = [{'id': r.get('mark') or f'C{i+1}', 'count': int(r.get('count') or 1),
                             'b': r.get('b') or 300, 'd': r.get('d') or 450,
                             'main': r.get('main') or '8-16', 'tie': r.get('tie') or '8-100-200',
                             'grade': r.get('grade') or 'M25'} for i, r in enumerate(tbl['columns'])]
            notes.append(f"📋 Column schedule read: {len(s['columns'])} types")
        if tbl.get('beams'):
            s['beams'] = [{'id': r.get('mark') or f'B{i+1}', 'kind': r.get('type') or r.get('kind') or 'primary',
                           'count': int(r.get('count') or 1), 'b': r.get('b') or 230, 'd': r.get('d') or 450,
                           'length': r.get('length') or 4000, 'top': r.get('top') or '2-12',
                           'bottom': r.get('bottom') or '2-12', 'tie': r.get('tie') or '8-150',
                           'grade': r.get('grade') or 'M25'} for i, r in enumerate(tbl['beams'])]
            notes.append(f"📋 Beam schedule read: {len(s['beams'])} types")
        if tbl.get('slabs'):
            s['slabs'] = [{'id': r.get('mark') or f'S{i+1}', 'area': r.get('area') or 50,
                           't': r.get('t') or 125, 'mesh': r.get('mesh') or '10-150',
                           'grade': r.get('grade') or 'M25'} for i, r in enumerate(tbl['slabs'])]
            notes.append(f"📋 Slab schedule read: {len(s['slabs'])} types")
    except Exception:
        pass
    g = re.search(r'\bm\s?(\d{2,3})\b', text, re.I)
    if g and g.group(1) in ('15', '20', '25', '30'):
        s['concrete_grade'] = 'M' + g.group(1); notes.append(f"Concrete grade M{g.group(1)}")
    fh = re.search(r'floor[^0-9]{0,12}([\d.]+)\s*m', low)
    if fh:
        s['floor_height'] = float(fh.group(1)) * 1000; notes.append(f"Floor height {fh.group(1)} m")
    cs = re.search(r'column[^0-9]{0,30}(\d{3})\s*[xX*]\s*(\d{3})', low)
    if cs and s['columns']:
        s['columns'][0]['b'] = int(cs.group(1)); s['columns'][0]['d'] = int(cs.group(2)); notes.append(f"Column {cs.group(1)}x{cs.group(2)}")
    bs = re.search(r'beam[^0-9]{0,30}(\d{3})\s*[xX*]\s*(\d{3})', low)
    if bs and s['beams']:
        s['beams'][0]['b'] = int(bs.group(1)); s['beams'][0]['d'] = int(bs.group(2)); notes.append(f"Beam {bs.group(1)}x{bs.group(2)}")
    st = re.search(r'slab[^0-9]{0,25}(\d{3})', low)
    if st and s['slabs']:
        s['slabs'][0]['t'] = int(st.group(1)); notes.append(f"Slab {st.group(1)}mm")
    # feet-inch layout drawings: overall dimensions -> slab area
    try:
        dims = sorted({d for d in schedule_fw.parse_ftin_dims(text) if d >= 1.5}, reverse=True)
    except Exception:
        dims = []
    if len(dims) >= 2 and s['slabs']:
        s['slabs'][0]['area'] = round(dims[0] * dims[1], 1)
        notes.append(f"📐 Layout dims {dims[0]:.1f}m x {dims[1]:.1f}m → slab area {dims[0]*dims[1]:.0f} m²")
    if notes:
        notes.insert(0, f'📄 Read {len(files)} PDF(s). ✅ Auto-filled {len(notes)} value(s).')
    else:
        notes = [f'📄 Read {len(files)} PDF(s) but no schedule values detected — this looks like a '
                 f'layout/graphics sheet. Auto-fill needs typed schedules (footing/column/beam/door '
                 f'lists). Fill manually; estimate still runs.']
    return render_template_string(STRUCT_HTML, s=s, result=None, notes=notes, BEAM_KINDS=BEAM_KINDS)


@app.route('/structural/export')
@login_required
def structural_export():
    res = _load_result('structural', _last_calc_project('structural'))
    if not res:
        return redirect(url_for('structural'))
    data = build_structural_excel(res, watermark=PLANS[_plan()]['watermark'])
    return send_file(io.BytesIO(data), as_attachment=True, download_name='RCC_Structure_BOQ.xlsx',
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@app.route('/structural/export_pdf')
@login_required
def structural_export_pdf():
    res = _load_result('structural', _last_calc_project('structural'))
    if not res:
        return redirect(url_for('structural'))
    if not _PDF_OK:
        return redirect(url_for('structural'))
    data = build_structural_pdf(res)
    _dump('RCC_Structure_BOQ.pdf', data)
    return send_file(io.BytesIO(data), as_attachment=True, download_name='RCC_Structure_BOQ.pdf',
                     mimetype='application/pdf')


# ============================================================ TEMPLATES & DATA UPLOADS
@app.route('/template/<sid>/<fmt>')
@login_required
def download_template(sid, fmt):
    """Fillable input templates (HTML / Excel) users download before starting."""
    if sid == 'structural':
        if fmt == 'xlsx':
            data = input_templates.structural_xlsx()
            return send_file(io.BytesIO(data), as_attachment=True, download_name='EstiBuild_RCC_Template.xlsx',
                             mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        html = input_templates.structural_html()
        return send_file(io.BytesIO(html.encode('utf-8')), as_attachment=True,
                         download_name='EstiBuild_RCC_Template.html', mimetype='text/html')
    if sid not in SCHED:
        return redirect(url_for('landing'))
    spec = SCHED[sid]['mod'].SPEC
    if fmt == 'xlsx':
        data = input_templates.module_xlsx(spec)
        return send_file(io.BytesIO(data), as_attachment=True,
                         download_name=f"EstiBuild_{spec['title']}_Template.xlsx",
                         mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    html = input_templates.module_html(spec)
    return send_file(io.BytesIO(html.encode('utf-8')), as_attachment=True,
                     download_name=f"EstiBuild_{spec['title']}_Template.html", mimetype='text/html')


@app.route('/sched/<sid>/ai_template', methods=['POST'])
@login_required
def sched_ai_template(sid):
    """AI reads the drawing -> downloadable EDITABLE HTML draft. User reviews,
    edits/adds items offline, exports the data file, uploads it back."""
    if sid not in SCHED:
        return redirect(url_for('landing'))
    mod = SCHED[sid]['mod']; spec = mod.SPEC
    files = [f for f in request.files.getlist('pdfs') if f and f.filename]
    if not files:
        return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=default_schedule(spec),
                                      result=None, notes=['No PDF for AI draft.'], fw_cols=fw_cols)
    # AI reads EVERY uploaded PDF and merges everything into ONE combined draft
    merged = {'tables': {}}
    errs = []
    for f in files:
        d, err = ai_reader.ai_extract_schedule(f.read(), spec)
        if err:
            errs.append(f'{f.filename}: {err}')
            continue
        for tid, rows in (d.get('tables') or {}).items():
            if isinstance(rows, list):
                merged['tables'].setdefault(tid, []).extend(rows)
    if errs and not merged['tables']:
        return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=default_schedule(spec),
                                      result=None, notes=[f'AI: {e}' for e in errs], fw_cols=fw_cols)
    html = input_templates.module_html(spec, prefill=merged)
    return send_file(io.BytesIO(html.encode('utf-8')), as_attachment=True,
                     download_name=f"EstiBuild_{spec['title']}_AI_Draft.html", mimetype='text/html')


@app.route('/structural/ai_template', methods=['POST'])
@login_required
def structural_ai_template():
    files = [f for f in request.files.getlist('pdfs') if f and f.filename]
    if not files:
        return render_template_string(STRUCT_HTML, s=STRUCT_DEFAULT, result=None, notes=['No PDF for AI draft.'], BEAM_KINDS=BEAM_KINDS)
    merged = {'tables': {}}
    errs = []
    for f in files:
        d, err = ai_reader.ai_extract_structural(f.read())
        if err:
            errs.append(f'{f.filename}: {err}')
            continue
        for tid, rows in (d.get('tables') or {}).items():
            if isinstance(rows, list):
                merged['tables'].setdefault(tid, []).extend(rows)
        # top-level structural keys (footings/columns/... as dicts of lists)
        for k in ('footings', 'columns', 'beams', 'slabs'):
            if isinstance(d.get(k), list):
                merged['tables'].setdefault(k, []).extend(d[k])
    if errs and not merged['tables']:
        return render_template_string(STRUCT_HTML, s=STRUCT_DEFAULT, result=None, notes=[f'AI: {e}' for e in errs], BEAM_KINDS=BEAM_KINDS)
    html = input_templates.structural_html(prefill=merged)
    return send_file(io.BytesIO(html.encode('utf-8')), as_attachment=True,
                     download_name='EstiBuild_RCC_AI_Draft.html', mimetype='text/html')


# ============================================================ SCHEDULE MODULES
@app.route('/sched/<sid>', methods=['GET', 'POST'])
@login_required
def sched(sid):
    if sid not in SCHED:
        return redirect(url_for('landing'))
    mod = SCHED[sid]['mod']; spec = mod.SPEC
    if request.method == 'POST':
        schedule = sched_parse(request.form, spec)
        res = mod.estimate(schedule)
        res['country_code'] = active_country()
        if request.form.get('action') == 'save':
            u = current_user()
            if db.count_projects(u['id']) >= PLANS[u['plan']]['max_projects']:
                res['save_error'] = 'Project limit reached — upgrade your plan to save more.'
            else:
                nm = request.form.get('proj_name') or f"{spec['title']} estimate"
                db.save_project(u['id'], nm, sid, schedule, res['grand_total'])
                res['saved_ok'] = nm
        _proj = (request.form.get('proj_name') or '').strip()[:80]
        if _proj:
            session['last_proj_name'] = _proj
        _save_excel_module(res, spec['title'])
        _save_result(res, sid, _proj)
        with _lock:
            _store['sched'][(sid, _proj or '', _uid())] = res
        return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=schedule, result=res, notes=None, fw_cols=fw_cols)
    return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=default_schedule(spec), result=None, notes=None, fw_cols=fw_cols)


@app.route('/sched/<sid>/upload', methods=['POST'])
@login_required
def sched_upload(sid):
    if sid not in SCHED:
        return redirect(url_for('landing'))
    mod = SCHED[sid]['mod']; spec = mod.SPEC
    files = [f for f in request.files.getlist('pdfs') if f and f.filename]
    if not files:
        return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=default_schedule(spec),
                                      result=None, notes=['No file received.'], fw_cols=fw_cols)
    # ---- fillable template uploads (.json from HTML template / .xlsx) - exact, zero AI ----
    first = files[0]
    fname = (first.filename or '').lower()
    try:
        if fname.endswith('.json'):
            data = json.loads(first.read())
            sc = input_templates.json_to_schedule(data, spec)
            return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=sc, result=None,
                                          notes=['📋 Template data loaded - review & click Calculate.'],
                                          fw_cols=fw_cols)
        if fname.endswith('.xlsx'):
            sc = input_templates.xlsx_to_schedule(first.read(), spec)
            return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=sc, result=None,
                                          notes=['📋 Excel template loaded - review & click Calculate.'],
                                          fw_cols=fw_cols)
        if fname.endswith(('.html', '.htm')):
            data = input_templates.html_to_data(first.read().decode('utf-8', 'replace'))
            data['module'] = sid
            sc = input_templates.json_to_schedule(data, spec)
            return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=sc, result=None,
                                          notes=['📋 HTML data file loaded - review & click Calculate.'],
                                          fw_cols=fw_cols)
    except Exception as e:
        return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=default_schedule(spec),
                                      result=None, notes=[f'Could not read template file: {e}'], fw_cols=fw_cols)
    blobs = [f.read() for f in files]
    text = '\n'.join(read_pdf_text(b) for b in blobs)
    # typed schedule tables (exact, zero AI cost)
    tables = {}
    try:
        import table_reader
        tables, _tn = table_reader.parse_schedules(blobs)
    except Exception:
        tables = {}
    sc, notes = enrich_schedule(default_schedule(spec), text, spec, tables=tables)
    notes.insert(0, f'📄 Read {len(files)} PDF(s) and combined them.')
    return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=sc, result=None, notes=notes, fw_cols=fw_cols)


@app.route('/sched/<sid>/ai', methods=['POST'])
@login_required
def sched_ai(sid):
    if sid not in SCHED:
        return redirect(url_for('landing'))
    mod = SCHED[sid]['mod']; spec = mod.SPEC
    files = [f for f in request.files.getlist('pdfs') if f and f.filename]
    if not files:
        notes = ['No PDF for AI to read.']
        return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=default_schedule(spec), result=None, notes=notes, fw_cols=fw_cols)
    pdf_bytes = files[0].read()
    data, err = ai_reader.ai_extract_schedule(pdf_bytes, spec)
    if err:
        notes = [f'🤖 AI: {err}']
        return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=default_schedule(spec), result=None, notes=notes, fw_cols=fw_cols)
    # merge AI data into default schedule
    sc = default_schedule(spec)
    if 'tables' in data:
        for tid, rows in data['tables'].items():
            if tid in sc['tables'] and isinstance(rows, list):
                sc['tables'][tid] = rows
    n_items = sum(len(v) if isinstance(v, list) else 0 for v in data.get('tables', {}).values())
    notes = [f'🤖 AI read {len(files)} drawing(s) — extracted {n_items} items. Review & Calculate.']
    return render_template_string(schedule_fw.TEMPLATE, spec=spec, sc=sc, result=None, notes=notes, fw_cols=fw_cols)


@app.route('/structural/ai', methods=['POST'])
@login_required
def structural_ai():
    files = [f for f in request.files.getlist('pdfs') if f and f.filename]
    if not files:
        return render_template_string(STRUCT_HTML, s=STRUCT_DEFAULT, result=None, notes=['No PDF for AI.'], BEAM_KINDS=BEAM_KINDS)
    pdf_bytes = files[0].read()
    data, err = ai_reader.ai_extract_structural(pdf_bytes)
    if err:
        return render_template_string(STRUCT_HTML, s=STRUCT_DEFAULT, result=None, notes=[f'🤖 AI: {err}'], BEAM_KINDS=BEAM_KINDS)
    import copy
    s = copy.deepcopy(STRUCT_DEFAULT)
    if 'concrete_grade' in data: s['concrete_grade'] = data['concrete_grade']
    if 'floor_height_mm' in data: s['floor_height'] = data['floor_height_mm']
    if 'floors' in data: s['floors_above'] = data['floors']
    if 'footings' in data and isinstance(data['footings'], list): s['footings'] = data['footings']
    if 'columns' in data and isinstance(data['columns'], list): s['columns'] = data['columns']
    if 'beams' in data and isinstance(data['beams'], list): s['beams'] = data['beams']
    if 'slabs' in data and isinstance(data['slabs'], list): s['slabs'] = data['slabs']
    notes = ['🤖 AI read the drawing and extracted structural data. Review each member & Calculate.']
    return render_template_string(STRUCT_HTML, s=s, result=None, notes=notes, BEAM_KINDS=BEAM_KINDS)


@app.route('/sched/<sid>/export')
@login_required
def sched_export(sid):
    if sid not in SCHED:
        return redirect(url_for('landing'))
    res = _load_result(sid, _last_calc_project(sid))
    if not res:
        return redirect(url_for('sched', sid=sid))
    data = build_module_excel(res, SCHED[sid]['title'], watermark=PLANS[_plan()]['watermark'])
    return send_file(io.BytesIO(data), as_attachment=True, download_name=f"{SCHED[sid]['title']}_BOQ.xlsx",
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


@app.route('/sched/<sid>/export_pdf')
@login_required
def sched_export_pdf(sid):
    if sid not in SCHED:
        return redirect(url_for('landing'))
    res = _load_result(sid, _last_calc_project(sid))
    if not res:
        return redirect(url_for('sched', sid=sid))
    if not _PDF_OK:
        return redirect(url_for('sched', sid=sid))
    data = build_module_pdf(res, SCHED[sid]['title'])
    _dump(f"{SCHED[sid]['title']}_BOQ.pdf", data)
    return send_file(io.BytesIO(data), as_attachment=True, download_name=f"{SCHED[sid]['title']}_BOQ.pdf",
                     mimetype='application/pdf')



# ============================================================ COMBINED PROJECT DASHBOARD
PROJECT_MODS = [('structural', 'RCC Structure', '🏗️'),
                ('archfin', 'Architecture & Finishing', '🏠'),
                ('sanitary', 'Sanitary & Plumbing', '🚿'),
                ('electrical', 'Electrical', '⚡'),
                ('steel', 'Steel Structure', '🔩'),
                ('roofing', 'Roofing & Truss', '🏭')]

PROJECT_DASH_HTML = r"""
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Projects - EstiBuild</title>
<style>*{box-sizing:border-box;margin:0;font-family:'Segoe UI',Arial,sans-serif}body{background:#f4f7fa;color:#223}
header{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:18px 24px}
.bar{max-width:1050px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;font-size:13px}
.bar a{color:#cfe8ff;text-decoration:none;margin-left:14px}
.wrap{max-width:1050px;margin:26px auto 60px;padding:0 16px}
.how{background:#fff;border:1px solid #d7e0ea;border-radius:12px;padding:14px 18px;margin-bottom:16px;font-size:13px;line-height:1.6}
.how b{color:#1F3B57}
.proj{background:#fff;border:1px solid #d7e0ea;border-radius:14px;padding:18px 20px;margin-bottom:18px}
.proj h2{font-size:16px;color:#1F3B57;margin-bottom:2px}
.proj .sub{font-size:12px;color:#7a8693;margin-bottom:12px}
table{width:100%;border-collapse:collapse;font-size:13px}
td,th{padding:7px 8px;border-bottom:1px solid #eef2f6;text-align:left}
th{color:#5b6a7a;font-size:11.5px;text-transform:uppercase;letter-spacing:.4px}
td.amt{text-align:right;font-weight:700;white-space:nowrap}
tr.tot td{border-top:2px solid #cdd8e2;font-weight:800;font-size:15px;color:#1F3B57}
tr.miss td{color:#a5b1bd}
.fin{background:#f0f9f2;border:1px dashed #1f9d55;border-radius:10px;padding:10px 14px;margin-top:12px;font-size:13px}
.fin b{color:#1f9d55;font-size:17px}
.btn{display:inline-block;background:#1f9d55;color:#fff;border-radius:9px;padding:10px 18px;font-weight:700;text-decoration:none;font-size:13px;margin-top:10px}
.exc{font-size:11px;color:#98a6b3;text-decoration:none;margin-left:10px}
.exc.on{color:#c0392b;font-weight:700}
</style></head><body>
<header><div class="bar"><div><b>🏗️ EstiBuild</b> <span style="opacity:.65;font-size:12px">My Projects</span></div><div>
<a href="{{url_for('landing')}}">🏠 Modules</a> <a href="{{url_for('dashboard')}}">📊 Dashboard</a> <a href="{{url_for('select')}}">🌍 {{current_country().flag}} {{current_country().currency}}</a></div></div></header>
<div class="wrap">
<div class="how">💡 <b>How projects work:</b> when you calculate any module, the <b>Project name you typed at the top of that form</b>
decides where it is saved. Use the <b>same name for every module of one building</b> (e.g. "Sharma House"). Each project below
shows its own total — projects never mix. Rates: <b>{{country_label}}</b>.</div>

{%if not projs%}
<div class="how" style="color:#c0392b"><b>No estimates yet.</b> Open a module, type a project name at the top of the form,
fill the schedule and click Calculate. Come back here to see the project total.</div>
{%endif%}

{%for p in projs%}
<div class="proj">
<h2>📁 {{p.name if p.name else '(no project name)'}}</h2>
<div class="sub">{{p.n}} of 6 modules calculated · rates: {{p.label}}{%if p.name%} · type "{{p.name}}" in the form to add more modules to this project{%endif%}
<a href="{{url_for('project_delete', project=p.name)}}" onclick="return confirm('Delete all saved results of this project?')" style="float:right;color:#c0392b;font-weight:700;font-size:11.5px">🗑 delete project</a></div>
<table>
<tr><th>Module</th><th style="text-align:right">Direct cost</th><th></th></tr>
{%for m in p.mods%}
{%if m.calculated%}
<tr{%if not m.included%} class="miss"{%endif%}>
<td>{{m.icon}} {{m.title}}</td>
<td class="amt">{%if m.included%}{{ "{:,.0f}".format(m.total) }}{%else%}<span style="color:#c0392b">excluded</span>{%endif%}</td>
<td style="white-space:nowrap"><a href="{{url_for('sched', sid=m.sid) if m.sid!='structural' else url_for('structural')}}" style="font-size:11.5px;color:#1f9d55;font-weight:700">recalculate ↻</a>
<a class="exc{%if not m.included%} on{%endif%}" href="{{url_for('project_exclude', sid=m.sid, project=p.name)}}">{%if m.included%}✕ exclude{%else%}↩ include{%endif%}</a></td></tr>
{%else%}
<tr class="miss"><td>{{m.icon}} {{m.title}}</td><td class="amt">—</td>
<td><a href="{{url_for('sched', sid=m.sid) if m.sid!='structural' else url_for('structural')}}" style="font-size:11.5px;color:#1f9d55;font-weight:700">open module →</a></td></tr>
{%endif%}
{%endfor%}
<tr class="tot"><td>PROJECT TOTAL (direct cost)</td><td class="amt">{{p.cur}} {{ "{:,.0f}".format(p.total) }}</td><td></td></tr>
</table>
<div class="fin">💰 Indicative final client price (OH 5% + profit 10% + contingency 3% + VAT {{p.vat}}%): <b>{{p.cur}} {{ "{:,.0f}".format(p.final) }}</b>
<span style="color:#7a8693;font-size:11.5px"> — editable version in the Excel</span></div>
{%if p.n%}<a class="btn" href="{{url_for('combined_export', project=p.name)}}">⬇ Download MASTER Excel — {{p.name if p.name else 'this project'}}</a>{%endif%}
</div>
{%endfor%}
</div></body></html>
"""


@app.route('/project')
@login_required
def project_dashboard():
    excluded = session.get('excluded_modules', {})
    if not isinstance(excluded, dict):
        excluded = {}
    try:
        names = db.list_export_projects(_uid())
    except Exception:
        names = []
    # include the unnamed group only if it has any result
    groups = []
    for name in names:
        groups.append(name)
    if any(_load_result(sid, '') for sid, _t, _i in PROJECT_MODS):
        groups.append('')
    cc = COUNTRIES.get(active_country(), {})
    vat = 5 if cc.get('code') == 'UAE' else 13
    projs = []
    for name in groups:
        mods = []
        total = 0.0
        n = 0
        pcc = cc
        for sid, title, icon in PROJECT_MODS:
            res = _load_result(sid, name)
            if res and res.get('grand_total'):
                if res.get('country_code'):
                    pcc = COUNTRIES.get(res['country_code'], cc)   # project's own currency
                inc = sid not in (excluded.get(name) or [])
                mods.append({'sid': sid, 'title': title, 'icon': icon,
                             'total': res['grand_total'], 'calculated': True, 'included': inc})
                if inc:
                    total += res['grand_total']
                    n += 1
            else:
                mods.append({'sid': sid, 'title': title, 'icon': icon,
                             'total': None, 'calculated': False, 'included': True})
        d = total
        pvat = 5 if pcc.get('code') == 'UAE' else 13
        final = (d * 1.05 + d * 1.05 * 0.10 + d * 0.03) * (1 + pvat / 100.0)
        projs.append({'name': name, 'mods': mods, 'total': total, 'n': n,
                      'final': final, 'vat': pvat,
                      'cur': pcc.get('currency', 'NPR'), 'label': pcc.get('name', '')})
    projs.sort(key=lambda p: p['name'].lower())
    return render_template_string(PROJECT_DASH_HTML, projs=projs,
                                  cur=cc.get('currency', 'NPR'),
                                  country_label=cc.get('name', ''))


@app.route('/project/exclude/<sid>')
@login_required
def project_exclude(sid):
    valid = {s for s, _t, _i in PROJECT_MODS}
    if sid not in valid:
        return redirect(url_for('project_dashboard'))
    proj = request.args.get('project', '')
    ex = session.get('excluded_modules', {})
    if not isinstance(ex, dict):
        ex = {}
    lst = ex.get(proj, [])
    if sid in lst:
        lst.remove(sid)
    else:
        lst.append(sid)
    ex[proj] = lst
    session['excluded_modules'] = ex
    return redirect(url_for('project_dashboard'))


@app.route('/project/delete')
@login_required
def project_delete():
    proj = request.args.get('project', '')
    uid = _uid()
    # 1. clear the shared DB (all workers)
    try:
        db.delete_project_exports(uid, proj)
    except Exception:
        pass
    # 2. clear THIS worker's in-memory cache too (the bug: results showed
    #    from _store even after the DB row was deleted)
    with _lock:
        st = _store.get('struct', {})
        for k in [k for k in st if isinstance(k, tuple) and len(k) == 2 and k[0] == uid and k[1] == proj]:
            st.pop(k, None)
        sc = _store.get('sched', {})
        for k in [k for k in sc if isinstance(k, tuple) and len(k) == 3 and k[2] == uid and k[1] == proj]:
            sc.pop(k, None)
    # 3. clear exclusions for this project
    ex = session.get('excluded_modules', {})
    if isinstance(ex, dict):
        ex.pop(proj, None)
        session['excluded_modules'] = ex
    return redirect(url_for('project_dashboard'))


@app.route('/combined/export')
@login_required
def combined_export():
    proj = request.args.get('project', '')
    excluded = set((session.get('excluded_modules', {}) or {}).get(proj, []))
    results = {}
    pcode = active_country()
    for sid, _t, _i in PROJECT_MODS:
        if sid in excluded:
            continue
        res = _load_result(sid, proj)
        if res:
            results[sid] = res
            if res.get('country_code'):
                pcode = res['country_code']
    if not results:
        return redirect(url_for('project_dashboard'))
    fname = (f"EstiBuild_{proj}_Master_BOQ.xlsx".replace(' ', '_').replace('/', '-')
             if proj else 'EstiBuild_Project_Master_BOQ.xlsx')
    data = build_combined_excel(results, COUNTRIES.get(pcode, {}).get('name', ''))
    return send_file(io.BytesIO(data), as_attachment=True,
                     download_name=fname,
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8080)), debug=False)
