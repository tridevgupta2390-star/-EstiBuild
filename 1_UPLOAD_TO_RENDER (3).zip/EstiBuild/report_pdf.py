"""PDF BOQ report builder (fpdf2) — mirrors the Excel export so clients can
cross-check the same numbers in two formats. Returns PDF bytes."""
import os
from fpdf import FPDF
from brand import COMPANY, TAGLINE, CONTACT, LOGO
import country_rates
from country_rates import COUNTRIES

NAVY = (31, 59, 87)
TEAL = (46, 134, 171)
GREY = (90, 100, 115)
GOLD = (252, 228, 166)
LIGHT = (221, 230, 239)

# latin-1 sanitising for the built-in helvetica font
REPL = {'∅': 'D', '³': '3', '²': '2', '—': '-', '–': '-', '·': '-', '×': 'x',
        '≈': '~', '“': '"', '”': '"', '‘': "'", '’': "'", '→': '->', '₹': 'Rs',
        '\u00a0': ' '}


def _s(txt):
    out = ''
    for ch in str(txt if txt is not None else ''):
        out += REPL.get(ch, ch)
    return out.encode('latin-1', 'replace').decode('latin-1')


def _cur(res=None):
    if res and res.get('country_code'):
        c = COUNTRIES.get(res['country_code'])
        if c:
            return c['currency']
    code = country_rates.get_country()
    if code in COUNTRIES:
        return COUNTRIES[code]['currency']
    return 'NPR'


def _fmt(v, dec=0):
    try:
        return f"{float(v):,.{dec}f}"
    except (TypeError, ValueError):
        return str(v)


class _PDF(FPDF):
    def header(self):
        if self.page_no() > 1:
            self.set_font('helvetica', 'I', 8)
            self.set_text_color(*GREY)
            self.cell(0, 5, _s(f'{COMPANY}  -  continued'), align='R')
            self.ln(7)

    def footer(self):
        self.set_y(-13)
        self.set_font('helvetica', 'I', 8)
        self.set_text_color(*GREY)
        self.cell(0, 5, _s(f'Page {self.page_no()}/{{nb}}  -  {COMPANY}'), align='C')


def _need_space(pdf, mm):
    """Start a new page if less than `mm` space remains (keeps headings with tables)."""
    if pdf.get_y() + mm > 279:
        pdf.add_page()


def _title_block(pdf, title, res=None):
    if os.path.exists(LOGO):
        try:
            pdf.image(LOGO, x=12, y=10, w=15)
        except Exception:
            pass
    pdf.set_xy(30, 10)
    pdf.set_font('helvetica', 'B', 17)
    pdf.set_text_color(*NAVY)
    pdf.cell(0, 8, _s(COMPANY))
    pdf.set_xy(30, 18)
    pdf.set_font('helvetica', '', 8.5)
    pdf.set_text_color(*GREY)
    pdf.cell(0, 5, _s(f'{TAGLINE} | {CONTACT}'))
    pdf.set_xy(12, 26)
    pdf.set_font('helvetica', 'B', 13)
    pdf.set_text_color(*TEAL)
    pdf.cell(0, 8, _s(f'{title.upper()} - BILL OF QUANTITIES'))
    pdf.set_xy(12, 34)
    pdf.set_font('helvetica', 'I', 8.5)
    pdf.set_text_color(*GREY)
    pdf.cell(0, 5, _s(f'All amounts in {_cur(res)}. Cross-check with the Excel export (same quantities & rates).'))
    pdf.set_y(42)


def _info_block(pdf, res, title):
    proj = res.get('project', {}) or {}
    rows = [('Module', title),
            ('Project', proj.get('name', '')),
            ('Location', proj.get('location', '')),
            ('Grand Total', f"{_cur(res)} {_fmt(res.get('grand_total', 0))}")]
    if res.get('totals'):
        t = res['totals']
        for k, lab in (('concrete_m3', 'Concrete (m3)'), ('steel_kg', 'Steel (kg)'),
                       ('shuttering_m2', 'Shuttering (m2)'), ('excavation_m3', 'Excavation (m3)')):
            if k in t:
                rows.append((lab, _fmt(t[k], 1)))
    pdf.set_font('helvetica', '', 9)
    for lab, val in rows:
        if val in ('', None):
            continue
        pdf.set_font('helvetica', 'B', 9)
        pdf.set_text_color(*NAVY)
        pdf.cell(38, 5.2, _s(lab))
        pdf.set_font('helvetica', '', 9)
        pdf.set_text_color(40, 40, 40)
        pdf.cell(110, 5.2, _s(val))
        pdf.ln(5.2)
    pdf.ln(3)


def _empty_warning(pdf, res):
    """If nothing was calculated, say so loudly instead of looking 'incomplete'."""
    n = sum(len(g.get('items', [])) for g in res.get('groups', {}).values())
    if n > 0:
        return
    pdf.set_fill_color(255, 236, 236)
    pdf.set_draw_color(180, 30, 30)
    pdf.set_text_color(170, 30, 30)
    pdf.set_font('helvetica', 'B', 11)
    pdf.multi_cell(0, 7, _s('NOTE: THIS ESTIMATE IS EMPTY - no items were calculated. '
                            'Go back, fill the schedule, and click Calculate before exporting.'),
                   border=1, fill=True)
    pdf.set_draw_color(0, 0, 0)
    pdf.ln(4)


def _table_header(pdf, cols, widths):
    pdf.set_font('helvetica', 'B', 8.5)
    pdf.set_fill_color(*NAVY)
    pdf.set_text_color(255, 255, 255)
    for c, w in zip(cols, widths):
        pdf.cell(w, 6, _s(c), border=1, fill=True)
    pdf.ln(6)
    pdf.set_text_color(40, 40, 40)


def _boq_section(pdf, res):
    W = [108, 14, 20, 20, 24]
    for gname, info in res['groups'].items():
        _need_space(pdf, 34)          # banner + header + at least 2 rows
        pdf.set_font('helvetica', 'B', 10)
        pdf.set_fill_color(*TEAL)
        pdf.set_text_color(255, 255, 255)
        pdf.cell(0, 7, _s(gname), border=1, fill=True)
        pdf.ln(7)
        _table_header(pdf, ['Item', 'Unit', 'Qty', 'Rate', 'Amount'], W)
        pdf.set_font('helvetica', '', 8.5)
        fill = False
        for it in info['items']:
            if pdf.get_y() > 265:
                pdf.add_page()
                _table_header(pdf, ['Item', 'Unit', 'Qty', 'Rate', 'Amount'], W)
                pdf.set_font('helvetica', '', 8.5)
            pdf.set_fill_color(245, 248, 251) if fill else pdf.set_fill_color(255, 255, 255)
            fill = not fill
            pdf.cell(W[0], 5.6, _s(it['desc'])[:95], border=1, fill=fill)
            pdf.cell(W[1], 5.6, _s(it['unit']), border=1, fill=fill)
            pdf.cell(W[2], 5.6, _fmt(it['qty'], 2), border=1, fill=fill, align='R')
            pdf.cell(W[3], 5.6, _fmt(it['rate']), border=1, fill=fill, align='R')
            pdf.cell(W[4], 5.6, _fmt(it['amount']), border=1, fill=fill, align='R')
            pdf.ln(5.6)
        pdf.set_font('helvetica', 'B', 9)
        pdf.set_fill_color(*LIGHT)
        pdf.set_text_color(*NAVY)
        pdf.cell(sum(W[:4]), 6.4, 'Sub-total', border=1, fill=True, align='R')
        pdf.cell(W[4], 6.4, _fmt(info['subtotal']), border=1, fill=True, align='R')
        pdf.ln(9)
    _need_space(pdf, 16)
    pdf.set_font('helvetica', 'B', 11)
    pdf.set_fill_color(*GOLD)
    pdf.set_text_color(60, 40, 0)
    pdf.cell(sum(W[:4]), 9, 'GRAND TOTAL', border=1, fill=True, align='R')
    pdf.cell(W[4], 9, _fmt(res['grand_total']), border=1, fill=True, align='R')
    pdf.ln(12)


def _materials_section(pdf, res):
    mats = res.get('materials')
    if not mats:
        return
    rows = []
    if isinstance(mats, dict):
        names = {'cement_bags': ('Cement (OPC 53)', 'bags', 950),
                 'sand_m3': ('Fine Aggregate (Sand)', 'cum', 2500),
                 'aggregate_m3': ('Coarse Aggregate', 'cum', 2800),
                 'steel_kg': ('TMT Steel (Fe500)', 'kg', 150),
                 'brick_no': ('Bricks', 'nos', 18),
                 'block_no': ('Blocks (AAC)', 'nos', 120)}
        for k, v in mats.items():
            if k in ('waste_steel_pct', 'waste_conc_pct'):
                continue
            lab, unit, rate = names.get(k, (k, '', 0))
            rows.append((lab, v, unit, rate, float(v) * rate))
    else:
        for m in mats:
            rows.append((m.get('label', ''), m.get('qty', 0), m.get('unit', ''),
                         m.get('rate', 0), m.get('value', 0)))
    if not rows:
        return
    _need_space(pdf, 40)
    pdf.set_font('helvetica', 'B', 12)
    pdf.set_text_color(*NAVY)
    pdf.cell(0, 8, 'MATERIAL PROCUREMENT SUMMARY')
    pdf.ln(9)
    W = [90, 28, 20, 24, 24]
    _table_header(pdf, ['Material', 'Qty', 'Unit', 'Rate', 'Value'], W)
    pdf.set_font('helvetica', '', 8.5)
    for lab, qty, unit, rate, val in rows:
        if pdf.get_y() > 265:
            pdf.add_page()
            _table_header(pdf, ['Material', 'Qty', 'Unit', 'Rate', 'Value'], W)
            pdf.set_font('helvetica', '', 8.5)
        pdf.cell(W[0], 5.6, _s(lab), border=1)
        pdf.cell(W[1], 5.6, _fmt(qty, 1), border=1, align='R')
        pdf.cell(W[2], 5.6, _s(unit), border=1)
        pdf.cell(W[3], 5.6, _fmt(rate), border=1, align='R')
        pdf.cell(W[4], 5.6, _fmt(val), border=1, align='R')
        pdf.ln(5.6)
    pdf.ln(8)


def _bbs_section(pdf, res):
    bbs = res.get('bbs_table') or []
    if not bbs:
        return
    _need_space(pdf, 45)
    pdf.set_font('helvetica', 'B', 12)
    pdf.set_text_color(*NAVY)
    pdf.cell(0, 8, 'BAR BENDING SCHEDULE (auto-generated)')
    pdf.ln(9)
    W = [24, 18, 12, 18, 20, 26, 18, 24]
    HDR = ['Bar Mark', 'Member', 'Dia(mm)', 'Nos', 'Cut Len(m)', 'Total Len(m)', 'kg/m', 'Weight(kg)']
    _table_header(pdf, HDR, W)
    pdf.set_font('helvetica', '', 8)
    for b in bbs:
        if pdf.get_y() > 265:
            pdf.add_page()
            _table_header(pdf, HDR, W)
            pdf.set_font('helvetica', '', 8)
        pdf.cell(W[0], 5.2, _s(b['mark']), border=1)
        pdf.cell(W[1], 5.2, _s(b['member']), border=1)
        pdf.cell(W[2], 5.2, _s(b['dia']), border=1, align='R')
        pdf.cell(W[3], 5.2, _fmt(b['count']), border=1, align='R')
        pdf.cell(W[4], 5.2, _fmt(b['cut_len'], 2), border=1, align='R')
        pdf.cell(W[5], 5.2, _fmt(b['total_len'], 1), border=1, align='R')
        pdf.cell(W[6], 5.2, _fmt(b['unit_wt'], 3), border=1, align='R')
        pdf.cell(W[7], 5.2, _fmt(b['weight'], 1), border=1, align='R')
        pdf.ln(5.2)
    net = sum(b['weight'] for b in bbs)
    _need_space(pdf, 26)
    pdf.set_font('helvetica', 'B', 9)
    pdf.set_fill_color(*LIGHT)
    pdf.set_text_color(*NAVY)
    pdf.cell(sum(W[:7]), 6.4, 'TOTAL net cutting weight (before 3% wastage)', border=1, fill=True, align='R')
    pdf.cell(W[7], 6.4, _fmt(net, 1), border=1, fill=True, align='R')
    pdf.ln(6.4)
    gross = res.get('totals', {}).get('steel_kg', round(net * 1.03, 1))
    pdf.cell(sum(W[:7]), 6.4, 'TOTAL incl 3% wastage (= BOQ steel qty)', border=1, fill=True, align='R')
    pdf.cell(W[7], 6.4, _fmt(gross, 1), border=1, fill=True, align='R')
    pdf.ln(8)
    bydia = res.get('steel_by_dia') or {}
    bars12 = res.get('steel_bars12') or {}
    if bydia:
        pdf.set_font('helvetica', 'B', 10)
        pdf.set_text_color(*NAVY)
        parts = []
        for d, v in bydia.items():
            b = bars12.get(d)
            parts.append(f"{d}mm: {_fmt(v)} kg" + (f" ({b} x 12m bars)" if b else ""))
        pdf.multi_cell(0, 6, _s('Steel by diameter (for ordering):  ' + '   '.join(parts)))
        pdf.ln(4)


def _labour_section(pdf, res):
    labour = res.get('labour') or {}
    if not labour:
        return
    _u = res.get('labour_rates') or {}
    rates = {'mason_days': _u.get('mason', 1200), 'mazdoor_days': _u.get('mazdoor', 800),
             'plumber_days': _u.get('plumber', 1500), 'electrician_days': _u.get('electrician', 1500),
             'wireman_days': _u.get('wireman', 1200), 'helper_days': _u.get('helper', 800),
             'tile_mason_days': _u.get('tile_mason', 1400), 'painter_days': _u.get('painter', 1300),
             'fixture_days': _u.get('fixture', 1200), 'fixture_install_days': _u.get('fixture_install', 1300),
             'steel_fab_days': _u.get('steel_fab', 1400)}
    labels = {'mason_days': 'Mason', 'mazdoor_days': 'Mazdoor (Helper)',
              'plumber_days': 'Plumber', 'electrician_days': 'Electrician',
              'wireman_days': 'Wireman', 'helper_days': 'Helper',
              'tile_mason_days': 'Tile Mason', 'painter_days': 'Painter',
              'fixture_days': 'Fixture Installer', 'fixture_install_days': 'Fixture Installer',
              'steel_fab_days': 'Steel Fabricator'}
    rows = []
    for key, days in labour.items():
        if key in ('note', 'total_days') or 'cost' in key or not isinstance(days, (int, float)) or not days:
            continue
        rows.append((labels.get(key, key.replace('_', ' ').title()), days,
                     rates.get(key, 1000), days * rates.get(key, 1000)))
    if not rows:
        return
    _need_space(pdf, 45)
    pdf.set_font('helvetica', 'B', 12)
    pdf.set_text_color(*NAVY)
    pdf.cell(0, 8, _s('LABOUR ESTIMATE (planning only - included in BOQ rates)'))
    pdf.ln(9)
    W = [70, 30, 40, 46]
    _table_header(pdf, ['Trade', 'Days', f'Rate/Day ({_cur(res)})', f'Cost ({_cur(res)})'], W)
    pdf.set_font('helvetica', '', 8.5)
    for lab, days, rate, cost in rows:
        if pdf.get_y() > 265:
            pdf.add_page()
            _table_header(pdf, ['Trade', 'Days', f'Rate/Day ({_cur(res)})', f'Cost ({_cur(res)})'], W)
            pdf.set_font('helvetica', '', 8.5)
        pdf.cell(W[0], 5.8, _s(lab), border=1)
        pdf.cell(W[1], 5.8, _fmt(days), border=1, align='R')
        pdf.cell(W[2], 5.8, _fmt(rate), border=1, align='R')
        pdf.cell(W[3], 5.8, _fmt(cost), border=1, align='R')
        pdf.ln(5.8)
    tot_d = sum(r[1] for r in rows)
    tot_c = sum(r[3] for r in rows)
    pdf.set_font('helvetica', 'B', 9)
    pdf.set_fill_color(*LIGHT)
    pdf.set_text_color(*NAVY)
    pdf.cell(W[0], 6.4, 'TOTAL', border=1, fill=True)
    pdf.cell(W[1], 6.4, _fmt(tot_d), border=1, fill=True, align='R')
    pdf.cell(W[2], 6.4, '', border=1, fill=True)
    pdf.cell(W[3], 6.4, _fmt(tot_c), border=1, fill=True, align='R')
    pdf.ln(10)


def _build(res, title, include_bbs):
    pdf = _PDF(format='A4')
    pdf.set_auto_page_break(True, margin=18)
    pdf.set_margins(12, 12, 12)
    pdf.add_page()
    _title_block(pdf, title, res)
    _info_block(pdf, res, title)
    _empty_warning(pdf, res)
    _boq_section(pdf, res)
    _materials_section(pdf, res)
    if include_bbs:
        _bbs_section(pdf, res)
    _labour_section(pdf, res)
    # signature strip (on its own page if the current one is full)
    _need_space(pdf, 22)
    pdf.set_font('helvetica', '', 9)
    pdf.set_text_color(60, 60, 60)
    pdf.cell(60, 6, 'Prepared by: ______________')
    pdf.cell(66, 6, 'Checked by: ______________')
    pdf.cell(0, 6, 'Approved by: ______________')
    return bytes(pdf.output())


def build_structural_pdf(res):
    return _build(res, 'RCC Structure Estimate', include_bbs=True)


def build_module_pdf(res, title):
    return _build(res, title, include_bbs=False)
