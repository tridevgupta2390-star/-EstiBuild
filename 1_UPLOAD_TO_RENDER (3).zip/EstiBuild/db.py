"""Database layer (SQLite) - users, projects/estimates, subscription plans.
No external DB server needed - one file (estibuild.db)."""
import sqlite3
import os
import time
import json
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = os.environ.get('DB_PATH', 'estibuild.db')

PLANS = {
    'free':   {'name': 'Free',  'max_projects': 3,  'excel': True, 'watermark': True,  'price': 'Rs 0'},
    'basic':  {'name': 'Basic', 'max_projects': 50, 'excel': True, 'watermark': True,  'price': 'Rs 1,500/mo'},
    'pro':    {'name': 'Pro',   'max_projects': 99999, 'excel': True, 'watermark': False, 'price': 'Rs 3,500/mo'},
    'team':   {'name': 'Team',  'max_projects': 99999, 'excel': True, 'watermark': False, 'price': 'Rs 9,000/mo'},
}


def conn():
    c = sqlite3.connect(DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    # WAL mode: readers never block the writer, writer never blocks readers -
    # essential for many simultaneous users across gunicorn workers.
    try:
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=30000")
        c.execute("PRAGMA synchronous=NORMAL")
    except Exception:
        pass
    return c


def init_db():
    c = conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      firm TEXT, phone TEXT,
      plan TEXT DEFAULT 'free',
      created REAL);
    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT, module TEXT,
      data TEXT,
      grand_total REAL DEFAULT 0,
      created REAL);
    CREATE TABLE IF NOT EXISTS exports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      module TEXT NOT NULL,
      data TEXT,
      created REAL,
      project TEXT DEFAULT '');
""")
    c.commit(); c.close()



def create_user(email, password, firm, phone=''):
    c = conn()
    try:
        c.execute("INSERT INTO users(email,password,firm,phone,plan,created) VALUES(?,?,?,?,?,?)",
                  (email.lower(), generate_password_hash(password), firm, phone, 'free', time.time()))
        c.commit()
        uid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
        return uid
    except sqlite3.IntegrityError:
        return None
    finally:
        c.close()


def verify_user(email, password):
    c = conn()
    r = c.execute("SELECT * FROM users WHERE email=?", (email.lower(),)).fetchone()
    c.close()
    if r and check_password_hash(r['password'], password):
        return dict(r)
    return None


def get_user(uid):
    c = conn()
    r = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    c.close()
    return dict(r) if r else None


def set_plan(uid, plan):
    c = conn()
    c.execute("UPDATE users SET plan=? WHERE id=?", (plan, uid))
    c.commit(); c.close()


def count_projects(uid):
    c = conn()
    n = c.execute("SELECT COUNT(*) FROM projects WHERE user_id=?", (uid,)).fetchone()[0]
    c.close(); return n


def save_project(uid, name, module, data, grand_total=0):
    c = conn()
    c.execute("INSERT INTO projects(user_id,name,module,data,grand_total,created) VALUES(?,?,?,?,?,?)",
              (uid, name, module, json.dumps(data), grand_total, time.time()))
    c.commit(); pid = c.execute("SELECT last_insert_rowid()").fetchone()[0]; c.close()
    return pid


def _ensure_project_col(c):
    """Idempotent: add the project column for older databases."""
    try:
        cols = [r['name'] for r in c.execute("PRAGMA table_info(exports)").fetchall()]
        if 'project' not in cols:
            c.execute("ALTER TABLE exports ADD COLUMN project TEXT DEFAULT ''")
            c.commit()
    except Exception:
        pass


def save_export(uid, module, data_json, project=''):
    """Persist the last calculation per user+module+project so the download works
    from ANY gunicorn worker AND different projects never mix."""
    c = conn()
    try:
        _ensure_project_col(c)
        c.execute("DELETE FROM exports WHERE user_id=? AND module=? AND project=?",
                  (uid, module, project))
        c.execute("INSERT INTO exports(user_id, module, data, created, project) VALUES(?,?,?,?,?)",
                  (uid, module, data_json, time.time(), project))
        c.commit()
    except Exception:
        pass
    finally:
        c.close()


def get_export(uid, module, project=''):
    c = conn()
    try:
        _ensure_project_col(c)
        r = c.execute("SELECT data FROM exports WHERE user_id=? AND module=? AND project=? "
                      "ORDER BY id DESC LIMIT 1", (uid, module, project)).fetchone()
        return r['data'] if r else None
    except Exception:
        return None
    finally:
        c.close()


def last_calc_project(uid, module):
    """Project of the most recent calculation of this module (across projects)."""
    c = conn()
    try:
        _ensure_project_col(c)
        r = c.execute("SELECT project FROM exports WHERE user_id=? AND module=? "
                      "ORDER BY id DESC LIMIT 1", (uid, module)).fetchone()
        return r['project'] if r else None
    except Exception:
        return None
    finally:
        c.close()


def delete_project_exports(uid, project):
    """Remove ALL saved results of one project."""
    c = conn()
    try:
        _ensure_project_col(c)
        c.execute("DELETE FROM exports WHERE user_id=? AND project=?", (uid, project))
        c.commit()
    except Exception:
        pass
    finally:
        c.close()


def list_export_projects(uid):
    """Distinct project names this user has calculated under."""
    c = conn()
    try:
        _ensure_project_col(c)
        rows = c.execute("SELECT DISTINCT project FROM exports WHERE user_id=? AND project != '' "
                         "ORDER BY project", (uid,)).fetchall()
        return [r['project'] for r in rows]
    except Exception:
        return []
    finally:
        c.close()


def list_projects(uid):
    c = conn()
    rows = c.execute("SELECT * FROM projects WHERE user_id=? ORDER BY created DESC", (uid,)).fetchall()
    c.close(); return [dict(r) for r in rows]


def get_project(pid, uid):
    c = conn()
    r = c.execute("SELECT * FROM projects WHERE id=? AND user_id=?", (pid, uid)).fetchone()
    c.close()
    return dict(r) if r else None


def delete_project(pid, uid):
    c = conn()
    c.execute("DELETE FROM projects WHERE id=? AND user_id=?", (pid, uid))
    c.commit(); c.close()
