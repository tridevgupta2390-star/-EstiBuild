"""Structural module form <-> HTML (detailed member schedule + BBS)."""
from modules.common import NUM

BEAM_KINDS = ['plinth beam', 'tie beam', 'primary', 'secondary', 'grade beam', 'lintel band']


def _CUR_RATES():
    import structural.engine as _se
    return _se.DEFAULT_SCHEDULE.get('rates', {})


def _CUR_LABOUR():
    import structural.engine as _se
    return _se.LABOUR


def _CUR_STEELFAB():
    import structural.engine as _se
    return _se.DEFAULT_SCHEDULE.get('labour_rates', {}).get('steel_fab', 1400)



def _collect_columns(gl, form):
    """Column rows with per-floor main bars: visible inputs are c_mainf_<floor>_<idx>;
    they are joined into the classic comma string ('8-16,8-16,6-16') that the engine,
    templates and saved projects already understand."""
    import html as _html
    out = []
    numset = {'count', 'b', 'd'}
    for idx in gl('c_row'):
        d = {}
        for k in ('id', 'count', 'b', 'd', 'main', 'tie', 'grade'):
            v = form.get(f'c_{k}_{idx}')
            if v is not None and str(v).strip() != '':
                d[k] = NUM(v) if k in numset else _html.unescape(v)
        if not str(d.get('main', '') or '').strip():
            fl = [str(form.get(f'c_mainf_{f}_{idx}') or '').strip() for f in range(15)]
            fl = [x for x in fl if x]
            if fl:
                d['main'] = ','.join(fl)
        if d:
            out.append(d)
    return out



def _collect_staircases(gl, form):
    """Multiple staircases: each row sc_row_{i} gives a full staircase spec."""
    import html as _html
    out = []
    numset = {'flights', 'run', 'width', 'waist', 'tread', 'riser', 'landings', 'landing_L', 'landing_W', 'landing_t'}
    for idx in gl('sc_row'):
        d = {}
        for k in ('id', 'type', 'flights', 'run', 'width', 'waist', 'mesh', 'tread', 'riser',
                   'landings', 'landing_L', 'landing_W', 'landing_t'):
            v = form.get(f'sc_{k}_{idx}')
            if v is not None and str(v).strip() != '':
                d[k] = NUM(v) if k in numset else _html.unescape(v)
        if d.get('flights'):
            out.append(d)
    # backwards compat: if no sc_row entries, check old single-field format
    if not out:
        old = {'flights': int(NUM(form.get('sc_flights', 2))), 'run': NUM(form.get('sc_run', 3600)),
               'width': NUM(form.get('sc_width', 1200)), 'waist': NUM(form.get('sc_waist', 150)),
               'mesh': form.get('sc_mesh', '10-150'), 'type': form.get('sc_type', 'dog-legged'),
               'tread': NUM(form.get('sc_tread', 300)), 'riser': NUM(form.get('sc_riser', 150)),
               'landings': int(NUM(form.get('sc_landings', 0))),
               'landing_L': NUM(form.get('sc_landing_L', 1200)), 'landing_W': NUM(form.get('sc_landing_W', 1200)),
               'landing_t': NUM(form.get('sc_landing_t', 150))}
        if old.get('flights'):
            out.append(old)
    return out


def parse_form(form):
    import html as _html
    gl = lambda k: form.getlist(k)

    def collect(marker, prefix, fields, numset):
        out = []
        for idx in gl(marker):
            def g(k):
                v = form.get(f'{prefix}_{k}_{idx}')
                return _html.unescape(v) if isinstance(v, str) else v
            d = {}
            for k in fields:
                v = g(k)
                if v is not None and str(v).strip() != '':
                    d[k] = NUM(v) if k in numset else v
            if d:
                out.append(d)
        return out

    sch = {
        'project_name': form.get('project_name', 'RCC Structural Estimate'),
        'location': form.get('location', 'Kathmandu'),
        'concrete_grade': form.get('concrete_grade', 'M25'), 'pcc_mix': form.get('pcc_mix', 'PCC 1:4:8'),
        'floor_height': NUM(form.get('floor_height', 3000)), 'floors_above': int(NUM(form.get('floors_above', 3))),
        'confinement_lo': NUM(form.get('confinement_lo', 450)),
        'cover_footing': NUM(form.get('cover_footing', 50)), 'cover_column': NUM(form.get('cover_column', 40)),
        'cover_beam': NUM(form.get('cover_beam', 25)), 'cover_slab': NUM(form.get('cover_slab', 20)),
        # fallbacks read the COUNTRY-CURRENT engine rates (apply_rates refreshes
        # them every request) so API/template-upload paths scale correctly too
        'rates': {k: NUM(form.get('rate_' + k, _CUR_RATES().get(k, dv))) for k, dv in {
            'rcc_m3': 16500, 'pcc_m3': 9500, 'excavation_m3': 450, 'backfill_m3': 400,
            'soling_m3': 3500, 'shuttering_m2': 850, 'steel_kg': 150}.items()},
        'labour_rates': {
            'mason': NUM(form.get('lr_mason', _CUR_LABOUR().get('rate_mason', 1200))),
            'mazdoor': NUM(form.get('lr_mazdoor', _CUR_LABOUR().get('rate_mazdoor', 800))),
            'steel_fab': NUM(form.get('lr_steel_fab', _CUR_STEELFAB()))},
        'footings': collect('f_row', 'f', ['id', 'kind', 'count', 'L', 'W', 't', 'depth', 'soling_t', 'mesh', 'ped_b', 'ped_d', 'ped_h', 'ped_main', 'ped_tie', 'strap_b', 'strap_d', 'strap_len', 'strap_top', 'strap_bot', 'strap_tie', 'pile_dia', 'pile_len', 'pile_main', 'spiral', 'cap_L', 'cap_W', 'cap_t', 'cap_mesh', 'pile_no', 'grade', 'soil'],
                          {'count', 'L', 'W', 't', 'depth', 'soling_t', 'ped_b', 'ped_d', 'ped_h', 'strap_b', 'strap_d', 'strap_len', 'pile_dia', 'pile_len', 'pile_no', 'cap_L', 'cap_W', 'cap_t'}),
        'columns': _collect_columns(gl, form),
        'beams': collect('b_row', 'b', ['id', 'kind', 'count', 'b', 'd', 'length', 'top', 'bottom', 'extra_top', 'side', 'tie', 'grade'], {'count', 'b', 'd', 'length'}),
        'slabs': collect('s_row', 's', ['id', 'area', 't', 'type', 'mesh', 'top_mesh', 'grade'], {'area', 't'}),
        'shearwalls': collect('w_row', 'w', ['id', 'length', 't', 'height', 'vertical', 'horizontal'], {'length', 't', 'height'}),
        'retwalls': collect('rw_row', 'rw', ['id', 'length', 'stem_t', 'stem_h', 'base_b', 'base_t', 'vert', 'horiz', 'base_mesh'], {'length', 'stem_t', 'stem_h', 'base_b', 'base_t'}),
        'tanks': collect('t_row', 't', ['id', 'kind', 'L', 'W', 'depth', 'wall_t', 'base_t', 'cover_t', 'wall_mesh', 'base_mesh', 'grade'],
                         {'L', 'W', 'depth', 'wall_t', 'base_t', 'cover_t'}),
        'ramps': collect('r_row', 'r', ['id', 'length', 'width', 'thickness', 'mesh', 'side_wall_h', 'side_wall_t', 'grade'],
                         {'length', 'width', 'thickness', 'side_wall_h', 'side_wall_t'}),
        'lifts': collect('l_row', 'l', ['id', 'L', 'W', 'pit_depth', 'core_height', 'wall_t', 'base_t', 'mesh', 'grade'],
                         {'L', 'W', 'pit_depth', 'core_height', 'wall_t', 'base_t'}),
        'others': collect('o_row', 'o', ['item', 'qty'], {'qty'}),
        'concrete_pumping': form.get('concrete_pumping', 'none'),
        'staircase': _collect_staircases(gl, form),
    }
    return sch


HTML = r"""
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>RCC Structure - EstiBuild</title>
<style>
:root{--nav:#1F3B57;--bg:#f4f7fa;--card:#fff;--line:#d7e0ea;--green:#1f9d55}
*{box-sizing:border-box}body{margin:0;font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:#223}
.top{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:13px 24px;display:flex;justify-content:space-between;align-items:center}
.top a{color:#cfe8ff;text-decoration:none;font-size:13px}
.wrap{max-width:1320px;margin:0 auto;padding:14px 16px 60px}
.grid2{display:grid;grid-template-columns:1.3fr 1fr;gap:14px;align-items:start}
@media(max-width:1040px){.grid2{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin-bottom:13px}
.card h2{margin:0 0 3px;font-size:16px;color:var(--nav)} .hint{color:#7a8693;font-size:12px;margin:0 0 10px}
label{display:block;font-size:10px;font-weight:600;color:#556;margin:4px 0 1px;text-transform:uppercase}
input,select{width:100%;padding:6px 7px;border:1px solid var(--line);border-radius:6px;font-size:12px}
.sec{font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:var(--nav);font-weight:800;margin:0 0 8px;padding-bottom:5px;border-bottom:2px solid var(--line)}
.flrow{display:flex;flex-wrap:wrap;gap:6px;margin-top:2px}
.fcell label{font-size:10px;color:#567;margin-bottom:1px;display:block;text-align:center}
.fcell input{width:80px;padding:5px 6px;border:1px solid #cdd8e2;border-radius:5px}
.mainfloors{margin-top:6px}
.fbtn{height:34px;padding:0 12px;border:none;border-radius:7px;background:#1f9d55;color:#fff;font-weight:800;font-size:13px;cursor:pointer;margin-top:10px;box-shadow:0 2px 6px rgba(31,157,85,.35)}
.fbtn.minus{background:#6c757d;width:36px;padding:0;box-shadow:none}
.row{display:grid;gap:7px}.r2{grid-template-columns:1fr 1fr}.r3{grid-template-columns:1fr 1fr 1fr}
.r4{grid-template-columns:repeat(4,1fr)}.r5{grid-template-columns:repeat(5,1fr)}.r6{grid-template-columns:repeat(6,1fr)}
.mem{border:1px solid #e6edf4;border-left:4px solid var(--nav);border-radius:8px;padding:9px 11px;margin-bottom:7px;background:#fcfdff;position:relative}
.del{position:absolute;top:7px;right:9px;background:#c0392b;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}
.add{background:var(--nav);color:#fff;border:none;padding:7px 14px;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;margin-top:3px}
.btn{background:var(--green);color:#fff;border:none;padding:13px 26px;border-radius:9px;font-size:15px;font-weight:700;cursor:pointer;width:100%;margin-top:10px}
.kpi{display:flex;gap:8px;flex-wrap:wrap}.kpi div{flex:1;min-width:100px;background:#eef4f9;border:1px solid var(--line);border-radius:9px;padding:9px;text-align:center}
.kpi .v{font-size:17px;font-weight:800;color:var(--nav)}.kpi .l{font-size:10px;color:#7a8693}
table{width:100%;border-collapse:collapse;font-size:11.5px;margin-top:4px}
th{background:var(--nav);color:#fff;padding:6px;text-align:left}td{padding:4px 6px;border-bottom:1px solid var(--line)}
.num{text-align:right}.ctr{text-align:center}.tot{background:#fff3cf;font-weight:800;text-align:right;padding:9px;border-radius:6px;margin-top:8px}
.pill{display:inline-block;background:var(--green);color:#fff;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;text-decoration:none}
.upload{border:2px dashed var(--nav);border-radius:10px;padding:13px;text-align:center;background:#f7fafd;margin-bottom:6px}
.guide{background:#f1f6fb;border:1px solid #cfe0ef;border-left:4px solid var(--nav);border-radius:8px;padding:10px 12px;margin:8px 0;font-size:11.5px}
.guide b{color:var(--nav)}.guide ul{margin:5px 0 5px 16px;padding:0;line-height:1.6}.guide i{color:#7a8693}
.bar{height:13px;border-radius:4px;background:linear-gradient(90deg,#1F3B57,#3a7ca5)}
.det{color:#5b7a99;font-size:10.5px}
</style></head><body>

<datalist id="dl_main"><option value="2-10"><option value="3-10"><option value="2-12"><option value="3-12"><option value="4-12"><option value="6-12"><option value="8-12"><option value="2-16"><option value="3-16"><option value="4-16"><option value="6-16"><option value="8-16"><option value="10-16"><option value="12-16"><option value="16-16"><option value="20-16"><option value="4-20"><option value="6-20"><option value="8-20"><option value="4-25"><option value="6-25"></datalist>
<datalist id="dl_tie"><option value="6-150"><option value="8-100"><option value="8-100-150"><option value="8-100-200"><option value="8-125-150"><option value="8-150"><option value="8-200"><option value="10-100-150"><option value="10-100-200"></datalist>
<datalist id="dl_mesh"><option value="8-200"><option value="10-200"><option value="10-150"><option value="12-200"><option value="12-150"><option value="12-100"><option value="16-150"><option value="16-100"><option value="16-200"></datalist>
<datalist id="dl_ped"><option value="4-12"><option value="6-12"><option value="8-12"><option value="4-16"><option value="6-16"><option value="8-16"><option value="4-20"><option value="6-20"><option value="8-20"></datalist>
<datalist id="dl_stirrup"><option value="6-150"><option value="8-100"><option value="8-100-150"><option value="8-100-200"><option value="8-125-150"><option value="8-150"><option value="10-100-150"></datalist>

<div class="top"><div><b>🏗️ RCC Structure Estimation</b> <span style="opacity:.8;font-size:12px">· {{SHORT}}</span></div><div><a href="{{url_for('landing')}}">◀ Home</a></div></div>
<div class="wrap"><div class="grid2"><div>
<div class="card"><div class="sec">Upload Structural PDF / Drawings</div>
<div class="guide"><b>📄 For best auto-fill, include these in your PDF:</b>
<ul>
<li>Foundation layout + footing schedule (F1, F2 sizes &amp; steel mesh)</li>
<li>Column schedule (C1, C2 sizes + main bars per floor — e.g. "8-16,8-16,6-16" or one row per floor: GF / F1 / F2...)</li>
<li>Beam schedule (sizes + top/bottom bars + EXTRA TOP @ supports + side bars for deep beams + stirrups)</li>
<li>Slab reinforcement layout (thickness + bottom mesh + TOP mesh for double-mesh / cantilever / sunken slabs)</li>
<li>✅ BBS (Bar Bending Schedule) is AUTO-GENERATED — no need to upload! System computes every bar, cutting length &amp; weight from your inputs</li>
<li>Structural design basis - concrete grade, steel grade, floor heights, seismic zone + Shear wall detail + Retaining wall section + Staircase detail + Soil report</li>
<li>Water tank / sump sizes, ramp lengths &amp; widths, lift pit dimensions - full water-retaining &amp; misc scope supported</li>
</ul>
<i>Typed schedule tables &amp; BBS auto-extract best. Drawings help confirm sizes manually.</i></div>
<form method="post" action="{{url_for('structural_upload')}}" enctype="multipart/form-data">
<details style="margin-bottom:8px;background:#eef6f0;border:1px solid #b7dfc3;border-radius:8px;padding:8px 10px">
<summary style="font-size:12px;font-weight:700;color:#1f9d55;cursor:pointer">📋 What to include for BEST auto-fill (click to see exactly what we read)</summary>
<div style="font-size:11px;color:#445;margin-top:8px;line-height:1.7">
<b>Best (100% exact, free):</b> typed schedule tables in any PDF — one table per PDF is fine, all combined:
<table style="font-size:10.5px;margin-top:4px">
<tr><th style="padding:4px 6px">Schedule table</th><th style="padding:4px 6px">Columns we look for</th></tr>
<tr style="background:#f7faf8"><td style="padding:3px 6px;font-weight:600">Footing Schedule</td><td style="padding:3px 6px;color:#567">Mark · Type · Nos · L (mm) · W (mm) · t (mm) · Depth · Mesh · Grade</td></tr>
<tr><td style="padding:3px 6px;font-weight:600">Column Schedule</td><td style="padding:3px 6px;color:#567">Mark · Nos · b (mm) · d (mm) · Main bars PER FLOOR (8-16,8-16,6-16) · Tie · Grade</td></tr>
<tr style="background:#f7faf8"><td style="padding:3px 6px;font-weight:600">Beam Schedule</td><td style="padding:3px 6px;color:#567">Mark · Type · Nos · b · d · Length · Top · Bottom · Extra top @supports · Side bars · Stirrup · Grade</td></tr>
<tr><td style="padding:3px 6px;font-weight:600">Slab Schedule</td><td style="padding:3px 6px;color:#567">Mark · Area (m²) · t (mm) · Bottom mesh · Top mesh (double mesh) · Grade</td></tr>
</table>
<div style="margin-top:6px">✅ <b>BBS is always auto-generated</b> from whatever you fill — no bar schedule upload needed.<br>
<b>Fallback (Rs 0.15/page):</b> any drawing via AI → editable draft</div>
</div>
</details>
<div class="upload"><input type="file" name="pdfs" accept="application/pdf,.json,.xlsx,.html" multiple>
<div style="margin-top:5px;font-size:11px;color:#7a8693">Upload one or many files: <b>footing schedule PDF + column schedule PDF + beam PDF...</b> separately — all combined! Or your filled <b>template .json/.xlsx/.html</b>. BBS is auto-generated.</div>
<div style="margin-top:7px;font-size:11.5px">
<a href="{{url_for('download_template', sid='structural', fmt='html')}}" target="_blank" rel="noopener" style="color:#1f9d55;font-weight:700">⬇ Fillable template (HTML)</a> &nbsp;·&nbsp;
<a href="{{url_for('download_template', sid='structural', fmt='xlsx')}}" target="_blank" rel="noopener" style="color:#1f9d55;font-weight:700">Excel template</a>
</div>
<div id="morepdfs"></div>
<div style="margin-top:8px"><button class="add" type="submit">⬆ Read PDF(s) &amp; auto-fill</button>
{%if ai_enabled()%}<button type="submit" formaction="{{url_for('structural_ai_template')}}" class="add" style="background:#8e44ad;margin-top:4px;width:100%">🤖 AI reads ALL your PDFs → editable draft (HTML)</button>{%else%}<div style="background:#f0e6f6;border:1px dashed #8e44ad;border-radius:7px;padding:8px;margin-top:4px;text-align:center;font-size:11px;color:#8e44ad"><b>🤖 AI Drawing Reader</b> — appears when OPENAI_API_KEY is set. Upload all PDFs; AI merges into <b>one editable HTML draft</b> — review &amp; correct offline, then upload it back. ~Rs 0.15/drawing.</div>{%endif%}
</div></div></form>
<a href="{{url_for('structural')}}" class="add" style="background:#e74c3c;margin-top:6px;display:inline-block;text-decoration:none">🔄 Reset form (clear all auto-fill)</a>
<button type="button" class="add" style="background:#6c757d;margin-top:6px" onclick="addPdf()">+ Add another PDF slot</button>
{%if notes%}<div style="background:#fff8e1;border:1px solid #f0d479;border-radius:8px;padding:9px;font-size:12px;margin:8px 0"><b>PDF result:</b><ul style="margin:4px 0 0 16px;padding:0">{%for n in notes%}<li>{{n}}</li>{%endfor%}</ul></div>{%endif%}
</div>
<form method="post" action="{{url_for('structural')}}">
<div class="card"><div class="sec">Project & Design Parameters</div>
<div class="row r2"><div><label>📁 Project name — same name for all modules of one building</label><input name="project_name" value="{{s.project_name if s.project_name and s.project_name not in ('RCC Structural Estimate', 'Detailed RCC Structural Estimate') else last_proj()}}" style="font-weight:700"></div>
<div><label>Location</label><input name="location" value="{{s.location}}"></div></div>
<div class="row r5">
<div><label>Concrete grade</label><select name="concrete_grade">{%set cg=s.concrete_grade%}{%for x in ['M20','M25','M30','M35','M40','M15']%}<option {{'selected' if x==cg}}>{{x}}</option>{%endfor%}</select></div>
<div><label>Concrete pumping</label><select name="concrete_pumping">{%set cp=s.get('concrete_pumping','none')%}{%for x in ['none','boom pump','line pump']%}<option {{'selected' if x==cp}}>{{x}}</option>{%endfor%}</select></div>
<div><label>Floor height (mm)</label><input name="floor_height" value="{{s.floor_height}}"></div>
<div><label>Floors above gr.</label><input name="floors_above" value="{{s.floors_above}}"></div>
<div><label>Confine zone lo (mm)</label><input name="confinement_lo" value="{{s.confinement_lo}}"></div></div>
<div class="row r4">
<div><label>Cover footing</label><input name="cover_footing" value="{{s.cover_footing}}"></div>
<div><label>Cover column</label><input name="cover_column" value="{{s.cover_column}}"></div>
<div><label>Cover beam</label><input name="cover_beam" value="{{s.cover_beam}}"></div>
<div><label>Cover slab</label><input name="cover_slab" value="{{s.cover_slab}}"></div></div></div>

<div class="card" style="border-left:4px solid #b8860b"><div class="sec">⚙ Unit Rates — editable (drive the whole BOQ)</div>
<p class="hint">Change any rate to your own market rate — all amounts recalculate. Composite rates (material + labour included).</p>
{%set r=s.rates%}
<div class="row r4">
<div><label>RCC /m³</label><input name="rate_rcc_m3" value="{{r.rcc_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>PCC /m³</label><input name="rate_pcc_m3" value="{{r.pcc_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Excavation /m³</label><input name="rate_excavation_m3" value="{{r.excavation_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Backfill /m³</label><input name="rate_backfill_m3" value="{{r.backfill_m3}}" style="background:#fffdf3;border-color:#f0d479"></div></div>
<div class="row r4" style="margin-top:8px">
<div><label>Soling /m³</label><input name="rate_soling_m3" value="{{r.soling_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Shuttering /m²</label><input name="rate_shuttering_m2" value="{{r.shuttering_m2}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Steel /kg</label><input name="rate_steel_kg" value="{{r.steel_kg}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div></div></div>

<div class="sec" style="margin-top:12px">👷 Labour Rates — per day (editable)</div>
<p class="hint">Your own daily wages. Used only in the labour planning sheet — labour is already inside the composite BOQ rates above.</p>
{%set lrv=s.get('labour_rates') or {'mason':1200,'mazdoor':800,'steel_fab':1400}%}
<div class="row r3">
<div><label>Mason /day</label><input name="lr_mason" value="{{lrv.get('mason',1200)}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Mazdoor /day</label><input name="lr_mazdoor" value="{{lrv.get('mazdoor',800)}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Steel fabricator /day</label><input name="lr_steel_fab" value="{{lrv.get('steel_fab',1400)}}" style="background:#fffdf3;border-color:#f0d479"></div></div></div>

<div class="card"><div class="sec">A · Footings / Piles</div>
<p class="hint">One row per footing TYPE. Steel: mesh "dia-spacing", pedestal "no-dia", tie "dia-confined-mid".</p>
<div id="footings">{%for f in s.footings%}
<div class="mem"><input type="hidden" name="f_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="f_id_{{loop.index0}}" value="{{f.id}}"></div>
<div><label>Type</label><select name="f_kind_{{loop.index0}}">{%set k=f.kind%}{%for t in ['isolated','strap','combined','raft','pile','strip']%}<option {{'selected' if t==k}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Count</label><input name="f_count_{{loop.index0}}" value="{{f.count}}"></div>
<div><label>L (mm)</label><input name="f_L_{{loop.index0}}" value="{{f.get('L','')}}"></div>
<div><label>W (mm)</label><input name="f_W_{{loop.index0}}" value="{{f.get('W','')}}"></div></div>
<div class="row r6">
<div><label>t (mm)</label><input name="f_t_{{loop.index0}}" value="{{f.get('t','')}}"></div>
<div><label>Depth GL</label><input name="f_depth_{{loop.index0}}" value="{{f.get('depth','')}}"></div>
<div><label>Soling t</label><input name="f_soling_t_{{loop.index0}}" value="{{f.get('soling_t','')}}"></div>
<div><label>Mesh</label><input name="f_mesh_{{loop.index0}}" list="dl_mesh" value="{{f.get('mesh','')}}"></div>
<div><label>Ped b</label><input name="f_ped_b_{{loop.index0}}" value="{{f.get('ped_b','')}}"></div>
<div><label>Ped d</label><input name="f_ped_d_{{loop.index0}}" value="{{f.get('ped_d','')}}"></div></div>
<div class="row r6">
<div><label>Ped h</label><input name="f_ped_h_{{loop.index0}}" value="{{f.get('ped_h','')}}"></div>
<div><label>Ped main</label><input name="f_ped_main_{{loop.index0}}" list="dl_ped" value="{{f.get('ped_main','')}}"></div>
<div><label>Ped tie</label><input name="f_ped_tie_{{loop.index0}}" list="dl_stirrup" value="{{f.get('ped_tie','')}}"></div>
<div><label>Strap len</label><input name="f_strap_len_{{loop.index0}}" value="{{f.get('strap_len','')}}"></div>
<div><label>Strap b</label><input name="f_strap_b_{{loop.index0}}" value="{{f.get('strap_b','')}}"></div>
<div><label>Strap d</label><input name="f_strap_d_{{loop.index0}}" value="{{f.get('strap_d','')}}"></div></div>
<div class="row r6">
<div><label>Strap top</label><input name="f_strap_top_{{loop.index0}}" list="dl_main" value="{{f.get('strap_top','')}}"></div>
<div><label>Strap bot</label><input name="f_strap_bot_{{loop.index0}}" list="dl_main" value="{{f.get('strap_bot','')}}"></div>
<div><label>Strap tie</label><input name="f_strap_tie_{{loop.index0}}" list="dl_stirrup" value="{{f.get('strap_tie','')}}"></div>
<div><label>Pile dia</label><input name="f_pile_dia_{{loop.index0}}" value="{{f.get('pile_dia','')}}"></div>
<div><label>Pile len</label><input name="f_pile_len_{{loop.index0}}" value="{{f.get('pile_len','')}}"></div>
<div><label>Pile no</label><input name="f_pile_no_{{loop.index0}}" value="{{f.get('pile_no','')}}"></div></div>
<div class="row r6">
<div><label>Pile main</label><input name="f_pile_main_{{loop.index0}}" list="dl_ped" value="{{f.get('pile_main','')}}"></div>
<div><label>Spiral</label><input name="f_spiral_{{loop.index0}}" list="dl_mesh" value="{{f.get('spiral','')}}"></div>
<div><label>Cap L</label><input name="f_cap_L_{{loop.index0}}" value="{{f.get('cap_L','')}}"></div>
<div><label>Cap W</label><input name="f_cap_W_{{loop.index0}}" value="{{f.get('cap_W','')}}"></div>
<div><label>Cap t</label><input name="f_cap_t_{{loop.index0}}" value="{{f.get('cap_t','')}}"></div>
<div><label>Cap mesh</label><input name="f_cap_mesh_{{loop.index0}}" list="dl_mesh" value="{{f.get('cap_mesh','')}}"></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addF()">+ Add footing type</button>
<button type="button" class="add" onclick="dupRows('f')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">B · Columns <span style="font-size:10px;color:#7a8693">steel varies per floor + ductile ties</span></div>
<div id="columns">{%for c in s.columns%}
<div class="mem"><input type="hidden" name="c_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="c_id_{{loop.index0}}" value="{{c.id}}"></div>
<div><label>Count</label><input name="c_count_{{loop.index0}}" value="{{c.count}}"></div>
<div><label>b (mm)</label><input name="c_b_{{loop.index0}}" value="{{c.b}}"></div>
<div><label>d (mm)</label><input name="c_d_{{loop.index0}}" value="{{c.d}}"></div>
<div><label>Tie</label><input name="c_tie_{{loop.index0}}" list="dl_tie" value="{{c.tie}}"></div>
<div><label>Grade</label><select name="c_grade_{{loop.index0}}">{%set cg=c.get('grade','M25')%}{%for x in ['M15','M20','M25','M30','M35','M40']%}<option {{'selected' if x==cg}}>{{x}}</option>{%endfor%}</select></div></div>
{%set ridx = loop.index0%}<div class="mainfloors" data-idx="{{ridx}}"><label>Main bars per floor (GF first) — leave a floor empty to repeat the one before it</label>
<div class="flrow">{%set mparts=(c.main or '').split(',')%}{%for f in range(15)%}<div class="fcell" style="{{'' if f < s.floors_above else 'display:none'}}"><label>{{'GF' if f==0 else 'F' ~ f}}</label><input name="c_mainf_{{f}}_{{ridx}}" list="dl_main" value="{{mparts[f] if f < mparts|length else ''}}" oninput="syncMain({{ridx}})"></div>{%endfor%}<div class="fcell"><label>&nbsp;</label><button type="button" class="fbtn" onclick="addFloor()" title="Add one more floor (updates 'Floors above gr.' for the whole building)">+ floor</button><button type="button" class="fbtn minus" onclick="delFloor()" title="Remove top floor">−</button></div></div>
<input type="hidden" name="c_main_{{ridx}}" value="{{c.main}}"></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addC()">+ Add column type</button>
<button type="button" class="add" onclick="dupRows('c')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">C · Beams (Primary + Secondary)</div>
<div id="beams">{%for b in s.beams%}
<div class="mem"><input type="hidden" name="b_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="b_id_{{loop.index0}}" value="{{b.id}}"></div>
<div><label>Type</label><select name="b_kind_{{loop.index0}}">{%set k=b.kind%}{%for t in BEAM_KINDS%}<option {{'selected' if t==k}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Count</label><input name="b_count_{{loop.index0}}" value="{{b.count}}"></div>
<div><label>b</label><input name="b_b_{{loop.index0}}" value="{{b.b}}"></div>
<div><label>d</label><input name="b_d_{{loop.index0}}" value="{{b.d}}"></div>
<div><label>Length</label><input name="b_length_{{loop.index0}}" value="{{b.length}}"></div></div>
<div class="row r5">
<div><label>Top</label><input name="b_top_{{loop.index0}}" list="dl_main" value="{{b.top}}"></div>
<div><label>Bottom</label><input name="b_bottom_{{loop.index0}}" list="dl_main" value="{{b.bottom}}"></div>
<div><label>Extra top @supports</label><input name="b_extra_top_{{loop.index0}}" list="dl_main" value="{{b.get('extra_top','')}}" placeholder="e.g. 1-16"></div>
<div><label>Side bars (deep>750mm)</label><input name="b_side_{{loop.index0}}" list="dl_main" value="{{b.get('side','')}}" placeholder="e.g. 2-12"></div>
<div><label>Stirrup</label><input name="b_tie_{{loop.index0}}" list="dl_stirrup" value="{{b.tie}}"></div>
<div><label>Grade</label><select name="b_grade_{{loop.index0}}">{%set bg=b.get('grade','M25')%}{%for x in ['M15','M20','M25','M30','M35','M40']%}<option {{'selected' if x==bg}}>{{x}}</option>{%endfor%}</select></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addB()">+ Add beam type</button>
<button type="button" class="add" onclick="dupRows('b')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">D · Slabs</div>
<div id="slabs">{%for x in s.slabs%}
<div class="mem"><input type="hidden" name="s_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="s_id_{{loop.index0}}" value="{{x.id}}"></div>
<div><label>Type</label><select name="s_type_{{loop.index0}}">{%set st=x.get('type','two-way slab')%}{%for t in ['one-way slab','two-way slab','sunken slab (toilet)','flat slab','waffle (ribbed)']%}<option {{'selected' if t==st}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Area m²</label><input name="s_area_{{loop.index0}}" value="{{x.area}}"></div>
<div><label>t (mm)</label><input name="s_t_{{loop.index0}}" value="{{x.t}}"></div>
<div><label>Bottom mesh</label><input name="s_mesh_{{loop.index0}}" list="dl_mesh" value="{{x.mesh}}"></div>
<div><label>Top mesh (opt)</label><input name="s_top_mesh_{{loop.index0}}" list="dl_mesh" value="{{x.get('top_mesh','')}}" placeholder="blank=1 layer"></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addS()">+ Add slab</button>
<button type="button" class="add" onclick="dupRows('s')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">E · Shear Walls</div>
<div id="walls" style="margin-top:8px">{%for w in s.shearwalls%}
<div class="mem"><input type="hidden" name="w_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="w_id_{{loop.index0}}" value="{{w.id}}"></div>
<div><label>Length</label><input name="w_length_{{loop.index0}}" value="{{w.length}}"></div>
<div><label>t</label><input name="w_t_{{loop.index0}}" value="{{w.t}}"></div>
<div><label>Height</label><input name="w_height_{{loop.index0}}" value="{{w.height}}"></div>
<div><label>Vert</label><input name="w_vertical_{{loop.index0}}" list="dl_mesh" value="{{w.vertical}}"></div></div>
<div class="row r2"><div><label>Horiz</label><input name="w_horizontal_{{loop.index0}}" list="dl_mesh" value="{{w.horizontal}}"></div><div></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addW()">+ Add shear wall</button>
<button type="button" class="add" onclick="dupRows('w')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card" style="border-left:4px solid #1f9d55"><div class="sec">F · Retaining / Trench Walls</div>
<p class="hint">Full auto-compute per wall: excavation, <b>100mm PCC bed</b> under base, stem + base RCC, shuttering both faces, steel (vertical + horizontal + base mesh) and backfill. Enter stem/base geometry + steel spacing.</p>
<div id="retwalls" style="margin-top:8px">{%for r in s.retwalls%}
<div class="mem"><input type="hidden" name="rw_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="rw_id_{{loop.index0}}" value="{{r.id}}"></div>
<div><label>Length</label><input name="rw_length_{{loop.index0}}" value="{{r.length}}"></div>
<div><label>Stem t</label><input name="rw_stem_t_{{loop.index0}}" value="{{r.stem_t}}"></div>
<div><label>Stem h</label><input name="rw_stem_h_{{loop.index0}}" value="{{r.stem_h}}"></div>
<div><label>Base b</label><input name="rw_base_b_{{loop.index0}}" value="{{r.base_b}}"></div></div>
<div class="row r5">
<div><label>Base t</label><input name="rw_base_t_{{loop.index0}}" value="{{r.base_t}}"></div>
<div><label>Vert</label><input name="rw_vert_{{loop.index0}}" list="dl_mesh" value="{{r.vert}}"></div>
<div><label>Horiz</label><input name="rw_horiz_{{loop.index0}}" list="dl_mesh" value="{{r.horiz}}"></div>
<div><label>Base mesh</label><input name="rw_base_mesh_{{loop.index0}}" list="dl_mesh" value="{{r.base_mesh}}"></div><div></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addRW()">+ Add retaining/trench wall</button>
<button type="button" class="add" onclick="dupRows('rw')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">G · Staircases (multiple OK — steps + landings auto-computed)</div>
<p class="hint">Add one row per staircase. A building can have a main stair + emergency exit + service spiral — each with its own dimensions.</p>
<div id="staircases">{% for sc in s.staircase %}
<div class="mem"><input type="hidden" name="sc_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="sc_id_{{loop.index0}}" value="{{sc.get('id','ST' ~ loop.index)}}"></div>
<div><label>Type</label><select name="sc_type_{{loop.index0}}">{%set tt=sc.get('type','dog-legged')%}{%for t in ['dog-legged','open-well','straight flight','spiral','cantilever']%}<option {{'selected' if t==tt}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Flights</label><input name="sc_flights_{{loop.index0}}" value="{{sc.flights}}"></div>
<div><label>Run (mm)</label><input name="sc_run_{{loop.index0}}" value="{{sc.run}}"></div>
<div><label>Tread (mm)</label><input name="sc_tread_{{loop.index0}}" value="{{sc.get('tread',300)}}"></div>
<div><label>Riser (mm)</label><input name="sc_riser_{{loop.index0}}" value="{{sc.get('riser',150)}}"></div></div>
<div class="row r6" style="margin-top:8px">
<div><label>Width (mm)</label><input name="sc_width_{{loop.index0}}" value="{{sc.width}}"></div>
<div><label>Waist (mm)</label><input name="sc_waist_{{loop.index0}}" value="{{sc.waist}}"></div>
<div><label>Mesh</label><input name="sc_mesh_{{loop.index0}}" list="dl_mesh" value="{{sc.mesh}}"></div>
<div><label>Landings (nos)</label><input name="sc_landings_{{loop.index0}}" value="{{sc.get('landings',0)}}"></div>
<div><label>Landing L (mm)</label><input name="sc_landing_L_{{loop.index0}}" value="{{sc.get('landing_L',1200)}}"></div>
<div><label>Landing W (mm)</label><input name="sc_landing_W_{{loop.index0}}" value="{{sc.get('landing_W',1200)}}"></div></div></div>
{% endfor %}</div>
<button type="button" class="add" onclick="addSC()">+ Add staircase</button>
<button type="button" class="add" onclick="dupRows('sc')" style="background:#8e44ad">⧉ Duplicate rows</button>
<p class="hint" style="margin-top:8px">Steps (½×tread×riser×width) and landing slabs auto-add to concrete/steel. Unit &amp; labour rates editable in the ⚙ gold card at top.</p></div>

<div class="card" style="border-left:4px solid #2980b9"><div class="sec">H · Water Tanks &amp; Sumps (IS 3370 water-retaining)</div>
<p class="hint">Overhead tanks &amp; underground sumps: walls + base + cover slab, mesh both faces, full BBS. Sumps auto-add excavation + PCC + backfill.</p>
<div id="tanks">{%for t in s.tanks%}
<div class="mem"><input type="hidden" name="t_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="t_id_{{loop.index0}}" value="{{t.id}}"></div>
<div><label>Type</label><select name="t_kind_{{loop.index0}}">{%set tk=t.kind%}{%for k in ['overhead tank','underground sump']%}<option {{'selected' if k==tk}}>{{k}}</option>{%endfor%}</select></div>
<div><label>L int (mm)</label><input name="t_L_{{loop.index0}}" value="{{t.L}}"></div>
<div><label>W int (mm)</label><input name="t_W_{{loop.index0}}" value="{{t.W}}"></div>
<div><label>Depth (mm)</label><input name="t_depth_{{loop.index0}}" value="{{t.depth}}"></div></div>
<div class="row r6" style="margin-top:8px">
<div><label>Wall t</label><input name="t_wall_t_{{loop.index0}}" value="{{t.wall_t}}"></div>
<div><label>Base t</label><input name="t_base_t_{{loop.index0}}" value="{{t.base_t}}"></div>
<div><label>Cover t</label><input name="t_cover_t_{{loop.index0}}" value="{{t.cover_t}}"></div>
<div><label>Wall mesh</label><input name="t_wall_mesh_{{loop.index0}}" list="dl_mesh" value="{{t.wall_mesh}}"></div>
<div><label>Base mesh</label><input name="t_base_mesh_{{loop.index0}}" list="dl_mesh" value="{{t.base_mesh}}"></div>
<div><label>Grade</label><select name="t_grade_{{loop.index0}}">{%set tg=t.get('grade','M25')%}{%for x in ['M20','M25','M30','M35']%}<option {{'selected' if x==tg}}>{{x}}</option>{%endfor%}</select></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addT()">+ Add tank / sump</button>
<button type="button" class="add" onclick="dupRows('t')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">I · Ramps</div>
<p class="hint">Inclined slab + optional side walls — steps-free access &amp; parking ramps.</p>
<div id="ramps">{%for r in s.ramps%}
<div class="mem"><input type="hidden" name="r_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="r_id_{{loop.index0}}" value="{{r.id}}"></div>
<div><label>Length incl. (mm)</label><input name="r_length_{{loop.index0}}" value="{{r.length}}"></div>
<div><label>Width (mm)</label><input name="r_width_{{loop.index0}}" value="{{r.width}}"></div>
<div><label>Thickness (mm)</label><input name="r_thickness_{{loop.index0}}" value="{{r.thickness}}"></div>
<div><label>Mesh</label><input name="r_mesh_{{loop.index0}}" list="dl_mesh" value="{{r.mesh}}"></div>
<div><label>Grade</label><select name="r_grade_{{loop.index0}}">{%set rg=r.get('grade','M25')%}{%for x in ['M20','M25','M30']%}<option {{'selected' if x==rg}}>{{x}}</option>{%endfor%}</select></div></div>
<div class="row r2" style="margin-top:8px">
<div><label>Side wall h (mm, 0=none)</label><input name="r_side_wall_h_{{loop.index0}}" value="{{r.get('side_wall_h',0)}}"></div>
<div><label>Side wall t (mm)</label><input name="r_side_wall_t_{{loop.index0}}" value="{{r.get('side_wall_t',150)}}"></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addR()">+ Add ramp</button>
<button type="button" class="add" onclick="dupRows('r')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">J · Lift Pits &amp; Machine Rooms</div>
<p class="hint">Lift core: water-tight pit + shaft walls + machine-room slab. Excavation, PCC &amp; backfill auto.</p>
<div id="lifts">{%for l in s.lifts%}
<div class="mem"><input type="hidden" name="l_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="l_id_{{loop.index0}}" value="{{l.id}}"></div>
<div><label>Plan L (mm)</label><input name="l_L_{{loop.index0}}" value="{{l.L}}"></div>
<div><label>Plan W (mm)</label><input name="l_W_{{loop.index0}}" value="{{l.W}}"></div>
<div><label>Pit depth (mm)</label><input name="l_pit_depth_{{loop.index0}}" value="{{l.pit_depth}}"></div>
<div><label>Core height (mm)</label><input name="l_core_height_{{loop.index0}}" value="{{l.core_height}}"></div></div>
<div class="row r4" style="margin-top:8px">
<div><label>Wall t</label><input name="l_wall_t_{{loop.index0}}" value="{{l.wall_t}}"></div>
<div><label>Base t</label><input name="l_base_t_{{loop.index0}}" value="{{l.base_t}}"></div>
<div><label>Mesh</label><input name="l_mesh_{{loop.index0}}" list="dl_mesh" value="{{l.mesh}}"></div>
<div><label>Grade</label><select name="l_grade_{{loop.index0}}">{%set lg=l.get('grade','M30')%}{%for x in ['M25','M30','M35','M40']%}<option {{'selected' if x==lg}}>{{x}}</option>{%endfor%}</select></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addL()">+ Add lift core</button>
<button type="button" class="add" onclick="dupRows('l')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">K · Water Retaining &amp; Misc Items</div>
<p class="hint">Waterproofing, joints, water stops, dewatering, curing. Weep holes auto-added for retaining walls.</p>
<div id="others">{%for o in s.others%}
<div class="mem"><input type="hidden" name="o_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r2">
<div><label>Item</label><select name="o_item_{{loop.index0}}">{%set oi=o.item%}{%for k in ['cement-based waterproofing (sunken slab/toilet)','bitumen coat 2 coats (retaining wall backface)','expansion joint filler + sealant','PVC water stop 230mm (construction joints)','dewatering from foundations','curing compound (or ponding)']%}<option {{'selected' if k==oi}}>{{k}}</option>{%endfor%}</select></div>
<div><label>Qty (sqm/rmt/cum)</label><input name="o_qty_{{loop.index0}}" value="{{o.qty}}"></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addO()">+ Add misc item</button>
<button type="button" class="add" onclick="dupRows('o')" style="background:#8e44ad">⧉ Duplicate rows</button></div>
<div style="display:flex;gap:8px;margin-top:10px">
<button class="btn" name="action" value="calc" style="flex:2;width:auto">⚙ Calculate</button>
<button class="btn" name="action" value="save" style="flex:1;width:auto;background:#2E86ab">💾 Save</button>
</div>
</form></div>

<div>
{%if result%}
<div class="card"><div class="kpi">
<div><div class="v">{{"{:,.0f}".format(result.grand_total)}}</div><div class="l">Total {{ current_country().currency }}</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.concrete_m3)}}</div><div class="l">Concrete m³</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.steel_kg)}}</div><div class="l">Steel kg</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.steel_kg/(result.totals.concrete_m3 or 1))}}</div><div class="l">kg/m³</div></div></div>
<div class="kpi" style="margin-top:8px">
<div><div class="v">{{"{:,.1f}".format(result.materials.cement_bags)}}</div><div class="l">Cement bags</div></div>
<div><div class="v">{{"{:,.1f}".format(result.materials.sand_m3)}}</div><div class="l">Sand m³</div></div>
<div><div class="v">{{"{:,.1f}".format(result.materials.aggregate_m3)}}</div><div class="l">Agg m³</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.excavation_m3)}}</div><div class="l">Excav m³</div></div></div>
<div style="text-align:right;margin-top:8px"><a class="pill" href="{{url_for('structural_export')}}" target="_blank" rel="noopener">⬇ Download Excel</a>
<a class="pill" href="{{url_for('structural_export_pdf')}}" target="_blank" rel="noopener" style="background:#c0392b">⬇ Download PDF</a>
{%if result.saved_ok%}<div style="font-size:12px;color:#1f9d55;margin-top:7px">💾 Saved as "{{result.saved_ok}}" — <a href="{{url_for('dashboard')}}">Dashboard</a></div>{%endif%}
{%if result.save_error%}<div style="font-size:12px;color:#c0392b;margin-top:7px">{{result.save_error}} — <a href="{{url_for('dashboard')}}">Upgrade</a></div>{%endif%}
{%if result.saved_file%}<div style="font-size:11px;color:#b8860b;margin-top:7px">📥 Excel also saved: {{result.saved_file}}</div>{%endif%}
</div></div>

<div class="card"><h2>Steel Procurement by Diameter</h2>
<table><tr><th>Dia</th><th class="num">Weight (kg)</th><th>Share</th><th class="num">12m bars</th></tr>
{%set tots=(result.steel_by_dia.values()|sum) or 1%}
{%for d,v in result.steel_by_dia.items()%}<tr><td class="ctr">∅{{d}} mm</td><td class="num">{{"{:,.0f}".format(v)}}</td>
<td><div class="bar" style="width:{{(v/tots*100)|round}}%"></div> {{(v/tots*100)|round}}%</td>
<td class="num">{{result.steel_bars12.get(d, 0)}} nos</td></tr>{%endfor%}
<tr style="background:#eef4f9;font-weight:700"><td>Total</td><td class="num">{{"{:,.0f}".format(tots)}}</td><td></td><td class="num">12m bars</td></tr></table>
<p class="hint" style="margin-top:6px">Last column = 12m stock lengths to order per diameter (incl. laps).</p></div>


{%if result.bbs_table%}
<div class="card"><h2>📋 Bar Bending Schedule (BBS)</h2>
<p class="hint">{{result.bbs_table|length}} bar groups — hand this to your steel fabricator</p>
<table><tr><th>Mark</th><th>Member</th><th>Dia</th><th class="ctr">No.</th><th class="num">Cut Len (m)</th><th class="num">Total (m)</th><th class="num">kg/m</th><th class="num">Wt (kg)</th></tr>
{%for b in result.bbs_table%}<tr><td>{{b.mark}}</td><td>{{b.member}}</td><td class="ctr">∅{{b.dia}}</td><td class="ctr">{{b.count}}</td><td class="num">{{b.cut_len}}</td><td class="num">{{b.total_len}}</td><td class="num">{{b.unit_wt}}</td><td class="num">{{b.weight}}</td></tr>{%endfor%}
<tr style="background:#eef4f9;font-weight:700"><td colspan="7" style="text-align:right">Sub-total</td><td class="num">{{"{:,.0f}".format(result.bbs_table|sum(attribute='weight'))}}</td></tr></table></div>
{%endif%}

{%if result.rate_analysis%}
<div class="card"><h2>💰 Rate Analysis (per m³ RCC)</h2>
<table><tr><th>Component</th><th class="num">Qty/m³</th><th class="num">Rate</th><th class="num">{{ current_country().currency }}/m³</th></tr>
<tr><td>Cement</td><td class="num">{{"{:.0f}".format(result.materials.cement_bags/(result.totals.concrete_m3*1.05 or 1))}} bags</td><td class="num">950</td><td class="num">{{"{:,.0f}".format(result.materials.cement_bags/(result.totals.concrete_m3*1.05 or 1)*950)}}</td></tr>
<tr><td>Steel (incl 3% wastage)</td><td class="num">{{result.rate_analysis.steel_kg_per_m3|int}} kg</td><td class="num">{{result.rate_analysis.steel_rate}}</td><td class="num">{{"{:,.0f}".format(result.rate_analysis.steel_kg_per_m3*result.rate_analysis.steel_rate)}}</td></tr>
<tr><td>Shuttering</td><td class="num">{{"{:.1f}".format(result.totals.shuttering_m2/(result.totals.concrete_m3 or 1))}} m²</td><td class="num">{{result.rate_analysis.shutter_rate}}</td><td class="num">{{"{:,.0f}".format(result.totals.shuttering_m2/(result.totals.concrete_m3 or 1)*result.rate_analysis.shutter_rate)}}</td></tr>
<tr style="background:#fff3cf;font-weight:800"><td>Cost per m³ RCC</td><td colspan="2"></td><td class="num">{{ current_country().currency }} {{"{:,.0f}".format(result.rate_analysis.cost_per_m3_rcc)}}</td></tr></table></div>
{%endif%}

{%if result.labour%}
<div class="card"><h2>👷 Labour Estimate</h2>
<table><tr><th>Worker</th><th class="num">Days</th><th class="num">Rate/day</th><th class="num">Cost {{ current_country().currency }}</th></tr>
{%set lr=result.labour_rates or {}%}
<tr><td>Mason</td><td class="num">{{result.labour.mason_days|int}}</td><td class="num">{{"{:,.0f}".format(lr.get('mason',1200))}}</td><td class="num">{{"{:,.0f}".format(result.labour.mason_cost)}}</td></tr>
<tr><td>Mazdoor (labourer)</td><td class="num">{{result.labour.mazdoor_days|int}}</td><td class="num">{{"{:,.0f}".format(lr.get('mazdoor',800))}}</td><td class="num">{{"{:,.0f}".format(result.labour.mazdoor_cost)}}</td></tr>
<tr style="background:#eef4f9;font-weight:700"><td>Total</td><td class="num">{{(result.labour.mason_days+result.labour.mazdoor_days)|int}}</td><td></td><td class="num">{{"{:,.0f}".format(result.labour.mason_cost+result.labour.mazdoor_cost)}}</td></tr></table>
<p class="hint" style="margin-top:8px">Steel fabrication: ~{{result.labour.steel_fab_days|int}} person-days (cutting + bending + placing)</p></div>
{%endif%}

<div class="card"><h2>Bill of Quantities (by work type)</h2>
{%for gname,info in result.groups.items()%}
<div class="sec" style="margin-top:10px">{{gname}} <span style="font-size:10px;color:#7a8693">{{ current_country().currency }} {{"{:,.0f}".format(info.subtotal)}}</span></div>
<table><tr><th>Code</th><th>Item</th><th class="ctr">Unit</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr>
{%for it in info['items']%}<tr><td>{{it.code}}</td><td>{{it.desc}}</td><td class="ctr">{{it.unit}}</td>
<td class="num">{{"{:,.2f}".format(it.qty)}}</td><td class="num">{{"{:,.0f}".format(it.rate)}}</td><td class="num">{{"{:,.0f}".format(it.amount)}}</td></tr>{%endfor%}</table>
{%endfor%}<div class="tot">GRAND TOTAL: {{ current_country().currency }} {{"{:,.0f}".format(result.grand_total)}}</div></div>

<div class="card"><h2>Member-wise Summary</h2>
{%for cat,ms in result.member_summary.items()%}
<div class="sec" style="margin-top:8px">{{cat}}</div>
<table><tr><th>ID</th><th>Type</th><th class="ctr">No</th><th class="num">Conc m³</th><th class="num">Steel kg</th><th class="num">Shutter m²</th><th>Steel detail</th></tr>
{%for m in ms%}<tr><td>{{m.id}}</td><td>{{m.kind}}</td><td class="ctr">{{m.count}}</td>
<td class="num">{{"{:,.2f}".format(m.conc)}}</td><td class="num">{{"{:,.0f}".format(m.steel)}}</td><td class="num">{{"{:,.1f}".format(m.shutter)}}</td>
<td class="det">{{m.detail}}</td></tr>{%endfor%}</table>
{%endfor%}</div>
{%else%}
<div class="card"><h2>📋 Get started</h2>
<p class="hint">A full member schedule is loaded (footings, columns with per-floor steel, beams, slabs, shear wall, retaining wall). Click <b>Calculate</b> for a professional work-type BOQ with BBS steel.</p>
<ul style="line-height:1.8;font-size:13px">
<li><b>Columns</b>: steel per floor (20-16,16-16,12-16); ductile ties (8-100-200)</li>
<li><b>Beams</b>: plinth / tie / primary / secondary with confined stirrups</li>
<li><b>Footings</b>: isolated/strap/combined/pile with excavation + soling + PCC</li>
<li>Output: <b>Earthwork · PCC · RCC Concrete · Steel · Shuttering</b> + steel by diameter</li>
</ul></div>
{%endif%}
</div></div></div>
<script>
const BK=[{%for k in BEAM_KINDS%}'{{k}}'{%if not loop.last%},{%endif%}{%endfor%}];
const C={f:{{s.footings|length}},c:{{s.columns|length}},b:{{s.beams|length}},s:{{s.slabs|length}},w:{{s.shearwalls|length}},rw:{{s.retwalls|length}},t:{{s.tanks|length}},r:{{s.ramps|length}},l:{{s.lifts|length}},o:{{s.others|length}},sc:{{s.staircase|length}}};
const OPT=(a)=>a.map(x=>`<option>${x}</option>`).join('');

function syncMain(i){const w=document.querySelector('.mainfloors[data-idx="'+i+'"]');if(!w)return;
const vals=[...w.querySelectorAll('input[name^="c_mainf_"]')].map(v=>v.value.trim()).filter(Boolean);
w.querySelector('input[name="c_main_'+i+'"]').value=vals.join(',');}
function resizeFloors(){const n=Math.max(1,parseInt(document.querySelector('input[name="floors_above"]')?.value)||1);
document.querySelectorAll('.mainfloors').forEach(w=>{w.querySelectorAll('.fcell').forEach((c,f)=>{c.style.display=f<n?'':'none';});});}
document.querySelectorAll('input[name="floors_above"]').forEach(el=>el.addEventListener('input',resizeFloors));
function addFloor(){const el=document.querySelector('input[name="floors_above"]');el.value=(parseInt(el.value)||1)+1;resizeFloors();}
function delFloor(){const el=document.querySelector('input[name="floors_above"]');el.value=Math.max(1,(parseInt(el.value)||1)-1);resizeFloors();}
resizeFloors();

function dupRow(btn,k){
  const cont=document.getElementById({f:'footings',c:'columns',b:'beams',s:'slabs',w:'walls',rw:'retwalls',t:'tanks',r:'ramps',l:'lifts',o:'others',sc:'staircases'}[k]);
  if(!cont)return;
  const row=btn.closest('.mem');
  const ni=C[k]++;
  const cl=row.cloneNode(true);
  cl.querySelectorAll('input,select').forEach(el=>{
    if(el.name){el.name=el.name.replace(/_(\d+)$/,'_'+ni);}
  });
  const hid=cl.querySelector('input[type="hidden"]');
  if(hid){hid.value=ni;}
  row.after(cl);
}
function dupRows(k){const cont=document.getElementById({f:'footings',c:'columns',b:'beams',s:'slabs',w:'walls',rw:'retwalls',t:'tanks',r:'ramps',l:'lifts',o:'others',sc:'staircases'}[k]);
if(!cont||!cont.children.length)return;[...cont.querySelectorAll('.mem')].forEach(rw=>{const ni=C[k]++;
const cl=rw.cloneNode(true);cl.querySelectorAll('input,select').forEach(el=>{if(el.name){el.name=el.name.replace(/_(\d+)$/,'_'+ni);}});
const hid=cl.querySelector('input[type="hidden"]');if(hid){hid.value=ni;}cont.appendChild(cl);});}
function box(k,i,html){const d=document.createElement('div');d.className='mem';d.innerHTML=`<input type="hidden" name="${k}_row" value="${i}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>${html(i)}`;
document.getElementById({f:'footings',c:'columns',b:'beams',s:'slabs',w:'walls',rw:'retwalls',t:'tanks',r:'ramps',l:'lifts',o:'others'}[k]).appendChild(d);}
const FK=i=>`<div class="row r5"><div><label>ID</label><input name="f_id_${i}"></div><div><label>Type</label><select name="f_kind_${i}">${OPT(['isolated','strap','combined','raft','pile','strip'])}</select></div><div><label>Count</label><input name="f_count_${i}" value="1"></div><div><label>L</label><input name="f_L_${i}" value="1500"></div><div><label>W</label><input name="f_W_${i}" value="1500"></div></div><div class="row r6"><div><label>t</label><input name="f_t_${i}" value="450"></div><div><label>Depth</label><input name="f_depth_${i}" value="1500"></div><div><label>Soling t</label><input name="f_soling_t_${i}" value="75"></div><div><label>Mesh</label><input name="f_mesh_${i}" list="dl_mesh" value="12-150"></div><div><label>Ped b</label><input name="f_ped_b_${i}" value="300"></div><div><label>Ped d</label><input name="f_ped_d_${i}" value="450"></div></div><div class="row r6"><div><label>Ped h</label><input name="f_ped_h_${i}" value="600"></div><div><label>Ped main</label><input name="f_ped_main_${i}" list="dl_ped" value="8-16"></div><div><label>Ped tie</label><input name="f_ped_tie_${i}" list="dl_stirrup" value="8-150"></div><div><label>Strap len</label><input name="f_strap_len_${i}"></div><div><label>Strap b</label><input name="f_strap_b_${i}"></div><div><label>Strap d</label><input name="f_strap_d_${i}"></div></div><div class="row r6"><div><label>Pile dia</label><input name="f_pile_dia_${i}"></div><div><label>Pile len</label><input name="f_pile_len_${i}"></div><div><label>Pile main</label><input name="f_pile_main_${i}" list="dl_ped"></div><div><label>Spiral</label><input name="f_spiral_${i}" list="dl_mesh"></div><div><label>Cap L</label><input name="f_cap_L_${i}"></div><div><label>Cap mesh</label><input name="f_cap_mesh_${i}" list="dl_mesh"></div></div>`;
const FLR=i=>{let h='';for(let f=0;f<15;f++){h+=`<div class="fcell" style="display:none"><label>${f==0?'GF':'F'+f}</label><input name="c_mainf_${f}_${i}" list="dl_main" value="${f==0?'8-16':''}" oninput="syncMain(${i})"></div>`;}return h+`<div class="fcell"><label>&nbsp;</label><button type="button" class="fbtn" onclick="addFloor()" title="Add one more floor">+ floor</button><button type="button" class="fbtn minus" onclick="delFloor()" title="Remove top floor">−</button></div>`;};
const CK=i=>`<div class="row r5"><div><label>ID</label><input name="c_id_${i}"></div><div><label>Count</label><input name="c_count_${i}" value="1"></div><div><label>b</label><input name="c_b_${i}" value="300"></div><div><label>d</label><input name="c_d_${i}" value="450"></div><div><label>Tie</label><input name="c_tie_${i}" list="dl_tie" value="8-100-200"></div></div><div><label>Grade</label><select name="c_grade_${i}">${OPT(['M15','M20','M25','M30'])}</select></div><div class="mainfloors" data-idx="${i}"><label>Main bars per floor (GF first)</label><div class="flrow">${FLR(i)}</div><input type="hidden" name="c_main_${i}"></div>`;
const BK2=i=>`<div class="row r6"><div><label>ID</label><input name="b_id_${i}"></div><div><label>Type</label><select name="b_kind_${i}">${OPT(BK)}</select></div><div><label>Count</label><input name="b_count_${i}" value="1"></div><div><label>b</label><input name="b_b_${i}" value="230"></div><div><label>d</label><input name="b_d_${i}" value="450"></div><div><label>Length</label><input name="b_length_${i}" value="4000"></div></div><div class="row r6"><div><label>Top</label><input name="b_top_${i}" list="dl_main" value="3-16"></div><div><label>Bottom</label><input name="b_bottom_${i}" list="dl_main" value="3-16"></div><div><label>Extra top @supports</label><input name="b_extra_top_${i}" list="dl_main" placeholder="e.g. 1-16"></div><div><label>Side bars (deep>750mm)</label><input name="b_side_${i}" list="dl_main" placeholder="e.g. 2-12"></div><div><label>Stirrup</label><input name="b_tie_${i}" list="dl_stirrup" value="8-100-150"></div><div><label>Grade</label><select name="b_grade_${i}">${OPT(['M15','M20','M25','M30'])}</select></div></div>`;
const SK=i=>`<div class="row r6"><div><label>ID</label><input name="s_id_${i}"></div><div><label>Area m²</label><input name="s_area_${i}" value="50"></div><div><label>t</label><input name="s_t_${i}" value="125"></div><div><label>Bottom mesh</label><input name="s_mesh_${i}" list="dl_mesh" value="10-150"></div><div><label>Top mesh (double mesh)</label><input name="s_top_mesh_${i}" list="dl_mesh" placeholder="blank=1 layer"></div></div>`;
const WK=i=>`<div class="row r5"><div><label>ID</label><input name="w_id_${i}"></div><div><label>Length</label><input name="w_length_${i}" value="6000"></div><div><label>t</label><input name="w_t_${i}" value="200"></div><div><label>Height</label><input name="w_height_${i}" value="3000"></div><div><label>Vert</label><input name="w_vertical_${i}" value="12-150"></div></div><div class="row r2"><div><label>Horiz</label><input name="w_horizontal_${i}" value="10-150"></div><div></div></div>`;
const RK=i=>`<div class="row r5"><div><label>ID</label><input name="rw_id_${i}"></div><div><label>Length</label><input name="rw_length_${i}" value="6000"></div><div><label>Stem t</label><input name="rw_stem_t_${i}" value="250"></div><div><label>Stem h</label><input name="rw_stem_h_${i}" value="3000"></div><div><label>Base b</label><input name="rw_base_b_${i}" value="2000"></div></div><div class="row r5"><div><label>Base t</label><input name="rw_base_t_${i}" value="300"></div><div><label>Vert</label><input name="rw_vert_${i}" value="12-150"></div><div><label>Horiz</label><input name="rw_horiz_${i}" value="10-150"></div><div><label>Base mesh</label><input name="rw_base_mesh_${i}" value="12-150"></div><div></div></div>`;
const TK=i=>`<div class="row r5"><div><label>ID</label><input name="t_id_${i}"></div><div><label>Type</label><select name="t_kind_${i}">${OPT(['overhead tank','underground sump'])}</select></div><div><label>L int (mm)</label><input name="t_L_${i}" value="1800"></div><div><label>W int (mm)</label><input name="t_W_${i}" value="1800"></div><div><label>Depth (mm)</label><input name="t_depth_${i}" value="1400"></div></div><div class="row r6" style="margin-top:8px"><div><label>Wall t</label><input name="t_wall_t_${i}" value="125"></div><div><label>Base t</label><input name="t_base_t_${i}" value="150"></div><div><label>Cover t</label><input name="t_cover_t_${i}" value="100"></div><div><label>Wall mesh</label><input name="t_wall_mesh_${i}" list="dl_mesh" value="10-150"></div><div><label>Base mesh</label><input name="t_base_mesh_${i}" list="dl_mesh" value="10-150"></div><div><label>Grade</label><select name="t_grade_${i}">${OPT(['M20','M25','M30','M35'])}</select></div></div>`;
const RMP=i=>`<div class="row r6"><div><label>ID</label><input name="r_id_${i}"></div><div><label>Length incl. (mm)</label><input name="r_length_${i}" value="6000"></div><div><label>Width (mm)</label><input name="r_width_${i}" value="3000"></div><div><label>Thickness (mm)</label><input name="r_thickness_${i}" value="150"></div><div><label>Mesh</label><input name="r_mesh_${i}" list="dl_mesh" value="10-150"></div><div><label>Grade</label><select name="r_grade_${i}">${OPT(['M20','M25','M30'])}</select></div></div><div class="row r2" style="margin-top:8px"><div><label>Side wall h (mm, 0=none)</label><input name="r_side_wall_h_${i}" value="300"></div><div><label>Side wall t (mm)</label><input name="r_side_wall_t_${i}" value="150"></div></div>`;
const LFT=i=>`<div class="row r5"><div><label>ID</label><input name="l_id_${i}"></div><div><label>Plan L (mm)</label><input name="l_L_${i}" value="2200"></div><div><label>Plan W (mm)</label><input name="l_W_${i}" value="2000"></div><div><label>Pit depth (mm)</label><input name="l_pit_depth_${i}" value="1800"></div><div><label>Core height (mm)</label><input name="l_core_height_${i}" value="9900"></div></div><div class="row r4" style="margin-top:8px"><div><label>Wall t</label><input name="l_wall_t_${i}" value="175"></div><div><label>Base t</label><input name="l_base_t_${i}" value="300"></div><div><label>Mesh</label><input name="l_mesh_${i}" list="dl_mesh" value="10-150"></div><div><label>Grade</label><select name="l_grade_${i}">${OPT(['M25','M30','M35','M40'])}</select></div></div>`;
const OTH=i=>`<div class="row r2"><div><label>Item</label><select name="o_item_${i}">${OPT(['cement-based waterproofing (sunken slab/toilet)','bitumen coat 2 coats (retaining wall backface)','expansion joint filler + sealant','PVC water stop 230mm (construction joints)','dewatering from foundations','curing compound (or ponding)'])}</select></div><div><label>Qty (sqm/rmt/cum)</label><input name="o_qty_${i}" value="20"></div></div>`;
const addF=()=>box('f',C.f++,FK); const addC=()=>{const i=C.c++;box('c',i,CK);resizeFloors();syncMain(i);};
const addB=()=>box('b',C.b++,BK2); const addS=()=>box('s',C.s++,SK);
const addW=()=>box('w',C.w++,WK); const addRW=()=>box('rw',C.rw++,RK);
const SCK=i=>`<div class="row r6"><div><label>ID</label><input name="sc_id_${i}" value="ST${i+1}"></div><div><label>Type</label><select name="sc_type_${i}">${OPT(['dog-legged','open-well','straight flight','spiral','cantilever'])}</select></div><div><label>Flights</label><input name="sc_flights_${i}" value="2"></div><div><label>Run (mm)</label><input name="sc_run_${i}" value="3600"></div><div><label>Tread (mm)</label><input name="sc_tread_${i}" value="300"></div><div><label>Riser (mm)</label><input name="sc_riser_${i}" value="150"></div></div><div class="row r6" style="margin-top:8px"><div><label>Width (mm)</label><input name="sc_width_${i}" value="1200"></div><div><label>Waist (mm)</label><input name="sc_waist_${i}" value="150"></div><div><label>Mesh</label><input name="sc_mesh_${i}" list="dl_mesh" value="10-150"></div><div><label>Landings (nos)</label><input name="sc_landings_${i}" value="0"></div><div><label>Landing L (mm)</label><input name="sc_landing_L_${i}" value="1200"></div><div><label>Landing W (mm)</label><input name="sc_landing_W_${i}" value="1200"></div></div>`;
const addSC=()=>box('sc',C.sc++,SCK);
const addT=()=>box('t',C.t++,TK); const addR=()=>box('r',C.r++,RMP);
const addL=()=>box('l',C.l++,LFT); const addO=()=>box('o',C.o++,OTH);
function addPdf(){const d=document.createElement('div');d.style.cssText='margin-top:6px;display:flex;gap:6px;align-items:center';d.innerHTML='<input type="file" name="pdfs" accept="application/pdf" multiple style="flex:1"><button type="button" style="background:#c0392b;color:#fff;border:none;border-radius:5px;padding:6px 10px;cursor:pointer;font-size:12px" onclick="this.parentElement.remove()">✕</button>';document.getElementById('morepdfs').appendChild(d);}
</script>
</body></html>
"""
