"""
pdf_parser.py  (enhanced)
-------------------------
Multi-strategy PDF reader for construction drawings / design sheets.

Strategy layers (each is best-effort, never crashes):
  1. Vector text extraction          (PyMuPDF)   - typed sheets / schedules
  2. OCR fallback                    (Tesseract) - scanned / stamped drawings
  3. Table extraction                (pdfplumber)- structural & BBS schedules
  4. Heuristic field + BBS parsing   (regex)

Returns: (found_inputs_dict, raw_text, notes)
  found_inputs_dict may include a special key 'measured_steel_kg' when a
  Bar Bending Schedule table is detected — the engine then uses measured
  steel instead of the ratio estimate.
"""
import io
import re
from collections import Counter

try:
    import pymupdf as fitz
except Exception:
    import fitz  # pragma: no cover

import pdfplumber

_PYTESSERACT_OK = False
try:
    import pytesseract
    from PIL import Image
    _PYTESSERACT_OK = True
except Exception:
    _PYTESSERACT_OK = False

SIZE_RE = re.compile(r'(\d{2,4})\s*[xX×*]\s*(\d{2,4})')
GRADE_RE = re.compile(r'\bM\s?(\d{2,3})\b')


# ---------------------------------------------------------------- text + OCR
def _text_fitz(pdf_bytes):
    out = ''
    doc = fitz.open(stream=pdf_bytes, filetype='pdf')
    for page in doc:
        out += page.get_text('text') + '\n'
    doc.close()
    return out


def _ocr_pdf(pdf_bytes, max_pages=8):
    if not _PYTESSERACT_OK:
        return ''
    out = ''
    try:
        doc = fitz.open(stream=pdf_bytes, filetype='pdf')
        for i, page in enumerate(doc):
            if i >= max_pages:
                break
            pix = page.get_pixmap(dpi=250)
            img = Image.open(io.BytesIO(pix.tobytes('png')))
            try:
                out += pytesseract.image_to_string(img, config='--psm 6') + '\n'
            except Exception:
                pass
        doc.close()
    except Exception:
        pass
    return out


# ---------------------------------------------------------------- tables
def _extract_tables(pdf_bytes):
    tables = []
    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            for page in pdf.pages[:12]:
                for t in page.extract_tables():
                    if t and len(t) > 1:
                        tables.append(t)
    except Exception:
        pass
    return tables


def _is_num(x):
    try:
        float(str(x).replace(',', '').replace(' ', ''))
        return True
    except (TypeError, ValueError):
        return False


def _to_num(x):
    try:
        return float(str(x).replace(',', '').replace(' ', ''))
    except (TypeError, ValueError):
        return None


def _parse_bbs(tables):
    """Sum the weight column of any Bar Bending Schedule table."""
    total = 0.0
    found = False
    for t in tables:
        if not t or not t[0]:
            continue
        headers = [str(c).lower() if c else '' for c in t[0]]
        # whole-table text to confirm it looks like a BBS
        joined = ' '.join(str(c) for row in t for c in row if c).lower()
        if not any(k in joined for k in ['bar', 'dia', 'steel', 'reinforce', 'bbs', 'weight', 'kg']):
            continue
        # locate weight column
        wcol = None
        for i, h in enumerate(headers):
            if ('wt' in h or 'weight' in h or 'kg' in h) and 'length' not in h:
                wcol = i
                break
        if wcol is None:
            # fallback: rightmost mostly-numeric column
            cand = None
            for i in range(len(headers)):
                nums = [r for r in t[1:] if i < len(r) and _is_num(r[i])]
                if len(nums) >= 3:
                    cand = i
            wcol = cand
        if wcol is not None:
            s = 0.0
            for r in t[1:]:
                if wcol < len(r) and _is_num(r[wcol]):
                    s += _to_num(r[wcol])
            if s > 0:
                total += s
                found = True
    return round(total, 1) if found else None


def _parse_schedules(tables):
    """Pull column/beam member sizes from structural schedule tables."""
    cols, beams = [], []
    for t in tables:
        text = ' '.join(str(c) for row in t for c in row if c).lower()
        is_col = any(k in text for k in ['column', 'col.', 'col '])
        is_beam = any(k in text for k in ['beam', 'grid beam'])
        if not (is_col or is_beam):
            continue
        for row in t:
            for cell in row:
                if not cell:
                    continue
                m = SIZE_RE.search(str(cell))
                if m:
                    a, b = int(m.group(1)), int(m.group(2))
                    if 150 <= a <= 600 and 150 <= b <= 800:
                        (cols if is_col else beams).append((a, b))
    out = {}
    if cols:
        a, b = Counter(cols).most_common(1)[0][0]
        out.update(column_b=a, column_d=b)
    if beams:
        a, b = Counter(beams).most_common(1)[0][0]
        out.update(beam_width=a, beam_depth=b)
    return out


# ---------------------------------------------------------------- field heuristics
def _num(s):
    try:
        return float(str(s).replace(',', ''))
    except (TypeError, ValueError):
        return None


def _find(pattern, text, flags=re.I):
    m = re.search(pattern, text, flags)
    return m


def _parse_fields(text):
    f = {}
    notes = []

    g = GRADE_RE.search(text)
    if g:
        for pref in ['25', '20', '30', '15']:
            if g.group(1) == pref:
                f['concrete_grade'] = f'M{pref}'
                break
        else:
            f['concrete_grade'] = f'M{g.group(1)}'

    # area
    am = _find(r'(?:built[- ]?up|plinth|carpet|floor\s*area|super\s*build)[^\d]{0,30}([\d.,]+)\s*(?:sq\.?\s*m|sqm|m2|m\^2|m\b)', text)
    if am:
        v = _num(am.group(1))
        if v and 10 < v < 100000:
            side = round(v ** 0.5, 1)
            f['footprint_length'] = side
            f['footprint_width'] = side

    # floors (number before or after keyword)
    fl = _find(r'(\d+)\s*(?:storeys?|stories?|floors?|level)', text)
    if not fl:
        fl = _find(r'(?:no\.?\s*of\s*floors?|number\s*of\s*floors?|storeys?|G\s*\+\s*\d)[^\d]{0,15}(\d+)', text)
    # handle "G+3" style
    gplus = _find(r'G\s*\+\s*(\d+)', text)
    if gplus:
        f['floors_above'] = int(gplus.group(1)) + 1  # ground + upper
    elif fl:
        f['floors_above'] = int(fl.group(1))

    # floor / plinth height
    fh = _find(r'floor[- ]?to[- ]?floor[^\d]{0,18}([\d.]+)\s*m', text) or \
         _find(r'floor height[^\d]{0,18}([\d.]+)\s*m', text)
    if fh:
        f['floor_height'] = _num(fh.group(1))
    ph = _find(r'plinth height[^\d]{0,18}([\d.]+)\s*m', text)
    if ph:
        f['plinth_height'] = _num(ph.group(1))

    # slab thickness
    st = _find(r'slab[^\d]{0,28}(?:thickness|thk|depth)[^\d]{0,12}(\d{2,4})\s*mm', text)
    if st:
        f['slab_thickness'] = _num(st.group(1))

    # column / beam size
    cs = _find(r'column[^\d]{0,35}(\d{2,4})\s*[xX×*]\s*(\d{2,4})\s*mm', text)
    if cs:
        f['column_b'] = int(cs.group(1)); f['column_d'] = int(cs.group(2))
    bs = _find(r'beam[^\d]{0,35}(\d{2,4})\s*[xX×*]\s*(\d{2,4})\s*mm', text)
    if bs:
        f['beam_width'] = int(bs.group(1)); f['beam_depth'] = int(bs.group(2))

    # footing L x W x T
    ft = _find(r'footing[^\d]{0,35}([\d.]+)\s*[xX×*]\s*([\d.]+)\s*[xX×*]\s*([\d.]+)\s*m', text)
    if ft:
        f['footing_length'] = _num(ft.group(1))
        f['footing_width'] = _num(ft.group(2))
        f['footing_thickness'] = _num(ft.group(3))
    fd = _find(r'footing depth[^\d]{0,18}([\d.]+)\s*m', text)
    if fd:
        f['footing_depth'] = _num(fd.group(1))

    # wall thickness
    wt = _find(r'(?:wall|external\s*wall)[^\d]{0,28}(?:thickness|thk)[^\d]{0,12}(\d{2,4})\s*mm', text)
    if wt:
        f['external_wall_thickness'] = _num(wt.group(1))

    # toilets / bedrooms
    tl = _find(r'(\d+)\s*(?:toilet|bath)', text)
    if tl:
        f['no_of_toilets'] = int(tl.group(1))
    br = _find(r'(\d+)\s*(?:bedroom|bed\s*room)', text)
    if br:
        f['no_of_toilets'] = max(f.get('no_of_toilets', 0) or 0, int(br.group(1)))
    kt = _find(r'(\d+)\s*kitchen', text)
    if kt:
        f['no_of_kitchens'] = int(kt.group(1))

    # foundation type
    low = text.lower()
    if 'pile' in low:
        f['foundation_type'] = 'pile'
    elif 'raft' in low:
        f['foundation_type'] = 'raft'
    elif 'strip' in low:
        f['foundation_type'] = 'strip'

    # steel ratio hint (informational)
    sr = _find(r'(?:steel|reinforcement|rebar|tmt)[^\d]{0,40}(\d{2,4})\s*kg', text)
    return f, sr.group(1) if sr else None


# ---------------------------------------------------------------- text BBS
def _parse_bbs_text(text):
    """Sum the weight column of a Bar Bending Schedule written as text lines."""
    lines = text.splitlines()
    start = None
    for i, l in enumerate(lines):
        if re.search(r'bar\s*bending|\bbbs\b', l, re.I):
            start = i
            break
    if start is None:
        return None
    # find a header row near the section that mentions weight
    hdr_idx = wpos = None
    for j in range(start, min(start + 4, len(lines))):
        m = re.search(r'(weight|wt|total\s*wt|kg)', lines[j], re.I)
        if m:
            hdr_idx = j
            wpos = m.start()
            break
    if hdr_idx is None:
        return None
    total = 0.0
    counted = 0
    for j in range(hdr_idx + 1, min(hdr_idx + 80, len(lines))):
        ln = lines[j]
        if not ln.strip():
            if counted >= 2:
                break
            continue
        nums = [(mm.start(), _to_num(mm.group())) for mm in
                re.finditer(r'\d[\d,]*\.?\d*', ln)]
        if not nums:
            if counted >= 2:
                break
            continue
        best = min(nums, key=lambda x: abs(x[0] - wpos))
        if best[1] and best[1] >= 1:
            total += best[1]
            counted += 1
    return round(total, 1) if counted >= 2 else None


# ---------------------------------------------------------------- public API
def extract_inputs_from_pdf(pdf_bytes):
    text = _text_fitz(pdf_bytes)
    used_ocr = False
    if len(text.strip()) < 40:
        ocr = _ocr_pdf(pdf_bytes)
        if len(ocr.strip()) > len(text.strip()):
            text = ocr
            used_ocr = True

    tables = _extract_tables(pdf_bytes)
    found, steel_hint = _parse_fields(text)

    # tables override member sizes (more reliable than free text)
    sched = _parse_schedules(tables)
    found.update(sched)

    bbs = _parse_bbs(tables)
    if not bbs:
        bbs = _parse_bbs_text(text)
    if bbs:
        found['measured_steel_kg'] = bbs

    # ---- build notes ----
    notes = []
    if used_ocr:
        notes.append('🔍 PDF had little embedded text — used OCR to read a scanned/stamped sheet.')
    if not found:
        notes.append('No key parameters detected. The PDF may be a raster drawing or an unusual '
                     'layout. Please verify the form manually — the estimate still runs.')
        return found, text, notes
    notes.append(f'✅ Pre-filled {len([k for k in found if k != "measured_steel_kg"])} field(s) — review & click Generate Estimate.')
    if 'concrete_grade' in found:
        notes.append(f'Detected concrete grade {found["concrete_grade"]}.')
    if 'floors_above' in found:
        notes.append(f'Detected {found["floors_above"]} floors.')
    if 'column_b' in found:
        notes.append(f'Detected column {found["column_b"]}×{found["column_d"]} mm.')
    if 'beam_width' in found:
        notes.append(f'Detected beam {found["beam_width"]}×{found["beam_depth"]} mm.')
    if 'slab_thickness' in found:
        notes.append(f'Detected slab thickness {found["slab_thickness"]} mm.')
    if sched:
        notes.append('📐 Read member sizes from a structural schedule table (high confidence).')
    if bbs:
        notes.append(f'⚙️ Bar Bending Schedule found — measured steel = {bbs:,.0f} kg (used instead of ratio estimate).')
    if steel_hint:
        notes.append(f'Found a ~{steel_hint} kg/m³ steel reference (informational).')
    if 'foundation_type' in found:
        notes.append(f'Detected foundation type: {found["foundation_type"]}.')
    return found, text, notes
