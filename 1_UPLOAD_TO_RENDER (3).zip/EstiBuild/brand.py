"""Central branding config — EstiBuild is its own company."""
COMPANY = "EstiBuild"
SHORT = "EstiBuild"
TAGLINE = "Smart Construction Estimation Platform"
CONTACT = "EstiBuild — Smart Construction Estimation"
CLIENT = ""
LOGO = "logo.png"
LOGO_FAINT = "logo_faint.png"

# ---- International currency ----
CURRENCY = "NPR"
CURRENCY_SYMBOL = "Rs"
