"""
estimation/norms.py
-------------------
Constants, mix ratios and default market rates (NPR) used by the engine.
All values follow NBC + IS 456 nominal-mix conventions used in Nepal practice.

These are *nominal* (rule-of-thumb) values intended for preliminary
estimation. For real procurement / billing, validate against the
approved design mix and current local market rates.
"""

# ---- Cement bag volume ----
BAG_VOL_M3 = 0.0347          # one 50 kg OPC bag ~ 0.0347 m3 of cement

# ---- Concrete (nominal mix a:b:c -> cement:sand:coarse agg) ----
DRY_FACTOR_CONCRETE = 1.54   # dry volume factor for concrete
CONCRETE_GRADES = {
    'M15': (1, 2, 4),
    'M20': (1, 1.5, 3),
    'M25': (1, 1, 2),
    'M30': (1, 0.75, 1.5),
}

# Plain Cement Concrete (lean mix) for foundation / levelling course
PCC_MIXES = {
    'PCC 1:4:8': (1, 4, 8),
    'PCC 1:3:6': (1, 3, 6),
    'PCC 1:2:4': (1, 2, 4),
}

# ---- Mortar (brick/block work & plaster) ----
MORTAR_DRY_FACTOR = 1.33
MORTAR_FRAC_IN_MASONRY = 0.30   # mortar ~30 % of finished masonry volume
PLASTER_DRY_FACTOR = 1.54

# ---- Steel reinforcement: kg per m3 of concrete, by element ----
STEEL_RATIOS = {
    'footing': 60,
    'pedestal': 80,
    'column': 120,
    'beam': 130,
    'slab': 80,
    'staircase': 110,
    'raft': 100,
    'retaining': 90,
}

# ---- Unit rates (NPR) - editable per project ----
# Composite work rates include material + labour + reasonable wastage.
DEFAULT_RATES = {
    # ---- structural ----
    'excavation_m3': 450,
    'pcc_m3': 9500,
    'rcc_m3': 16500,
    'shuttering_m2': 850,
    'steel_kg': 150,        # TMT supplied + cut/bend/fixed
    # ---- civil / earthwork ----
    'backfill_m3': 400,
    'moorum_m3': 1800,
    'soling_m3': 3500,
    'antitermite_m2': 120,
    # ---- masonry / architectural ----
    'brickwork_m3': 9500,
    'blockwork_m3': 11500,
    'dpc_m2': 350,
    'door_frame_m': 1200,
    'window_frame_m': 1000,
    'door_shutter_no': 7500,
    'window_shutter_no': 6500,
    # ---- finishing ----
    'plaster_m2': 450,
    'flooring_m2': 1800,
    'dado_m2': 1400,
    'painting_m2': 180,
    'skirting_m': 250,
    'waterproofing_m2': 650,
    # ---- sanitary / plumbing ----
    'cpvc_pipe_m': 700,
    'pvc_pipe_m': 650,
    'wc_no': 9000,
    'washbasin_no': 5500,
    'sink_no': 6000,
    'tap_no': 800,
    'shower_no': 1200,
    'tank_no': 35000,
    'septic_m3': 9000,
    'soakpit_no': 25000,
}

# ---- Material unit rates (for procurement summary value) ----
MATERIAL_RATES = {
    'cement_bag': 950,
    'sand_m3': 2500,
    'aggregate_m3': 2800,
    'steel_kg': 115,
    'brick_no': 18,
    'block_no': 120,
}
