"""Construction Quantity & Material Estimation Engine.

RCC structural + civil + architectural + sanitary/plumbing + finishing.
Based on Nepal Building Code (NBC) + Indian Standard (IS 456) thumb rules.
All quantities in SI units; costs in NPR.
"""
