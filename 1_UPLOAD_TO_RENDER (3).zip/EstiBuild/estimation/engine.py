"""
estimation/engine.py
--------------------
Master estimation engine.

`estimate(inputs)` returns a complete Bill of Quantities with:
  * quantities per work item
  * priced amounts (NPR, composite rates)
  * material procurement breakup (cement, sand, aggregate, steel, bricks/blocks)

Input is a flat dict produced by `normalize_inputs(raw)`.
"""
from . import norms as N


# ------------------------------------------------------------------ #
#  Default project inputs (can be overridden by form or PDF parser)  #
# ------------------------------------------------------------------ #
DEFAULT_INPUTS = {
    # --- project meta ---
    'project_name': 'Sample Residential Building',
    'client': '',
    'location': 'Kathmandu',
    'seismic_zone': 'Zone V',
    # --- geometry ---
    'plot_length': 15.0, 'plot_width': 10.0,
    'footprint_length': 12.0, 'footprint_width': 9.0,
    'floors_above': 3,          # storeys above ground incl. ground (G+2 -> 3)
    'basements': 0,
    'floor_height': 3.0,        # m floor-to-floor
    'plinth_height': 0.6,       # m
    # --- foundation ---
    'foundation_type': 'isolated',   # isolated / raft / strip / pile
    'footing_length': 1.5, 'footing_width': 1.5,
    'footing_thickness': 0.45, 'footing_depth': 1.5,
    # --- structural grid ---
    'grid_lines_x': 4, 'grid_lines_y': 4,
    'column_b': 300, 'column_d': 450,        # mm
    'beam_width': 230, 'beam_depth': 450,    # mm
    'slab_thickness': 125,                   # mm
    # --- masonry ---
    'external_wall_thickness': 230,          # mm
    'internal_wall_thickness': 115,          # mm
    'wall_material': 'brick',                # brick / block / aac
    'internal_wall_factor': 0.5,             # m of internal wall per m2 of floor
    'opening_ratio': 0.25,                   # door/window deduction
    'no_of_doors': 9, 'no_of_windows': 12,
    # --- mixes ---
    'concrete_grade': 'M20',
    'pcc_mix': 'PCC 1:4:8',
    'mortar_ratio': '1:6',
    'plaster_ratio': '1:4',
    'steel_factor': 1.0,                     # global multiplier on steel ratios
    # --- sanitary / plumbing ---
    'no_of_toilets': 3, 'no_of_kitchens': 1,
    'has_septic': True,
    # --- finishing ---
    'flooring_type': 'Vitrified Tile',
    'misc_percent': 3.0,
    # special: when a Bar Bending Schedule is parsed from PDF, steel is measured
    'measured_steel_kg': None,
}


def normalize_inputs(raw):
    """Merge a raw dict (form/pdf) onto DEFAULT_INPUTS with type coercion."""
    out = {}
    for k, v in DEFAULT_INPUTS.items():
        out[k] = v
    for k, v in (raw or {}).items():
        if v is None or v == '':
            continue
        if k in DEFAULT_INPUTS:
            if isinstance(DEFAULT_INPUTS[k], bool):
                out[k] = str(v).lower() in ('1', 'true', 'yes', 'on')
            elif isinstance(DEFAULT_INPUTS[k], int) and not isinstance(DEFAULT_INPUTS[k], bool):
                try:
                    out[k] = int(float(v))
                except (TypeError, ValueError):
                    out[k] = v
            elif isinstance(DEFAULT_INPUTS[k], float):
                try:
                    out[k] = float(v)
                except (TypeError, ValueError):
                    out[k] = v
            else:
                out[k] = v
    # rates
    out['rates'] = dict(N.DEFAULT_RATES)
    if isinstance(raw, dict) and isinstance(raw.get('_custom_rates'), dict):
        out['rates'].update(raw['_custom_rates'])
    out['mat_rates'] = dict(N.MATERIAL_RATES)
    return out


# ------------------------------------------------------------------ #
#  Mix breakup helpers                                               #
# ------------------------------------------------------------------ #
def _ratio_tuple(ratio_str):
    return tuple(float(x) for x in str(ratio_str).split(':'))


def concrete_breakup(volume, grade):
    """Return (cement_bags, sand_m3, aggregate_m3) for `volume` m3 of concrete."""
    a, b, c = N.CONCRETE_GRADES[grade]
    s = a + b + c
    dry = volume * N.DRY_FACTOR_CONCRETE
    cement = (a / s) * dry / N.BAG_VOL_M3
    sand = (b / s) * dry
    agg = (c / s) * dry
    return cement, sand, agg


def pcc_breakup(volume, mix):
    a, b, c = N.PCC_MIXES[mix]
    s = a + b + c
    dry = volume * N.DRY_FACTOR_CONCRETE
    return (a / s) * dry / N.BAG_VOL_M3, (b / s) * dry, (c / s) * dry


def mortar_breakup(mortar_volume, ratio_str):
    parts = _ratio_tuple(ratio_str)
    s = sum(parts)
    dry = mortar_volume * N.MORTAR_DRY_FACTOR
    cement = (parts[0] / s) * dry / N.BAG_VOL_M3
    sand = (parts[1] / s) * dry
    return cement, sand


def plaster_breakup(area, thickness_mm, ratio_str):
    parts = _ratio_tuple(ratio_str)
    s = sum(parts)
    mortar = area * (thickness_mm / 1000.0)
    dry = mortar * N.PLASTER_DRY_FACTOR
    cement = (parts[0] / s) * dry / N.BAG_VOL_M3
    sand = (parts[1] / s) * dry
    return cement, sand


def masonry_breakup(volume, ratio_str, blocks_per_m3):
    """Brick/block + mortar breakup for `volume` m3 of finished masonry."""
    mortar_vol = volume * N.MORTAR_FRAC_IN_MASONRY
    cem, sand = mortar_breakup(mortar_vol, ratio_str)
    solid = volume - mortar_vol
    nos = solid * blocks_per_m3
    return nos, cem, sand


# ------------------------------------------------------------------ #
#  Item container                                                    #
# ------------------------------------------------------------------ #
class BOQ:
    def __init__(self, rates):
        self.rates = rates
        self.materials = {
            'cement_bags': 0.0, 'sand_m3': 0.0, 'aggregate_m3': 0.0,
            'steel_kg': 0.0, 'brick_no': 0.0, 'block_no': 0.0,
        }

    def add_materials(self, m):
        for k in self.materials:
            self.materials[k] += m.get(k, 0.0)

    def item(self, code, desc, unit, qty, rate_key=None, rate_override=None,
             mat=None):
        rate = rate_override if rate_override is not None else (
            self.rates[rate_key] if rate_key else 0)
        if mat:
            self.add_materials(mat)
        return {
            'code': code, 'desc': desc, 'unit': unit,
            'qty': round(qty, 3) if qty else 0,
            'rate': round(rate, 2),
            'amount': round(qty * rate, 2) if qty else 0,
        }


# ------------------------------------------------------------------ #
#  Main estimate                                                     #
# ------------------------------------------------------------------ #
def estimate(raw_inputs):
    inp = normalize_inputs(raw_inputs)
    R = inp['rates']
    boq = BOQ(R)

    # ---- derived geometry ----
    L, W = inp['footprint_length'], inp['footprint_width']
    fp_area = L * W                       # footprint (one floor)
    Nf = inp['floors_above']
    built_up = fp_area * Nf
    ext_perim = 2 * (L + W)
    col_sec = inp['column_b'] * inp['column_d'] / 1e6   # m2
    beam_sec = inp['beam_width'] * inp['beam_depth'] / 1e6
    slab_t = inp['slab_thickness'] / 1000.0
    grade = inp['concrete_grade']
    pcc_mix = inp['pcc_mix']
    mortar = inp['mortar_ratio']
    plaster = inp['plaster_ratio']
    ext_t = inp['external_wall_thickness'] / 1000.0
    int_t = inp['internal_wall_thickness'] / 1000.0
    op = inp['opening_ratio']
    is_brick = inp['wall_material'] in ('brick',)
    is_block = inp['wall_material'] in ('block', 'aac')
    blocks_per_m3 = 500 if is_brick else 44  # 400x200x200 AAC ~ 44/m3

    no_col = inp['grid_lines_x'] * inp['grid_lines_y']
    beam_len = inp['grid_lines_y'] * L + inp['grid_lines_x'] * W  # per floor grid

    cats = {}

    # ================================================================ #
    #  1. RCC STRUCTURAL WORK
    # ================================================================ #
    items = []
    items_mat = []
    # -- 1.1 Foundation concrete --
    if inp['foundation_type'] == 'isolated':
        exc = no_col * (inp['footing_length'] + 0.6) * (inp['footing_width'] + 0.6) * inp['footing_depth']
        pcc_v = no_col * inp['footing_length'] * inp['footing_width'] * 0.075
        foot_v = no_col * inp['footing_length'] * inp['footing_width'] * inp['footing_thickness']
        ped_v = no_col * col_sec * 0.6
        c, s, a = pcc_breakup(pcc_v, pcc_mix)
        items_mat.append({'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a})
        c, s, a = concrete_breakup(foot_v, grade)
        items_mat.append({'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a})
        c, s, a = concrete_breakup(ped_v, grade)
        items_mat.append({'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a})
        items.append(boq.item('1.1', 'PCC 1:4:8 in footings', 'cum', pcc_v, 'pcc_m3', mat=items_mat[0]))
        items.append(boq.item('1.2', 'RCC footings (isolated)', 'cum', foot_v, 'rcc_m3', mat=items_mat[1]))
        items.append(boq.item('1.3', 'RCC pedestal (footing to plinth)', 'cum', ped_v, 'rcc_m3', mat=items_mat[2]))
        foot_steel = foot_v * N.STEEL_RATIOS['footing'] * inp['steel_factor']
        ped_steel = ped_v * N.STEEL_RATIOS['pedestal'] * inp['steel_factor']
    else:  # raft approximation
        raft_v = fp_area * inp['footing_thickness'] * 1.4   # raft + beams allowance
        exc = (L + 1) * (W + 1) * inp['footing_depth']
        pcc_v = fp_area * 0.075
        c, s, a = pcc_breakup(pcc_v, pcc_mix)
        items_mat.append({'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a})
        c, s, a = concrete_breakup(raft_v, grade)
        items_mat.append({'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a})
        items.append(boq.item('1.1', 'PCC levelling course under raft', 'cum', pcc_v, 'pcc_m3', mat=items_mat[0]))
        items.append(boq.item('1.2', 'RCC raft foundation', 'cum', raft_v, 'rcc_m3', mat=items_mat[1]))
        foot_steel = raft_v * N.STEEL_RATIOS['raft'] * inp['steel_factor']
        ped_v = 0
        ped_steel = 0

    # -- 1.4 Columns --
    col_h = inp['floor_height'] * Nf
    col_v = no_col * col_sec * col_h
    c, s, a = concrete_breakup(col_v, grade)
    items.append(boq.item('1.4', 'RCC columns (plinth to roof)', 'cum', col_v, 'rcc_m3',
                          mat={'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a}))
    col_steel = col_v * N.STEEL_RATIOS['column'] * inp['steel_factor']

    # -- 1.5 Beams (plinth tie beam + floor beams) --
    plinth_beam_v = beam_len * beam_sec
    floor_beam_v = beam_len * beam_sec * Nf
    beam_total = plinth_beam_v + floor_beam_v
    c, s, a = concrete_breakup(beam_total, grade)
    items.append(boq.item('1.5', 'RCC beams (plinth, floor & roof tie beams)', 'cum', beam_total, 'rcc_m3',
                          mat={'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a}))
    beam_steel = beam_total * N.STEEL_RATIOS['beam'] * inp['steel_factor']

    # -- 1.6 Slabs --
    n_slabs = Nf + 1                      # floor/roof slabs + plinth slab
    slab_v = fp_area * slab_t * n_slabs
    c, s, a = concrete_breakup(slab_v, grade)
    items.append(boq.item('1.6', 'RCC slabs (suspended floor, roof & plinth)', 'cum', slab_v, 'rcc_m3',
                          mat={'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a}))
    slab_steel = slab_v * N.STEEL_RATIOS['slab'] * inp['steel_factor']

    # -- 1.7 Staircase --
    stair_v = 0.9 * Nf                    # ~0.9 m3/flight incl. landing
    c, s, a = concrete_breakup(stair_v, grade)
    items.append(boq.item('1.7', 'RCC staircase (waist slab, steps & landing)', 'cum', stair_v, 'rcc_m3',
                          mat={'cement_bags': c, 'sand_m3': s, 'aggregate_m3': a}))
    stair_steel = stair_v * N.STEEL_RATIOS['staircase'] * inp['steel_factor']

    # -- 1.8 Steel reinforcement (TMT) --
    measured = inp.get('measured_steel_kg')
    try:
        measured = float(measured) if measured not in (None, '') else None
    except (TypeError, ValueError):
        measured = None
    if measured and measured > 0:
        total_steel = measured
        steel_desc = 'TMT steel reinforcement (cut, bend, fix) — from Bar Bending Schedule'
    else:
        total_steel = foot_steel + ped_steel + col_steel + beam_steel + slab_steel + stair_steel
        steel_desc = 'TMT steel reinforcement (cut, bend, fix)'
    items.append(boq.item('1.8', steel_desc, 'kg', total_steel, 'steel_kg',
                          mat={'steel_kg': total_steel}))

    # -- 1.9 Shuttering (formwork) --
    sh_foot = no_col * 2 * (inp['footing_length'] + inp['footing_width']) * inp['footing_thickness']
    sh_col = no_col * 2 * (inp['column_b'] + inp['column_d']) / 1000.0 * col_h
    beam_perim = (2 * inp['beam_depth'] + inp['beam_width']) / 1000.0
    sh_beam = beam_perim * beam_len * (Nf + 1)
    sh_slab = fp_area * n_slabs
    sh_total = sh_foot + sh_col + sh_beam + sh_slab
    items.append(boq.item('1.9', 'Shuttering / formwork (RCC elements)', 'sqm', sh_total, 'shuttering_m2'))

    cats['1. RCC Structural Work'] = items

    # ================================================================ #
    #  2. CIVIL & EARTHWORK
    # ================================================================ #
    items = []
    backfill = exc - (pcc_v + foot_v + ped_v) if inp['foundation_type'] == 'isolated' else 0
    items.append(boq.item('2.1', 'Earthwork excavation in foundation', 'cum', exc, 'excavation_m3'))
    items.append(boq.item('2.2', 'Backfilling with excavated soil', 'cum', max(backfill, 0), 'backfill_m3'))
    plinth_fill = fp_area * inp['plinth_height'] * 0.85
    items.append(boq.item('2.3', 'Plinth filling with moorum/sand', 'cum', plinth_fill, 'moorum_m3'))
    soling = fp_area * 0.15
    items.append(boq.item('2.4', 'Brick/stone soling under plinth fill', 'cum', soling, 'soling_m3'))
    items.append(boq.item('2.5', 'Anti-termite treatment', 'sqm', built_up, 'antitermite_m2'))
    cats['2. Civil & Earthwork'] = items

    # ================================================================ #
    #  3. ARCHITECTURAL (Masonry & Joinery)
    # ================================================================ #
    items = []
    # external masonry (gross wall area minus openings)
    ext_area = ext_perim * inp['floor_height'] * Nf * (1 - op)
    ext_vol = ext_area * ext_t
    # internal masonry
    int_len = fp_area * inp['internal_wall_factor']
    int_area = int_len * inp['floor_height'] * Nf * (1 - op * 0.5)
    int_vol = int_area * int_t

    ext_rate_key = 'brickwork_m3' if is_brick else 'blockwork_m3'
    blk_rate_key = 'brickwork_m3' if is_brick else 'blockwork_m3'

    nos, c, s = masonry_breakup(ext_vol, mortar, blocks_per_m3)
    mat = {'cement_bags': c, 'sand_m3': s, 'brick_no' if is_brick else 'block_no': nos}
    items.append(boq.item('3.1', f'{inp["wall_material"].title()} masonry in external walls ({int(inp["external_wall_thickness"])}mm)',
                          'cum', ext_vol, ext_rate_key, mat=mat))
    nos, c, s = masonry_breakup(int_vol, mortar, blocks_per_m3)
    mat = {'cement_bags': c, 'sand_m3': s, 'brick_no' if is_brick else 'block_no': nos}
    items.append(boq.item('3.2', f'{inp["wall_material"].title()} masonry in internal partition walls ({int(inp["internal_wall_thickness"])}mm)',
                          'cum', int_vol, ext_rate_key, mat=mat))

    dpc_area = ext_perim * ext_t
    items.append(boq.item('3.3', 'Damp Proof Course (DPC) at plinth', 'sqm', dpc_area, 'dpc_m2'))

    door_frame = inp['no_of_doors'] * (2 * 2.1 + 0.9)   # rmt approx
    win_frame = inp['no_of_windows'] * (2 * 1.2 + 1.5)
    items.append(boq.item('3.4', 'Door frames (wooden/sections)', 'rmt', door_frame, 'door_frame_m'))
    items.append(boq.item('3.5', 'Window frames (wooden/aluminium)', 'rmt', win_frame, 'window_frame_m'))
    items.append(boq.item('3.6', 'Door shutters', 'nos', inp['no_of_doors'], 'door_shutter_no'))
    items.append(boq.item('3.7', 'Window shutters', 'nos', inp['no_of_windows'], 'window_shutter_no'))
    cats['3. Architectural (Masonry & Joinery)'] = items

    # ================================================================ #
    #  4. SANITARY & PLUMBING
    # ================================================================ #
    items = []
    nt, nk = inp['no_of_toilets'], inp['no_of_kitchens']
    # supply pipes (CPVC) and soil/waste (PVC)
    cpvc = nt * 12 + nk * 6 + Nf * inp['floor_height'] * 1.0    # risers
    pvc = nt * 7 + nk * 4 + Nf * inp['floor_height'] * 1.5
    items.append(boq.item('4.1', 'CPVC cold/hot water supply pipes incl. fittings', 'rmt', cpvc, 'cpvc_pipe_m'))
    items.append(boq.item('4.2', 'UPVC soil, waste & vent pipes incl. fittings', 'rmt', pvc, 'pvc_pipe_m'))
    items.append(boq.item('4.3', 'Water closet (WC) pan with cistern', 'nos', nt, 'wc_no'))
    items.append(boq.item('4.4', 'Wash basins', 'nos', nt, 'washbasin_no'))
    items.append(boq.item('4.5', 'Kitchen sinks (SS)', 'nos', nk, 'sink_no'))
    items.append(boq.item('4.6', 'Taps / mixtures', 'nos', nt * 3 + nk * 2, 'tap_no'))
    items.append(boq.item('4.7', 'Showers / health faucets', 'nos', nt, 'shower_no'))
    tank_cap = Nf * 1500
    items.append(boq.item('4.8', f'Overhead water tank (Sintex ~{int(tank_cap)} L)', 'nos', 1, 'tank_no'))
    if inp['has_septic']:
        sep_v = max(nt * 2.5, 4.0)
        items.append(boq.item('4.9', 'Septic tank (RCC) with cover', 'cum', sep_v, 'septic_m3'))
        items.append(boq.item('4.10', 'Soak pit (rubble masonry)', 'nos', 1, 'soakpit_no'))
    cats['4. Sanitary & Plumbing'] = items

    # ================================================================ #
    #  5. FINISHING WORK
    # ================================================================ #
    items = []
    # plaster areas
    int_plaster_walls = 2 * int_area + ext_area        # both faces of int walls + inner face of ext
    ceiling = fp_area * Nf
    ext_plaster = ext_area
    c, s = plaster_breakup(int_plaster_walls + ceiling, 12, plaster)
    items.append(boq.item('5.1', 'Internal wall & ceiling plaster 12mm', 'sqm', int_plaster_walls + ceiling,
                          'plaster_m2', mat={'cement_bags': c, 'sand_m3': s}))
    c, s = plaster_breakup(ext_plaster, 20, plaster)
    items.append(boq.item('5.2', 'External wall plaster 20mm', 'sqm', ext_plaster, 'plaster_m2',
                          mat={'cement_bags': c, 'sand_m3': s}))
    items.append(boq.item('5.3', f'Flooring - {inp["flooring_type"]}', 'sqm', built_up, 'flooring_m2'))
    dado = nt * 5.0 * 2.1 + nk * 6.0 * 0.6
    items.append(boq.item('5.4', 'Dado / wall tiling in toilet & kitchen', 'sqm', dado, 'dado_m2'))
    items.append(boq.item('5.5', 'Internal painting (primer + 2 coats)', 'sqm', int_plaster_walls + ceiling, 'painting_m2'))
    items.append(boq.item('5.6', 'External painting / texture', 'sqm', ext_plaster, 'painting_m2'))
    items.append(boq.item('5.7', 'Skirting', 'rmt', (int_len + ext_perim) * Nf, 'skirting_m'))
    items.append(boq.item('5.8', 'Roof waterproofing (brick bat coba / membrane)', 'sqm', fp_area, 'waterproofing_m2'))
    cats['5. Finishing Work'] = items

    # ---- subtotals ----
    grand = 0.0
    for name, itms in cats.items():
        sub = sum(i['amount'] for i in itms)
        grand += sub
        # attach subtotal
        cats[name] = itms

    # ---- miscellaneous allowance ----
    misc_amt = grand * inp['misc_percent'] / 100.0
    cats['6. Miscellaneous & Contingencies'] = [boq.item(
        '6.1', f'Miscellaneous & contingencies ({inp["misc_percent"]}%)', 'L.S.', misc_amt,
        rate_override=1.0)]
    grand += misc_amt

    # ---- material summary ----
    mat_summary = boq.materials

    # ---- nice formatting ----
    return {
        'project': {
            'name': inp['project_name'],
            'client': inp['client'],
            'location': inp['location'],
            'seismic_zone': inp['seismic_zone'],
        },
        'inputs': inp,
        'categories': cats,
        'grand_total': round(grand, 2),
        'built_up_area_m2': round(built_up, 2),
        'built_up_area_sqft': round(built_up * 10.7639, 2),
        'cost_per_sqft': round(grand / (built_up * 10.7639), 2) if built_up else 0,
        'cost_per_sqm': round(grand / built_up, 2) if built_up else 0,
        'material_summary': {k: round(v, 2) for k, v in mat_summary.items()},
        'mat_rates': inp['mat_rates'],
    }


if __name__ == '__main__':
    # quick smoke test
    import json
    res = estimate({})
    print('Grand total: NPR', f"{res['grand_total']:,.0f}")
    print('Built-up area:', res['built_up_area_m2'], 'm2 (', res['built_up_area_sqft'], 'sqft )')
    print('Cost/sqft: NPR', f"{res['cost_per_sqft']:,.0f}")
    print('Materials:', json.dumps(res['material_summary'], indent=2))
    for cat, items in res['categories'].items():
        sub = sum(i['amount'] for i in items)
        print(f'  {cat}: NPR {sub:,.0f}  ({len(items)} items)')
