"""Bar Bending Schedule helpers (IS 2502). Unit weight w = d^2/162.2 kg/m.
Geometry in mm; lengths returned in metres so weight comes out in kg."""


def unit_weight(dia):
    return (dia * dia) / 162.2


def straight_weight(count, length_m, dia):
    return count * length_m * unit_weight(dia)


def num_along(breadth_mm, cover_mm, spacing_mm):
    if spacing_mm <= 0:
        return 1
    return max(1, int(round((breadth_mm - 2 * cover_mm) / spacing_mm)) + 1)


def layer_weight(L_mm, W_mm, cover_mm, dia, spacing_mm):
    count = num_along(W_mm, cover_mm, spacing_mm)
    return straight_weight(count, (L_mm - 2 * cover_mm) / 1000.0, dia)


def mesh_weight(L_mm, W_mm, cover_mm, dia_x, sp_x, dia_y, sp_y):
    return layer_weight(L_mm, W_mm, cover_mm, dia_x, sp_x) + layer_weight(W_mm, L_mm, cover_mm, dia_y, sp_y)


def stirrup_length(b_mm, d_mm, cover_mm, tie_dia):
    a = b_mm - 2 * cover_mm
    c = d_mm - 2 * cover_mm
    return (2 * (a + c) + 20 * tie_dia) / 1000.0


def num_stirrups(height_mm, spacing_mm):
    if spacing_mm <= 0:
        return 1
    return max(2, int(round(height_mm / spacing_mm)) + 1)


def parse_nodia(spec):
    out = []
    if not spec:
        return out
    for p in str(spec).replace(' ', '').split(','):
        if not p.strip():
            continue
        for sep in ('-', 'x', 'X', '*', '/'):
            if sep in p:
                a, b = p.split(sep, 1)
                try:
                    out.append((int(float(a)), int(float(b))))
                except ValueError:
                    pass
                break
    return out


def parse_diaspacing(spec):
    if not spec:
        return None
    p = str(spec).replace(' ', '')
    for sep in ('-', 'x', 'X', '*', '/'):
        if sep in p:
            a, b = p.split(sep, 1)
            try:
                return (int(float(a)), int(float(b)))
            except ValueError:
                return None
    return None


import re as _re


def parse_tie(spec):
    if not spec:
        return (8, 100, 100)
    nums = [int(float(x)) for x in _re.findall(r'\d+', str(spec))]
    if len(nums) >= 3:
        return (nums[0], nums[1], nums[2])
    if len(nums) == 2:
        return (nums[0], nums[1], nums[1])
    if len(nums) == 1:
        return (nums[0], 100, 100)
    return (8, 100, 100)


def spiral_length(pile_dia_mm, pile_len_mm, pitch_mm, cover_mm):
    core = pile_dia_mm - 2 * cover_mm
    turns = pile_len_mm / pitch_mm if pitch_mm else 0
    return 3.14159 * core / 1000.0 * turns
