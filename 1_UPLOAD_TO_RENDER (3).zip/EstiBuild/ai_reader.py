"""AI-powered drawing reader using GPT-4o-mini vision.
Only called when user clicks "Use AI" button — the free text extraction
runs first by default. AI is for GRAPHICAL drawings (floor plans, visual
schedules) that the text extractor can't read.

Cost: ~Rs 0.15 per drawing page (GPT-4o-mini vision API)
Set OPENAI_API_KEY env var to enable.
"""
import os
import io
import base64
import json

try:
    import pymupdf as fitz
except Exception:
    import fitz

OPENAI_KEY = os.environ.get('OPENAI_API_KEY', '')


def is_ai_enabled():
    return bool(OPENAI_KEY)


def pdf_to_images(pdf_bytes, max_pages=6, dpi=200):
    """Convert PDF pages to base64 images for the vision API."""
    images = []
    try:
        doc = fitz.open(stream=pdf_bytes, filetype='pdf')
        for i, page in enumerate(doc):
            if i >= max_pages:
                break
            pix = page.get_pixmap(dpi=dpi)
            img_bytes = pix.tobytes('png')
            b64 = base64.b64encode(img_bytes).decode('utf-8')
            images.append(b64)
        doc.close()
    except Exception:
        pass
    return images


def ai_extract_structural(pdf_bytes):
    """Send structural drawing pages to GPT-4o-mini, get structured data back."""
    if not is_ai_enabled():
        return None, 'AI not configured. Set OPENAI_API_KEY on the server.'

    images = pdf_to_images(pdf_bytes, max_pages=4, dpi=200)
    if not images:
        return None, 'Could not read PDF images.'

    import urllib.request

    prompt = """You are a structural engineer reading construction drawings.
Analyze these drawing images and extract ALL structural data as JSON.
Return ONLY valid JSON with this exact structure:

{
  "concrete_grade": "M25",
  "floor_height_mm": 3000,
  "floors": 3,
  "footings": [{"id":"F1","kind":"isolated","count":10,"L":1800,"W":1800,"t":450,"depth":1500,"mesh":"12-150","ped_b":300,"ped_d":450,"ped_h":600,"ped_main":"8-16","ped_tie":"8-150"}],
  "columns": [{"id":"C1","count":6,"b":300,"d":450,"main":"20-16,16-16,12-16","tie":"8-100-200"}],
  "beams": [{"id":"B1","kind":"primary","count":14,"b":230,"d":450,"length":4000,"top":"3-16","bottom":"3-16","tie":"8-100-150"}],
  "slabs": [{"id":"S1","area":108,"t":125,"mesh":"10-150"}],
  "bbs_total_steel_kg": 9500
}

Rules:
- Extract exact dimensions from the drawings (in mm)
- Steel format: "no-dia" for bars, "dia-spacing" for mesh, "dia-conf-mid" for ties
- If you see a Bar Bending Schedule, use the exact steel weight
- If a value is not visible, omit that field (don't guess)
- Return ONLY the JSON, no other text"""

    messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
    for img_b64 in images:
        messages[0]["content"].append({
            "type": "image_url",
            "image_url": {"url": f"data:image/png;base64,{img_b64}"}
        })

    body = json.dumps({
        "model": "gpt-4o-mini",
        "messages": messages,
        "max_tokens": 2000,
        "temperature": 0.1
    }).encode()

    req = urllib.request.Request(
        'https://api.openai.com/v1/chat/completions',
        data=body,
        headers={'Authorization': f'Bearer {OPENAI_KEY}', 'Content-Type': 'application/json'}
    )

    try:
        resp = urllib.request.urlopen(req, timeout=60)
        result = json.loads(resp.read())
        text = result['choices'][0]['message']['content']
        # extract JSON from response
        if '{' in text:
            start = text.index('{')
            end = text.rindex('}') + 1
            data = json.loads(text[start:end])
            return data, None
        return None, 'AI response did not contain valid data.'
    except Exception as e:
        return None, f'AI error: {str(e)[:100]}'


def ai_extract_schedule(pdf_bytes, spec):
    """Send architectural/sanitary/electrical drawing pages to AI, get field values."""
    if not is_ai_enabled():
        return None, 'AI not configured. Set OPENAI_API_KEY on the server.'

    images = pdf_to_images(pdf_bytes, max_pages=6, dpi=200)
    if not images:
        return None, 'Could not read PDF images.'

    import urllib.request

    # Build a prompt that knows the module's tables and fields
    table_info = []
    for t in spec['tables']:
        fields = [f"{f['name']}({f['type']})" for f in t['fields']]
        table_info.append(f"Table '{t['id']}': fields = {', '.join(fields)}")

    prompt = f"""You are reading construction drawings/schedules for estimation.
Module tables to fill:
{chr(10).join(table_info)}

Analyze the drawing images and extract data. Return ONLY valid JSON:
{{"tables": {{"table_id": [{{"field_name": value, ...}}, ...], ...}}}}

Rules:
- Match each extracted item to the correct table
- Use numeric values for number fields, text for text fields
- Only include fields you can read from the drawing
- Steel: "no-dia" format, "dia-spacing" for mesh
- Return ONLY JSON, no explanation."""

    messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
    for img_b64 in images:
        messages[0]["content"].append({
            "type": "image_url",
            "image_url": {"url": f"data:image/png;base64,{img_b64}"}
        })

    body = json.dumps({
        "model": "gpt-4o-mini",
        "messages": messages,
        "max_tokens": 3000,
        "temperature": 0.1
    }).encode()

    req = urllib.request.Request(
        'https://api.openai.com/v1/chat/completions',
        data=body,
        headers={'Authorization': f'Bearer {OPENAI_KEY}', 'Content-Type': 'application/json'}
    )

    try:
        resp = urllib.request.urlopen(req, timeout=90)
        result = json.loads(resp.read())
        text = result['choices'][0]['message']['content']
        if '{' in text:
            start = text.index('{')
            end = text.rindex('}') + 1
            data = json.loads(text[start:end])
            return data, None
        return None, 'AI response did not contain valid data.'
    except Exception as e:
        return None, f'AI error: {str(e)[:100]}'
