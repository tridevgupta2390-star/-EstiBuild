import io, json, re

def _sc(D):
    """Staircase from DEFAULT_SCHEDULE — handles both list and dict formats."""
    sc = D.get('staircase', {})
    if isinstance(sc, list):
        return sc[0] if sc else {}
    return sc


"""Fillable input templates (HTML + Excel) for every module + parsers for uploads.

Flow:
  1. User downloads a fillable HTML/Excel template from the app (or gets an AI-drafted
     pre-filled HTML from the AI reader).
  2. User fills it offline in any browser - with add-row buttons for extra items.
  3. User clicks 'Download Data File' -> gets a .json.
  4. User uploads the .json (or the filled .xlsx) to the module -> form auto-fills
     exactly (zero AI cost, deterministic).

The exported JSON mirrors the app's internal schedule structure.
"""
import io
import json

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

HDR_FILL = PatternFill('solid', fgColor='1F3B57')
HDR_FONT = Font(color='FFFFFF', bold=True)


# ------------------------------------------------------------------ HTML templates
def _inp(name, val, typ='text', options=None, extra=''):
    v = _esc('' if val is None else str(val))
    if options:
        opts = ''.join(f'<option{" selected" if str(o) == v else ""}>{_esc(o)}</option>' for o in options)
        return f'<select name="{name}" {extra}>{opts}</select>'
    return f'<input type="{typ}" name="{name}" value="{v}" {extra}>'


def _esc(s):
    return str(s if s is not None else '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def module_html(spec, prefill=None):
    """Standalone fillable HTML for a schedule module. prefill = dict with
    scalars/tables (e.g. AI draft) - defaults from the spec otherwise."""
    prefill = prefill or {}
    pf_tables = prefill.get('tables') or {}
    pf_scal = prefill.get('scalars') or {}
    sid = spec['id']
    title = spec['title']
    parts = []
    parts.append(f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>{_esc(title)} - EstiBuild Input</title>
<style>
*{{box-sizing:border-box;font-family:'Segoe UI',Arial,sans-serif}}
body{{margin:0;background:#f4f7fa;color:#223}}
.top{{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:16px 22px}}
.top h1{{margin:0;font-size:19px}} .top p{{margin:4px 0 0;font-size:12px;opacity:.85}}
.wrap{{max-width:1250px;margin:16px auto;padding:0 14px}}
.card{{background:#fff;border:1px solid #d7e0ea;border-radius:10px;padding:14px 16px;margin-bottom:14px}}
h2{{font-size:14px;color:#1F3B57;margin:0 0 10px;text-transform:uppercase;letter-spacing:.4px}}
label{{display:block;font-size:10px;font-weight:600;color:#556;margin:4px 0 1px;text-transform:uppercase}}
input,select{{width:100%;padding:6px 7px;border:1px solid #d7e0ea;border-radius:6px;font-size:12px;background:#fffdf8}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
th{{background:#1F3B57;color:#fff;padding:6px;text-align:left;font-size:10.5px}}
td{{padding:4px 5px;border-bottom:1px solid #e6edf4}}
.add{{background:#2E86ab;color:#fff;border:none;padding:7px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;margin-top:6px}}
.del{{background:#c0392b;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}}
.export{{display:block;width:100%;background:#1f9d55;color:#fff;border:none;padding:15px;border-radius:10px;font-size:16px;font-weight:800;cursor:pointer;margin:8px 0 30px}}
.note{{background:#fff8e1;border:1px solid #f0d479;border-radius:8px;padding:10px;font-size:12px;color:#7a6411}}
.row{{display:grid;gap:8px}} .cols{{display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}}
</style></head><body>
<div class="top"><h1>🏗️ EstiBuild - {_esc(title)} Input Form</h1>
<p>Fill the schedules below, click '+ Add' for more items, then press the green button to download your data file. Upload that file in EstiBuild → auto-fill → Calculate.</p></div>
<div class="wrap">
<div class="note"><b>How it works:</b> fill in your browser (no internet needed) → <b>⬇ Download Data File</b> → in EstiBuild open this module → upload the downloaded <b>.json</b> file. Lengths in metres, areas in m².</div>
""")

    # scalars card
    parts.append('<div class="card"><h2>Project Details</h2><div class="cols">')
    for s in spec['scalars']:
        val = pf_scal.get(s['name'], s.get('default', ''))
        if s['type'] == 'select':
            parts.append(f'<div><label>{_esc(s["label"])}</label>{_inp(s["name"], val, options=s.get("options"))}</div>')
        else:
            parts.append(f'<div><label>{_esc(s["label"])}</label>{_inp(s["name"], val)}</div>')
    parts.append('</div>')
    # labour rates
    if spec.get('labour'):
        from modules.common import LABOUR_RATES, LABOUR_LABELS
        parts.append('<h2 style="margin-top:12px">Labour Rates (per day)</h2><div class="cols">')
        for k in spec['labour']:
            val = (prefill.get('labour_rates') or {}).get(k, LABOUR_RATES.get(k, ''))
            parts.append(f'<div><label>{_esc(LABOUR_LABELS.get(k, k))}</label>{_inp("lr_" + k, val)}</div>')
        parts.append('</div>')
    parts.append('</div>')

    # tables
    for t in spec['tables']:
        tid = t['id']
        rows = pf_tables.get(tid) or t.get('default_rows') or []
        parts.append(f'<div class="card"><h2>{_esc(t["title"])}</h2>')
        if t.get('hint'):
            parts.append(f'<p style="font-size:11px;color:#7a8693;margin:0 0 8px">{_esc(t["hint"])}</p>')
        parts.append(f'<table data-table="{tid}"><thead><tr>')
        parts.append('<th style="width:34px"></th>')
        for f in t['fields']:
            parts.append(f'<th>{_esc(f["label"])}</th>')
        parts.append('</tr></thead><tbody>')
        for r in rows:
            parts.append('<tr>')
            parts.append('<td><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
            for f in t['fields']:
                val = r.get(f['name'], '')
                if f['type'] == 'select':
                    parts.append(f'<td>{_inp(f["name"], val, options=f.get("options"))}</td>')
                else:
                    parts.append(f'<td>{_inp(f["name"], val)}</td>')
            parts.append('</tr>')
        parts.append('</tbody></table>')
        parts.append(f'<button class="add" onclick="addRow(\'{tid}\')">+ { _esc(t.get("add_label", "Add row"))}</button></div>')

    # hidden row templates + JS
    parts.append(f'<div id="tpls" style="display:none">')
    for t in spec['tables']:
        tid = t['id']
        parts.append(f'<template id="tpl_{tid}"><tr>')
        parts.append('<td><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
        for f in t['fields']:
            val = ''
            if f['type'] == 'select':
                parts.append(f'<td>{_inp(f["name"], val, options=f.get("options"))}</td>')
            else:
                parts.append(f'<td>{_inp(f["name"], val)}</td>')
        parts.append('</tr></template>')
    parts.append('</div>')

    parts.append(f"""
<button class="export" onclick="exportData()">⬇ Download Data File for EstiBuild (.json)</button>
</div>
<script>
const MODULE = "{sid}";
function addRow(tid) {{
  const tpl = document.getElementById('tpl_' + tid);
  document.querySelector('table[data-table="' + tid + '"] tbody').appendChild(tpl.content.cloneNode(true));
}}
function exportData() {{
  const data = {{module: MODULE, scalars: {{}}, labour_rates: {{}}, tables: {{}}}};
  document.querySelectorAll('.card').forEach(card => {{
    card.querySelectorAll('[name]').forEach(inp => {{
      const n = inp.name;
      if (n.startsWith('lr_')) data.labour_rates[n.slice(3)] = inp.value;
      else if (!inp.closest('table')) data.scalars[n] = inp.value;
    }});
  }});
  document.querySelectorAll('table[data-table]').forEach(tb => {{
    const tid = tb.dataset.table;
    data.tables[tid] = [];
    tb.querySelectorAll('tbody tr').forEach(tr => {{
      const row = {{}};
      tr.querySelectorAll('[name]').forEach(inp => row[inp.name] = inp.value);
      if (Object.values(row).some(v => String(v).trim() !== '')) data.tables[tid].push(row);
    }});
  }});
  const blob = new Blob([JSON.stringify(data, null, 2)], {{type: 'application/json'}});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = MODULE + '_input.json';
  document.body.appendChild(a); a.click(); a.remove();
}}
</script></body></html>""")
    return ''.join(parts)


# ------------------------------------------------------------------ structural template
STRUCT_TABLES = [
    ('footings', 'Footings / Piles',
     [('id', 'Mark'), ('kind', 'Type (isolated/strap/combined/raft/pile/strip)'), ('count', 'Nos'),
      ('L', 'L (mm)'), ('W', 'W (mm)'), ('t', 't (mm)'), ('depth', 'Depth GL (mm)'),
      ('soling_t', 'Soling t'), ('mesh', 'Mesh'), ('ped_b', 'Ped b'), ('ped_d', 'Ped d'),
      ('ped_h', 'Ped h'), ('ped_main', 'Ped main'), ('ped_tie', 'Ped tie'),
      ('strap_len', 'Strap len'), ('strap_b', 'Strap b'), ('strap_d', 'Strap d'),
      ('strap_top', 'Strap top'), ('strap_bot', 'Strap bot'), ('strap_tie', 'Strap tie'),
      ('pile_dia', 'Pile dia'), ('pile_len', 'Pile len'), ('pile_no', 'Pile no'),
      ('pile_main', 'Pile main'), ('spiral', 'Spiral'), ('cap_L', 'Cap L'), ('cap_W', 'Cap W'),
      ('cap_t', 'Cap t'), ('cap_mesh', 'Cap mesh'), ('grade', 'Grade'), ('soil', 'Soil')]),
    ('columns', 'Columns',
     [('id', 'Mark'), ('count', 'Nos'), ('b', 'b (mm)'), ('d', 'd (mm)'),
      ('main', 'Main bars/floor'), ('tie', 'Tie'), ('grade', 'Grade')]),
    ('beams', 'Beams',
     [('id', 'Mark'), ('kind', 'Type'), ('count', 'Nos'), ('b', 'b (mm)'), ('d', 'd (mm)'),
      ('length', 'Length (mm)'), ('top', 'Top'), ('bottom', 'Bottom'), ('extra_top', 'Extra top'), ('side', 'Side bars (opt)'),
      ('tie', 'Stirrup'), ('grade', 'Grade')]),
    ('slabs', 'Slabs',
     [('id', 'Mark'), ('area', 'Area m²'), ('t', 't (mm)'), ('type', 'Type'),
      ('mesh', 'Bottom mesh'), ('top_mesh', 'Top mesh (optional)'), ('grade', 'Grade')]),
    ('shearwalls', 'Shear Walls',
     [('id', 'Mark'), ('length', 'Length (mm)'), ('t', 't (mm)'), ('height', 'Height (mm)'),
      ('vertical', 'Vertical'), ('horizontal', 'Horizontal')]),
    ('retwalls', 'Retaining / Trench Walls',
     [('id', 'Mark'), ('length', 'Length (mm)'), ('stem_t', 'Stem t'), ('stem_h', 'Stem h'),
      ('base_b', 'Base b'), ('base_t', 'Base t'), ('vert', 'Vert'), ('horiz', 'Horiz'), ('base_mesh', 'Base mesh')]),
    ('tanks', 'Water Tanks & Sumps',
     [('id', 'Mark'), ('kind', 'Type (overhead tank/underground sump)'), ('L', 'L int (mm)'),
      ('W', 'W int (mm)'), ('depth', 'Depth (mm)'), ('wall_t', 'Wall t'), ('base_t', 'Base t'),
      ('cover_t', 'Cover t'), ('wall_mesh', 'Wall mesh'), ('base_mesh', 'Base mesh'), ('grade', 'Grade')]),
    ('ramps', 'Ramps',
     [('id', 'Mark'), ('length', 'Length incl (mm)'), ('width', 'Width (mm)'), ('thickness', 'Thickness (mm)'),
      ('mesh', 'Mesh'), ('side_wall_h', 'Side wall h (0=none)'), ('side_wall_t', 'Side wall t'), ('grade', 'Grade')]),
    ('lifts', 'Lift Pits & Machine Rooms',
     [('id', 'Mark'), ('L', 'Plan L (mm)'), ('W', 'Plan W (mm)'), ('pit_depth', 'Pit depth (mm)'),
      ('core_height', 'Core height (mm)'), ('wall_t', 'Wall t'), ('base_t', 'Base t'),
      ('mesh', 'Mesh'), ('grade', 'Grade')]),
    ('others', 'Water Retaining & Misc Items',
     [('item', 'Item (waterproofing/bitumen/expansion joint/water stop/dewatering/curing)'),
      ('qty', 'Qty (sqm/rmt/cum)')]),
]

STRUCT_SCALARS = [
    ('project_name', 'Project name', 'text'), ('location', 'Location', 'text'),
    ('concrete_grade', 'Concrete grade', 'select', ['M20', 'M25', 'M30', 'M35', 'M40', 'M15']),
    ('pcc_mix', 'PCC mix', 'text'), ('floor_height', 'Floor height (mm)', 'number'),
    ('floors_above', 'Floors above ground', 'number'), ('confinement_lo', 'Confinement zone lo (mm)', 'number'),
    ('cover_footing', 'Cover footing', 'number'), ('cover_column', 'Cover column', 'number'),
    ('cover_beam', 'Cover beam', 'number'), ('cover_slab', 'Cover slab', 'number'),
    ('concrete_pumping', 'Concrete pumping', 'select', ['none', 'boom pump', 'line pump']),
    ('rate_rcc_m3', 'RCC rate /m³', 'number'), ('rate_pcc_m3', 'PCC rate /m³', 'number'),
    ('rate_excavation_m3', 'Excavation rate /m³', 'number'), ('rate_backfill_m3', 'Backfill rate /m³', 'number'),
    ('rate_soling_m3', 'Soling rate /m³', 'number'), ('rate_shuttering_m2', 'Shuttering rate /m²', 'number'),
    ('rate_steel_kg', 'Steel rate /kg', 'number'),
    ('lr_mason', 'Mason /day', 'number'), ('lr_mazdoor', 'Mazdoor /day', 'number'),
    ('lr_steel_fab', 'Steel fabricator /day', 'number'),
    ('sc_type', 'Staircase type', 'select', ['dog-legged', 'open-well', 'straight flight', 'spiral', 'cantilever']),
    ('sc_flights', 'Stair flights', 'number'), ('sc_run', 'Stair run (mm)', 'number'),
    ('sc_tread', 'Tread (mm)', 'number'), ('sc_riser', 'Riser (mm)', 'number'),
    ('sc_width', 'Stair width (mm)', 'number'), ('sc_waist', 'Waist (mm)', 'number'),
    ('sc_mesh', 'Stair mesh', 'text'), ('sc_landings', 'Landings (nos)', 'number'),
    ('sc_landing_L', 'Landing L (mm)', 'number'), ('sc_landing_W', 'Landing W (mm)', 'number'),
    ('sc_landing_t', 'Landing t (mm)', 'number'),
]


def structural_html(prefill=None):
    """Fillable HTML for the RCC Structure module."""
    prefill = prefill or {}
    pf_tables = prefill.get('tables') or {}
    pf_scal = {k: v for k, v in (prefill.get('scalars') or {}).items()}
    from structural.engine import DEFAULT_SCHEDULE as D
    defaults = {
        'project_name': D['project_name'], 'location': D['location'], 'concrete_grade': D['concrete_grade'],
        'pcc_mix': D['pcc_mix'], 'floor_height': D['floor_height'], 'floors_above': D['floors_above'],
        'confinement_lo': D['confinement_lo'], 'cover_footing': D['cover_footing'],
        'cover_column': D['cover_column'], 'cover_beam': D['cover_beam'], 'cover_slab': D['cover_slab'],
        'concrete_pumping': 'none',
        'sc_type': _sc(D).get('type', 'dog-legged'), 'sc_flights': _sc(D)['flights'],
        'sc_run': _sc(D)['run'], 'sc_tread': _sc(D).get('tread', 300),
        'sc_riser': _sc(D).get('riser', 150), 'sc_width': _sc(D)['width'],
        'sc_waist': _sc(D)['waist'], 'sc_mesh': _sc(D)['mesh'],
        'sc_landings': _sc(D).get('landings', 0), 'sc_landing_L': _sc(D).get('landing_L', 1200),
        'sc_landing_W': _sc(D).get('landing_W', 1200), 'sc_landing_t': _sc(D).get('landing_t', 150),
        'lr_mason': 1200, 'lr_mazdoor': 800, 'lr_steel_fab': 1400,
    }
    for k, v in D['rates'].items():
        defaults['rate_' + k] = v
    defaults.update(pf_scal)
    parts = []
    parts.append(f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>RCC Structure - EstiBuild Input</title>
<style>
*{{box-sizing:border-box;font-family:'Segoe UI',Arial,sans-serif}}
body{{margin:0;background:#f4f7fa;color:#223}}
.top{{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:16px 22px}}
.top h1{{margin:0;font-size:19px}} .top p{{margin:4px 0 0;font-size:12px;opacity:.85}}
.wrap{{max-width:1250px;margin:16px auto;padding:0 14px}}
.card{{background:#fff;border:1px solid #d7e0ea;border-radius:10px;padding:14px 16px;margin-bottom:14px}}
h2{{font-size:14px;color:#1F3B57;margin:0 0 10px;text-transform:uppercase;letter-spacing:.4px}}
label{{display:block;font-size:10px;font-weight:600;color:#556;margin:4px 0 1px;text-transform:uppercase}}
input,select{{width:100%;padding:6px 7px;border:1px solid #d7e0ea;border-radius:6px;font-size:12px;background:#fffdf8}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
th{{background:#1F3B57;color:#fff;padding:6px;text-align:left;font-size:10.5px}}
td{{padding:4px 5px;border-bottom:1px solid #e6edf4}}
.add{{background:#2E86ab;color:#fff;border:none;padding:7px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;margin-top:6px}}
.del{{background:#c0392b;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}}
.export{{display:block;width:100%;background:#1f9d55;color:#fff;border:none;padding:15px;border-radius:10px;font-size:16px;font-weight:800;cursor:pointer;margin:8px 0 30px}}
.note{{background:#fff8e1;border:1px solid #f0d479;border-radius:8px;padding:10px;font-size:12px;color:#7a6411}}
.cols{{display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(160px,1fr))}}
</style></head><body>
<div class="top"><h1>🏗️ EstiBuild - RCC Structure Input Form</h1>
<p>Fill the member schedules, '+ Add' for more items, then download the data file and upload it in EstiBuild.</p></div>
<div class="wrap">
<div class="note">BBS is auto-generated from these inputs. Dimensions in mm, areas in m².</div>
<div class="card"><h2>Project & Parameters (incl. rates, staircase)</h2><div class="cols">""")
    for s in STRUCT_SCALARS:
        name, label, typ = s[0], s[1], s[2]
        val = defaults.get(name, '')
        if typ == 'select':
            parts.append(f'<div><label>{_esc(label)}</label>{_inp(name, val, options=s[3])}</div>')
        else:
            parts.append(f'<div><label>{_esc(label)}</label>{_inp(name, val, typ="number" if typ == "number" else "text")}</div>')
    parts.append('</div></div>')

    from structural.engine import DEFAULT_SCHEDULE as D
    for tid, ttitle, fields in STRUCT_TABLES:
        rows = pf_tables.get(tid) or D.get(tid, [])
        parts.append(f'<div class="card"><h2>{_esc(ttitle)}</h2>')
        parts.append(f'<table data-table="{tid}"><thead><tr><th style="width:34px"></th>')
        for fname, flabel in fields:
            parts.append(f'<th>{_esc(flabel)}</th>')
        parts.append('</tr></thead><tbody>')
        for r in rows:
            parts.append('<tr><td><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
            for fname, flabel in fields:
                parts.append(f'<td>{_inp(fname, r.get(fname, ""))}</td>')
            parts.append('</tr>')
        parts.append('</tbody></table>')
        parts.append(f'<button class="add" onclick="addRow(\'{tid}\')">+ Add</button></div>')

    parts.append('<div id="tpls" style="display:none">')
    for tid, ttitle, fields in STRUCT_TABLES:
        parts.append(f'<template id="tpl_{tid}"><tr><td><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
        for fname, flabel in fields:
            parts.append(f'<td>{_inp(fname, "")}</td>')
        parts.append('</tr></template>')
    parts.append('</div>')
    parts.append("""
<button class="export" onclick="exportData()">⬇ Download Data File for EstiBuild (.json)</button>
</div>
<script>
const MODULE = "structural";
function addRow(tid) {
  const tpl = document.getElementById('tpl_' + tid);
  document.querySelector('table[data-table="' + tid + '"] tbody').appendChild(tpl.content.cloneNode(true));
}
function exportData() {
  const data = {module: MODULE, scalars: {}, tables: {}};
  document.querySelectorAll('.card [name]').forEach(inp => {
    if (!inp.closest('table')) data.scalars[inp.name] = inp.value;
  });
  document.querySelectorAll('table[data-table]').forEach(tb => {
    const tid = tb.dataset.table;
    data.tables[tid] = [];
    tb.querySelectorAll('tbody tr').forEach(tr => {
      const row = {};
      tr.querySelectorAll('[name]').forEach(inp => row[inp.name] = inp.value);
      if (Object.values(row).some(v => String(v).trim() !== '')) data.tables[tid].push(row);
    });
  });
  const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'structural_input.json';
  document.body.appendChild(a); a.click(); a.remove();
}
</script></body></html>""")
    return ''.join(parts)


# ------------------------------------------------------------------ Excel templates
def module_xlsx(spec):
    """Excel input template: headers + example rows + DROPDOWN LISTS on every
    select/suggest column (options live on a hidden OPTIONS sheet so users
    offline always know the valid spellings that unlock the right rates)."""
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet('READ ME')
    ws['A1'] = f'{spec["title"]} - EstiBuild Input Template'
    ws['A1'].font = Font(bold=True, size=13)
    lines = ['Fill each sheet (one row per item). Sheet name = table.',
             'Columns with choices have DROPDOWNS - pick from the list so the',
             'correct rate applies. Typing a different spelling may use default rates.',
             'Save and upload this .xlsx in EstiBuild - the form auto-fills.',
             'Lengths in metres, areas in m², thickness in mm.']
    for i, ln in enumerate(lines, 3):
        ws.cell(row=i, column=1).value = ln
    ws.column_dimensions['A'].width = 90
    opt_ws = None
    opt_col = 0
    for t in spec['tables']:
        ws = wb.create_sheet(t['id'][:31])
        for c, f in enumerate(t['fields'], 1):
            cell = ws.cell(row=1, column=c)
            cell.value = f['label']
            cell.fill = HDR_FILL
            cell.font = HDR_FONT
        for r, row in enumerate(t.get('default_rows') or [], 2):
            for c, f in enumerate(t['fields'], 1):
                ws.cell(row=r, column=c).value = row.get(f['name'], '')
        for c in range(1, len(t['fields']) + 1):
            ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = 16
        # dropdowns for choice columns (select = strict, suggest = warning only)
        for c, f in enumerate(t['fields'], 1):
            opts = f.get('options') or []
            if not opts or f.get('type') not in ('select', 'suggest'):
                continue
            if opt_ws is None:
                opt_ws = wb.create_sheet('OPTIONS')
                opt_ws.sheet_state = 'hidden'
            opt_col += 1
            ol = get_column_letter(opt_col)
            opt_ws.cell(row=1, column=opt_col, value=f"{t['id']}.{f['name']}")
            for i, o in enumerate(opts, 2):
                opt_ws.cell(row=i, column=opt_col, value=str(o))
            dv = DataValidation(type='list',
                                formula1=f"OPTIONS!${ol}$2:${ol}${len(opts) + 1}",
                                allow_blank=True)
            if f.get('type') == 'suggest':
                dv.errorStyle = 'warning'   # suggestions, not restrictions
            ws.add_data_validation(dv)
            fl = ws.cell(row=1, column=c).column_letter
            dv.add(f'{fl}2:{fl}400')
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def structural_xlsx():
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet('READ ME')
    ws['A1'] = 'RCC Structure - EstiBuild Input Template'
    ws['A1'].font = Font(bold=True, size=13)
    for i, ln in enumerate(['Fill each sheet (one row per member type).',
                            'Dimensions in mm, areas in m².', 'Upload this .xlsx in EstiBuild RCC Structure.'], 3):
        ws.cell(row=i, column=1).value = ln
    ws.column_dimensions['A'].width = 80
    for tid, ttitle, fields in STRUCT_TABLES:
        ws = wb.create_sheet(tid[:31])
        for c, (fname, flabel) in enumerate(fields, 1):
            cell = ws.cell(row=1, column=c)
            cell.value = flabel
            cell.fill = HDR_FILL
            cell.font = HDR_FONT
        for c in range(1, len(fields) + 1):
            ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = 15
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ------------------------------------------------------------------ upload parsers
class FormDict(dict):
    def getlist(self, key):
        v = self.get(key)
        return v if isinstance(v, list) else ([v] if v is not None else [])


def html_to_data(html_text):
    """Parse our fillable HTML template server-side (works for AI drafts and any
    saved template where values are in the value= attributes). Mirrors the
    browser's exportData() JS: returns the same dict as the .json export."""
    import re as _re
    import html as _htmlmod

    def _val(tag):
        m = _re.search(r'value="([^"]*)"', tag)
        return _htmlmod.unescape(m.group(1)) if m else ''

    data = {'scalars': {}, 'labour_rates': {}, 'tables': {}}
    # tables: table[data-table=X] -> rows
    for tm in _re.finditer(r'<table data-table="(\w+)">(.*?)</table>', html_text, _re.S):
        tid, inner = tm.group(1), tm.group(2)
        tbody = inner.split('<tbody>')[1].split('</tbody>')[0] if '<tbody>' in inner else inner
        rows = []
        for rm in _re.finditer(r'<tr>(.*?)</tr>', tbody, _re.S):
            rec = {}
            for im in _re.finditer(r'<(input|select)\b([^>]*)>', rm.group(1)):
                nm = _re.search(r'name="([^"]+)"', im.group(2))
                if nm:
                    rec[nm.group(1)] = _val(im.group(2))
            for sm in _re.finditer(r'<select name="([^"]+)"[^>]*>(.*?)</select>', rm.group(1), _re.S):
                mm = _re.search(r'<option selected>([^<]*)</option>', sm.group(2)) or _re.search(r'<option>([^<]*)</option>', sm.group(2))
                if mm:
                    rec[sm.group(1)] = _htmlmod.unescape(mm.group(1))
            if any(str(v).strip() for v in rec.values()):
                rows.append(rec)
        data['tables'][tid] = rows
    # scalars + labour: named inputs outside tables (before the first data-table)
    head = html_text.split('<table data-table=')[0]
    for im in _re.finditer(r'<(input|select)\b([^>]*)>', head):
        nm = _re.search(r'name="([^"]+)"', im.group(2))
        if not nm:
            continue
        name = nm.group(1)
        if name.startswith('lr_'):
            data['labour_rates'][name[3:]] = _val(im.group(2))
        else:
            data['scalars'][name] = _val(im.group(2))
    # selects in the head section (selected option)
    for sm in _re.finditer(r'<select name="([^"]+)"[^>]*>(.*?)</select>', head, _re.S):
        mm = _re.search(r'<option selected>([^<]*)</option>', sm.group(2)) or _re.search(r'<option>([^<]*)</option>', sm.group(2))
        if mm:
            name = sm.group(1)
            v = _htmlmod.unescape(mm.group(1))
            if name.startswith('lr_'):
                data['labour_rates'][name[3:]] = v
            else:
                data['scalars'][name] = v
    return data


def json_to_schedule(data, spec):
    """Template JSON -> schedule dict (reuses the app's own parse for validation)."""
    import schedule_fw
    form = FormDict()
    for k, v in (data.get('scalars') or {}).items():
        form[k] = str(v)
    for k, v in (data.get('labour_rates') or {}).items():
        form['lr_' + k] = str(v)
    for t in spec['tables']:
        rows = (data.get('tables') or {}).get(t['id']) or []
        form[t['id'] + '_row'] = [str(i) for i in range(len(rows))]
        for i, r in enumerate(rows):
            for f in t['fields']:
                if f['name'] in r and r[f['name']] is not None and str(r[f['name']]).strip() != '':
                    form[f"{t['id']}_{f['name']}_{i}"] = str(r[f['name']])
    return schedule_fw.parse(form, spec)


def json_to_structural(data):
    """Template JSON -> structural schedule dict (reuses parse_struct_form)."""
    import structural_ui
    form = FormDict()
    for k, v in (data.get('scalars') or {}).items():
        form[k] = str(v)
    for tid, _t, fields in STRUCT_TABLES:
        rows = (data.get('tables') or {}).get(tid) or []
        prefix = {'footings': 'f', 'columns': 'c', 'beams': 'b', 'slabs': 's',
                  'shearwalls': 'w', 'retwalls': 'rw', 'tanks': 't', 'ramps': 'r',
                  'lifts': 'l', 'others': 'o'}[tid]
        form[prefix + '_row'] = [str(i) for i in range(len(rows))]
        for i, r in enumerate(rows):
            for fname, _fl in fields:
                if fname in r and r[fname] is not None and str(r[fname]).strip() != '':
                    form[f'{prefix}_{fname}_{i}'] = str(r[fname])
    return structural_ui.parse_form(form)


def xlsx_to_schedule(bytes_data, spec):
    """Filled Excel template -> schedule dict."""
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(bytes_data))
    data = {'module': spec['id'], 'scalars': {}, 'tables': {}}
    label_to_name = {}
    for t in spec['tables']:
        label_to_name[t['id']] = {f['label'].lower(): f['name'] for f in t['fields']}
    for ws in wb.worksheets:
        name = ws.title.lower()
        tid = None
        for t in spec['tables']:
            if t['id'] == name or t['title'].lower() == name:
                tid = t['id']
                break
        if not tid:
            continue
        headers = {}
        for c in range(1, ws.max_column + 1):
            v = ws.cell(row=1, column=c).value
            if v:
                headers[c] = label_to_name[tid].get(str(v).lower())
        rows = []
        for r in range(2, ws.max_row + 1):
            rec = {}
            empty = True
            for c, fname in headers.items():
                if not fname:
                    continue
                v = ws.cell(row=r, column=c).value
                if v is not None and str(v).strip() != '':
                    rec[fname] = v
                    empty = False
            if not empty:
                rows.append(rec)
        if rows:
            data['tables'][tid] = rows
    return json_to_schedule(data, spec)


def xlsx_to_structural(bytes_data):
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(bytes_data))
    data = {'module': 'structural', 'scalars': {}, 'tables': {}}
    for ws in wb.worksheets:
        name = ws.title.lower()
        tid = None
        fields = None
        for tid_, _t, fields_ in STRUCT_TABLES:
            if tid_ == name:
                tid, fields = tid_, fields_
                break
        if not tid:
            continue
        headers = {}
        for c in range(1, ws.max_column + 1):
            v = ws.cell(row=1, column=c).value
            if v:
                for fname, flabel in fields:
                    if flabel.lower() == str(v).lower():
                        headers[c] = fname
                        break
        rows = []
        for r in range(2, ws.max_row + 1):
            rec = {}
            empty = True
            for c, fname in headers.items():
                if not fname:
                    continue
                v = ws.cell(row=r, column=c).value
                if v is not None and str(v).strip() != '':
                    rec[fname] = v
                    empty = False
            if not empty:
                rows.append(rec)
        if rows:
            data['tables'][tid] = rows
    return json_to_structural(data)
