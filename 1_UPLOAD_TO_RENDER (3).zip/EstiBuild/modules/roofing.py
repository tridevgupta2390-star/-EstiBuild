"""Roofing & Truss module — geometry-driven professional estimation.

Enter building geometry (length, span, pitch, overhang, roof form) and the system
auto-derives: truss count, sloping roof area, purlin runs (from section+spacing),
ridge length, eaves gutters, downpipes and hip capping — all clearly labelled
"(auto)". Manual table rows always override the auto items.

Truss self-weight uses span rules-of-thumb used by pro estimators
(angle ~ span/4 + 5 kg/m2 of plan area; tubular ~ 0.7x; king/queen post lighter),
with a per-row kg override for exact member takeoffs (table 2).
"""
import math
from modules.common import NUM, ro, Estimate
from modules.steel import SECTION_UW, SECTION_LIST


def _truss_kgm2(ttype, span):
    s = span if span and span > 0 else 10.0
    tl = ttype.lower()
    if 'tubular' in tl:
        return (s / 4.0 + 5.0) * 0.7
    if 'king post' in tl:
        return s / 5.0 + 4.0
    if 'queen post' in tl:
        return s / 4.5 + 4.5
    if 'fan' in tl:
        return s / 4.0 + 4.5
    if 'saw-tooth' in tl:
        return s / 4.0 + 6.0
    if 'bowstring' in tl or 'arched' in tl:
        return s / 5.0 + 5.0
    if 'attic' in tl:
        return s / 3.5 + 7.0
    if 'scissors' in tl:
        return s / 4.0 + 5.5
    if 'parallel chord' in tl:
        return s / 4.0 + 5.0
    if 'howe' in tl:
        return s / 4.0 + 6.0
    if 'north-light' in tl:
        return s / 4.0 + 7.0
    if 'mono-pitch' in tl:
        return s / 4.0 + 4.0
    if 'space frame' in tl:
        return 25.0
    return s / 4.0 + 5.0


TRUSS_TYPES = ['King post truss', 'Queen post truss', 'Fink truss (angle)', 'Pratt truss (angle)',
               'Howe truss (angle)', 'Warren truss (angle)', 'Fan truss', 'North-Light truss',
               'Mono-pitch truss', 'Saw-tooth truss', 'Bowstring/arched truss', 'Attic truss (room-in-roof)',
               'Scissors truss', 'Parallel chord truss',
               'Fink truss (tubular)', 'Pratt truss (tubular)', 'Warren truss (tubular)',
               'Space frame', 'Timber truss']

# ---------------------------------------------------------------- rates (NPR base, composite)
TRUSS = 195       # /kg fabricated + erected
PURLIN = 175      # /kg
BATT = {'steel angle batten': 160, 'timber batten': 240, 'tube batten': 175,
        'runner channel': 165}                      # per rmt
SHEET = {'GI corrugated 0.4mm': 700, 'GI corrugated 0.5mm': 850, 'Colour-coated PPGL 0.5mm': 1080,
         'Colour-coated PPGL 0.6mm': 1250, 'Aluminium standing seam': 1650,
         'Polycarbonate 6mm': 2400, 'FRP skylight sheet': 1150, 'Fibre cement (AC) sheet': 780,
         'Stone-coated roofing tile': 1950, 'PUF insulated sandwich 50mm': 2650,
         'Clay Mangalore tile (with battens)': 1450}  # per sqm incl. laps & fixing
ACC = {'ridge capping': 550, 'eaves gutter (GI)': 700, 'downpipe 110mm': 900,
       'flashing / apron': 600, 'barge board cover': 550, 'drip edge': 480,
       'valley gutter': 850, 'ridge roll (tile roof)': 650,
       'snow guard / bracket (per m)': 650, 'gutter bracket (per m)': 250,
       'hip capping (per m)': 600}   # per rmt
FAST = {'self-drilling screw + washer': 25, 'stitching screw': 15, 'roof clip': 45,
        'anchor hook / bracket': 85, 'sealing tape (per m)': 40,
        'tile clip (steel)': 35, 'tile riser / batten holder': 45}  # per nos / rmt
INSUL = {'building paper / underlay': 55, 'aluminium foil insulation': 95,
         'glass wool 50mm': 380, 'rockwool 50mm': 520, 'PU foam spray': 750,
         'vapour barrier': 110}                       # per sqm
VENT = {'turbo ventilator 24"': 5800, 'turbo ventilator 14"': 3800,
        'ridge ventilator (per m)': 1200, 'FRP sky light panel': 1200,
        'polycarbonate dome 600mm': 4800, 'power roof exhaust fan': 16000}  # nos / sqm
TIMBER = {'rafter (sal wood)': 2400, 'purlin (sal wood)': 2200, 'batten (sal wood)': 2000,
          'board / sheathing': 2600}                  # per cft

SCREW_PER_SQM = 6       # auto roof screws per sqm of sheeting
GUSSET_PCT = 0.08       # auto gusset + weld allowance on truss steel
PRIMER_PER_KG = 6.0     # auto primer on truss + purlin steel
DOWNPIPE_SPACING = 9.0  # one downpipe per ~9m of gutter (global practice 8-10m)
PURLIN_SECTIONS = ['Z 150x2.0', 'C 150x2.0', 'Z 200x2.5', 'C 200x2.5', 'Z 250x3.0', 'C 250x3.0',
                   'ISA 75x75x8', 'ISA 100x100x8', 'ISA 100x100x10']


def _uw(sec, row=None):
    if row is not None and NUM(row.get('uw')) > 0:
        return NUM(row.get('uw'))
    return SECTION_UW.get(str(sec).strip(), 25.0)


def _geometry(scal):
    """Roof geometry -> dict of derived lengths/areas (all metres / m2)."""
    BL = NUM(scal.get('bldg_length'))          # building length (m)
    S = NUM(scal.get('bldg_span'))             # roof span (m)
    pitch = NUM(scal.get('pitch_deg'), 25.0)   # degrees
    ovh = NUM(scal.get('overhang'), 0.6)       # eaves overhang (m)
    form = scal.get('roof_form', 'gable')
    if BL <= 0 or S <= 0:
        return {'ok': False, 'form': form, 'pitch': pitch}
    cp = max(math.cos(math.radians(pitch)), 0.1)
    if form == 'mono-pitch':
        slope_len = (S + ovh) / cp
        roof_area = (BL + 2 * ovh) * slope_len
        plan_area = (BL + 2 * ovh) * (S + ovh)
        ridge_len = BL + 2 * ovh
        gutter_len = BL + 2 * ovh              # low eaves side
        hip_len = 0.0
    elif form == 'hip':
        slope_len = (S / 2.0 + ovh) / cp
        roof_area = (BL + S + 2 * ovh) * slope_len          # perimeter/2 x slope
        plan_area = (BL + 2 * ovh) * (S + 2 * ovh)
        ridge_len = max(BL - S, 0.0)
        gutter_len = 2 * (BL + S) + 8 * ovh
        hip_len = 4 * (S / 2.0 * math.sqrt(2) / cp)         # 4 hips, 45 deg plan
    else:  # gable
        slope_len = (S / 2.0 + ovh) / cp
        roof_area = 2 * (BL + 2 * ovh) * slope_len
        plan_area = (BL + 2 * ovh) * (S + 2 * ovh)
        ridge_len = BL + 2 * ovh
        gutter_len = 2 * (BL + 2 * ovh)
        hip_len = 0.0
    return {'ok': True, 'form': form, 'pitch': pitch, 'BL': BL, 'S': S, 'ovh': ovh,
            'slope_len': slope_len, 'roof_area': roof_area, 'plan_area': plan_area,
            'ridge_len': ridge_len, 'gutter_len': gutter_len, 'hip_len': hip_len}


def estimate(sched):
    T = sched['tables']
    scal = sched.get('scalars', {})
    geo = _geometry(scal)
    est = Estimate({})
    truss_kg = 0.0
    member_kg = 0.0
    purlin_kg = 0.0
    sheet_area = 0.0
    n_trusses = 0

    # ---- 1. trusses (count auto = building length / spacing + 1) ----
    for r in T['trusses']:
        span = NUM(r.get('span')) or geo.get('S', 0)
        spc = NUM(r.get('spacing'))
        n = NUM(r.get('count'))
        if not n and geo['ok'] and spc:
            n = int(BL_DIV(geo['BL'], spc)) + 1
        if not (span and spc and n):
            continue
        ttype = r.get('type', 'Fink truss (angle)')
        area_per = span * spc
        ov = NUM(r.get('wt_override'))
        kg_per = ov if ov > 0 else _truss_kgm2(ttype, span) * area_per
        w = kg_per * n
        cnt_note = 'auto' if not NUM(r.get('count')) else str(int(n))
        est.item('1. Roof Trusses', f"{r.get('id','T')} - {ttype}, span {span:g}m @ {spc:g}m c/c (x{n:g} {cnt_note})",
                 'kg', round(w, 1), rate=ro(r, TRUSS),
                 take=(n, span, spc, None, round(kg_per / area_per if area_per else 0, 2)),
                 note='nos x span x spacing x kg/m² (roof area x self-weight) = kg')
        truss_kg += w
        n_trusses += int(n)

    # ---- 2. truss member detail (member-by-member takeoff) ----
    for r in T['members']:
        L, n = NUM(r.get('length')), NUM(r.get('count'))
        if not (L and n):
            continue
        sec = r.get('section', 'ISA 75x75x8')
        w = _uw(sec, r) * L * n
        est.item('2. Truss Member Detail', f"{r.get('tid','')} {r.get('member','chord')} - {sec} ({L}m x {n})",
                 'kg', round(w, 1), rate=ro(r, TRUSS),
                 take=(n, L, None, None, round(_uw(sec, r), 2)), note='nos x length x unit wt (kg/m) = kg')
        member_kg += w

    # ---- 3. purlins (manual rows; AUTO from geometry if table empty) ----
    for r in T['purlins']:
        L = NUM(r.get('length'))
        if not L:
            continue
        sec = r.get('section', 'Z 200x2.5')
        w = _uw(sec, r) * L
        est.item('3. Purlins & Girts', f"{sec} - {r.get('id','')} ({L:,.0f} rmt run)", 'kg', round(w, 1),
                 rate=ro(r, PURLIN))
        purlin_kg += w
    if not T['purlins'] and geo['ok'] and scal.get('purlin_section'):
        psec = scal.get('purlin_section', 'Z 200x2.5')
        pspc = NUM(scal.get('purlin_spacing'), 1.5) or 1.5
        rows_side = int(math.ceil(geo['slope_len'] / pspc)) + 1
        if geo['form'] == 'mono-pitch':
            run = rows_side * (geo['BL'] + 2 * geo['ovh'])
        else:
            run = 2 * rows_side * (geo['BL'] + 2 * geo['ovh'])
        w = run * _uw(psec)
        est.item('3. Purlins & Girts',
                 f"{psec} (auto: {rows_side} rows/side @ {pspc:g}m x {(geo['BL'] + 2 * geo['ovh']):g}m = {run:,.0f} rmt)",
                 'kg', round(w, 1), rate=PURLIN,
                 take=(1, round(run, 1), None, None, round(_uw(psec), 2)),
                 note='total run length x unit wt (kg/m) = kg')
        purlin_kg += w

    # ---- 4. battens ----
    for r in T['battens']:
        L = NUM(r.get('length'))
        if not L:
            continue
        it = r.get('item', 'steel angle batten')
        est.item('4. Battens & Runners', f"{it} - {r.get('spec','')}".strip(' -'), 'rmt', L,
                 rate=ro(r, BATT.get(it, 200)))

    # ---- 5. sheeting (manual; AUTO sloping area from geometry if empty) ----
    for r in T['sheeting']:
        a = NUM(r.get('area'))
        if not a:
            continue
        mat = r.get('material', 'Colour-coated PPGL 0.5mm')
        est.item('5. Roof Covering', f"{mat} (incl. laps & fixing) - {r.get('id','')}".strip(' -'),
                 'sqm', a, rate=ro(r, SHEET.get(mat, 1000)))
        est.mat('roof_sheet_m2', 'Roof Sheeting', a, 'sqm', SHEET.get(mat, 1000))
        sheet_area += a
    if not T['sheeting'] and geo['ok'] and geo['roof_area'] > 0:
        mat = 'Colour-coated PPGL 0.5mm'
        a = round(geo['roof_area'], 1)
        est.item('5. Roof Covering', f"{mat} (auto sloping area from geometry: {a:,.0f} m² @ {geo['pitch']:g}° pitch)",
                 'sqm', a, rate=SHEET[mat])
        est.mat('roof_sheet_m2', 'Roof Sheeting', a, 'sqm', SHEET[mat])
        sheet_area += a

    # ---- 6. accessories (manual rows + AUTO ridge/gutter/downpipe/hip from geometry) ----
    have = {str(r.get('item', '')).lower() for r in T['accessories']}
    for r in T['accessories']:
        L = NUM(r.get('length'))
        if not L:
            continue
        it = r.get('item', 'ridge capping')
        est.item('6. Ridge, Gutters & Flashing', f"{it} - {r.get('spec','')}".strip(' -'), 'rmt', L,
                 rate=ro(r, ACC.get(it, 600)), take=((NUM(r.get('count'),1) or 1), L, None, None), note='running length')
    if geo['ok']:
        if geo['ridge_len'] > 0 and not any('ridge' in h for h in have):
            est.item('6. Ridge, Gutters & Flashing',
                     f"ridge capping (auto from geometry: {geo['ridge_len']:g} rmt)", 'rmt',
                     round(geo['ridge_len'], 1), rate=ACC['ridge capping'])
        if geo['hip_len'] > 0 and not any('hip' in h for h in have):
            est.item('6. Ridge, Gutters & Flashing',
                     f"hip capping (per m) (auto from geometry: {geo['hip_len']:g} rmt)", 'rmt',
                     round(geo['hip_len'], 1), rate=ACC['hip capping (per m)'])
        if geo['gutter_len'] > 0 and not any('gutter' in h and 'valley' not in h for h in have):
            est.item('6. Ridge, Gutters & Flashing',
                     f"eaves gutter (GI) (auto from geometry: {geo['gutter_len']:g} rmt)", 'rmt',
                     round(geo['gutter_len'], 1), rate=ACC['eaves gutter (GI)'])
        if not any('downpipe' in h for h in have) and geo['gutter_len'] > 0:
            n_dp = int(math.ceil(geo['gutter_len'] / DOWNPIPE_SPACING))
            est.item('6. Ridge, Gutters & Flashing',
                     f"downpipe 110mm (auto @ 1 per {DOWNPIPE_SPACING:g}m gutter = {n_dp} nos)", 'nos',
                     n_dp, rate=ACC['downpipe 110mm'])

    # ---- 7. fasteners (manual + AUTO from sheeting) ----
    for r in T['fasteners']:
        q = NUM(r.get('qty'))
        if not q:
            continue
        it = r.get('item', 'self-drilling screw + washer')
        unit = 'rmt' if 'tape' in it else 'nos'
        est.item('7. Roof Fasteners', it, unit, q, rate=ro(r, FAST.get(it, 25)), take=(q, None, None, None), note='quantity')
    if sheet_area > 0:
        auto_screws = round(sheet_area * SCREW_PER_SQM)
        est.item('7. Roof Fasteners', f'self-drilling screw + washer (auto @ {SCREW_PER_SQM}/m² of sheeting)',
                 'nos', auto_screws, rate=FAST['self-drilling screw + washer'])

    # ---- 8. insulation ----
    for r in T['insulation']:
        a = NUM(r.get('area'))
        if not a:
            continue
        t = r.get('type', 'glass wool 50mm')
        est.item('8. Insulation & Underlay', t, 'sqm', a, rate=ro(r, INSUL.get(t, 300)),
                 take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))

    # ---- 9. ventilators & skylights ----
    for r in T['vents']:
        q = NUM(r.get('qty'))
        if not q:
            continue
        it = r.get('item', 'turbo ventilator 24"')
        unit = 'sqm' if 'panel' in it else ('rmt' if 'ridge vent' in it else 'nos')
        est.item('9. Ventilators & Skylights', it, unit, q, rate=ro(r, VENT.get(it, 4000)), take=(q, None, None, None), note='quantity')

    # ---- 10. timber ----
    for r in T['timber']:
        q = NUM(r.get('qty'))
        if not q:
            continue
        it = r.get('item', 'rafter (sal wood)')
        est.item('10. Timber Roofing', f"{it} - {r.get('spec','')}".strip(' -'), 'cft', q,
                 rate=ro(r, TIMBER.get(it, 2200)), take=(q, None, None, None), note='cft volume')
        est.mat('timber_cft', 'Timber (Sal)', q, 'cft', 2200)

    # ---- AUTO-DERIVED from truss system ----
    frame_kg = truss_kg + member_kg + purlin_kg
    if frame_kg > 0:
        est.item('2A. Auto: Truss Connections', f'gusset plates + site welds allowance ({GUSSET_PCT*100:.0f}% of truss steel)',
                 'kg', round(frame_kg * GUSSET_PCT, 1), rate=PLATE_RATE,
                 take=(1, round(frame_kg, 1), GUSSET_PCT, None), note='frame steel x gusset allowance %')
        est.item('2B. Auto: Frame Protection', f'red-oxide primer 2 coats on truss + purlin steel (auto)',
                 'kg', round(frame_kg, 1), rate=PRIMER_PER_KG,
                 take=(1, round(frame_kg, 1), None, None), note='truss + member + purlin steel')
        est.mat('roof_steel_kg', 'Roof Steel (trusses+purlins)', frame_kg * 1.08, 'kg', 185)

    # ---- labour ----
    tn = (frame_kg * 1.08) / 1000.0
    fab_d = round(tn * 2.5, 0); weld_d = round(tn * 1.5, 0)
    erect_d = round(tn * 2 + sheet_area * 0.03, 0)
    paint_d = round(tn * 1.0, 0); help_d = round((fab_d + weld_d + erect_d + paint_d) * 1.2, 0)
    kpis = []
    if geo['ok']:
        kpis += [('Roof plan area', f"{geo['plan_area']:,.0f} m²"),
                 ('Sloping area', f"{geo['roof_area']:,.0f} m²"),
                 ('Pitch', f"{geo['pitch']:g}°")]
    kpis += [('Trusses', f"{n_trusses} nos"), ('Truss steel', f"{truss_kg/1000:,.2f} t"),
             ('Purlins', f"{purlin_kg/1000:,.2f} t")]
    if sheet_area > 0:
        kpis.append(('Cost / m² roof', f"{est.grand / sheet_area:,.0f}"))
    proj = {'name': sched['scalars'].get('project_name', ''), 'location': sched['scalars'].get('location', '')}
    res = est.result(project=proj, kpis=kpis)
    from modules.common import LABOUR_RATES as _LR
    _lrd = sched.get('labour_rates') or {}
    res['labour_rates'] = {k: _lrd.get(k) or _LR[k] for k in ['steel_fab', 'welder', 'erector', 'painter', 'helper']}
    res['labour'] = {
        'steel_fab_days': int(fab_d), 'welder_days': int(weld_d), 'erector_days': int(erect_d),
        'painter_days': int(paint_d), 'helper_days': int(help_d),
        'total_days': int(fab_d + weld_d + erect_d + paint_d + help_d),
    }
    return res


def BL_DIV(bl, spc):
    return math.floor(bl / spc)


PLATE_RATE = 165

SPEC = {
    'id': 'roofing', 'title': 'Roofing & Truss', 'color': '#c0392b', 'icon': '🏭',
    'intro': ('Enter building geometry (length, span, pitch, overhang, roof form) — truss count, sloping '
              'roof area, purlin runs, ridge, gutters, downpipes & hip capping are AUTO-derived. 19 truss '
              'types from King post to space frame, member-level takeoff, sheeting, insulation, ventilators.'),
    'upload_guide': [
        'Roof plan / building dimensions: length, span, eaves overhang, roof pitch',
        'Truss schedule (T1, T2...) with type & span - count auto = length / spacing + 1',
        'Purlin section & spacing (Z/C/angle) - quantity auto-computed from geometry',
        'Sheeting spec (GI/PPGL/tile/sandwich) + accessories - gutters/ridge auto',
    ],
    'upload_note': 'Leave tables empty to use the auto-derived (auto) quantities from geometry - or add manual rows to override.',
    'labour': ['steel_fab', 'welder', 'erector', 'painter', 'helper'],
    'scalars': [
        {'name': 'project_name', 'label': 'Project name', 'type': 'text', 'default': 'Roofing & Truss Estimate'},
        {'name': 'location', 'label': 'Location', 'type': 'text', 'default': 'Kathmandu'},
        {'name': 'bldg_length', 'label': 'Building length (m)', 'type': 'number', 'default': 30},
        {'name': 'bldg_span', 'label': 'Roof span (m)', 'type': 'number', 'default': 12},
        {'name': 'pitch_deg', 'label': 'Roof pitch (degrees)', 'type': 'number', 'default': 25},
        {'name': 'overhang', 'label': 'Eaves overhang (m)', 'type': 'number', 'default': 0.6},
        {'name': 'roof_form', 'label': 'Roof form', 'type': 'select', 'default': 'gable',
         'options': ['gable', 'hip', 'mono-pitch']},
        {'name': 'purlin_section', 'label': 'Purlin section (auto)', 'type': 'select', 'default': 'Z 200x2.5',
         'options': PURLIN_SECTIONS},
        {'name': 'purlin_spacing', 'label': 'Purlin spacing (m)', 'type': 'number', 'default': 1.5},
    ],
    'tables': [
        {'id': 'trusses', 'title': '1. Roof Trusses (T1, T2, ... by type & span)',
         'hint': 'weight auto = span rule x span x spacing; count auto = bldg length / spacing + 1; override with exact kg',
         'add_label': 'add truss type',
         'fields': [
             {'name': 'id', 'label': 'Truss mark', 'type': 'text'},
             {'name': 'type', 'label': 'Truss type', 'type': 'suggest', 'options': TRUSS_TYPES},
             {'name': 'span', 'label': 'Span (m, blank=geo)', 'type': 'number'},
             {'name': 'spacing', 'label': 'Spacing (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos (blank=auto)', 'type': 'number'},
             {'name': 'wt_override', 'label': 'kg/truss (blank=auto)', 'type': 'number'},
         ],
         'default_rows': [
             {'id': 'T1', 'type': 'Fink truss (angle)', 'span': 12, 'spacing': 5, 'count': ''},
             {'id': 'T2', 'type': 'King post truss', 'span': 6, 'spacing': 4, 'count': ''},
         ]},
        {'id': 'members', 'title': '2. Truss Member Detail (optional exact takeoff)',
         'hint': 'chords & webs member-by-member — skip if using span estimate above',
         'add_label': 'add member',
         'fields': [
             {'name': 'tid', 'label': 'Truss', 'type': 'text'},
             {'name': 'member', 'label': 'Member', 'type': 'select', 'default': 'top chord',
              'options': ['top chord', 'bottom chord', 'diagonal web', 'vertical web', 'rafter tie']},
             {'name': 'section', 'label': 'Section', 'type': 'suggest', 'options': SECTION_LIST},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
             {'name': 'uw', 'label': 'kg/m (blank=auto)', 'type': 'number'},
         ],
         'default_rows': []},
        {'id': 'purlins', 'title': '3. Purlins & Girts (auto from geometry if empty)',
         'hint': 'add manual runs to override the auto quantity', 'add_label': 'add purlin run',
         'fields': [
             {'name': 'id', 'label': 'Mark', 'type': 'text'},
             {'name': 'section', 'label': 'Section', 'type': 'suggest',
              'options': [s for s in SECTION_LIST if s[:1] in 'ZC' or 'ISA' in s]},
             {'name': 'length', 'label': 'Total run (m)', 'type': 'number'},
             {'name': 'uw', 'label': 'kg/m (blank=auto)', 'type': 'number'},
         ],
         'default_rows': []},
        {'id': 'battens', 'title': '4. Battens & Runners', 'add_label': 'add batten',
         'fields': [
             {'name': 'item', 'label': 'Type', 'type': 'select', 'default': 'steel angle batten',
              'options': sorted(BATT.keys())},
             {'name': 'spec', 'label': 'Size', 'type': 'text'},
             {'name': 'length', 'label': 'Length (rmt)', 'type': 'number'},
         ],
         'default_rows': [
             {'item': 'steel angle batten', 'spec': 'ISA 50x50x6', 'length': 260},
         ]},
        {'id': 'sheeting', 'title': '5. Roof Covering / Sheeting (auto sloping area if empty)',
         'hint': 'rate per sqm incl. laps, screws & fixing', 'add_label': 'add sheeting',
         'fields': [
             {'name': 'id', 'label': 'Zone', 'type': 'text'},
             {'name': 'material', 'label': 'Material', 'type': 'suggest', 'options': sorted(SHEET.keys())},
             {'name': 'area', 'label': 'Area (m²)', 'type': 'number'},
         ],
         'default_rows': []},
        {'id': 'accessories', 'title': '6. Ridge, Gutters & Flashing (auto if empty)',
         'hint': 'ridge / gutters / downpipes / hips auto-derived from geometry', 'add_label': 'add accessory',
         'fields': [
             {'name': 'item', 'label': 'Item', 'type': 'suggest', 'options': sorted(ACC.keys())},
             {'name': 'spec', 'label': 'Spec', 'type': 'text'},
             {'name': 'length', 'label': 'Length (rmt)', 'type': 'number'},
         ],
         'default_rows': [
             {'item': 'flashing / apron', 'spec': 'parapet/pipes', 'length': 18},
         ]},
        {'id': 'fasteners', 'title': '7. Roof Fasteners (screws auto-added from sheeting)',
         'add_label': 'add fastener',
         'fields': [
             {'name': 'item', 'label': 'Item', 'type': 'suggest', 'options': sorted(FAST.keys())},
             {'name': 'qty', 'label': 'Qty (nos/rmt)', 'type': 'number'},
         ],
         'default_rows': [
             {'item': 'roof clip', 'qty': 120},
         ]},
        {'id': 'insulation', 'title': '8. Insulation & Underlay', 'add_label': 'add insulation',
         'fields': [
             {'name': 'type', 'label': 'Type', 'type': 'select', 'default': 'glass wool 50mm',
              'options': sorted(INSUL.keys())},
             {'name': 'area', 'label': 'Area (m²)', 'type': 'number'},
         ],
         'default_rows': [
             {'type': 'building paper / underlay', 'area': 420},
         ]},
        {'id': 'vents', 'title': '9. Ventilators & Skylights', 'add_label': 'add ventilator',
         'fields': [
             {'name': 'item', 'label': 'Item', 'type': 'suggest', 'options': sorted(VENT.keys())},
             {'name': 'qty', 'label': 'Qty', 'type': 'number'},
         ],
         'default_rows': [
             {'item': 'turbo ventilator 24"', 'qty': 6},
         ]},
        {'id': 'timber', 'title': '10. Timber Roofing (optional)', 'add_label': 'add timber item',
         'fields': [
             {'name': 'item', 'label': 'Item', 'type': 'select', 'default': 'rafter (sal wood)',
              'options': sorted(TIMBER.keys())},
             {'name': 'spec', 'label': 'Size', 'type': 'text'},
             {'name': 'qty', 'label': 'Qty (cft)', 'type': 'number'},
         ],
         'default_rows': []},
    ],
}

PDF_KEYWORDS = ['roof', 'truss', 'purlin', 'batten', 'sheeting', 'gutter', 'ridge',
                'flashing', 'downpipe', 'ventilator', 'insulation', 'fink', 'pratt', 'howe',
                'king post', 'queen post', 'pitch', 'overhang']
