"""Combined Architecture & Finishing module. Masonry auto-deducts openings."""
from modules.common import Estimate, NUM, ro, masonry_breakup, plaster_breakup

WALL = {'brick': (9500, 500), 'block': (11500, 44), 'aac': (11500, 50), 'stone': (18000, 90)}
FILL = {'earth filling (compacted)': 350, 'murum filling': 450, 'sand filling': 950,
        'PCC bed 1:4:8 (100mm)': 9500, 'hardcore stone packing': 1200}
PART = {'gypsum board partition 50mm (double skin)': 1650, 'gypsum board partition 100mm': 1950,
        'cement board partition': 2100, 'WPC partition': 2400,
        'glass partition (aluminium frame)': 4800, 'PVC partition panel': 1400,
        'acoustic partition panel': 3200}
PLASTER = {'internal wall 12mm': 320, 'internal wall 15mm': 380, 'external wall 20mm': 420, 'ceiling': 300,
           'soffit (stair)': 350, 'sponge finish': 380, 'sand faced': 480, 'stone grit': 550, 'waterproof (toilet/bsmnt)': 500, 'gypsum (machine applied)': 380, 'polymer modified': 550, 'drywall (gypsum board)': 600,
    'stone pointing (flush)': 180, 'stone pointing (raked)': 200, 'stone pointing (v-groove)': 220}
FLOOR = {'vitrified tile': 1800, 'double charged tile': 2200, 'glazed ceramic': 1500, 'marble': 3200, 'italian marble': 5500,
         'granite': 3800, 'kota stone': 1800, 'sandstone': 1600, 'wooden laminate': 2600, 'engineered wood': 2800,
         'solid wood': 4500, 'vinyl': 1500, 'epoxy': 2200, 'terrazzo': 1200, 'IPS': 800, 'anti-skid tile': 1700, 'terrazzo in-situ': 1500, 'raised access floor': 3500, 'sports vinyl': 3000, 'self-leveling compound': 400, 'stone carpet (resin)': 2800, 'industrial epoxy heavy': 3500}
WTILE = {'ceramic': 1400, 'porcelain': 1700, 'marble': 2800, 'glass tile': 2500, 'stone': 2600, '3D tile': 3500, 'zellige': 4000}
PAINT = {'primer': 60, 'putty': 45, 'distemper': 90, 'emulsion': 130, 'premium emulsion': 220, 'luxury emulsion': 350,
         'texture': 380, 'enamel (wood)': 160, 'enamel (metal)': 200, 'exterior emulsion': 200, 'weather shield': 350, 'lime wash': 50, 'stencil/mural': 600, 'microcement/microtopping': 2500, 'anti-graffiti coating': 800, 'WPC panel finish': 2200}
CEIL = {'pop flat': 280, 'pop designer': 650, 'gypsum': 450, 'pvc': 400, 'mineral fiber': 500, 'wooden grid': 1500, 'metal grid': 1200, 'acoustic (mineral fiber)': 600, 'metal strip ceiling': 1500, 'stretch membrane': 2800, 'coffered': 3500}
CLAD = {'ACP': 2800, 'natural stone': 3400, 'artificial stone': 2200, 'ceramic tile': 1600, 'GRC': 2400, 'HPL': 3000,
        'wooden': 2600, 'brick tile': 1200, 'metal mesh': 2000, 'exposed brick': 1100, 'curtain wall (alu frame)': 4500, 'sandwich panel': 2200, 'fiber cement board': 1800, 'UPVC cladding': 1600}
GLASS = {'toughened': 2200, 'laminated': 3200, 'reflective': 2800, 'frosted': 2400, 'double glazed': 4500, 'tinted': 3000, 'insulated unit': 5500, 'switchable(smart)': 12000, 'solar control (low-E)': 3500, 'tempered laminated': 4000, 'wired glass': 2500, 'DGU (double glazed unit)': 4500}
DOOR = {'main entrance': 9500, 'panel': 6500, 'flush': 4200, 'wc/pvc': 3500, 'steel security': 7500, 'upvc': 6000, 'wooden': 9000, 'collapsible': 4500, 'fire rated (1hr)': 12000, 'rolling shutter': 8000, 'glass (frameless)': 15000, 'sliding folding': 9000, 'flush veneer': 6500, 'fire exit (panic bar)': 14000}
WIN = {'alu sliding': 3500, 'casement': 3200, 'upvc': 4200, 'wooden': 4500, 'louvered': 3800, 'fixed (glazing)': 2800, 'sliding folding': 5500, 'double glazed upvc': 5500, 'curtain wall glazing': 4500, 'skylight': 6000, 'louvered glass': 3500}
RAIL = {'MS tubular': 3500, 'MS decorative': 4500, 'SS 304 tubular': 5500, 'SS 316 tubular': 7500, 'SS glass infill': 8000,
        'SS cable/rope': 9000, 'glass frameless': 8500, 'glass point-fixed': 11000, 'glass framed': 7000, 'aluminium': 5500,
        'aluminium glass': 7500, 'wrought iron': 5000, 'wooden': 6500, 'concrete + wood': 4500, 'brass': 12000}
WP = {'roof (brick bat coba)': 650, 'toilet': 450, 'basement': 900, 'water tank': 700, 'sunken slab': 550, 'terrace membrane': 800, 'balcony': 600}
POLISH = {'wood polish': 350, 'melamine': 450, 'PU polish': 550, 'marble': 250, 'granite': 320, 'stone': 280, 'crystallization': 400}
MISC = {'parapet wall': (1800, 'rmt'), 'sunshade/chajja': (1500, 'rmt'), 'louver': (2200, 'sqm'), 'jaali': (3500, 'sqm'),
        'balcony finish': (1200, 'sqm'), 'cornice/moulding': (800, 'rmt'), 'anti-termite treatment': (120, 'sqm'), 'expansion joint': (1500, 'rmt'), 'pergola / shade structure': (3500, 'sqm')}

# ---- NEW categories (added for completeness) ----
STAIR_FIN = {'anti-skid tile tread': 1700, 'granite tread': 3500, 'marble tread': 3000,
             'stone tread (kota)': 1800, 'tile tread + riser': 1400, 'wooden tread': 4000,
             'stair nosing (aluminum)': 800, 'stair nosing (brass)': 1200, 'stair nosing (PVC)': 400}
SILL = {'marble sill (window)': 800, 'granite sill': 1200, 'stone sill (kota)': 600,
        'tile sill': 400, 'RCC precast sill': 350, 'RCC sill cast-in-place': 450,
        'threshold (patta) marble': 1000, 'threshold granite': 1500,
        'reveal plaster (opening sides)': 350}
ROOF_FIN = {'roof tile (clay/concrete)': 1200, 'terrace IPS finishing': 800,
            'terrazzo terrace': 1200, 'XPS insulation board 50mm': 1500,
            'EPS thermocol 50mm': 400, 'mineral wool insulation': 1800,
            'PVC rainwater gutter': 600, 'GI rainwater gutter': 900,
            'roof edge coping (aluminum)': 1200, 'roof edge coping (stone)': 1500,
            'heat reflective coating': 800, 'underdeck insulation': 1000}
METAL = {'MS window grill': 1200, 'MS safety grill (balcony)': 1500, 'MS gate (compound)': 2000,
         'MS collapsible gate': 1800, 'rolling shutter (MS)': 1500, 'rolling shutter (GI)': 1800,
         'MS railing (boundary)': 1800, 'MS catwalk/platform': 2500,
         'spiral steel staircase': 35000, 'steel handrail (pipe)': 800,
         'aluminium partition (office)': 2200, 'aluminium louver (ventilation)': 1800,
         'ACP signage/nameplate': 2500, 'catwalk grating': 2800}
COMPOUND = {'compound wall (brick+plaster+paint)': 4500, 'compound wall (block+finish)': 5500,
            'precast boundary post': 3500, 'chainlink fencing': 800,
            'driveway concrete paving': 1200, 'paver block driveway': 1000,
            'interlocking paver': 900, 'crazy paving stone': 1500,
            'drainage channel (RCC)': 1500, 'garden edging stone': 800,
            'prec concrete kerb': 700, 'asphalt driveway': 1800}
SURFACE = {'hack marking/roughening': 80, 'cement slurry wash (bond coat)': 50,
           'epoxy bonding agent': 200, 'fungicidal treatment': 100,
           'surface retarder': 150}
PRECAST = {'GRC cornice/moulding': 2500, 'GRC bracket/corbel': 1500, 'GRC column capital': 3500,
           'GRC dome element': 5000, 'GRP decorative panel': 3000,
           'precast concrete coping': 1200, 'precast window sill': 400,
           'precast kerb stone': 700, 'precast paver': 900,
           'precast boundary post': 3000, 'terrazzo precast (sill/threshold)': 1200}

CEM, SND, BRK, BLK = 950, 2500, 18, 120
# ---- door & window hardware ----
DHWARE = {'hinges (SS pair)': 350, 'mortice lock set': 1800, 'handles (SS)': 800, 'door stopper': 250, 'tower bolt': 300, ' Aldrop': 600, 'peephole': 200, 'automatic door closer': 2500, 'panic bar': 3500}
# ---- sealants & joint fillers ----
SEALANT = {'silicone sealant': 450, 'polyurethane sealant': 650, 'expansion joint cover': 1500, 'insect mesh (window)': 800, 'wall corner bead': 250}


# ---- door frame rates (per RMT) ----
DOOR_FRAME = {'Wooden': 450, 'Steel': 600, 'Aluminium': 550, 'UPVC': 500}
# ---- door hardware set (per door) ----
DOOR_HW = {'basic (hinges+lock+handle)': 1800, 'standard (+stopper+bolt+peephole)': 3000,
           'premium (+closer)': 5000, 'fire-rated (+panic+closer)': 8000}
# ---- architrave/beading (per RMT) ----
DOOR_ARCH = 150
# ---- window frame+sash (per SQM) ----
WIN_FRAME = {'alu sliding': 2500, 'casement': 2200, 'upvc': 3000, 'wooden': 3500,
             'fixed (glazing)': 1800, 'louvered': 2000, 'curtain wall glazing': 3500, 'skylight': 4500}
# ---- glass (per SQM) ----
WIN_GLASS = {'single clear 5mm': 400, 'single clear 6mm': 550, 'toughened 10mm': 1500,
             'double glazed unit': 1800, 'tinted': 700, 'reflective': 900,
             'frosted': 600, 'laminated': 1200, 'solar control (low-E)': 1500}
# ---- fly mesh (per SQM) ----
WIN_MESH = 350
DPC_RATE = 350      # damp proof course per sqm
SKIRT_RATE = 250     # flooring skirting per rmt
BALCONY_RATE = 1200  # balcony finish + drip + wp per sqm
VENT_RATE = {'louvered (aluminium)': 1200, 'louvered (wooden)': 900, 'fixed glass': 1000, 'exhaust opening': 500}

SPEC = {
    'id': 'archfin', 'title': 'Architecture & Finishing', 'icon': '🏛️', 'color': '#7d3c98',
    'intro': 'Complete building work: masonry (doors/windows auto-deduct), plaster, flooring, tiling, painting, '
             'false ceiling, cladding, glass, 15 railing types, balconies, parapet/sunshade, waterproofing, polish.',
    'upload_guide': [
        'Floor plans (ALL floors) - wall lengths, door/window positions, room sizes',
        'Door schedule - type, W x H, count, material, fire-rating',
        'Window schedule - type, W x H, count, glazing type',
        'Finishing specification - flooring, paint, plaster, ceiling per room',
        'Elevation drawings - external wall height, cladding areas',
        'Section drawings - floor-to-floor heights, balcony projections',
        'Staircase detail - tread/riser finish, nosing type, width',
        'Stone and marble schedule - sill sizes, threshold, counter specs',
        'Roof detail - insulation type/thickness, terrace finish, gutter',
        'MS/metal work schedule - grill sections, gate W x H, shutter specs',
        'Compound wall and site layout - wall L x H, gate, paving area',
        'Door and window hardware schedule - locks, hinges, closers',
        'Waterproofing detail - roof/toilet/basement type and area',
        'Precast and decorative schedule - cornice, coping, GRC elements',
        'Sealant and expansion joint specification',
    ],
    'upload_note': 'Upload as many PDFs as needed (separate sheets OK - all combined). Typed schedule TABLES auto-extract best.',
        'upload_note': 'Typed schedule & spec TABLES auto-extract best. Wall/window dimensions from drawings are confirmed manually.',
    'labour': ['mason', 'mazdoor', 'tile_mason', 'painter'],
    'scalars': [{'name': 'project_name', 'label': 'Project name', 'type': 'text', 'default': 'Architecture & Finishing'},
                {'name': 'location', 'label': 'Location', 'type': 'text', 'default': 'Kathmandu'},
                {'name': 'mortar', 'label': 'Masonry mortar', 'type': 'text', 'default': '1:6'},
                {'name': 'plaster_ratio', 'label': 'Plaster ratio', 'type': 'text', 'default': '1:4'},
                {'name': 'bldg_L', 'label': 'Building L (m) - wall helper', 'type': 'number', 'default': 0},
                {'name': 'bldg_W', 'label': 'Building W (m) - wall helper', 'type': 'number', 'default': 0},
                {'name': 'wall_height', 'label': 'Wall height (m) - helper', 'type': 'number', 'default': 3.0}],
    'tables': [
        {'id': 'rooms', 'title': '1A. Wall Takeoff Helper - building size + rooms (walls auto!)',
         'hint': 'enter building L x W + each room size: external & internal wall lengths auto-compute (rooms method). Clear the walls table below to let it take over. PDF drawings fill this automatically.',
         'add_label': 'add room',
         'fields': [
             {'name': 'name', 'label': 'Room', 'type': 'text'},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'width', 'label': 'Width (m)', 'type': 'number'},
         ],
         'default_rows': []},
        {'id': 'walls', 'title': '1. Masonry Walls', 'hint': 'doors & windows reduce this automatically; use Nos for repeated identical walls', 'add_label': 'Add wall',
         'fields': [{'name': 'id', 'label': 'ID', 'type': 'text'}, {'name': 'material', 'label': 'Material', 'type': 'select', 'options': list(WALL)},
                    {'name': 'thickness', 'label': 'Thk (mm)', 'type': 'number'}, {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
                    {'name': 'count', 'label': 'Nos (same wall)', 'type': 'number'},
                    {'name': 'height', 'label': 'Height (m)', 'type': 'number'}, {'name': 'type', 'label': 'Type', 'type': 'select', 'options': ['external', 'internal']},
                    {'name': 'mortar', 'label': 'Mortar', 'type': 'select', 'options': ['1:4', '1:5', '1:6', '1:8']}],
         'default_rows': [{'id': 'W1', 'material': 'brick', 'thickness': 230, 'length': 48, 'height': 9, 'type': 'external', 'mortar': '1:4'},
                          {'id': 'W2', 'material': 'brick', 'thickness': 115, 'length': 80, 'height': 9, 'type': 'internal', 'mortar': '1:6'}]},
        {'id': 'plinth', 'title': '1B. Plinth Wall Work (plinth beam → floor level)',
     'hint': 'masonry between foundation and ground floor — DPC auto-counted with walls above', 'add_label': 'add plinth wall',
     'fields': [
         {'name': 'id', 'label': 'Mark', 'type': 'text'},
         {'name': 'material', 'label': 'Material', 'type': 'select', 'default': 'brick',
          'options': ['brick', 'block', 'aac', 'stone']},
         {'name': 'thickness', 'label': 'Thickness (mm)', 'type': 'number'},
         {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
         {'name': 'height', 'label': 'Height (m)', 'type': 'number'},
         {'name': 'mortar', 'label': 'Mortar', 'type': 'select', 'default': '1:6',
          'options': ['1:4', '1:5', '1:6', '1:8']},
     ],
     'default_rows': [
         {'id': 'PW1', 'material': 'brick', 'thickness': 230, 'length': 48, 'height': 0.9, 'mortar': '1:6'},
     ]},
    {'id': 'plinthfill', 'title': '1C. Plinth Filling & Floor Bed',
     'hint': 'inside plinth walls — earth/murum/sand filling, PCC bed', 'add_label': 'add filling layer',
     'fields': [
         {'name': 'item', 'label': 'Layer', 'type': 'select', 'default': 'earth filling (compacted)',
          'options': sorted(FILL.keys())},
         {'name': 'area', 'label': 'Area (m²)', 'type': 'number'},
         {'name': 'depth', 'label': 'Depth (m)', 'type': 'number'},
     ],
     'default_rows': [
         {'item': 'earth filling (compacted)', 'area': 160, 'depth': 0.9},
         {'item': 'PCC bed 1:4:8 (100mm)', 'area': 160, 'depth': 0.1},
     ]},
    {'id': 'doors', 'title': '2. Doors (frame + shutter + hardware)', 'hint': 'auto-computes frame RMT, shutter area, architrave, hardware', 'add_label': 'Add door type',
         'fields': [{'name': 'id', 'label': 'ID', 'type': 'text'},
                    {'name': 'type', 'label': 'Door type', 'type': 'select', 'options': list(DOOR)},
                    {'name': 'frame_material', 'label': 'Frame material', 'type': 'select', 'options': list(DOOR_FRAME)},
                    {'name': 'frame_section', 'label': 'Frame section', 'type': 'suggest', 'options': ['100x65mm', '125x75mm', '150x75mm', '175x75mm']},
                    {'name': 'width', 'label': 'Width (m)', 'type': 'number'},
                    {'name': 'height', 'label': 'Height (m)', 'type': 'number'},
                    {'name': 'leaves', 'label': 'Leaves', 'type': 'select', 'options': ['Single', 'Double']},
                    {'name': 'panels', 'label': 'Panels', 'type': 'select', 'options': ['1', '2', '3', '4']},
                    {'name': 'hw_set', 'label': 'Hardware set', 'type': 'select', 'options': list(DOOR_HW)},
                    {'name': 'count', 'label': 'Count', 'type': 'number'},
                    {'name': 'location', 'label': 'Location', 'type': 'select', 'options': ['external', 'internal']}],
         'default_rows': [{'id': 'D1', 'type': 'main entrance', 'frame_material': 'Wooden', 'frame_section': '150x75mm', 'width': 1.2, 'height': 2.1, 'leaves': 'Double', 'panels': '4', 'hw_set': 'premium (+closer)', 'count': 1, 'location': 'external'},
                          {'id': 'D2', 'type': 'panel', 'frame_material': 'Wooden', 'frame_section': '125x75mm', 'width': 0.9, 'height': 2.1, 'leaves': 'Single', 'panels': '3', 'hw_set': 'standard (+stopper+bolt+peephole)', 'count': 6, 'location': 'internal'},
                          {'id': 'D3', 'type': 'flush', 'frame_material': 'Wooden', 'frame_section': '100x65mm', 'width': 0.8, 'height': 2.0, 'leaves': 'Single', 'panels': '1', 'hw_set': 'basic (hinges+lock+handle)', 'count': 3, 'location': 'internal'},
                          {'id': 'D4', 'type': 'wc/pvc', 'frame_material': 'UPVC', 'frame_section': '100x65mm', 'width': 0.7, 'height': 2.0, 'leaves': 'Single', 'panels': '1', 'hw_set': 'basic (hinges+lock+handle)', 'count': 3, 'location': 'internal'}]},
        {'id': 'windows', 'title': '3. Windows (frame + glass + mesh)', 'hint': 'auto-computes frame area, glazing, fly mesh', 'add_label': 'Add window type',
         'fields': [{'name': 'id', 'label': 'ID', 'type': 'text'},
                    {'name': 'type', 'label': 'Window type', 'type': 'select', 'options': list(WIN_FRAME)},
                    {'name': 'tracks', 'label': 'Tracks/panels', 'type': 'select', 'options': ['1-track', '2-track', '3-track', '1-panel', '2-panel', '3-panel', 'fixed']},
                    {'name': 'width', 'label': 'Width (m)', 'type': 'number'},
                    {'name': 'height', 'label': 'Height (m)', 'type': 'number'},
                    {'name': 'glass', 'label': 'Glass type', 'type': 'select', 'options': list(WIN_GLASS)},
                    {'name': 'fly_mesh', 'label': 'Fly mesh', 'type': 'select', 'options': ['Yes', 'No']},
                    {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'id': 'WN1', 'type': 'alu sliding', 'tracks': '2-track', 'width': 1.5, 'height': 1.2, 'glass': 'single clear 5mm', 'fly_mesh': 'Yes', 'count': 8},
                          {'id': 'WN2', 'type': 'casement', 'tracks': '2-panel', 'width': 1.2, 'height': 1.2, 'glass': 'single clear 5mm', 'fly_mesh': 'Yes', 'count': 4}]},
        {'id': 'vents', 'title': '4. Ventilators', 'hint': 'louvered/glass with frame', 'add_label': 'Add ventilator',
         'fields': [{'name': 'id', 'label': 'ID', 'type': 'text'},
                    {'name': 'type', 'label': 'Type', 'type': 'select', 'options': ['louvered (aluminium)', 'louvered (wooden)', 'fixed glass', 'exhaust opening']},
                    {'name': 'width', 'label': 'Width (m)', 'type': 'number'},
                    {'name': 'height', 'label': 'Height (m)', 'type': 'number'},
                    {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'id': 'V1', 'type': 'louvered (aluminium)', 'width': 0.6, 'height': 0.45, 'count': 4}]},
        {'id': 'plaster', 'title': '5. Plaster (additional surfaces)', 'hint': 'wall plaster auto from masonry - add only ceiling/soffit/special', 'add_label': 'Add extra plaster',
         'fields': [{'name': 'surface', 'label': 'Surface', 'type': 'select', 'options': list(PLASTER)},
                    {'name': 'area', 'label': 'Area (m²)', 'type': 'number'}, {'name': 'thk', 'label': 'Thk (mm)', 'type': 'number'}],
         'default_rows': [{'surface': 'ceiling', 'area': 360, 'thk': 10}]},
        {'id': 'flooring', 'title': '6. Flooring', 'add_label': 'Add flooring item',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(FLOOR)},
                    {'name': 'area', 'label': 'Area (m²)', 'type': 'number'},
                    {'name': 'screed', 'label': 'Screed bed (mm)', 'type': 'suggest', 'options': ['0','20','25','30','40','50']},
                    {'name': 'skirting', 'label': 'Skirting (rmt)', 'type': 'number'}],
         'default_rows': [{'type': 'vitrified tile', 'area': 320, 'skirting': 220}]},
        {'id': 'walltile', 'title': '7. Wall Tiling / Dado', 'add_label': 'Add wall tiling',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(WTILE)}, {'name': 'area', 'label': 'Area (m²)', 'type': 'number'}],
         'default_rows': [{'type': 'ceramic', 'area': 110}]},
        {'id': 'painting', 'title': '8. Painting (additional only)', 'hint': 'wall painting auto from masonry - add only enamel/texture/special', 'add_label': 'Add extra paint',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(PAINT)},
                    {'name': 'area', 'label': 'Area (m²)', 'type': 'number'}, {'name': 'coats', 'label': 'Coats', 'type': 'number'}],
         'default_rows': [{'type': 'enamel (wood)', 'area': 120, 'coats': 2}]},
        {'id': 'cladding', 'title': '9. Cladding & Facade', 'add_label': 'Add cladding',
         'fields': [{'name': 'type', 'label': 'Material', 'type': 'select', 'options': list(CLAD)}, {'name': 'area', 'label': 'Area (m²)', 'type': 'number'}],
         'default_rows': [{'type': 'ACP', 'area': 60}, {'type': 'exposed brick', 'area': 40}]},
        {'id': 'glass', 'title': '10. Glass Work', 'add_label': 'Add glass',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(GLASS)}, {'name': 'area', 'label': 'Area (m²)', 'type': 'number'}],
         'default_rows': [{'type': 'toughened', 'area': 12}]},
        {'id': 'railing', 'title': '11. Railings', 'hint': '15 real types', 'add_label': 'Add railing',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(RAIL)},
                    {'name': 'length', 'label': 'Length (rmt)', 'type': 'number'}, {'name': 'height', 'label': 'Height (m)', 'type': 'number'}],
         'default_rows': [{'type': 'glass frameless', 'length': 12, 'height': 1.1}, {'type': 'SS 304 tubular', 'length': 18, 'height': 1.0}]},
        {'id': 'balcony', 'title': '12. Balcony Floor Finishing & Drip Course', 'add_label': 'Add balcony',
         'fields': [{'name': 'id', 'label': 'ID', 'type': 'text'}, {'name': 'count', 'label': 'Count', 'type': 'number'},
                    {'name': 'proj', 'label': 'Projection (m)', 'type': 'number'}, {'name': 'width', 'label': 'Width (m)', 'type': 'number'}],
         'default_rows': [{'id': 'B1', 'count': 3, 'proj': 1.2, 'width': 3.0}]},
        {'id': 'misc', 'title': '13. Parapet / Sunshade / Louver', 'add_label': 'Add item',
         'fields': [{'name': 'item', 'label': 'Item', 'type': 'select', 'options': list(MISC)}, {'name': 'qty', 'label': 'Qty', 'type': 'number'}],
         'default_rows': [{'item': 'parapet wall', 'qty': 48}, {'item': 'sunshade/chajja', 'qty': 40}, {'item': 'anti-termite treatment', 'qty': 360}]},
        {'id': 'wp', 'title': '14. Waterproofing', 'add_label': 'Add waterproofing',
         'fields': [{'name': 'loc', 'label': 'Location', 'type': 'select', 'options': list(WP)},
                    {'name': 'coats', 'label': 'Coats', 'type': 'select', 'options': ['2 coats','3 coats','2+1 protective']},
                    {'name': 'area', 'label': 'Area (m²)', 'type': 'number'}],
         'default_rows': [{'loc': 'roof (brick bat coba)', 'area': 120}, {'loc': 'toilet', 'area': 90}]},
        {'id': 'polish', 'title': '15. Polish & Protection', 'add_label': 'Add polish',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(POLISH)}, {'name': 'area', 'label': 'Area (m²)', 'type': 'number'}],
         'default_rows': [{'type': 'wood polish', 'area': 40}]},
        {'id': 'stairfin', 'title': '16. Staircase Finishing', 'add_label': 'Add stair item',
         'fields': [{'name': 'type', 'label': 'Finish type', 'type': 'select', 'options': list(STAIR_FIN)},
                    {'name': 'spec', 'label': 'Specification', 'type': 'suggest', 'options': ['2 staircases, 12 treads each', '1 staircase, 10 treads', '3 flights x 12 treads']},
                    {'name': 'nos_treads', 'label': 'No. of treads', 'type': 'number'},
                    {'name': 'width', 'label': 'Stair width (m)', 'type': 'number'}],
         'default_rows': [{'type': 'anti-skid tile tread', 'spec': '2 staircases, 12 treads each', 'nos_treads': 24, 'width': 1.2}]},
        {'id': 'sill', 'title': '17. Sill, Reveal & Threshold', 'add_label': 'Add sill/reveal',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(SILL)},
                    {'name': 'spec', 'label': 'Size (W x thk mm)', 'type': 'suggest', 'options': ['150x40mm', '100x30mm', '200x50mm', '150x25mm', '250x50mm']},
                    {'name': 'length', 'label': 'Length (rmt)', 'type': 'number'}],
         'default_rows': [{'type': 'marble sill (window)', 'spec': '150x40mm', 'length': 40}, {'type': 'threshold (patta) marble', 'spec': '100x30mm', 'length': 15}]},
        {'id': 'rooffin', 'title': '18. Roof Finishing & Insulation', 'add_label': 'Add roof item',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(ROOF_FIN)},
                    {'name': 'spec', 'label': 'Thickness / detail', 'type': 'suggest', 'options': ['40mm screed + tile', '50mm XPS board', '30mm screed', '20mm IPS', 'brick bat coba 100mm', 'EPS 50mm']},
                    {'name': 'area', 'label': 'Area (sqm)', 'type': 'number'}],
         'default_rows': [{'type': 'terrace IPS finishing', 'spec': '40mm screed + tile', 'area': 120}]},
        {'id': 'metal', 'title': '19. MS / Metal Work (Grills, Gates, Shutters)', 'add_label': 'Add metal item',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(METAL)},
                    {'name': 'spec', 'label': 'Section / specification', 'type': 'suggest', 'options': ['12mm sq bar @ 125 c/c + 25x5 flat frame', '12mm sq bar @ 100 c/c', '16mm round @ 150 c/c', 'angle 40x40x6 frame + sheet', 'MS tube 25x25 @ 150 c/c', 'MS sheet 2mm on angle frame']},
                    {'name': 'width', 'label': 'Width (m)', 'type': 'number'},
                    {'name': 'height', 'label': 'Height (m)', 'type': 'number'},
                    {'name': 'count', 'label': 'Nos', 'type': 'number'}],
         'default_rows': [{'type': 'MS window grill', 'spec': '12mm sq bar @ 125 c/c + 25x5 flat frame', 'width': 1.5, 'height': 1.2, 'count': 8},
                          {'type': 'MS gate (compound)', 'spec': 'angle 40x40x6 frame + sheet', 'width': 4.0, 'height': 1.8, 'count': 1}]}, 
        {'id': 'compound', 'title': '20. Compound Wall & Site Paving', 'add_label': 'Add site work item',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(COMPOUND)},
                    {'name': 'spec', 'label': 'Specification (thickness/height)', 'type': 'suggest', 'options': ['1.8m high, 230mm brick', '2.0m high, 200mm block', '1.5m high, 115mm brick', '2.4m high', '60mm interlocking paver', '100mm RCC slab']},
                    {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
                    {'name': 'height', 'label': 'Height / Width (m)', 'type': 'number'}],
         'default_rows': [{'type': 'compound wall (brick+plaster+paint)', 'spec': '1.8m high, 230mm brick', 'length': 60, 'height': 1.8},
                          {'type': 'paver block driveway', 'spec': '60mm interlocking', 'length': 10, 'height': 8}]}, 
        {'id': 'surface', 'title': '21. Surface Preparation', 'add_label': 'Add prep item',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(SURFACE)},
                    {'name': 'spec', 'label': 'Where applied', 'type': 'suggest', 'options': ['before plaster', 'before tile', 'on RCC surface', 'on old surface', 'toilet walls', 'external walls']},
                    {'name': 'area', 'label': 'Area (sqm)', 'type': 'number'}],
         'default_rows': [{'type': 'cement slurry wash (bond coat)', 'spec': 'before plaster', 'area': 360}]},
        {'id': 'partitions', 'title': '23. Partitions & Panelling',
         'hint': 'drywall / glass / WPC partitions incl. framing, boards both sides, jointing & finishing', 'add_label': 'add partition',
         'fields': [
             {'name': 'id', 'label': 'Mark', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select',
              'options': sorted(PART.keys())},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'height', 'label': 'Height (m)', 'type': 'number'},
         ],
         'default_rows': [
             {'id': 'P1', 'type': 'gypsum board partition 50mm (double skin)', 'length': 12, 'height': 3.0},
         ]},
        {'id': 'precast', 'title': '22. Precast & Decorative Elements', 'add_label': 'Add precast item',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(PRECAST)},
                    {'name': 'spec', 'label': 'Size / profile', 'type': 'suggest', 'options': ['300x150mm', '200x100mm', '450x75mm', '600x150mm', '150x100mm cornice']},
                    {'name': 'qty', 'label': 'Qty (rmt/nos)', 'type': 'number'}],
         'default_rows': []},
    ],
}


def estimate(sched):
    mortar = sched['scalars'].get('mortar', '1:6'); pratio = sched['scalars'].get('plaster_ratio', '1:4'); T = sched['tables']
    scal = sched.get('scalars', {})
    est = Estimate({})
    gross = {}

    # ---- WALL TAKEOFF HELPER (rooms method): walls auto from building + rooms ----
    bL = NUM(scal.get('bldg_L')); bW = NUM(scal.get('bldg_W'))
    wh = NUM(scal.get('wall_height'), 3.0) or 3.0
    rooms = T.get('rooms') or []
    helper_walls = None
    if bL > 0 and bW > 0 and not any(NUM(w.get('length')) for w in T['walls']):
        ext_len = round(2 * (bL + bW), 1)
        rp = sum(2 * (NUM(r.get('length')) + NUM(r.get('width'))) for r in rooms
                 if NUM(r.get('length')) > 0 and NUM(r.get('width')) > 0)
        int_len = round(max((rp - 2 * (bL + bW)) / 2.0, 0), 1) if rp else 0
        helper_walls = (ext_len, int_len)
        T['walls'] = [
            {'id': 'EXT-AUTO', 'material': 'brick', 'thickness': 230, 'length': ext_len,
             'count': 1, 'height': wh, 'type': 'external', 'mortar': mortar},
            {'id': 'INT-AUTO', 'material': 'brick', 'thickness': 115, 'length': int_len,
             'count': 1, 'height': wh, 'type': 'internal', 'mortar': mortar},
        ]
    for w in T['walls']:
        mat = (w.get('material') or 'brick').lower(); thk = NUM(w.get('thickness'), 230)
        wm = w.get('mortar', mortar)
        nw = NUM(w.get('count'), 1) or 1
        gross[(mat, wm)] = gross.get((mat, wm), 0) + NUM(w.get('length')) * nw * NUM(w.get('height')) * thk / 1000.0
    tot_gross = sum(gross.values()); open_vol = 0.0
    for d in T['doors']:
        a = NUM(d.get('width')) * NUM(d.get('height')) * NUM(d.get('count')); open_vol += a * (230 if d.get('location') == 'external' else 115) / 1000.0
    for w in T['windows']:
        a = NUM(w.get('width')) * NUM(w.get('height')) * NUM(w.get('count')); open_vol += a * 230 / 1000.0
    for v in T['vents']:
        a = NUM(v.get('width')) * NUM(v.get('height')) * NUM(v.get('count')); open_vol += a * 115 / 1000.0
    net = max(0.0, tot_gross - open_vol); factor = net / tot_gross if tot_gross else 1.0
    # measurement-sheet style: each wall measured, then openings deducted
    for w in T['walls']:
        est.take('1. Masonry',
                 f"Wall {w.get('id','')} {(w.get('material') or 'brick')} {NUM(w.get('thickness'),230):.0f}mm ({w.get('type','')}) - gross",
                 'cum', NUM(w.get('length')) * (NUM(w.get('count'),1) or 1) * NUM(w.get('height')) * NUM(w.get('thickness'),230) / 1000.0,
                 take=((NUM(w.get('count'),1) or 1), NUM(w.get('length')), NUM(w.get('height')), NUM(w.get('thickness'),230)/1000.0))
    if open_vol:
        est.take('1. Masonry', 'Less: door / window / ventilator openings', 'cum', -round(open_vol,3),
                 note='deducted from gross wall volume')
    for (mat, wm), gv in gross.items():
        mrate, bp = WALL.get(mat, (9500, 500)); nv = gv * factor
        est.item('1. Masonry', f"{mat.title()} masonry ({wm} mortar) - net of openings", 'cum', nv, rate=mrate,
                 note='net = gross less openings' if open_vol else '')
        nos, cem, sand = masonry_breakup(nv, bp, wm)
        est.mat('bricks', 'Bricks' if mat == 'brick' else 'Blocks', nos, 'nos', BRK if mat == 'brick' else BLK)
        est.mat('cement', 'Cement', cem, 'bags', CEM).mat('sand', 'Sand', sand, 'cum', SND)
    dpc_len = sum(NUM(w.get('length')) * (NUM(w.get('count'), 1) or 1) for w in T['walls'] if w.get('type') == 'external')
    if dpc_len:
        est.item('1. Masonry', 'Damp Proof Course (DPC)', 'sqm', dpc_len * 0.230, rate=DPC_RATE,
                 take=(1, round(dpc_len,2), 0.23, None), note='external wall length x 230mm')

    # ---- PLINTH WALL WORK (plinth beam to ground floor level) ----
    for r in T['plinth']:
        L, h = NUM(r.get('length')), NUM(r.get('height'))
        if not (L and h):
            continue
        mat = (r.get('material') or 'brick').lower()
        thk = NUM(r.get('thickness'), 230)
        wm = r.get('mortar', mortar)
        vol = L * h * thk / 1000.0
        mrate, bp = WALL.get(mat, (9500, 500))
        est.item('1. Masonry', f"Plinth wall {mat} {thk:.0f}mm ({wm} mortar) - {r.get('id','')}", 'cum',
                 round(vol, 2), rate=ro(r, mrate), take=(1, L, h, thk/1000.0))
        nos, cem, sand = masonry_breakup(vol, bp, wm)
        est.mat('bricks', 'Bricks' if mat == 'brick' else 'Blocks', nos, 'nos', BRK if mat == 'brick' else BLK)
        est.mat('cement', 'Cement', cem, 'bags', CEM).mat('sand', 'Sand', sand, 'cum', SND)
    for r in T['plinthfill']:
        a, d = NUM(r.get('area')), NUM(r.get('depth'))
        if not (a and d):
            continue
        it = r.get('item', 'earth filling (compacted)')
        vol = a * d
        est.item('1B. Plinth Filling & Floor Bed', f"{it} ({a:,.0f} m² x {d} m)", 'cum',
                 round(vol, 2), rate=ro(r, FILL.get(it, 400)), take=(1, a, d, None))

    # ---- AUTO-DERIVE plaster + putty + paint from walls (masonry brings finishes) ----
    ext_wa = sum(NUM(w.get('length')) * (NUM(w.get('count'), 1) or 1) * NUM(w.get('height')) for w in T['walls'] if w.get('type') == 'external')
    int_wa = sum(NUM(w.get('length')) * (NUM(w.get('count'), 1) or 1) * NUM(w.get('height')) for w in T['walls'] if w.get('type') == 'internal')
    ext_open = 0; int_open = 0
    for d in T['doors']:
        a = NUM(d.get('width')) * NUM(d.get('height')) * NUM(d.get('count'))
        if d.get('location') == 'external': ext_open += a
        else: int_open += a
    for wn in T['windows']: ext_open += NUM(wn.get('width')) * NUM(wn.get('height')) * NUM(wn.get('count'))
    for v in T['vents']: ext_open += NUM(v.get('width')) * NUM(v.get('height')) * NUM(v.get('count'))
    ext_net = max(0, ext_wa - ext_open)
    int_net = max(0, int_wa - int_open)
    int_plaster_area = 2 * int_net + ext_net
    ext_plaster_area = ext_net
    if (ext_wa + int_wa) > 0:
        est.item('5. Plaster', 'Internal wall plaster (auto from masonry) 12mm', 'sqm', round(int_plaster_area, 1),
                 rate=PLASTER.get('internal wall 12mm', 320), note='2 x internal net wall area + external net area (auto)')
        c, s = plaster_breakup(int_plaster_area, 12, pratio)
        est.mat('cement', 'Cement', c, 'bags', CEM).mat('sand', 'Sand', s, 'cum', SND)
        est.item('5. Plaster', 'External wall plaster (auto from masonry) 20mm', 'sqm', round(ext_plaster_area, 1),
                 rate=PLASTER.get('external wall 20mm', 420), note='external wall area net of openings (auto)')
        c2, s2 = plaster_breakup(ext_plaster_area, 20, pratio)
        est.mat('cement', 'Cement', c2, 'bags', CEM).mat('sand', 'Sand', s2, 'cum', SND)
        est.item('8. Painting', 'Wall putty (auto from masonry) 2 coats', 'sqm', round(int_plaster_area, 1), rate=PAINT.get('putty', 45), note='same area as internal plaster (auto)')
        est.item('8. Painting', 'Internal emulsion (auto from masonry) 2 coats', 'sqm', round(int_plaster_area, 1), rate=PAINT.get('emulsion', 130), note='same area as internal plaster (auto)')
        est.item('8. Painting', 'External paint (auto from masonry) 2 coats', 'sqm', round(ext_plaster_area, 1), rate=PAINT.get('exterior emulsion', 200), note='same area as external plaster (auto)')
    for d in T['doors']:
        cnt = NUM(d.get('count')); w = NUM(d.get('width')); h = NUM(d.get('height'))
        dt = d.get('type', 'flush'); fm = d.get('frame_material', 'Wooden')
        frm = (2*h + w) * cnt; shut = w * h * cnt; arch = (2*h + w) * 2 * cnt
        # frame
        est.item('2. Doors', f"Frame ({fm} {d.get('frame_section','')}) - {d.get('id','')}", 'rmt', round(frm,1),
                 rate=ro(d, DOOR_FRAME.get(fm, 450)), take=(cnt, 2*h + w, None, None), note='(2H + W) per door')
        # shutter
        lv = d.get('leaves','Single'); pn = d.get('panels','1')
        est.item('2. Doors', f"Shutter - {dt} ({pn} panel, {lv}) - {d.get('id','')}", 'sqm', round(shut,2),
                 rate=ro(d, DOOR.get(dt, 4200)), take=(cnt, w, h, None))
        # architrave/beading both sides
        est.item('2. Doors', f"Architrave/beading - {d.get('id','')}", 'rmt', round(arch,1), rate=DOOR_ARCH,
                 take=(cnt, (2*h + w) * 2, None, None), note='2 x (2H + W), both faces')
        # hardware set
        hw = d.get('hw_set', 'basic (hinges+lock+handle)')
        est.item('2. Doors', f"Hardware ({hw}) - {d.get('id','')}", 'set', int(cnt), rate=ro(d, DOOR_HW.get(hw, 1800)),
                 take=(cnt, None, None, None), note='1 set per door')
    for wn in T['windows']:
        cnt = NUM(wn.get('count')); w = NUM(wn.get('width')); h = NUM(wn.get('height'))
        wt = wn.get('type', 'alu sliding'); gt = wn.get('glass', 'single clear 5mm')
        area = w * h * cnt
        # frame + sash
        est.item('3. Windows', f"Frame+sash ({wt}, {wn.get('tracks','')}) - {wn.get('id','')}", 'sqm', round(area,2),
                 rate=ro(wn, WIN_FRAME.get(wt, 2500)), take=(cnt, w, h, None))
        # glazing
        est.item('3. Windows', f"Glass ({gt}) - {wn.get('id','')}", 'sqm', round(area,2),
                 rate=ro(wn, WIN_GLASS.get(gt, 400)), take=(cnt, w, h, None))
        # fly mesh
        if wn.get('fly_mesh') == 'Yes':
            est.item('3. Windows', f"Fly/insect mesh - {wn.get('id','')}", 'sqm', round(area,2), rate=WIN_MESH,
                     take=(cnt, w, h, None))
    for v in T['vents']:
        cnt = NUM(v.get('count')); area = NUM(v.get('width')) * NUM(v.get('height')) * cnt
        if area:
            vt = v.get('type', 'louvered (aluminium)')
            est.item('4. Ventilators', f"{vt} - {v.get('id','')}", 'sqm', round(area,2),
                     rate=ro(v, VENT_RATE.get(vt, 1000)),
                     take=(cnt, NUM(v.get('width')), NUM(v.get('height')), None))
    for r in T['plaster']:
        a = NUM(r.get('area'))
        if a:
            surf = r.get('surface'); thk = NUM(r.get('thk'), int(''.join(ch for ch in str(surf) if ch.isdigit()) or '12'))
            est.item('5. Plaster', f"{surf}", 'sqm', a, rate=ro(r, PLASTER.get(surf, 320)),
                     take=(NUM(r.get('count'),1) or 1, NUM(r.get('length')), NUM(r.get('height')), None))
            c, s = plaster_breakup(a, thk, pratio); est.mat('cement', 'Cement', c, 'bags', CEM).mat('sand', 'Sand', s, 'cum', SND)
    for r in T['flooring']:
        a = NUM(r.get('area'))
        if a:
            est.item('6. Flooring', f"{r.get('type')} flooring", 'sqm', a, rate=ro(r, FLOOR.get(r.get('type'), 1500)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))
            sc = NUM(r.get('screed'), 0)
            if sc > 0:
                est.item('6. Flooring', f'Cement screed bed {int(sc)}mm (sub-floor preparation)', 'sqm', a, rate=200,
                         take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))
        sk = NUM(r.get('skirting'))
        if sk:
            est.item('6. Flooring', 'Skirting', 'rmt', sk, rate=SKIRT_RATE,
                     take=((NUM(r.get('count'),1) or 1), sk, None, None), note='skirting length entered / room perimeter')
    for r in T['walltile']:
        a = NUM(r.get('area'))
        if a:
            est.item('7. Wall Tiling', f"{r.get('type')} wall tiling", 'sqm', a, rate=ro(r, WTILE.get(r.get('type'), 1400)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('height')), None))
    for r in T['painting']:
        a = NUM(r.get('area'))
        if a:
            est.item('8. Painting', f"{r.get('type')} ({int(NUM(r.get('coats'), 2))} coats)", 'sqm', a,
                     rate=ro(r, PAINT.get(r.get('type'), 130)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('height')), None))
    for r in T['cladding']:
        a = NUM(r.get('area'))
        if a:
            est.item('9. Cladding & Facade', f"{r.get('type')} cladding", 'sqm', a, rate=ro(r, CLAD.get(r.get('type'), 2800)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('height')), None))
    for r in T['glass']:
        a = NUM(r.get('area'))
        if a:
            est.item('10. Glass', f"{r.get('type')} glass", 'sqm', a, rate=ro(r, GLASS.get(r.get('type'), 2200)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('height')), None))
    for r in T['railing']:
        L = NUM(r.get('length'))
        if L:
            est.item('11. Railings', f"{r.get('type')} railing ({r.get('height', 1.1)}m)", 'rmt', L,
                     rate=ro(r, RAIL.get(r.get('type'), 5500)),
                     take=((NUM(r.get('count'),1) or 1), L, None, None), note='railing running length')
    for b in T['balcony']:
        a = NUM(b.get('count')) * NUM(b.get('proj')) * NUM(b.get('width'))
        if a:
            est.item('12. Balcony Floor Finishing & Drip Course', 'Balcony floor finishing (tile/stone) + drip course + waterproofing', 'sqm', a,
                     rate=ro(b, BALCONY_RATE),
                     take=(NUM(b.get('count')), NUM(b.get('proj')), NUM(b.get('width')), None), note='count x projection x width')
    for r in T['misc']:
        q = NUM(r.get('qty'))
        if q:
            mrate, unit = MISC.get(r.get('item'), (1500, 'rmt')); est.item('13. Parapet / Sunshade / Louver', str(r.get('item')), unit, q,
                     rate=ro(r, mrate), take=((NUM(r.get('count'),1) or 1), q, None, None), note='quantity as entered')
    for r in T['wp']:
        a = NUM(r.get('area'))
        if a:
            coats = r.get('coats','2 coats')
            est.item('14. Waterproofing', f"{r.get('loc')} ({coats})", 'sqm', a, rate=ro(r, WP.get(r.get('loc'), 650)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))
    for r in T['polish']:
        a = NUM(r.get('area'))
        if a:
            est.item('15. Polish & Protection', f"{r.get('type')}", 'sqm', a, rate=ro(r, POLISH.get(r.get('type'), 350)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))
    for r in T['stairfin']:
        nt = NUM(r.get('nos_treads'), 0); w = NUM(r.get('width'), 1.2)
        q = nt * 0.3 * w if nt else 0  # tread run ~0.3m each
        if q:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('16. Staircase Finishing', d, 'sqm', q, rate=ro(r, STAIR_FIN.get(r.get('type'), 1500)),
                     take=(nt, 0.3, w, None), note='treads x 0.3m tread run x stair width')
    for r in T['sill']:
        q = NUM(r.get('length'))
        if q:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('17. Sill & Threshold', d, 'rmt', q, rate=ro(r, SILL.get(r.get('type'), 800)),
                     take=((NUM(r.get('count'),1) or 1), q, None, None), note='running length')
    for r in T['rooffin']:
        q = NUM(r.get('area'))
        if q:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('18. Roof Finishing & Insulation', d, 'sqm', q, rate=ro(r, ROOF_FIN.get(r.get('type'), 1000)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))
    for r in T['metal']:
        w = NUM(r.get('width')); h = NUM(r.get('height')); cnt = NUM(r.get('count'), 1)
        q = w * h * cnt if (w and h) else cnt
        if q:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('19. MS / Metal Work', d, 'sqm', q, rate=ro(r, METAL.get(r.get('type'), 1500)),
                     take=(cnt if (w and h) else q, w if (w and h) else None, h if (w and h) else None, None),
                     note='count x width x height')
    for r in T['compound']:
        l = NUM(r.get('length')); h = NUM(r.get('height'))
        q = l * h if (l and h) else l if l else 0
        if q:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('20. Compound & Site', d, 'sqm', q, rate=ro(r, COMPOUND.get(r.get('type'), 1500)),
                     take=(1, l, h, None) if (l and h) else (1, l, None, None), note='length x height')
    for r in T['surface']:
        q = NUM(r.get('area'))
        if q:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('21. Surface Prep', d, 'sqm', q, rate=ro(r, SURFACE.get(r.get('type'), 100)),
                     take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))
    for r in T['precast']:
        q = NUM(r.get('qty'))
        if q:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('22. Precast & Decorative', d, 'nos', q, rate=ro(r, PRECAST.get(r.get('type'), 1000)),
                     take=(q, None, None, None), note='numbers entered')

    # ---- partitions & panelling ----
    for r in T.get('partitions', []):
        L, h = NUM(r.get('length')), NUM(r.get('height'))
        if not (L and h):
            continue
        pt = r.get('type', 'gypsum board partition 50mm (double skin)')
        est.item('23. Partitions & Panelling', f"{pt} - {r.get('id','')}", 'sqm', round(L * h, 1),
                 rate=ro(r, PART.get(pt, 1650)), take=((NUM(r.get('count'),1) or 1), L, h, None))

    arch_mason_days = round((int_plaster_area + ext_plaster_area) / 40, 0) if (ext_wa + int_wa) > 0 else 0
    arch_tile_days = round((sum(NUM(r.get('area',0)) for r in T['flooring']) + sum(NUM(r.get('area',0)) for r in T['walltile'])) / 15, 0)
    arch_paint_days = round((int_plaster_area + ext_plaster_area) / 80, 0) if (ext_wa + int_wa) > 0 else 0
    arch_mazdoor_days = round((arch_mason_days + arch_tile_days + arch_paint_days) * 2.5, 0)
    arch_total_labour = int(arch_mason_days + arch_tile_days + arch_paint_days + arch_mazdoor_days)

    kpis = []
    if helper_walls:
        kpis.append(('Walls ext/int (auto)', f"{helper_walls[0]:g} / {helper_walls[1]:g} m"))
    kpis += [('Gross masonry', f"{tot_gross:.1f} m³"), ('Openings cut', f"{open_vol:.1f} m³"), ('Net masonry', f"{net:.1f} m³"),
            ('Doors', f"{sum(NUM(d.get('count')) for d in T['doors']):.0f}"), ('Windows', f"{sum(NUM(w.get('count')) for w in T['windows']):.0f}")]
    proj = {'name': sched['scalars'].get('project_name', ''), 'location': sched['scalars'].get('location', '')}
    res = est.result(project=proj, kpis=kpis)
    from modules.common import LABOUR_RATES as _LR
    _lrd = sched.get('labour_rates') or {}
    res['labour_rates'] = {k: _lrd.get(k) or _LR[k] for k in ['mason', 'mazdoor', 'tile_mason', 'painter']}
    res['labour'] = {
        'mason_days': int(arch_mason_days), 'mazdoor_days': int(arch_mazdoor_days),
        'tile_mason_days': int(arch_tile_days), 'painter_days': int(arch_paint_days),
        'total_days': arch_total_labour,
    }
    return res


PDF_KEYWORDS = ['window', 'door', 'plaster', 'paint', 'flooring', 'tile', 'railing', 'cladding', 'glass', 'ceiling']
