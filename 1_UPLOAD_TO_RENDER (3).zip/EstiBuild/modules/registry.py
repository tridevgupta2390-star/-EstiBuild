"""Estimation categories registry."""
import modules.archfin as archfin
import modules.sanitary as san
import modules.electrical as ele
import modules.steel as steel
import modules.roofing as roofing

LANDING = [
    {'id': 'structural', 'no': 1, 'title': 'RCC Structure', 'icon': '🏗️', 'color': '#1F3B57',
     'desc': 'RCC concrete estimate: foundations, columns, beams, slabs, walls, staircase — member schedule with BBS steel.', 'detailed': True},
    {'id': 'archfin', 'no': 2, 'title': 'Architecture & Finishing', 'icon': '🏛️', 'color': '#7d3c98',
     'desc': 'Masonry (auto opening deduction), plaster, flooring, tiling, painting, false ceiling, cladding, glass, 15 railing types, balconies, parapet/sunshade, waterproofing, polish.', 'mod': archfin, 'sched': True},
    {'id': 'sanitary', 'no': 3, 'title': 'Sanitary & Plumbing', 'icon': '🚿', 'color': '#2980b9',
     'desc': 'Pipes by diameter (brand), CP fittings (brand), fixtures (brand), bathroom accessories, tanks, pump, drainage.', 'mod': san, 'sched': True},
    {'id': 'electrical', 'no': 4, 'title': 'Electrical', 'icon': '⚡', 'color': '#e67e22',
     'desc': 'Points, conduit & wire by size, switchgear, fixtures, earthing, backup, LV systems.', 'mod': ele, 'sched': True},
    {'id': 'steel', 'no': 5, 'title': 'Steel Structure', 'icon': '🏭', 'color': '#5d6d7e',
     'desc': 'Hot-rolled & plated built-up sections, tubular & cold-formed, decking, bracing, gussets, HSFG bolts, welds, galvanizing, fabrication & erection.', 'mod': steel, 'sched': True},
    {'id': 'roofing', 'no': 6, 'title': 'Roofing & Truss', 'icon': '🏠', 'color': '#c0392b',
     'desc': 'Trusses by type & span (Fink/Pratt/Howe/tubular/space frame), member takeoff, purlins, battens, sheeting, gutters, insulation, ventilators, timber.', 'mod': roofing, 'sched': True},
]
SCHED = {m['id']: m for m in LANDING if m.get('sched')}
