"""Sanitary & plumbing - Nepal brands, full toilet detail, accessories."""
from modules.common import Estimate, NUM, ro

PIPE = {'GI fire main 100mm': 1400, 'CPVC supply 15mm': 350, 'CPVC supply 20mm': 450, 'CPVC supply 25mm': 600, 'CPVC supply 32mm': 800,
        'CPVC hot 25mm': 750, 'UPVC soil 110mm': 950, 'UPVC waste 75mm': 500, 'UPVC waste 40mm': 320,
        'rain water 110mm': 700, 'CI soil 100mm': 1400, 'gas pipe 15mm': 900, 'SWR 160mm': 1100, 'PPR hot water 25mm': 650, 'PPR hot water 32mm': 850, 'PEX 20mm': 550, 'HDPE 110mm': 900, 'copper 15mm': 1400, 'ductile iron 100mm': 1800}
PIPE_BRAND = {'Supreme': 1.0, 'Astral': 1.15, 'Finolex': 1.1, 'Prince': 0.9, 'Other': 1.0}
FIT = {'pillar cock': 1200, 'bib cock': 700, 'angle valve (2-way)': 700, 'wall mixer (bath)': 4500, 'wall mixer (basin)': 3800,
       'diverter (2-way)': 8000, 'diverter (3-way)': 13000, 'overhead shower': 3500, 'hand shower': 1800,
       'health faucet (jet spray)': 1800, 'sensor tap': 12000, 'flush valve (concealed)': 9000, 'flush tank': 2500,
       'washing machine tap': 600, 'body jet': 4500, 'angular shower': 2800}
FIT_BRAND = {'Jaquar': 1.25, 'Cera': 1.0, 'Hindware': 1.0, 'Esika': 0.9, 'Marc': 0.85, 'Grohe': 2.3, 'Kohler': 2.0, 'Waterdance': 0.8}
FIX = {'EWC one-piece': 18000, 'EWC two-piece': 13000, 'EWC wall-hung': 22000, 'Indian pan': 7000, 'Orissa pan': 7500,
       'wash basin (counter)': 9000, 'wash basin (wall)': 5500, 'wash basin (pedestal)': 8000, 'half basin': 4500,
       'corner basin': 6000, 'SS sink (single)': 7000, 'SS sink (double bowl)': 11000, 'granite sink': 14000,
       'urinal (wall)': 8000, 'urinal (stall)': 12000, 'bathtub (acrylic)': 45000, 'bathtub (fibreglass)': 28000,
       'jacuzzi': 120000, 'shower tray': 8000, 'bidet': 15000, 'shower enclosure (glass)': 18000, 'dishwasher connection kit': 3500, 'washing machine point (tap+drain)': 1500, 'water softener connection': 2000, 'kitchen RO point': 2500, 'bathroom glass partition': 12000, 'smart toilet (washlet)': 45000, 'concealed cistern (Geberit type)': 8000, 'waterless urinal': 15000, 'water cooler/dispenser': 18000, 'kitchen chimney (range hood)': 12000}
FIX_BRAND = {'Hindware': 1.0, 'Cera': 1.05, 'Parryware': 1.1, 'Jaquar': 1.25, 'Kohler': 2.0, 'Roca': 1.6, 'Varmora': 0.9, 'Asian': 0.85, 'Somany': 1.0, 'TOTO': 1.9}
ACC = {'mirror (frameless)': 2500, 'mirror cabinet': 6500, 'towel ring': 600, 'towel rail': 900, 'soap dish (wall)': 500,
       'soap dispenser': 1200, 'robe hook': 350, 'glass shelf': 1200, 'tumbler holder': 450, 'toilet paper holder': 500,
       'grab bar (SS)': 1500, 'toothbrush holder': 400, 'shower caddy': 1400, 'WC brush set': 700, 'towel warmer': 8000}
STOR = {'overhead tank (plastic)': 35, 'overhead tank (loft/steel)': 60, 'underground sump (RCC)': 12, 'fire water tank (RCC)': 15, 'loft tank (plastic 500L)': 7000, 'pressurized tank (hydro-pneo)': 80000}
STOR_BRAND = {'Supreme': 1.0, 'Sintex': 1.05, 'RCAP': 0.95, 'Local': 0.85}
PUMP = {'fire pump set 100 PSI (main + jockey)': 900000, 'booster pump (single)': 28000, 'hydro-pneumatic system': 120000, 'solar water heater (ETC)': 60000,
        'solar water heater (flat plate)': 90000, 'geyser (storage 25L)': 9000, 'water softener': 35000, 'RO water purifier (commercial)': 45000, 'UV sterilizer 2"': 22000, 'sump pump (basement drainage)': 18000, 'booster pump per floor': 15000, 'heat pump water heater': 80000, 'solar heater installation kit': 8000}
# ---- pipe fittings & accessories ----
FITACC = {'landing hydrant (double outlet)': 45000, 'hose reel + cabinet': 22000, 'sprinkler head (installed)': 1200, 'elbow 90 (CPVC 25mm)': 80, 'elbow 90 (UPVC 110mm)': 250, 'tee (CPVC 25mm)': 120, 'tee (UPVC 110mm)': 350, 'reducer (CPVC)': 90, 'coupler (CPVC)': 50, 'end cap (UPVC)': 60, 'gate valve 25mm': 450, 'water meter 15mm (domestic)': 3200, 'water meter 25mm (bulk)': 5500, 'ball valve 25mm': 350, 'check valve (NRV) 25mm': 500, 'air valve': 800, 'U-clamp/bracket': 40, 'pipe saddle': 30, 'flange adapter': 250, 'union coupling': 180, 'GI clamp with nail': 15}
# ---- testing & commissioning ----
TEST = {'hydrostatic pressure test (water supply)': 2500, 'smoke test (drainage)': 1500, 'flushing & cleaning (water supply)': 800, 'chlorination (water tank)': 1200, 'flow test (fixtures)': 500, 'pump performance test': 2000, 'commissioning (complete system)': 5000}
# ---- valves & controls (standalone) ----
VALVE = {'gate valve (CI 50mm)': 1200, 'gate valve (CI 100mm)': 2500, 'ball valve (brass 25mm)': 350, 'check valve NRV 50mm': 800, 'pressure reducing valve': 4500, 'float valve (tank)': 600, 'solenoid valve': 2500, 'water meter 25mm': 1800, 'water meter 50mm': 4500}

# ---- pipe trenching (excavation + refilling for underground) ----
TRENCH = {'trench excavation (soft) 600mm wide': 350, 'trench excavation (hard) 600mm wide': 550,
          'trench refilling': 200, 'granular bedding in trench': 800}
# ---- fixture finish tiers ----
FIX_FINISH = {'standard (glossy white)': 1.0, 'premium (matte/matt)': 1.2, 'luxury (designer/color)': 1.5}
# ---- RCC sump/septic breakdown ----
RCC_TANK = {'excavation for tank': 450, 'PCC base 1:4:8': 9500, 'RCC walls + base M25': 16500,
            'RCC cover slab': 16500, 'internal plaster (waterproof)': 500, 'inlet/outlet connection': 2500}
DISP = {'septic tank (RCC)': 9000, 'soak pit': 25000, 'manhole': 18000, 'grease trap': 15000, 'inspection chamber': 8000, 'floor trap (nahani)': 600, 'STP (sewage treatment plant)': 25000, 'rainwater harvesting system': 35000, 'fire hydrant point': 12000, 'fire sprinkler head': 3500, 'swimming pool filtration': 80000}


def _bf(m, k):
    return m.get((k or '').strip(), 1.0)


SPEC = {
    'id': 'sanitary', 'title': 'Sanitary & Plumbing', 'icon': '🚿', 'color': '#2980b9',
    'intro': 'Complete plumbing & toilet estimate: pipes (brand), CP fittings (brand), fixtures '
             '(WC/basin/sink/bathtub with brand), bathroom accessories, tanks, pump/heater, drainage.',
    'upload_guide': [
        'Sanitary fixture layout - toilet/kitchen positions (WC, basin, sink, shower)',
        'Plumbing/drainage layout - ALL pipe runs with diameters',
        'Sanitary schedule - fixture types, brands, counts',
        'Water supply schematic - tank capacity, pump',
        'CP fitting schedule - taps, mixers, showers, diverters with brands',
        'Bathroom accessory schedule - mirror, towel rail, grab bar',
        'STP / sewage treatment plant layout - if applicable',
        'Rainwater harvesting system layout - if applicable',
        'Fire fighting layout - hydrant positions, sprinkler grid',
        'Hot water system - solar heater / geyser / PPR loop',
        'Swimming pool detail - if applicable',
    ],
    'upload_note': 'Upload as many PDFs as needed. Typed fixture/pipe SCHEDULES auto-extract best. For fire-fighting: include the FIRE SYSTEM schedule (fire pump, GI fire main, hydrants, hose reels, sprinklers).',
        'upload_note': 'Fixture counts & pipe lengths auto-extracted from typed schedules. For fire-fighting: include the FIRE SYSTEM schedule (fire pump, GI fire main, hydrants, hose reels, sprinklers).',
    'labour': ['plumber', 'helper', 'fixture_install'],
    'scalars': [{'name': 'project_name', 'label': 'Project name', 'type': 'text', 'default': 'Sanitary & Plumbing'},
                {'name': 'location', 'label': 'Location', 'type': 'text', 'default': 'Kathmandu'}],
    'tables': [
        {'id': 'pipes', 'title': '1. Pipework', 'hint': 'length in any unit (auto-convert)', 'add_label': 'Add pipe run',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(PIPE)},
                    {'name': 'brand', 'label': 'Brand', 'type': 'select', 'options': list(PIPE_BRAND)},
                    {'name': 'diameter', 'label': 'Dia (mm)', 'type': 'suggest', 'options': ['15','20','25','32','40','50','75','110','160']},
                    {'name': 'length', 'label': 'Length (rmt)', 'type': 'number'},
                    {'name': 'underground', 'label': 'Underground?', 'type': 'select', 'options': ['No','Yes (needs trench)']}],
         'default_rows': [{'type': 'CPVC supply 25mm', 'brand': 'Supreme', 'length': 80}, {'type': 'UPVC soil 110mm', 'brand': 'Supreme', 'length': 45},
                          {'type': 'UPVC waste 75mm', 'brand': 'Prince', 'length': 40}, {'type': 'rain water 110mm', 'brand': 'Supreme', 'length': 40}]},
        {'id': 'fit', 'title': '2. CP & Brass Fittings', 'hint': 'taps, mixer, shower, diverter — Nepal brands', 'add_label': 'Add fitting',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(FIT)},
                    {'name': 'brand', 'label': 'Brand', 'type': 'select', 'options': list(FIT_BRAND)}, {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'pillar cock', 'brand': 'Jaquar', 'count': 12}, {'type': 'wall mixer (bath)', 'brand': 'Jaquar', 'count': 4},
                          {'type': 'overhead shower', 'brand': 'Jaquar', 'count': 4}, {'type': 'angle valve (2-way)', 'brand': 'Jaquar', 'count': 12}]},
        {'id': 'fix', 'title': '3. Sanitary Fixtures', 'hint': 'WC, basin, sink, urinal, bathtub, jacuzzi', 'add_label': 'Add fixture',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(FIX)},
                    {'name': 'brand', 'label': 'Brand', 'type': 'select', 'options': list(FIX_BRAND)},
                    {'name': 'finish', 'label': 'Finish', 'type': 'select', 'options': list(FIX_FINISH)},
                    {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'EWC one-piece', 'brand': 'Hindware', 'count': 4}, {'type': 'wash basin (counter)', 'brand': 'Hindware', 'count': 5},
                          {'type': 'SS sink (double bowl)', 'brand': 'Cera', 'count': 1}]},
        {'id': 'acc', 'title': '4. Bathroom & Toilet Accessories', 'hint': 'mirror, shower, towel, grab bar', 'add_label': 'Add accessory',
         'fields': [{'name': 'item', 'label': 'Item', 'type': 'select', 'options': list(ACC)}, {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'item': 'mirror (frameless)', 'count': 5}, {'item': 'towel ring', 'count': 8}, {'item': 'soap dish (wall)', 'count': 5},
                          {'item': 'glass shelf', 'count': 5}, {'item': 'WC brush set', 'count': 4}, {'item': 'grab bar (SS)', 'count': 4}]},
        {'id': 'stor', 'title': '5. Water Storage', 'hint': 'per litre', 'add_label': 'Add storage',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(STOR)},
                    {'name': 'brand', 'label': 'Brand', 'type': 'select', 'options': list(STOR_BRAND)}, {'name': 'cap', 'label': 'Capacity (litres)', 'type': 'number'}],
         'default_rows': [{'type': 'overhead tank (plastic)', 'brand': 'Sintex', 'cap': 3000}, {'type': 'underground sump (RCC)', 'brand': 'Local', 'cap': 10000}]},
        {'id': 'pump', 'title': '6. Pump / Water Heater', 'add_label': 'Add equipment',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(PUMP)}, {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'booster pump (single)', 'count': 1}, {'type': 'geyser (storage 25L)', 'count': 2}]},
        {'id': 'disp', 'title': '7. Drainage & Disposal', 'add_label': 'Add disposal item',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(DISP)},
                    {'name': 'qty', 'label': 'Qty', 'type': 'number'}, {'name': 'unit', 'label': 'Unit', 'type': 'select', 'options': ['nos', 'cum']}],
         'default_rows': [{'type': 'septic tank (RCC)', 'qty': 6, 'unit': 'cum'}, {'type': 'soak pit', 'qty': 1, 'unit': 'nos'}, {'type': 'manhole', 'qty': 2, 'unit': 'nos'}]},
        {'id': 'fitacc', 'title': '8. Pipe Fittings, Valves & Accessories', 'hint': 'elbows, tees, valves, clamps per system', 'add_label': 'Add fitting',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(FITACC) + list(VALVE)},
                    {'name': 'spec', 'label': 'Where / which line', 'type': 'suggest', 'options': ['main supply', 'soil line', 'waste line', 'toilet branch', 'kitchen sink', 'roof tank', 'pump room', 'basement']},
                    {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'gate valve 25mm', 'spec': 'main supply', 'count': 2}, {'type': 'U-clamp/bracket', 'spec': 'pipe support', 'count': 40}]},
        {'id': 'test', 'title': '9. Testing & Commissioning', 'hint': 'pressure test, chlorination, commissioning', 'add_label': 'Add test',
         'fields': [{'name': 'type', 'label': 'Test', 'type': 'select', 'options': list(TEST)},
                    {'name': 'count', 'label': 'Systems', 'type': 'number'}],
         'default_rows': [{'type': 'hydrostatic pressure test (water supply)', 'count': 1}, {'type': 'commissioning (complete system)', 'count': 1}]},
    ],
}


def estimate(sched):
    est = Estimate({}); T = sched['tables']
    for r in T['pipes']:
        L = NUM(r.get('length'))
        if L:
            dia = r.get('diameter','')
            d = f"{r.get('type')} dia {dia} ({r.get('brand')})" if dia else f"{r.get('type')} ({r.get('brand')})"
            est.item('1. Pipework', d + ' with fittings', 'rmt', L, rate=ro(r, PIPE.get(r.get('type'), 600) * _bf(PIPE_BRAND, r.get('brand'))), take=((NUM(r.get('count'),1) or 1), L, None, None), note='pipe running length')
            if 'Yes' in str(r.get('underground','')):
                est.item('1. Pipework', f'Trench excavation + refilling for {r.get("type","pipe")}', 'rmt', L, rate=ro(r, TRENCH.get('trench excavation (soft) 600mm wide', 550)), take=(1, L, None, None), note='along underground pipe run')
    for r in T['fit']:
        c = NUM(r.get('count'))
        if c:
            est.item('2. CP & Brass Fittings', f"{r.get('type')} - {r.get('brand')}", 'nos', c, rate=ro(r, FIT.get(r.get('type'), 1000) * _bf(FIT_BRAND, r.get('brand'))), take=(c, None, None, None), note='numbers')
    for r in T['fix']:
        c = NUM(r.get('count'))
        if c:
            fin = FIX_FINISH.get(r.get('finish','standard (glossy white)'), 1.0)
            est.item('3. Sanitary Fixtures', f"{r.get('type')} - {r.get('brand')} ({r.get('finish','standard')})", 'nos', c, rate=ro(r, FIX.get(r.get('type'), 8000) * _bf(FIX_BRAND, r.get('brand')) * fin), take=(c, None, None, None), note='numbers')
    for r in T['acc']:
        c = NUM(r.get('count'))
        if c:
            est.item('4. Bathroom Accessories', str(r.get('item')), 'nos', c, rate=ro(r, ACC.get(r.get('item'), 800)), take=(c, None, None, None), note='numbers')
    for r in T['stor']:
        cap = NUM(r.get('cap'))
        if cap:
            est.item('5. Water Storage', f"{r.get('type')} ({r.get('brand')}, {int(cap)} L)", 'litre', cap, rate=ro(r, STOR.get(r.get('type'), 35) * _bf(STOR_BRAND, r.get('brand'))), take=((NUM(r.get('count'),1) or 1), cap, None, None), note='count x litre capacity')
    for r in T['pump']:
        c = NUM(r.get('count'))
        if c:
            est.item('6. Pump / Water Heater', str(r.get('type')), 'nos', c, rate=ro(r, PUMP.get(r.get('type'), 28000)), take=(c, None, None, None), note='numbers')
    for r in T['disp']:
        q = NUM(r.get('qty'))
        if q:
            est.item('7. Drainage & Disposal', str(r.get('type')), r.get('unit', 'nos'), q, rate=ro(r, DISP.get(r.get('type'), 8000)), take=(q, None, None, None), note='quantity as entered')
    for r in T['fitacc']:
        c = NUM(r.get('count'))
        if c:
            rate = FITACC.get(r.get('type'), VALVE.get(r.get('type'), 200))
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('8. Pipe Fittings & Valves', d, 'nos', c, rate=ro(r, rate), take=(c, None, None, None), note='numbers')
    for r in T['test']:
        c = NUM(r.get('count'))
        if c:
            est.item('9. Testing & Commissioning', str(r.get('type')), 'system', c, rate=ro(r, TEST.get(r.get('type'), 1500)), take=(c, None, None, None), note='systems')

    sn_plumber_days = round(sum(NUM(r.get('length',0)) for r in T['pipes']) / 20, 0)
    sn_fix_days = round(sum(NUM(r.get('count',0)) for r in T['fix']) * 0.5 + sum(NUM(r.get('count',0)) for r in T['fit']) * 0.3, 0)
    sn_helper_days = round((sn_plumber_days + sn_fix_days) * 1.5, 0)
    sn_total = int(sn_plumber_days + sn_fix_days + sn_helper_days)

    kpis = [('Pipework', f"{sum(NUM(r.get('length')) for r in T['pipes']):.0f} m"), ('Fixtures', f"{sum(NUM(r.get('count')) for r in T['fix']):.0f}")]
    proj = {'name': sched['scalars'].get('project_name', ''), 'location': sched['scalars'].get('location', '')}
    res = est.result(project=proj, kpis=kpis)
    from modules.common import LABOUR_RATES as _LR
    _lrd = sched.get('labour_rates') or {}
    res['labour_rates'] = {k: _lrd.get(k) or _LR[k] for k in ['plumber', 'helper', 'fixture_install']}
    res['labour'] = {
        'plumber_days': int(sn_plumber_days), 'helper_days': int(sn_helper_days),
        'fixture_install_days': int(sn_fix_days), 'total_days': sn_total,
    }
    return res


PDF_KEYWORDS = ['toilet', 'wc', 'basin', 'sink', 'shower', 'bathtub', 'plumbing', 'cpvc', 'pipe', 'septic', 'faucet']
