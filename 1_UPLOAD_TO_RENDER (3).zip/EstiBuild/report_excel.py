"""Professional multi-sheet Excel BOQ builders.
Generates: Cover/Spec sheet, Cost Estimate, Materials, BBS, Labour.

Key detail: formula cells are written WITH cached results. openpyxl leaves the
<v> element empty, so any viewer without a calculation engine (file previews,
Drive, mobile office apps) shows blank amounts. We compute the values here and
inject them into the saved XML — numbers are visible everywhere, and Excel still
recalculates live when the user edits Qty/Rate (fullCalcOnLoad is set).
"""
import io
import os
import re as _re
import zipfile
from PIL import Image as PILImage
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.drawing.image import Image as XLImage
from brand import COMPANY, TAGLINE, CONTACT, CLIENT, LOGO, LOGO_FAINT

CAT = PatternFill('solid', fgColor='2E5A88')
SUB = PatternFill('solid', fgColor='DDE6EF')
TOT = PatternFill('solid', fgColor='FCE4A6')
EDT = PatternFill('solid', fgColor='EAF4EA')
HEAD = PatternFill('solid', fgColor='1F3B57')
WHITE = Font(color='FFFFFF', bold=True)
BOLD = Font(bold=True)
thin = Side(style='thin', color='9DB2C4')
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)
MONEY = '#,##0'
QTY = '#,##0.00'


def _img(path, w, h):
    """openpyxl Image resized to w x h px. PIL-resizing the pixels is required because
    setting .width/.height on an openpyxl Image does NOT persist (it reverts to native
    size on save, which dumps a huge image over the sheet)."""
    pil = PILImage.open(path).convert('RGBA').resize((w, h))
    buf = io.BytesIO(); pil.save(buf, format='PNG'); buf.seek(0)
    return XLImage(buf)


def _brand(ws, last_col):
    if os.path.exists(LOGO):
        try:
            ws.add_image(_img(LOGO, 55, 52), 'A1')
        except Exception:
            pass
    # A merge range must span at least 2 cells. When last_col == 'B' the range
    # would be B1:B1 (single cell) — invalid OOXML that makes Excel show the
    # "we found a problem with some content" repair prompt -> skip the merge.
    if last_col != 'B':
        ws.merge_cells(f'B1:{last_col}1')
    ws['B1'] = COMPANY; ws['B1'].font = Font(bold=True, size=14, color='1F3B57')
    if last_col != 'B':
        ws.merge_cells(f'B2:{last_col}2')
    ws['B2'] = TAGLINE; ws['B2'].font = Font(italic=True, color='555555')
    if last_col != 'B':
        ws.merge_cells(f'B3:{last_col}3')
    ws['B3'] = CONTACT; ws['B3'].font = Font(size=9, color='555555')
    ws['A4'] = 'Prepared By (contractor):'; ws['A4'].font = Font(bold=True, size=9, color='7a8693')
    if last_col != 'B':
        ws.merge_cells(f'B4:{last_col}4')
    ws[f'B4'] = CLIENT; ws[f'B4'].fill = EDT


def _hdr(ws, row, headers, col=1):
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=col+i)
        c.value = h; c.fill = HEAD; c.font = WHITE; c.border = BORDER


def _watermark(ws, anchor):
    if os.path.exists(LOGO_FAINT):
        try:
            ws.add_image(_img(LOGO_FAINT, 220, 205), anchor)
        except Exception:
            pass



def _cur(res):
    """Currency code for this estimate's country (stamped at calculation time)."""
    from country_rates import COUNTRIES
    return COUNTRIES.get(res.get('country_code') or '', {}).get('currency', 'NPR')


def _sheet_cover(wb, res, module_title):
    """Sheet 1: Project Info + Specification + Brands"""
    ws = wb.create_sheet('1. Project Info', 0)
    ws.column_dimensions['A'].width = 28
    ws.column_dimensions['B'].width = 45
    _brand(ws, 'B')
    ws['A6'] = 'PROJECT INFORMATION'; ws['A6'].font = Font(bold=True, size=12, color='1F3B57')
    ws['A6'].fill = SUB
    ws.merge_cells('A6:B6')
    info = [
        ('Module', module_title),
        ('Project', res.get('project', {}).get('name', '')),
        ('Location', res.get('project', {}).get('location', '')),
        (f'Grand Total ({_cur(res)})', f"{res['grand_total']:,.0f}"),
    ]
    if 'totals' in res:
        for k in ('concrete_m3', 'steel_kg', 'shuttering_m2', 'excavation_m3'):
            if k in res['totals']:
                info.append((k.replace('_', ' ').title(), f"{res['totals'][k]:,.1f}"))
    r = 7
    for label, val in info:
        ws.cell(row=r, column=1).value = label
        ws.cell(row=r, column=1).font = BOLD
        ws.cell(row=r, column=2).value = str(val)
        r += 1
    r += 1
    ws.cell(row=r, column=1).value = 'SPECIFICATIONS & BRANDS SELECTED'
    ws.cell(row=r, column=1).font = Font(bold=True, size=12, color='1F3B57')
    ws.cell(row=r, column=1).fill = SUB
    ws.merge_cells(f'A{r}:B{r}')
    r += 1
    specs = [
        ('Standards', 'NBC + IS 456 + IS 2502'),
        ('Currency', f'{_cur(res)} (rates: {res.get("country_code", "NEPAL")})'),
        ('Rates', 'Composite (Material + Labour included)'),
        ('Excel formulas', 'Amount = Qty x Rate (editable, recalculates in Excel)'),
        ('BBS', 'Auto-generated (no upload needed)'),
        ('Wastage', 'Steel +3%, Concrete materials +5%'),
    ]
    for label, val in specs:
        ws.cell(row=r, column=1).value = label
        ws.cell(row=r, column=1).font = BOLD
        ws.cell(row=r, column=2).value = val
        r += 1
    return ws


def _sheet_boq(wb, res, title, watermark=True, cache=None, tk_rows=None, name=None, tk_sheet='3. Quantity Takeoff'):
    """Sheet 2: Cost Estimate (BOQ with rates + cached formula results).
    Qty cells LIVE-LINK to the Quantity Takeoff sheet wherever a measurement
    line exists: ='3. Quantity Takeoff'!J<row> (or a sum of rows)."""
    ws = wb.create_sheet(name or '2. Cost Estimate')
    _brand(ws, 'E')
    ws.merge_cells('A5:E5')
    ws['A5'] = f'{title.upper()} - BILL OF QUANTITIES (editable formulas)'
    ws['A5'].font = Font(bold=True, size=12, color='7d3c98')
    ws.merge_cells('A6:E6')
    n_items = sum(len(g.get('items', [])) for g in res['groups'].values())
    if n_items == 0:
        ws['A6'] = 'WARNING: THIS ESTIMATE IS EMPTY - fill the schedule and click Calculate before exporting.'
        ws['A6'].font = Font(bold=True, color='C0392B')
    else:
        ws['A6'] = ('LIVE-LINKED: Qty cells with measurements reference the Quantity Takeoff '
                    'sheet - change L/B/D there and this BOQ recalculates. Rates (green) editable here.')
        ws['A6'].font = Font(italic=True, color='555555')
    HR = 7
    _hdr(ws, HR, ['Item', 'Unit', 'Qty', f'Rate {_cur(res)}', f'Amount {_cur(res)}'])
    r = HR + 1
    subtotal_cells = []
    for gname, info in res['groups'].items():
        ws.merge_cells(f'A{r}:E{r}')
        ws.cell(row=r, column=1).value = gname
        ws.cell(row=r, column=1).fill = CAT; ws.cell(row=r, column=1).font = WHITE
        r += 1
        first = r
        for it in info['items']:
            ws.cell(row=r, column=1).value = it['desc']
            ws.cell(row=r, column=2).value = it['unit']
            # live-link qty to Quantity Takeoff rows when measurement lines exist
            link = None
            if tk_rows and it.get('tk'):
                rows_ = [tk_rows[i] for i in it['tk'] if i in tk_rows]
                if rows_:
                    link = '=' + '+'.join(f"'{tk_sheet}'!K{rr}" for rr in rows_)
            if link:
                ws.cell(row=r, column=3).value = link
                if cache is not None:
                    cache[f'C{r}'] = it['qty']
            else:
                ws.cell(row=r, column=3).value = it['qty']
            ws.cell(row=r, column=3).number_format = QTY
            ws.cell(row=r, column=4).value = it['rate']
            ws.cell(row=r, column=4).number_format = MONEY
            ws.cell(row=r, column=5).value = f'=C{r}*D{r}'
            ws.cell(row=r, column=5).number_format = MONEY
            if cache is not None:
                cache[f'E{r}'] = round(it['qty'] * it['rate'], 2)
            ws.cell(row=r, column=3).fill = EDT
            ws.cell(row=r, column=4).fill = EDT
            for col in range(1, 6):
                ws.cell(row=r, column=col).border = BORDER
            r += 1
        last = r - 1
        ws.merge_cells(f'A{r}:D{r}')
        ws.cell(row=r, column=1).value = 'Sub-total'
        ws.cell(row=r, column=1).font = BOLD; ws.cell(row=r, column=1).fill = SUB
        ws.cell(row=r, column=1).alignment = Alignment(horizontal='right')
        ws.cell(row=r, column=5).value = f'=SUM(E{first}:E{last})'
        ws.cell(row=r, column=5).number_format = MONEY
        if cache is not None:
            cache[f'E{r}'] = info['subtotal']
        ws.cell(row=r, column=5).fill = SUB; ws.cell(row=r, column=5).font = BOLD
        subtotal_cells.append(f'E{r}')
        r += 1
    ws.merge_cells(f'A{r}:D{r}')
    ws.cell(row=r, column=1).value = 'GRAND TOTAL'
    ws.cell(row=r, column=1).fill = TOT; ws.cell(row=r, column=1).font = Font(bold=True, size=12)
    ws.cell(row=r, column=1).alignment = Alignment(horizontal='right')
    ws.cell(row=r, column=5).value = '=' + '+'.join(subtotal_cells)
    ws.cell(row=r, column=5).number_format = MONEY
    if cache is not None:
        cache[f'E{r}'] = res['grand_total']
    ws.cell(row=r, column=5).fill = TOT; ws.cell(row=r, column=5).font = Font(bold=True, size=12)
    ws.column_dimensions['A'].width = 50
    for c in 'BCDE':
        ws.column_dimensions[c].width = 14
    if watermark:
        _watermark(ws, 'C15')
    return ws



def _tk_layout(res):
    """Deterministic row layout of the Quantity Takeoff sheet.
    Returns list of (row_number, takeoff_index_or_None, section_name)."""
    out = []
    r = 8                       # header row 7, data starts at 8
    cur = None
    for i, t in enumerate(res.get('takeoff') or []):
        if t.get('group') != cur:
            cur = t.get('group')
            out.append((r, None, cur))
            r += 1
        out.append((r, i, None))
        r += 1
    return out


def _sheet_takeoff(wb, res, cache=None, name=None):
    """Sheet 3: Quantity Takeoff - measurement-sheet style (Nos x L x B x D = Qty).
    LIVE: dims drive =PRODUCT() formulas, and the Cost Estimate sheet's Qty cells
    reference these results - change L/B/D here and the whole BOQ recalculates."""
    ws = wb.create_sheet(name or '3. Quantity Takeoff')
    _brand(ws, 'L')
    ws.merge_cells('A5:L5')
    ws['A5'] = 'QUANTITY TAKEOFF / MEASUREMENT SHEET (nos x L x B x D x wt = quantity)'
    ws['A5'].font = Font(bold=True, size=12, color='1F9D55')
    ws.merge_cells('A6:L6')
    ws['A6'] = ('LIVE SHEET: change any Nos / L / B / D / Wt value - the Qty here AND in the '
                'Cost Estimate sheet recalculate automatically (open in Excel). '
                'Wt/unit = kg/m (steel sections) or kg/m² (trusses). Quantities only.')
    ws['A6'].font = Font(italic=True, color='555555')
    HR = 7
    _hdr(ws, HR, ['#', 'Section', 'Item / Description', 'Nos', 'L (m)', 'B (m)',
                  'D/H (m)', 'Wt/unit', 'Unit', 'Calculation', 'Qty', 'Remarks'])
    tk = res.get('takeoff') or []
    idx = 0
    for row, i, section in _tk_layout(res):
        if section is not None:
            ws.merge_cells(f'A{row}:L{row}')
            ws.cell(row=row, column=1).value = section or ''
            ws.cell(row=row, column=1).fill = CAT; ws.cell(row=row, column=1).font = WHITE
            continue
        t = tk[i]
        idx += 1
        dims = [t.get('nos'), t.get('L'), t.get('B'), t.get('D'), t.get('wt')]
        prod = 1.0; n_dim = 0
        for d in dims:
            if isinstance(d, (int, float)):
                prod *= d; n_dim += 1
        calc = ' x '.join(f'{d:,.2f}'.rstrip('0').rstrip('.') if isinstance(d, float) else f'{d}'
                          for d in dims if d is not None) or '-'
        ws.cell(row=row, column=1).value = idx
        ws.cell(row=row, column=3).value = t.get('desc')
        for j, d in enumerate(dims):
            c = ws.cell(row=row, column=4 + j)
            if isinstance(d, (int, float)):
                c.value = round(d, 3); c.number_format = QTY
                c.fill = EDT
        ws.cell(row=row, column=9).value = t.get('unit')
        ws.cell(row=row, column=10).value = calc
        if n_dim >= 2 and abs(prod - (t.get('qty') or 0)) < max(0.005, abs(t.get('qty') or 0) * 0.001):
            ws.cell(row=row, column=11).value = f'=PRODUCT(D{row}:H{row})'
            ws.cell(row=row, column=11).number_format = QTY
            if cache is not None:
                cache[f'K{row}'] = round(prod, 3)
        else:
            ws.cell(row=row, column=11).value = t.get('qty')
            ws.cell(row=row, column=11).number_format = QTY
            if t.get('qty') is not None and cache is not None:
                cache[f'K{row}'] = t.get('qty')
        ws.cell(row=row, column=12).value = t.get('note') or ''
        for col in range(1, 13):
            ws.cell(row=row, column=col).border = BORDER
    if not tk:
        ws.merge_cells('A8:L8')
        ws.cell(row=8, column=1).value = 'No measurement lines recorded for this estimate.'
        ws.cell(row=8, column=1).font = Font(italic=True, color='777777')
    ws.column_dimensions['A'].width = 5
    ws.column_dimensions['B'].width = 4
    ws.column_dimensions['C'].width = 46
    for c in 'DEFG':
        ws.column_dimensions[c].width = 10
    ws.column_dimensions['H'].width = 9
    ws.column_dimensions['I'].width = 7
    ws.column_dimensions['J'].width = 26
    ws.column_dimensions['K'].width = 12
    ws.column_dimensions['L'].width = 34
    return ws


def _sheet_material(wb, res, cache=None, name=None):
    """Sheet 3: Material Summary"""
    ws = wb.create_sheet(name or '4. Materials')
    _brand(ws, 'E')
    ws.merge_cells('A4:E4')
    ws['A4'] = 'MATERIAL PROCUREMENT SUMMARY (editable)'
    ws['A4'].font = Font(bold=True, size=12, color='1F3B57')
    if res.get('materials'):
        mats = res['materials']
        _hdr(ws, 5, ['Material', 'Qty', 'Unit', f'Rate {_cur(res)}', f'Value {_cur(res)}'])
        r = 6
        if isinstance(mats, dict):
            mat_names = {'cement_bags': ('Cement (OPC 53)', 'bags', 950),
                         'sand_m3': ('Fine Aggregate (Sand)', 'cum', 2500),
                         'aggregate_m3': ('Coarse Aggregate', 'cum', 2800),
                         'steel_kg': ('TMT Steel (Fe500)', 'kg', 150),
                         'brick_no': ('Bricks', 'nos', 18),
                         'block_no': ('Blocks (AAC)', 'nos', 120)}
            for k, v in mats.items():
                if k in ('waste_steel_pct', 'waste_conc_pct'): continue
                info = mat_names.get(k, (k, '', 0))
                ws.cell(row=r, column=1).value = info[0]
                ws.cell(row=r, column=2).value = round(v, 1)
                ws.cell(row=r, column=3).value = info[1]
                ws.cell(row=r, column=4).value = info[2]
                ws.cell(row=r, column=4).number_format = MONEY
                ws.cell(row=r, column=5).value = f'=B{r}*D{r}'
                ws.cell(row=r, column=5).number_format = MONEY
                if cache is not None:
                    cache[f'E{r}'] = round(round(v, 1) * info[2], 2)
                ws.cell(row=r, column=2).fill = EDT; ws.cell(row=r, column=4).fill = EDT
                r += 1
        elif isinstance(mats, list):
            for m in mats:
                ws.cell(row=r, column=1).value = m['label']
                ws.cell(row=r, column=2).value = m['qty']
                ws.cell(row=r, column=3).value = m['unit']
                ws.cell(row=r, column=4).value = m['rate']
                ws.cell(row=r, column=4).number_format = MONEY
                ws.cell(row=r, column=5).value = f'=B{r}*D{r}'
                ws.cell(row=r, column=5).number_format = MONEY
                if cache is not None:
                    cache[f'E{r}'] = round(m['qty'] * m['rate'], 2)
                ws.cell(row=r, column=2).fill = EDT; ws.cell(row=r, column=4).fill = EDT
                r += 1
    ws.column_dimensions['A'].width = 26
    for c in 'BCDE':
        ws.column_dimensions[c].width = 14
    return ws


def _sheet_labour(wb, res, cache=None, name=None):
    """Sheet 4: Labour Estimate"""
    ws = wb.create_sheet(name or '5. Labour')
    ws.merge_cells('A1:D1')
    ws['A1'] = COMPANY; ws['A1'].font = Font(bold=True, size=14, color='1F3B57')
    labour = res.get('labour', {})
    if not labour:
        ws['A3'] = 'Labour estimate not available for this module.'
        return ws
    _hdr(ws, 3, ['Trade', 'Days', 'Rate/Day (NPR)', 'Cost (NPR)'])
    _user = res.get('labour_rates') or {}
    rates = {'mason_days': _user.get('mason', 1200), 'mazdoor_days': _user.get('mazdoor', 800),
             'plumber_days': _user.get('plumber', 1500), 'electrician_days': _user.get('electrician', 1500),
             'wireman_days': _user.get('wireman', 1200), 'helper_days': _user.get('helper', 800),
             'tile_mason_days': _user.get('tile_mason', 1400), 'painter_days': _user.get('painter', 1300),
             'fixture_days': _user.get('fixture', 1200), 'fixture_install_days': _user.get('fixture_install', 1300),
             'steel_fab_days': _user.get('steel_fab', 1400)}
    labels = {'mason_days': 'Mason', 'mazdoor_days': 'Mazdoor (Helper)',
              'plumber_days': 'Plumber', 'electrician_days': 'Electrician',
              'wireman_days': 'Wireman', 'helper_days': 'Helper',
              'tile_mason_days': 'Tile Mason', 'painter_days': 'Painter',
              'fixture_days': 'Fixture Installer', 'fixture_install_days': 'Fixture Installer',
              'steel_fab_days': 'Steel Fabricator'}
    r = 4
    total_days = 0
    total_cost = 0
    for key, days in labour.items():
        if key in ('note', 'total_days') or 'cost' in key or not isinstance(days, (int, float)):
            continue
        if not days:
            continue
        rate = rates.get(key, 1000)
        cost = days * rate
        ws.cell(row=r, column=1).value = labels.get(key, key.replace('_', ' ').title())
        ws.cell(row=r, column=2).value = days
        ws.cell(row=r, column=3).value = rate
        ws.cell(row=r, column=3).number_format = MONEY
        ws.cell(row=r, column=4).value = f'=B{r}*C{r}'
        ws.cell(row=r, column=4).number_format = MONEY
        if cache is not None:
            cache[f'D{r}'] = round(cost, 2)
        total_days += days
        total_cost += cost
        r += 1
    ws.cell(row=r, column=1).value = 'TOTAL'
    ws.cell(row=r, column=1).font = BOLD; ws.cell(row=r, column=1).fill = SUB
    ws.cell(row=r, column=2).value = total_days
    ws.cell(row=r, column=2).font = BOLD; ws.cell(row=r, column=2).fill = SUB
    ws.cell(row=r, column=4).value = total_cost
    ws.cell(row=r, column=4).number_format = MONEY
    ws.cell(row=r, column=4).font = BOLD; ws.cell(row=r, column=4).fill = SUB
    r += 2
    ws.cell(row=r, column=1).value = 'Note: Labour cost is already included in the BOQ rates above.'
    ws.cell(row=r, column=1).font = Font(italic=True, size=9, color='7a8693')
    ws.column_dimensions['A'].width = 24
    for c in 'BCD':
        ws.column_dimensions[c].width = 16
    return ws


def _sheet_bbs(wb, res, name=None):
    """Sheet 5: Bar Bending Schedule (structural only)"""
    ws = wb.create_sheet(name or '6. BBS (Bar Schedule)')
    ws.merge_cells('A1:H1')
    ws['A1'] = 'BAR BENDING SCHEDULE (auto-generated)'
    ws['A1'].font = Font(bold=True, size=14, color='1F3B57')
    bbs = res.get('bbs_table', [])
    if not bbs:
        ws['A3'] = 'BBS not applicable for this module.'
        return ws
    _hdr(ws, 3, ['Bar Mark', 'Member', 'Dia (mm)', 'Nos', 'Cut Length (m)', 'Total Length (m)', 'Unit Wt (kg/m)', 'Weight (kg)'])
    r = 4
    total_wt = 0
    for b in bbs:
        ws.cell(row=r, column=1).value = b['mark']
        ws.cell(row=r, column=2).value = b['member']
        ws.cell(row=r, column=3).value = b['dia']
        ws.cell(row=r, column=4).value = b['count']
        ws.cell(row=r, column=5).value = b['cut_len']
        ws.cell(row=r, column=6).value = b['total_len']
        ws.cell(row=r, column=6).number_format = QTY
        ws.cell(row=r, column=7).value = b['unit_wt']
        ws.cell(row=r, column=8).value = b['weight']
        ws.cell(row=r, column=8).number_format = '#,##0.0'
        total_wt += b['weight']
        r += 1
    ws.cell(row=r, column=1).value = 'TOTAL (before 3% wastage)'
    ws.merge_cells(f'A{r}:G{r}')
    ws.cell(row=r, column=1).font = BOLD; ws.cell(row=r, column=1).fill = SUB
    ws.cell(row=r, column=1).alignment = Alignment(horizontal='right')
    ws.cell(row=r, column=8).value = round(total_wt, 1)
    ws.cell(row=r, column=8).number_format = '#,##0.0'
    ws.cell(row=r, column=8).font = BOLD; ws.cell(row=r, column=8).fill = SUB
    r += 1
    ws.cell(row=r, column=1).value = f'TOTAL (after 3% wastage) = {res.get("totals",{}).get("steel_kg",0):,.0f} kg'
    ws.merge_cells(f'A{r}:H{r}')
    ws.cell(row=r, column=1).font = Font(bold=True, size=11, color='b8860b')
    r += 2
    ws.cell(row=r, column=1).value = 'STEEL BY DIAMETER (for ordering):'
    ws.cell(row=r, column=1).font = BOLD
    r += 1
    bars12 = res.get('steel_bars12') or {}
    for d, v in res.get('steel_by_dia', {}).items():
        ws.cell(row=r, column=1).value = f'Dia {d}mm'
        ws.cell(row=r, column=2).value = f'{v:,.0f} kg'
        if d in bars12:
            ws.cell(row=r, column=3).value = f'{bars12[d]} bars of 12m'
        r += 1
    ws.column_dimensions['A'].width = 22
    ws.column_dimensions['B'].width = 10
    for c in 'CDEFGH':
        ws.column_dimensions[c].width = 14
    return ws


def _finish(wb, cache):
    """Save workbook to bytes and inject cached results into formula cells.
    openpyxl writes <f>...</f><v></v> (EMPTY value) — viewers without a calc
    engine then show blank amounts. Injecting the computed number into <v> makes
    the values visible everywhere; Excel still recalculates on open/edit."""
    buf = io.BytesIO()
    wb.save(buf)
    data = buf.getvalue()
    if not cache:
        return data
    try:
        zin = zipfile.ZipFile(io.BytesIO(data))
        items = {n: zin.read(n) for n in zin.namelist()}
        zin.close()
        wbxml = items['xl/workbook.xml'].decode('utf-8')
        rels = items['xl/_rels/workbook.xml.rels'].decode('utf-8')
    except Exception:
        return data
    relmap = {}
    for rel in _re.finditer(r'<Relationship\b[^>]*/?>', rels):
        tag = rel.group(0)
        mid = _re.search(r'Id="([^"]+)"', tag)
        mtg = _re.search(r'Target="([^"]+)"', tag)
        if mid and mtg:
            relmap[mid.group(1)] = mtg.group(1)
    for m in _re.finditer(r'<sheet\b[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"', wbxml):
        name, rid = m.group(1), m.group(2)
        if name not in cache or rid not in relmap:
            continue
        target = relmap[rid].lstrip('/')
        path = target if target.startswith('xl/') else 'xl/' + target
        if path not in items:
            continue
        xml = items[path].decode('utf-8')
        for ref, val in cache[name].items():
            pat = _re.compile(r'(<c r="%s"[^>]*>)(<f[^>]*>[^<]*</f>)(?:<v\s*/>|<v></v>)'
                              % _re.escape(ref))
            xml = pat.sub(lambda mm, v=val: f'{mm.group(1)}{mm.group(2)}<v>{v}</v>', xml, count=1)
        items[path] = xml.encode('utf-8')
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zout:
        for n, d in items.items():
            zout.writestr(n, d)
    return out.getvalue()



def _sheet_commercial(wb, cache=None, name='6. Commercial Summary', lines=None):
    """Final client price: direct costs + overhead% + profit% + contingency% + VAT%.
    All % cells (green) are editable - every amount is a live formula."""
    ws = wb.create_sheet(name)
    _brand(ws, 'C')
    ws.merge_cells('A5:C5')
    ws['A5'] = 'COMMERCIAL SUMMARY - FINAL CLIENT PRICE'
    ws['A5'].font = Font(bold=True, size=13, color='9C6500')
    ws.merge_cells('A6:C6')
    ws['A6'] = ('Edit the green % cells to suit your contract - all amounts recalculate. '
                'Typical: overhead 5-8%, profit 10-15%, contingency 3-5%. VAT: Nepal/India 13%, UAE 5%.')
    ws['A6'].font = Font(italic=True, size=9, color='555555')
    _hdr(ws, 7, ['Particulars', 'Amount', 'Rate / % (editable)'])

    lines = lines or []
    d = sum(a for _l, a in lines)
    r = 8
    first = r
    for label, amt in lines:
        ws.cell(row=r, column=1).value = label
        ws.cell(row=r, column=2).value = amt
        ws.cell(row=r, column=2).number_format = MONEY
        if cache is not None:
            cache[f'B{r}'] = amt
        r += 1
    # direct cost total
    ws.cell(row=r, column=1).value = 'DIRECT COST (total estimate)'
    ws.cell(row=r, column=1).font = BOLD
    ws.cell(row=r, column=2).value = f'=SUM(B{first}:B{r - 1})'
    ws.cell(row=r, column=2).number_format = MONEY
    if cache is not None:
        cache[f'B{r}'] = round(d, 2)
    ws.cell(row=r, column=2).fill = SUB
    direct = r
    r += 2

    def pct_line(label, pct, note, formula, cached):
        nonlocal r
        ws.cell(row=r, column=1).value = label
        pc = ws.cell(row=r, column=3)
        pc.value = pct
        pc.number_format = '0.0"%"'
        pc.fill = EDT
        ws.cell(row=r, column=2).value = formula
        ws.cell(row=r, column=2).number_format = MONEY
        if cache is not None:
            cache[f'B{r}'] = round(cached, 2)
        ws.cell(row=r, column=3).value = note
        for col in range(1, 4):
            ws.cell(row=r, column=col).border = BORDER
        r += 1
        return r - 1

    oh = pct_line('Overhead / site establishment', 5.0, '% of direct cost',
                  f'=B{direct}*C{r}/100', d * 0.05)
    sub1 = r
    ws.cell(row=r, column=1).value = 'Sub-total (direct + overhead)'
    ws.cell(row=r, column=1).font = BOLD
    ws.cell(row=r, column=2).value = f'=B{direct}+B{oh}'
    ws.cell(row=r, column=2).number_format = MONEY
    if cache is not None:
        cache[f'B{r}'] = round(d * 1.05, 2)
    r += 1
    pf = pct_line('Contractor profit', 10.0, '% of sub-total',
                  f'=B{sub1}*C{r}/100', d * 1.05 * 0.10)
    ct = pct_line('Contingency / risk allowance', 3.0, '% of direct cost',
                  f'=B{direct}*C{r}/100', d * 0.03)
    sub2 = r
    ws.cell(row=r, column=1).value = 'SUB-TOTAL BEFORE VAT'
    ws.cell(row=r, column=1).font = BOLD
    ws.cell(row=r, column=2).value = f'=B{sub1}+B{pf}+B{ct}'
    ws.cell(row=r, column=2).number_format = MONEY
    if cache is not None:
        cache[f'B{r}'] = round(d * 1.05 + d * 1.05 * 0.10 + d * 0.03, 2)
    ws.cell(row=r, column=2).fill = SUB
    r += 1
    vt = pct_line('VAT', 13.0, 'Nepal/India 13% - UAE 5%',
                  f'=B{sub2}*C{r}/100', (d * 1.05 + d * 1.05 * 0.10 + d * 0.03) * 0.13)
    r += 1
    ws.cell(row=r, column=1).value = 'FINAL CLIENT PRICE'
    ws.cell(row=r, column=1).font = Font(bold=True, size=12)
    ws.cell(row=r, column=2).value = f'=B{sub2}+B{vt}'
    ws.cell(row=r, column=2).number_format = MONEY
    if cache is not None:
        cache[f'B{r}'] = round((d * 1.05 + d * 1.05 * 0.10 + d * 0.03) * 1.13, 2)
    ws.cell(row=r, column=2).fill = TOT
    ws.cell(row=r, column=2).font = Font(bold=True, size=12)
    ws.cell(row=r, column=3).value = 'incl. overheads, profit & VAT'
    ws.column_dimensions['A'].width = 40
    ws.column_dimensions['B'].width = 18
    ws.column_dimensions['C'].width = 26
    return ws

def build_module_excel(res, title, watermark=True):
    """Build multi-sheet Excel for schedule modules (archfin, sanitary, electrical).
    Returns bytes (with cached formula values)."""
    wb = Workbook()
    wb.remove(wb.active)
    cache = {}
    _sheet_cover(wb, res, title)
    tk_rows = {i: row for row, i, _s in _tk_layout(res) if i is not None}
    _sheet_boq(wb, res, title, watermark, cache.setdefault('2. Cost Estimate', {}), tk_rows)
    _sheet_takeoff(wb, res, cache.setdefault('3. Quantity Takeoff', {}))
    _sheet_material(wb, res, cache.setdefault('4. Materials', {}))
    _sheet_labour(wb, res, cache.setdefault('5. Labour', {}))
    _sheet_commercial(wb, cache.setdefault('6. Commercial Summary', {}),
                      lines=[(f'{title} - direct cost', res['grand_total'])])
    return _finish(wb, cache)


def build_structural_excel(res, watermark=True):
    """Build multi-sheet Excel for structural module. Returns bytes (with cached
    formula values)."""
    wb = Workbook()
    wb.remove(wb.active)
    cache = {}
    _sheet_cover(wb, res, 'RCC Structure Estimate')
    tk_rows = {i: row for row, i, _s in _tk_layout(res) if i is not None}
    _sheet_boq(wb, res, 'RCC Structure Estimate', watermark, cache.setdefault('2. Cost Estimate', {}), tk_rows)
    _sheet_takeoff(wb, res, cache.setdefault('3. Quantity Takeoff', {}))
    _sheet_material(wb, res, cache.setdefault('4. Materials', {}))
    _sheet_labour(wb, res, cache.setdefault('5. Labour', {}))
    _sheet_bbs(wb, res)
    _sheet_commercial(wb, cache.setdefault('7. Commercial Summary', {}),
                      lines=[('RCC Structure - direct cost', res['grand_total'])])
    return _finish(wb, cache)
MODULE_ORDER = [('structural', 'RCC Structure', 'RCC'),
                ('archfin', 'Architecture & Finishing', 'ARCH'),
                ('sanitary', 'Sanitary & Plumbing', 'SAN'),
                ('electrical', 'Electrical', 'ELEC'),
                ('steel', 'Steel Structure', 'STEEL'),
                ('roofing', 'Roofing & Truss', 'ROOF')]


def build_combined_excel(results, country_label=''):
    """One master workbook: every calculated module's sheets + project summary +
    commercial summary (final client price). results = {sid: res}."""
    wb = Workbook()
    wb.remove(wb.active)
    cache = {}
    ws = wb.create_sheet('1. Project Summary')
    _brand(ws, 'C')
    ws.merge_cells('A5:C5')
    ws['A5'] = 'PROJECT MASTER BOQ - ALL MODULES'
    ws['A5'].font = Font(bold=True, size=13, color='1F3B57')
    if country_label:
        ws.merge_cells('A6:C6')
        ws['A6'] = f'Country rates: {country_label}'
        ws['A6'].font = Font(italic=True, color='555555')
    _hdr(ws, 8, ['Module', 'Direct Cost', 'Status'])
    sc = cache.setdefault('1. Project Summary', {})
    r = 9
    first = r
    for sid, title, _p in MODULE_ORDER:
        ws.cell(row=r, column=1).value = title
        if sid in results:
            amt = results[sid]['grand_total']
            ws.cell(row=r, column=2).value = amt
            ws.cell(row=r, column=2).number_format = MONEY
            sc[f'B{r}'] = amt
            ws.cell(row=r, column=3).value = 'calculated'
            r += 1
        else:
            ws.cell(row=r, column=3).value = 'not calculated'
            r += 1
    ws.cell(row=r, column=1).value = 'PROJECT TOTAL (direct cost)'
    ws.cell(row=r, column=1).font = BOLD
    ws.cell(row=r, column=2).value = f'=SUM(B{first}:B{r-1})'
    ws.cell(row=r, column=2).number_format = MONEY
    sc[f'B{r}'] = round(sum(v['grand_total'] for v in results.values()), 2)
    ws.cell(row=r, column=2).fill = TOT
    r += 2
    ws.cell(row=r, column=1).value = ('Each module has its own BOQ / Quantity Takeoff / Materials / Labour sheets '
                                      'in this workbook. The Commercial Summary sheet at the end gives the FINAL '
                                      'client price (overhead + profit + contingency + VAT - all editable).')
    ws.cell(row=r, column=1).font = Font(italic=True, size=9, color='555555')
    ws.column_dimensions['A'].width = 36
    ws.column_dimensions['B'].width = 18
    ws.column_dimensions['C'].width = 16
    for sid, title, pref in MODULE_ORDER:
        res = results.get(sid)
        if not res:
            continue
        tk_rows = {i: row for row, i, _s in _tk_layout(res) if i is not None}
        _sheet_boq(wb, res, title, True, cache.setdefault(f'{pref} - BOQ', {}), tk_rows,
                   name=f'{pref} - BOQ', tk_sheet=f'{pref} - Takeoff')
        _sheet_takeoff(wb, res, cache.setdefault(f'{pref} - Takeoff', {}), name=f'{pref} - Takeoff')
        _sheet_material(wb, res, cache.setdefault(f'{pref} - Materials', {}), name=f'{pref} - Materials')
        _sheet_labour(wb, res, cache.setdefault(f'{pref} - Labour', {}), name=f'{pref} - Labour')
        if sid == 'structural':
            _sheet_bbs(wb, res, name='RCC - BBS')
    _sheet_commercial(wb, cache.setdefault('Commercial Summary', {}), name='Commercial Summary',
                      lines=[(t, results[s]['grand_total']) for s, t, _p in MODULE_ORDER if s in results])
    return _finish(wb, cache)
