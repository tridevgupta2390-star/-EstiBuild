"""Country-specific construction rates — Nepal / India / Dubai.
Real market rates (2024-2025). Editable per-row in the app.
To add a country: copy a block, change name/currency/rates."""

COUNTRIES = {
    'NEPAL': {
        'name': 'Nepal', 'flag': '🇳🇵', 'currency': 'NPR', 'symbol': 'Rs',
        'factor': 1.0,
        'key_rates': {
            'rcc_m3': 16500, 'pcc_m3': 9500, 'excavation_m3': 450, 'backfill_m3': 400,
            'soling_m3': 3500, 'shuttering_m2': 850, 'steel_kg': 150,
            'cement_bag': 950, 'sand_m3': 2500, 'aggregate_m3': 2800,
            'brick_no': 18, 'block_no': 120,
            'mason_day': 1200, 'mazdoor_day': 800,
            'brickwork_m3': 9500, 'plaster_m2': 320, 'painting_m2': 130,
            'flooring_m2': 1800, 'cpvc_m': 600, 'pvc_m': 950,
            'light_point': 1800, 'wire_m': 110, 'led_no': 1500,
        }
    },
    'INDIA': {
        'name': 'India', 'flag': '🇮🇳', 'currency': 'INR', 'symbol': '₹',
        'factor': 0.50,
        'key_rates': {
            'rcc_m3': 8500, 'pcc_m3': 5500, 'excavation_m3': 250, 'backfill_m3': 200,
            'soling_m3': 2000, 'shuttering_m2': 450, 'steel_kg': 75,
            'cement_bag': 400, 'sand_m3': 1800, 'aggregate_m3': 1500,
            'brick_no': 8, 'block_no': 55,
            'mason_day': 600, 'mazdoor_day': 400,
            'brickwork_m3': 5500, 'plaster_m2': 200, 'painting_m2': 70,
            'flooring_m2': 800, 'cpvc_m': 300, 'pvc_m': 500,
            'light_point': 900, 'wire_m': 55, 'led_no': 800,
        }
    },
    'UAE': {
        'name': 'Dubai / UAE', 'flag': '🇦🇪', 'currency': 'AED', 'symbol': 'AED',
        'factor': 0.067,
        'key_rates': {
            'rcc_m3': 1100, 'pcc_m3': 600, 'excavation_m3': 35, 'backfill_m3': 30,
            'soling_m3': 250, 'shuttering_m2': 55, 'steel_kg': 4.5,
            'cement_bag': 18, 'sand_m3': 100, 'aggregate_m3': 85,
            'brick_no': 2, 'block_no': 4,
            'mason_day': 180, 'mazdoor_day': 100,
            'brickwork_m3': 650, 'plaster_m2': 30, 'painting_m2': 12,
            'flooring_m2': 90, 'cpvc_m': 40, 'pvc_m': 65,
            'light_point': 120, 'wire_m': 8, 'led_no': 100,
        }
    },
}

import copy

_current = {'code': None}
_BASE = {'captured': False}


def get_country():
    return _current['code']


def set_country(code):
    _current['code'] = code


def _capture_base():
    """Snapshot the original Nepal (base) rate maps before any country scaling,
    so switching countries repeatedly never compounds the factor."""
    if _BASE['captured']:
        return
    import structural.engine as se
    import modules.archfin as af
    import modules.sanitary as sn
    import modules.electrical as el
    import estimation.norms as n
    _BASE['struct_labour'] = (se.LABOUR.get('rate_mason', 1200), se.LABOUR.get('rate_mazdoor', 800),
                              se.DEFAULT_SCHEDULE.get('labour_rates', {}).get('steel_fab', 1400))
    _BASE['struct_maps'] = {'OTHER': copy.deepcopy(getattr(se, 'OTHER', {})),
                            'PUMP_RATE': copy.deepcopy(getattr(se, 'PUMP_RATE', {})),
                            'SOIL_RATE': copy.deepcopy(getattr(se, 'SOIL_RATE', {})),
                            'WEEP_RATE': getattr(se, 'WEEP_RATE', 60)}
    _BASE['archfin'] = {a: copy.deepcopy(getattr(af, a, {}))
                        for a in ['WALL', 'PLASTER', 'FLOOR', 'WTILE', 'PAINT', 'CEIL', 'CLAD', 'GLASS',
                                  'DOOR', 'WIN', 'RAIL', 'WP', 'POLISH', 'MISC', 'FILL', 'PART',
                                  'STAIR_FIN', 'SILL', 'ROOF_FIN', 'METAL', 'COMPOUND', 'SURFACE',
                                  'PRECAST', 'DHWARE', 'SEALANT', 'DOOR_FRAME', 'DOOR_HW',
                                  'WIN_FRAME', 'WIN_GLASS', 'VENT_RATE']}
    _BASE['archfin_scalar'] = {a: getattr(af, a) for a in ('DOOR_ARCH', 'WIN_MESH', 'BLK', 'DPC_RATE', 'SKIRT_RATE', 'BALCONY_RATE')}
    _BASE['sanitary'] = {a: copy.deepcopy(getattr(sn, a, {}))
                         for a in ['PIPE', 'FIT', 'FIX', 'ACC', 'STOR', 'PUMP', 'DISP', 'FITACC',
                                   'VALVE', 'TEST', 'TRENCH', 'RCC_TANK']}
    _BASE['electrical'] = {a: copy.deepcopy(getattr(el, a, {}))
                           for a in ['POINT', 'WIRE', 'SWITCH', 'FIXT', 'EARTH', 'BACKUP', 'LV',
                                     'CONDACC', 'MOTOR']}
    import modules.steel as stl
    _BASE['steel'] = {a: copy.deepcopy(getattr(stl, a, {}))
                      for a in ['ROLLED', 'BUILTUP', 'HOLLOW', 'COLD', 'BRACE', 'PLATE',
                                'DECK', 'BOLT', 'PROT', 'SVC', 'STEEL_STAIR']}
    import modules.roofing as rfg
    _BASE['roofing'] = {a: copy.deepcopy(getattr(rfg, a, {}))
                        for a in ['TRUSS', 'PURLIN', 'BATT', 'SHEET', 'ACC', 'FAST',
                                  'INSUL', 'VENT', 'TIMBER', 'PRIMER_PER_KG']}
    _BASE['norms'] = copy.deepcopy(getattr(n, 'MATERIAL_RATES', {}))
    _BASE['captured'] = True


def _rnd(x):
    """Adaptive rounding: keeps small UAE/AED rates from collapsing to 0."""
    if x >= 100:
        return round(x, 0)
    if x >= 10:
        return round(x, 1)
    return round(x, 2)


def _scale_from_base(target, base, factor):
    """Recompute `target` rate map = Nepal base x factor (never compounds)."""
    for k, v in base.items():
        if isinstance(v, tuple):
            target[k] = (_rnd(v[0] * factor), v[1])
        elif isinstance(v, (int, float)):
            target[k] = _rnd(v * factor)


def apply_rates(code):
    """Apply a country's rates to ALL module rate maps (base is NPR/Nepal).
    Always recomputed from the captured Nepal base, so switching countries
    back and forth never compounds the factor."""
    _capture_base()
    if code not in COUNTRIES:
        return
    c = COUNTRIES[code]
    factor = c['factor']
    kr = c['key_rates']
    set_country(code)

    # --- structural engine rates (direct override from key_rates) ---
    import structural.engine as se
    sr = se.DEFAULT_SCHEDULE['rates']
    for sk in ('rcc_m3', 'pcc_m3', 'excavation_m3', 'backfill_m3', 'soling_m3',
               'shuttering_m2', 'steel_kg'):
        if sk in kr:
            sr[sk] = kr[sk]
    se.LABOUR['rate_mason'] = kr.get('mason_day', _BASE['struct_labour'][0])
    se.LABOUR['rate_mazdoor'] = kr.get('mazdoor_day', _BASE['struct_labour'][1])
    se.DEFAULT_SCHEDULE['labour_rates'] = {
        'mason': se.LABOUR['rate_mason'], 'mazdoor': se.LABOUR['rate_mazdoor'],
        'steel_fab': _rnd(_BASE['struct_labour'][2] * factor)}

    # --- labour day-rates (shared defaults for all modules) ---
    import modules.common as mc
    base_lab = _BASE.get('labour')
    if base_lab is None:
        base_lab = dict(mc.LABOUR_RATES)
        _BASE['labour'] = base_lab
    for k, v in base_lab.items():
        mc.LABOUR_RATES[k] = round(v * factor, 0)
    mc.LABOUR_RATES['mason'] = kr.get('mason_day', mc.LABOUR_RATES['mason'])
    mc.LABOUR_RATES['mazdoor'] = kr.get('mazdoor_day', mc.LABOUR_RATES['mazdoor'])

    # --- archfin: recompute every rate map from Nepal base x factor, then override key items ---
    import modules.archfin as af
    for attr in ['WALL', 'PLASTER', 'FLOOR', 'WTILE', 'PAINT', 'CEIL', 'CLAD', 'GLASS',
                 'DOOR', 'WIN', 'RAIL', 'WP', 'POLISH', 'MISC', 'FILL', 'PART',
                 'STAIR_FIN', 'SILL', 'ROOF_FIN', 'METAL', 'COMPOUND', 'SURFACE',
                 'PRECAST', 'DHWARE', 'SEALANT', 'DOOR_FRAME', 'DOOR_HW',
                 'WIN_FRAME', 'WIN_GLASS', 'VENT_RATE']:
        _scale_from_base(getattr(af, attr, {}), _BASE['archfin'][attr], factor)
    for attr in ('DOOR_ARCH', 'WIN_MESH', 'BLK', 'DPC_RATE', 'SKIRT_RATE', 'BALCONY_RATE'):
        setattr(af, attr, _rnd(_BASE['archfin_scalar'][attr] * factor))
    if isinstance(af.WALL.get('brick'), tuple):
        af.WALL['brick'] = (kr['brickwork_m3'], 500)
    af.PLASTER['internal wall 12mm'] = kr['plaster_m2']
    af.PAINT['emulsion'] = kr['painting_m2']
    af.FLOOR['vitrified tile'] = kr['flooring_m2']
    af.CEM = kr['cement_bag']; af.SND = kr['sand_m3']; af.BRK = kr['brick_no']

    # --- sanitary: recompute from base x factor, override key items ---
    import modules.sanitary as sn
    for attr in ['PIPE', 'FIT', 'FIX', 'ACC', 'STOR', 'PUMP', 'DISP', 'FITACC',
                 'VALVE', 'TEST', 'TRENCH', 'RCC_TANK']:
        _scale_from_base(getattr(sn, attr, {}), _BASE['sanitary'][attr], factor)
    sn.PIPE['CPVC supply 25mm'] = kr['cpvc_m']
    sn.PIPE['UPVC soil 110mm'] = kr['pvc_m']

    # --- electrical: recompute from base x factor, override key items ---
    import modules.electrical as el
    for attr in ['POINT', 'WIRE', 'SWITCH', 'FIXT', 'EARTH', 'BACKUP', 'LV',
                 'CONDACC', 'MOTOR']:
        _scale_from_base(getattr(el, attr, {}), _BASE['electrical'][attr], factor)
    el.POINT['light'] = kr['light_point']
    el.WIRE['FRLS wire 2.5 sqmm'] = kr['wire_m']
    el.FIXT['LED panel'] = kr['led_no']

    # --- steel structure: recompute from base x factor (SECTION_UW stays - physical property) ---
    import modules.steel as stl
    for attr in ['ROLLED', 'BUILTUP', 'HOLLOW', 'COLD', 'BRACE', 'PLATE']:
        v = _BASE['steel'][attr]
        if isinstance(v, (int, float)):
            setattr(stl, attr, round(v * factor, 1))
    for attr in ['DECK', 'BOLT', 'PROT', 'SVC', 'STEEL_STAIR']:
        _scale_from_base(getattr(stl, attr, {}), _BASE['steel'].get(attr, {}), factor)

    # --- roofing & truss ---
    import modules.roofing as rfg
    for attr in ['TRUSS', 'PURLIN']:
        v = _BASE['roofing'][attr]
        if isinstance(v, (int, float)):
            setattr(rfg, attr, round(v * factor, 1))
    for attr in ['BATT', 'SHEET', 'ACC', 'FAST', 'INSUL', 'VENT', 'TIMBER']:
        _scale_from_base(getattr(rfg, attr, {}), _BASE['roofing'][attr], factor)
    rfg.PLATE_RATE = _rnd(_BASE['steel']['PLATE'] * factor)
    rfg.PRIMER_PER_KG = _rnd(_BASE['roofing'].get('PRIMER_PER_KG', 6.0) * factor)

    # --- estimation norms ---
    import estimation.norms as n
    n.MATERIAL_RATES['cement_bag'] = kr['cement_bag']
    n.MATERIAL_RATES['sand_m3'] = kr['sand_m3']
    n.MATERIAL_RATES['aggregate_m3'] = kr['aggregate_m3']
    n.MATERIAL_RATES['steel_kg'] = _rnd(_BASE['norms'].get('steel_kg', 150) * factor)
    n.MATERIAL_RATES['brick_no'] = kr['brick_no']
