"""Position-aware PDF table reader - ZERO AI cost, deterministic.

Reads typed schedule tables from PDFs using word coordinates:
  1. words -> visual rows (grouped by y-center)
  2. rows -> cells (split on x-gaps)
  3. row fragments -> COLUMN STREAMS (x-regions) so SIDE-BY-SIDE CAD tables
     parse independently - exactly how real drawing sheets lay out schedules
  4. per stream: '<X> SCHEDULE' title -> header row (field mapping) -> data rows
"""
import pymupdf

HEADER_MAP = {
    'mark': 'mark', 'id': 'mark', 'type': 'type', 'kind': 'kind', 'wall': 'type', 'door': 'type',
    'window': 'type', 'material': 'material', 'thk': 'thickness', 'thickness': 'thickness',
    'length': 'length', 'len': 'length', 'height': 'height', 'ht': 'height',
    'count': 'count', 'nos': 'count', 'no.': 'count', 'qty': 'count',
    'width': 'width', 'frame': 'frame', 'glass': 'glass', 'mesh': 'mesh', 'location': 'location',
    'size': 'size', 'spec': 'spec', 'brand': 'brand', 'dia': 'diameter',
    'capacity': 'cap', 'cap': 'cap', 'wattage': 'wattage', 'room': 'room',
    'walltype': 'mark', 'wallmark': 'mark', 'wallno': 'mark', 'doorno': 'mark', 'winno': 'mark',
    'w': 'width', 'h': 'height', 'l': 'length', 'no': 'mark',
    'number': 'count', 'quantity': 'count', 'nos.': 'count',
    'mortar': 'mortar', 'main': 'main', 'tie': 'tie', 'stirrup': 'tie',
    'top': 'top', 'bottom': 'bottom', 'area': 'area', 'grade': 'grade',
    'depth': 'depth', 't': 't', 'b': 'b', 'd': 'd',
}

WALL_KEYWORDS = {'wall', 'masonry', 'brickwork', 'partition'}
DOOR_KEYWORDS = {'door'}
WINDOW_KEYWORDS = {'window', 'ventilator'}

TITLE_KINDS = [
    ('wall', 'walls'), ('masonry', 'walls'), ('partition', 'walls'),
    ('door', 'doors'), ('window', 'windows'), ('ventilator', 'windows'),
    ('pipe', 'pipes'), ('fixture', 'fixtures'), ('point', 'points'), ('wire', 'wires'),
    ('footing', 'footings'), ('column', 'columns'), ('beam', 'beams'), ('slab', 'slabs'),
    ('furniture', None), ('room', 'rooms'),
]


def _norm(s):
    return ''.join(ch for ch in str(s).lower() if ch.isalnum())


def _field_for(cell):
    n = _norm(cell)
    for unit in ('sqmm', 'sqm', 'rmt', 'mm', 'm2', 'm'):
        if n.endswith(unit) and len(n) > len(unit):
            n = n[:-len(unit)]
            break
    if n in HEADER_MAP:
        return HEADER_MAP[n]
    for h, f in sorted(HEADER_MAP.items(), key=lambda kv: -len(kv[0])):
        if len(h) > 1 and h in n:
            return f
    return None


def classify_table(header_cells):
    kinds = set()
    fields = {}
    for i, c in enumerate(header_cells):
        n = _norm(c)
        if not n:
            continue
        for kw in WALL_KEYWORDS:
            if kw in n:
                kinds.add('walls')
        for kw in DOOR_KEYWORDS:
            if kw in n and 'window' not in n:
                kinds.add('doors')
        for kw in WINDOW_KEYWORDS:
            if kw in n:
                kinds.add('windows')
        f = _field_for(c)
        if f and f not in fields.values():
            fields[i] = f
    if 'walls' in kinds:
        kind = 'walls'
    elif 'windows' in kinds and 'doors' not in kinds:
        kind = 'windows'
    elif 'doors' in kinds:
        kind = 'doors'
    else:
        kind = None
    return kind, fields


def extract_rows(pdf_bytes, max_pages=6):
    """Return list of row fragments: (page_no, y, x0, [cell strings])."""
    rows = []
    try:
        doc = pymupdf.open(stream=pdf_bytes, filetype='pdf')
    except Exception:
        return rows
    for pno, page in enumerate(doc):
        if pno >= max_pages:
            break
        words = page.get_text('words')
        if not words:
            continue
        lines = []
        for w in sorted(words, key=lambda w: ((w[1] + w[3]) / 2, w[0])):
            yc = (w[1] + w[3]) / 2
            if lines and abs(lines[-1][0] - yc) <= 3.0:
                lines[-1][1].append(w)
            else:
                lines.append([yc, [w]])
        for yc, ws in lines:
            ws.sort(key=lambda w: w[0])
            cells = []          # (x0, x1, text)
            cur = [ws[0]]
            for w in ws[1:]:
                if w[0] - cur[-1][2] > 5.0:
                    cells.append((cur[0][0], cur[-1][2], ' '.join(x[4] for x in cur)))
                    cur = [w]
                else:
                    cur.append(w)
            cells.append((cur[0][0], cur[-1][2], ' '.join(x[4] for x in cur)))
            cells = [c for c in cells if c[2].strip()]
            # split side-by-side tables: gap > 40pt starts a new row fragment
            groups = [[cells[0]]] if cells else []
            for prev, c in zip(cells, cells[1:]):
                if c[0] - prev[1] > 140.0:
                    groups.append([])
                groups[-1].append(c)
            for g in groups:
                texts = [c[2].strip() for c in g if c[2].strip()]
                if texts:
                    rows.append((pno, round(yc, 1), round(g[0][0], 0), texts))
    doc.close()
    return rows


def _parse_stream(rows, out, notes, file_label=1):
    """Linear title -> header -> data state machine over ONE column stream."""
    i = 0
    pending_kind = None
    current = None
    while i < len(rows):
        pno, y, cells = rows[i]
        low = ' '.join(cells).lower()
        if len(cells) <= 4 and 'schedule' in low:
            kind = None
            for kw, k in TITLE_KINDS:
                if kw in low:
                    kind = k
                    break
            if kind is not None:
                pending_kind = kind or '_skip'
                current = None
                i += 1
                continue
        nlow = _norm(low)
        field_hits = sum(1 for h in HEADER_MAP if len(h) > 1 and h in nlow)
        kind_h, fields_h = classify_table(cells)
        # a header row maps >= 2 fields and has no purely-numeric cells
        # (data rows like ['D-1','1.2','2.1','1','Main Door'] must NOT become headers)
        numeric_cells = sum(1 for c in cells if _norm(c).replace('.', '').isdigit())
        is_header = (field_hits >= 3 or (pending_kind and field_hits >= 2)) and \
                    len(fields_h) >= 2 and numeric_cells == 0 and len(cells) >= 3
        if is_header:
            kind, fields = kind_h, fields_h
            if pending_kind == '_skip':
                current = None
                pending_kind = None
                i += 1
                continue
            kind = pending_kind or kind
            if kind and fields:
                current = (kind, fields)
                pending_kind = None
                src_label = 'PDF %d, page %d' % (file_label, pno + 1) if file_label else 'page %d' % (pno + 1)
                notes.append('Detected %s schedule table in %s (%d columns mapped)'
                             % (kind, src_label, len(fields)))
                i += 1
                continue
        if current and len(cells) >= 2:
            kind, fields = current
            rec = {}
            for idx, val in enumerate(cells):
                f = fields.get(idx)
                if f and f not in rec:
                    rec[f] = val
            if not rec.get('mark') and cells and len(cells[0]) <= 8 and _norm(cells[0])[:1] in 'wdvfcbsl':
                rec['mark'] = cells[0]
            if rec.get('mark') or (rec.get('type') and len(rec) >= 2):
                out.setdefault(kind, []).append(rec)
        i += 1


def _num(v, default=0.0):
    import re as _re
    m = _re.search(r'-?\d+(?:\.\d+)?', str(v).replace(',', ''))
    return float(m.group()) if m else default


def parse_schedules(pdf_bytes_list):
    """Extract schedule tables from one PDF (bytes) or a list of them.
    Returns (dict kind -> [row dicts], log_notes)."""
    if isinstance(pdf_bytes_list, (bytes, bytearray)):
        pdf_bytes_list = [pdf_bytes_list]
    out = {}
    notes = []
    for fi, b in enumerate(pdf_bytes_list, 1):
        rows = extract_rows(b)
        if not rows:
            continue
        # group row fragments into column streams (~60pt x-clusters per page)
        streams = {}
        for pno, y, x0, cells in rows:
            streams.setdefault((pno, int(x0 // 60)), []).append((pno, y, cells))
        file_out = {}
        for key in sorted(streams, key=lambda k: (k[0], k[1])):
            _parse_stream(streams[key], file_out, notes, file_label=fi)
        for k, v in file_out.items():
            out.setdefault(k, []).extend(v)
    if not notes:
        notes.append('No schedule tables detected (need typed tables with headers).')

    # convert numeric fields
    for kind in list(out.keys()):
        cleaned = []
        for rec in out[kind]:
            r = dict(rec)
            for f in ('thickness', 'length', 'height', 'count', 'width', 'area', 'depth', 't', 'b', 'd', 'cap'):
                if f in r:
                    r[f] = _num(r[f], 0)
            if 'count' in r and r['count'] <= 0:
                r['count'] = 1
            if 'size' in r and 'x' in str(r['size']):
                try:
                    a, b = str(r['size']).lower().split('x')
                    r.setdefault('width', _num(a))
                    r.setdefault('height', _num(b))
                    # size like 1200 x 2100 is mm -> convert to metres
                    for f in ('width', 'height'):
                        if 20 < r[f] <= 6000:
                            r[f] = round(r[f] / 1000.0, 3)
                except ValueError:
                    pass
            if r.get('length') or r.get('width') or r.get('height') or r.get('area') or r.get('count', 0) > 1:
                cleaned.append(r)
        out[kind] = cleaned
    return out, notes
