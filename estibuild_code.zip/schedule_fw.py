"""Reusable schedule framework with unit conversion + editable rate.
Length/area fields auto-get a unit selector and convert to m / m2.
Every row gets an editable Rate box (blank = market rate)."""
from modules.common import NUM

CONV = {'L': {'m': 1, 'cm': 0.01, 'mm': 0.001, 'ft': 0.3048, 'in': 0.0254, 'inch': 0.0254},
        'A': {'m2': 1, 'sqm': 1, 'ft2': 0.092903, 'sqft': 0.092903}}
NON_DIM = {'thickness', 'thk', 'count', 'qty', 'cap', 'capacity', 'coats', 'lights', 'fan', 'ac',
           'rate', 'area2', 'spec', 'name', 'id', 'item', 'type', 'surface', 'loc', 'location',
           'material', 'room', 'brand', 'unit'}


def dim_of(f):
    n = f['name'].lower(); lab = f.get('label', '').lower()
    if n in NON_DIM:
        return None
    if n == 'area' or 'm²' in lab or 'sqm' in lab or '(m2)' in lab:
        return 'A'
    if n in ('length', 'width', 'height', 'proj', 'projection', 'run', 'depth') or '(m)' in lab or '(rmt)' in lab:
        return 'L'
    return None


def annotate(spec):
    for t in spec['tables']:
        for f in t['fields']:
            f['_dim'] = dim_of(f)
    return spec


def _conv(f, raw, unit):
    d = f.get('_dim')
    if d not in CONV:
        return NUM(raw)
    return NUM(raw) * CONV[d].get(unit, 1)


def parse(form, spec):
    import html as _html
    annotate(spec)
    sched = {'scalars': {}, 'tables': {}}
    for s in spec['scalars']:
        v = form.get(s['name'], s['default'])
        if isinstance(v, str):
            v = _html.unescape(v)      # browser submits HTML-escaped option text (&amp; &#34;)
        sched['scalars'][s['name']] = NUM(v) if s['type'] == 'number' else v
    # user-editable labour day-rates (blank/0 -> country default)
    from modules.common import LABOUR_RATES
    sched['labour_rates'] = {}
    for k in spec.get('labour', []):
        raw = form.get('lr_' + k)
        sched['labour_rates'][k] = NUM(raw, LABOUR_RATES.get(k, 1000)) if raw is not None and str(raw).strip() != '' else LABOUR_RATES.get(k, 1000)
    for t in spec['tables']:
        rows = []
        for idx in form.getlist(t['id'] + '_row'):
            if idx == 'NEWIDX':
                continue          # hidden "add row" template - never a real row
            row = {}
            for f in t['fields']:
                nm = f"{t['id']}_{f['name']}_{idx}"; raw = form.get(nm)
                if raw is None or str(raw).strip() == '':
                    continue
                if isinstance(raw, str):
                    raw = _html.unescape(raw)   # option text arrives HTML-escaped
                if f.get('_dim'):
                    row[f['name']] = _conv(f, raw, form.get(nm + '_u', 'm'))
                elif f['type'] == 'number':
                    row[f['name']] = NUM(raw)
                else:
                    row[f['name']] = raw
            if row:
                rv = form.get(f"{t['id']}_rate_{idx}")
                if rv is not None and str(rv).strip() != '':
                    row['rate'] = NUM(rv)
                rows.append(row)
        sched['tables'][t['id']] = rows
    return sched


def default_schedule(spec):
    annotate(spec)
    import copy
    from modules.common import LABOUR_RATES
    return {'scalars': {s['name']: s['default'] for s in spec['scalars']},
            'labour_rates': {k: LABOUR_RATES[k] for k in spec.get('labour', [])},
            'tables': {t['id']: copy.deepcopy(t.get('default_rows', [])) for t in spec['tables']}}


def parse_ftin_dims(text):
    """Extract dimensions from drawing text in ANY common notation -> metres list.
    Reads: 14'-8"  14'-8.5"  14'-8 1/2"  14'-8½"  14' 8"  14'-8 (no quote)  6'  6 ft
           176"  8 1/2"  20 in  3.6m  3600mm  360cm  + Unicode primes 14′-8″ / curly quotes.
    No false positives on plain text (1:4 mortar, M20, dates, money)."""
    import re
    if not text:
        return []
    # normalise Unicode primes & curly quotes to ASCII
    s = str(text).translate({0x2032: "'", 0x2019: "'", 0x2033: '"', 0x201D: '"'})
    out = []
    FR = {'½': .5, '¼': .25, '¾': .75, '⅓': 1 / 3, '⅔': 2 / 3,
          '⅛': .125, '⅜': .375, '⅝': .625, '⅞': .875}

    def _frac(m):
        if m.group('f'):
            try:
                return int(m.group('f')) / int(m.group('g'))
            except ZeroDivisionError:
                return 0
        return FR.get(m.group('u'), 0) if m.group('u') else 0

    # --- 1) feet + inches (quote optional): 14'-8"  14'-8.5"  14'-8 1/2"  14'-8½"  14' 8"
    pat_fi = re.compile(
        r"(?P<ft>\d{1,3})\s*'\s*-?\s*"
        r"(?P<in>\d{1,2})(?P<dec>\.\d+)?(?:\s+(?P<f>\d+)\s*/\s*(?P<g>\d+))?"
        r"(?P<u>[½¼¾⅓⅔⅛⅜⅝⅞])?\s*(?P<q>\")?")
    spans = []
    for m in pat_fi.finditer(s):
        ft, inch = int(m.group('ft')), int(m.group('in'))
        if ft > 400 or inch >= 12:
            continue
        dec = float(m.group('dec')) if m.group('dec') else 0.0
        out.append(round((ft * 12 + inch + dec + _frac(m)) * 0.0254, 2))
        spans.append(m.span())
    for a, b in reversed(spans):                      # blank consumed so later
        s = s[:a] + ' ' * (b - a) + s[b:]             # patterns don't re-match

    # --- 2) feet only: 6'   6.5 ft   6FT   6 feet   6' wide
    for m in re.finditer(r"(?<![.\d])(\d{1,3}(?:\.\d+)?)\s*(?:'|ft\b|feet\b)", s, re.I):
        v = float(m.group(1)) * 0.3048
        if 0.1 <= v <= 150:
            out.append(round(v, 2))

    # --- 3) inches only: 176"   8 1/2"   8½"   20 in   20in   20 inches
    pat_in = re.compile(
        r"(?<![.\d])(\d{1,3}(?:\.\d+)?)"
        r"(?:(?:\s+\d+\s*/\s*\d+)|[½¼¾⅓⅔⅛⅜⅝⅞])?\s*"
        r"(?:\"|in\b|inch\b|inches\b)", re.I)
    for m in pat_in.finditer(s):
        inches = float(m.group(1))
        if m.group(0).strip() and inches and 1 <= inches <= 480:
            # add fraction if present
            fr = re.search(r"(\d+)\s*/\s*(\d+)|[½¼¾⅓⅔⅛⅜⅝⅞]", m.group(0)[m.end(1) - m.start():])
            extra = 0.0
            if fr:
                if fr.group(1):
                    try: extra = int(fr.group(1)) / int(fr.group(2))
                    except (ValueError, ZeroDivisionError): extra = 0
                else:
                    extra = FR.get(fr.group(0), 0)
            if 1 <= inches + extra <= 480:
                out.append(round((inches + extra) * 0.0254, 2))

    # --- 4) mm / cm with explicit unit: 3600mm  3,600 mm  360cm  (blanked before metres)
    for pat, div in ((r"(\d[\d,]*(?:\.\d+)?)\s*(?:mm|millimet(?:er|re)s?)\b", 1000.0),
                     (r"(\d[\d,]*(?:\.\d+)?)\s*(?:cm|centimet(?:er|re)s?)\b", 100.0)):
        ms = list(re.finditer(pat, s, re.I))
        for m in ms:
            v = float(m.group(1).replace(',', '')) / div
            if 0.05 <= v <= 100:
                out.append(round(v, 2))
        for m in reversed(ms):
            s = s[:m.start()] + ' ' * (m.end() - m.start()) + s[m.end():]

    # --- 5) metres with explicit unit: 3.6m  3.60 M  4 meters (mm/cm already removed)
    for m in re.finditer(r"(?<![.\d])(\d{1,3}(?:\.\d+)?)\s*m(?:et(?:er|re)s?)?\b", s, re.I):
        v = float(m.group(1))
        if 0.05 <= v <= 100:
            out.append(round(v, 2))

    return out


def _apply_tables(sched, tbl, spec, notes):
    """Fill module tables from parsed schedule PDFs (exact, zero AI).
    Returns list of table ids that were replaced."""
    applied = []
    sid = spec.get('id')
    T = sched['tables']
    if sid == 'archfin':
        def _m(v, dft):
            """value -> metres (CAD tables sometimes give mm like 900 for doors)."""
            try:
                x = float(v)
            except (TypeError, ValueError):
                return dft
            return round(x / 1000.0, 3) if 20 < x <= 6000 else x
        if tbl.get('walls'):
            T['walls'] = [{'id': r.get('mark') or f'W{i+1}',
                           'material': str(r.get('material') or 'brick').lower(),
                           'thickness': r.get('thickness') or 230,
                           'length': r.get('length') or 0, 'count': int(r.get('count') or 1),
                           'height': r.get('height') or 3.0,
                           'type': str(r.get('type') or 'external').lower(),
                           'mortar': r.get('mortar') or sched['scalars'].get('mortar', '1:6')}
                          for i, r in enumerate(tbl['walls'])]
            notes.append(f"📋 Wall schedule read: {len(T['walls'])} wall types (exact)")
            applied.append('walls')
        if tbl.get('doors'):
            T['doors'] = [{'id': r.get('mark') or f'D{i+1}', 'type': r.get('type') or 'flush',
                           'frame_material': r.get('frame') or 'Wooden',
                           'width': _m(r.get('width'), 0.9), 'height': _m(r.get('height'), 2.1),
                           'count': int(r.get('count') or 1),
                           'location': r.get('location') or 'internal'}
                          for i, r in enumerate(tbl['doors'])]
            notes.append(f"📋 Door schedule read: {len(T['doors'])} door types")
            applied.append('doors')
        if tbl.get('windows'):
            T['windows'] = [{'id': r.get('mark') or f'WN{i+1}', 'type': r.get('type') or 'alu sliding',
                             'width': _m(r.get('width'), 1.2), 'height': _m(r.get('height'), 1.2),
                             'glass': r.get('glass') or 'single clear 5mm',
                             'fly_mesh': r.get('mesh') or 'Yes',
                             'count': int(r.get('count') or 1)}
                            for i, r in enumerate(tbl['windows'])]
            notes.append(f"📋 Window schedule read: {len(T['windows'])} window types")
            applied.append('windows')
    elif sid == 'sanitary':
        if tbl.get('pipes'):
            T['pipes'] = [{'type': r.get('type'), 'brand': r.get('brand') or 'Local',
                           'length': r.get('length') or 0} for r in tbl['pipes']]
            notes.append(f"📋 Pipe schedule read: {len(T['pipes'])} pipe types")
            applied.append('pipes')
        if tbl.get('fixtures'):
            T['fix'] = [{'type': r.get('type'), 'brand': r.get('brand') or 'Local',
                         'count': int(r.get('count') or 1)} for r in tbl['fixtures']]
            notes.append(f"📋 Fixture schedule read: {len(T['fix'])} fixture types")
            applied.append('fix')
    elif sid == 'electrical':
        if tbl.get('points'):
            T['points'] = [{'type': r.get('type'), 'switch_brand': r.get('brand') or 'Anchor',
                            'count': int(r.get('count') or 1)} for r in tbl['points']]
            notes.append(f"📋 Point schedule read: {len(T['points'])} point types")
            applied.append('points')
        if tbl.get('wires'):
            T['wire'] = [{'type': r.get('type'), 'length': r.get('length') or 0} for r in tbl['wires']]
            notes.append(f"📋 Wire schedule read: {len(T['wire'])} wire types")
            applied.append('wire')
        if tbl.get('fixtures'):
            T['fixt'] = [{'type': r.get('type'), 'brand': r.get('brand') or 'Local',
                          'count': int(r.get('count') or 1), 'wattage': r.get('wattage') or ''}
                         for r in tbl['fixtures']]
            notes.append(f"📋 Fixture schedule read: {len(T['fixt'])} fixture types")
    return applied


def enrich_schedule(sched, text, spec, tables=None):
    """Extract numbers from PDF text and actually pre-fill the schedule."""
    import re
    low = text.lower()
    notes = []
    applied = []
    if tables:
        applied = _apply_tables(sched, tables, spec, notes) or []
    schedules_authoritative = bool(applied)
    walls_before = [r.get('length') for r in (sched['tables'].get('walls') or [])]

    def find_num(keywords, max_ahead=22):
        for kw in keywords:
            m = re.search(re.escape(kw) + r'[^0-9]{0,' + str(max_ahead) + r'}([\d.]+)', low)
            if m:
                try:
                    v = float(m.group(1))
                    if 0 < v < 1000000:
                        return v
                except ValueError:
                    pass
        return None

    for s in spec['scalars']:
        if s['type'] != 'number' or schedules_authoritative:
            continue
        toks = [w for w in re.findall(r'[a-z]{4,}', s['label'].lower())
                if w not in ('name', 'area', 'default', 'height')]
        v = find_num(toks)
        if v is not None:
            sched['scalars'][s['name']] = v
            notes.append(f"{s['label']} → {v}")

    for t in spec['tables']:
        if schedules_authoritative:
            break            # exact schedule tables read - skip keyword guessing
        for row in sched['tables'][t['id']]:
            kw = None
            for k in ('type', 'item', 'material', 'loc', 'surface', 'id'):
                if row.get(k):
                    kw = str(row[k])
                    break
            qfield = None
            for k in ('count', 'area', 'length', 'qty', 'cap'):
                if k in row:
                    qfield = k
                    break
            if not kw or not qfield:
                continue
            kl = kw.lower()
            variants = [kl] + ([kl.split()[0]] if ' ' in kl else []) + ([kl.split()[-1]] if ' ' in kl else [])
            v = find_num(variants)
            if v is not None:
                row[qfield] = v
                notes.append(f"{kw} → {qfield} = {v}")
    # ---- WALL DRAWINGS: dims (mm / ft-in / m) -> Wall Takeoff Helper ----
    walls_rows = sched['tables'].get('walls') or []
    walls_unchanged = (not schedules_authoritative) and [r.get('length') for r in walls_rows] == walls_before
    if walls_rows and walls_unchanged:
        dims_w = sorted({d for d in parse_ftin_dims(text) if 1.2 <= d <= 30}, reverse=True)
        # metric/mm drawings: standalone 3-5 digit numbers (900-15000 mm)
        mmvals = [int(x) / 1000.0 for x in re.findall(r'(?<![\d.])(\d{3,5})(?![\d.])', text)]
        mmvals = sorted({round(d, 2) for d in mmvals if 1.2 <= d <= 30}, reverse=True)
        if len(mmvals) >= 4 and len(dims_w) < 3:
            dims_w = mmvals                      # metric drawing -> mm dims
        if len(dims_w) >= 2 and any(s['name'] == 'bldg_L' for s in spec['scalars']):
            bL, bW = dims_w[0], dims_w[1]
            sched['scalars']['bldg_L'] = bL
            sched['scalars']['bldg_W'] = bW
            pool = [d for d in dims_w[2:] if 1.2 <= d <= 10]
            rooms_rows = sched['tables'].get('rooms')
            pairs = []
            if rooms_rows is not None:
                while len(pool) >= 2 and len(pairs) < 8:
                    pairs.append((pool.pop(0), pool.pop(0)))
                for i, (rl, rw) in enumerate(pairs):
                    rooms_rows.append({'name': f'Room {i+1}', 'length': rl, 'width': rw})
            # clear the demo wall rows so the Takeoff Helper takes over
            for wr in walls_rows:
                wr['length'] = ''
            notes.append(f'📐 Wall drawing read: building {bL:g}m x {bW:g}m'
                         + (f' + {len(pairs)} room sizes' if pairs else '')
                         + ' → walls auto-compute via Takeoff Helper (review room pairs!)')

    # ---- layout drawings (feet-inch dims only): derive overall size -> areas ----
    dims = sorted({d for d in parse_ftin_dims(text) if d >= 1.5}, reverse=True)
    if len(dims) >= 2 and not any('Layout drawing detected' in n for n in notes):
        L, W = dims[0], dims[1]
        area = round(L * W, 1)
        perim = round(2 * (L + W), 1)
        filled = []
        for tid in ('flooring', 'plaster', 'surface', 'wp'):
            rows = sched['tables'].get(tid) or []
            for row in rows:
                if 'area' in row:
                    row['area'] = area
                    filled.append(tid)
                    break
        for row in (sched['tables'].get('flooring') or []):
            if 'skirting' in row and not row.get('skirting'):
                row['skirting'] = perim
                filled.append('skirting')
        if filled:
            notes.insert(0, f'📐 Layout drawing detected: overall ~{L:g}m x {W:g}m = {area} m² '
                            f'(perimeter {perim} m) → filled {", ".join(sorted(set(filled)))}.')

    if not notes:
        notes = ['📄 PDF read, but this drawing has no typed schedule data (it is a graphics/layout sheet '
                 'with no text keywords). Auto-fill works best on: footing/column/beam schedules, door & '
                 'window schedules, and item lists (sanitary/electrical). Fill the form manually — the '
                 'estimate still runs perfectly.']
    else:
        notes.insert(0, f'✅ Auto-filled {len(notes)} value(s) from PDF. Review & click Calculate.')
    return sched, notes


def build_rcfg(spec, scalars=None):
    """JS config for the live Rate boxes: per table -> driving-field option map
    (base market rate, aux factors neutralised) + factor maps for aux fields."""
    scalars = scalars or {}
    rr = spec.get('row_rate')
    if not rr:
        return {}
    DRV = ('type', 'item', 'material', 'surface', 'loc', 'profile', 'system', 'location')
    out = {}
    for t in spec.get('tables', []):
        tid = t['id']
        cfg = dict((spec.get('rate_cfg') or {}).get(tid) or {})
        ad = cfg.get('ad', {})
        f = None
        options = []
        for fl in t.get('fields', []):
            if fl.get('name') in DRV and fl.get('type') in ('select', 'suggest'):
                f = fl['name']
                options = fl.get('options') or []
                break
        m = {}
        if f:
            for o in options:
                row = {f: o}
                row.update(ad)
                v = rr(tid, row, scalars)
                if v is not None:
                    m[str(o)] = v
        if not m:
            row = dict(ad)
            v = rr(tid, row, scalars)
            if v is not None:
                m = {'*': v}
        x = [[xf, dict(fm)] for xf, fm in (cfg.get('x') or [])]
        if m:
            out[tid] = {'f': f, 'm': m, 'x': x}
    return out


def _cols(n):
    return {1: 'r1', 2: 'r2', 3: 'r3', 4: 'r4', 5: 'r5', 6: 'r6'}.get(min(n, 6), 'r6')


TEMPLATE = r"""
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{spec.title}} - EstiBuild</title>
<style>
:root{--nav:#1F3B57;--bg:#f4f7fa;--card:#fff;--line:#d7e0ea;--green:#1f9d55}
.bar{height:14px;border-radius:4px;background:linear-gradient(90deg,#1F3B57,#2E86ab);min-width:2px}
.money{font-size:12.5px}
.money td{padding:6px 7px;border-bottom:1px solid #e6edf4}
.combo{display:flex;gap:3px;align-items:stretch}
.combo input{flex:1;min-width:0}
.cbs{width:32px;padding:0;border:1px solid #b9cadb;border-radius:6px;background:#e8f0f8;cursor:pointer;font-size:11px;color:#2E86ab;text-align:center;-webkit-appearance:none;appearance:none;flex:none}
.cbs:hover{background:#d8e6f2;border-color:#2E86ab}
*{box-sizing:border-box}body{margin:0;font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:#223}
.top{color:#fff;padding:13px 24px;display:flex;justify-content:space-between;align-items:center}
.swd{position:relative;display:inline-block}
.swd summary{cursor:pointer;list-style:none;background:#ffffff;color:#1F3B57;font-weight:800;padding:6px 13px;border-radius:7px;margin-right:12px;display:inline-block;font-size:12px;user-select:none}
.swd summary::-webkit-details-marker{display:none}
.swd[open] summary{background:#eef3f8}
.swbox{position:absolute;right:0;top:calc(100% + 6px);background:#fff;border:1px solid #d7e0ea;border-radius:10px;box-shadow:0 10px 28px rgba(31,59,87,.25);min-width:245px;z-index:60;padding:5px}
.swh{font-size:10px;font-weight:800;color:#7a8693;text-transform:uppercase;padding:5px 9px 3px;letter-spacing:.5px}
.swd .swm{display:block;font-size:12.5px;font-weight:600;padding:7px 10px;color:#223;text-decoration:none;border-radius:6px}
.swd .swm:hover{background:#f1f6fb}
.swd .swm.cur{font-weight:700;color:#1F3B57;background:#f1f6fb}
.top a{color:#fff;text-decoration:none;font-size:13px;opacity:.92}
.wrap{max-width:1340px;margin:0 auto;padding:14px 16px 60px}
.grid2{display:grid;grid-template-columns:1.3fr 1fr;gap:14px;align-items:start}
@media(max-width:1080px){.grid2{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:11px;padding:14px 16px;margin-bottom:13px}
.card h2{margin:0 0 3px;font-size:16px;color:var(--nav)} .hint{color:#7a8693;font-size:12px;margin:0 0 10px}
label{display:block;font-size:10px;font-weight:600;color:#556;margin:4px 0 1px;text-transform:uppercase;letter-spacing:.3px}
input,select{width:100%;padding:6px 7px;border:1px solid var(--line);border-radius:6px;font-size:12px}
select.u{margin-top:3px;padding:2px 4px;font-size:10px;color:#555}
.sec{font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:{{spec.color}};font-weight:800;margin:0 0 8px;padding-bottom:5px;border-bottom:2px solid var(--line)}
.row{display:grid;gap:7px}.r2{grid-template-columns:1fr 1fr}.r3{grid-template-columns:1fr 1fr 1fr}
.r4{grid-template-columns:repeat(4,1fr)}.r5{grid-template-columns:repeat(5,1fr)}.r6{grid-template-columns:repeat(6,1fr)}
.mem{border:1px solid #e8e8f0;border-left:4px solid {{spec.color}};border-radius:8px;padding:9px 11px;margin-bottom:7px;background:#fcfcfe;position:relative}
.ratef{margin-top:6px}.ratef label{color:#b8860b}.ratef input{background:#fffdf3;border-color:#f0d479}
.del{position:absolute;top:7px;right:9px;background:#c0392b;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}
.add{background:{{spec.color}};color:#fff;border:none;padding:7px 14px;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;margin-top:3px}
.btn{background:var(--green);color:#fff;border:none;padding:13px 26px;border-radius:9px;font-size:15px;font-weight:700;cursor:pointer;width:100%;margin-top:10px}
.upload{border:2px dashed {{spec.color}};border-radius:10px;padding:13px;text-align:center;background:#fafbfd;margin-bottom:6px}
.guide{background:#f1f6fb;border:1px solid #cfe0ef;border-left:4px solid {{spec.color}};border-radius:8px;padding:10px 12px;margin:8px 0;font-size:11.5px}
.guide b{color:{{spec.color}}}.guide ul{margin:5px 0 5px 16px;padding:0;line-height:1.6}.guide i{color:#7a8693}
.notes{background:#fff8e1;border:1px solid #f0d479;border-radius:8px;padding:9px;font-size:12px;margin:8px 0}.notes ul{margin:4px 0 0 16px;padding:0}
.kpi{display:flex;gap:8px;flex-wrap:wrap}.kpi div{flex:1;min-width:96px;background:#f3f6fa;border:1px solid var(--line);border-radius:9px;padding:9px;text-align:center}
.kpi .v{font-size:17px;font-weight:800;color:{{spec.color}}}.kpi .l{font-size:10px;color:#7a8693}
table{width:100%;border-collapse:collapse;font-size:11.5px;margin-top:4px}
th{background:var(--nav);color:#fff;padding:6px;text-align:left}td{padding:4px 6px;border-bottom:1px solid var(--line)}
.num{text-align:right}.ctr{text-align:center}.tot{background:#fff3cf;font-weight:800;text-align:right;padding:9px;border-radius:6px;margin-top:8px}
.pill{display:inline-block;background:var(--green);color:#fff;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;text-decoration:none}
</style></head><body>
<div class="top" style="background:{{spec.color}}"><div><b>{{spec.icon}} {{spec.title}} Estimation</b> <span style="opacity:.8;font-size:12px">· {{SHORT}}</span></div>
<div><a href="{{url_for('new_estimate')}}" onclick="if(history.length>1){history.back();return false;}" style="background:#ffffff;color:#1F3B57;font-weight:800;padding:6px 13px;border-radius:7px;margin-right:12px">◀ Go Back</a>
<details class="swd"><summary>⇄ Switch Module ▾</summary><div class="swbox">
<div class="swh">Same project — continue in:</div>
{%set MODS=[('structural','🏗️','RCC Structure'),('archfin','🏛️','Architecture & Finishing'),('sanitary','🚿','Sanitary & Plumbing'),('electrical','⚡','Electrical'),('steel','🏭','Steel Structure'),('roofing','🏠','Roofing & Truss')]%}
{%for mid,micon,mtitle in MODS%}
{%if mid==spec.id%}<div class="swm cur">{{micon}} {{mtitle}} · current</div>
{%else%}<a class="swm" href="{{url_for('structural') if mid=='structural' else url_for('sched',sid=mid)}}">{{micon}} {{mtitle}}</a>{%endif%}
{%endfor%}
</div></details>
<a href="{{url_for('landing')}}">🏠 Home</a></div></div>
<div class="wrap"><div class="grid2"><div>
<div class="card"><div class="sec">Upload {{spec.title}} PDF / Drawing</div>
<div style="background:#eef6fb;border:1px solid #b9d9eb;border-radius:9px;padding:10px 12px;margin:10px 0;font-size:11.5px;color:#36556b;line-height:1.55"><b style="color:#1F3B57">⚡ Save hours of estimation work</b><br>Send the fillable EstiBuild HTML or Excel template to the engineer, architect, or designer who prepared the drawings. They can enter the dimensions and materials they already know; upload the completed template here and EstiBuild turns it into an editable estimate in minutes. This avoids duplicate data entry and can reduce preparation time from hours to minutes.</div>
<form method="post" action="{{url_for('sched_upload', sid=spec.id)}}" enctype="multipart/form-data">
<details style="margin-bottom:8px;background:#eef6f0;border:1px solid #b7dfc3;border-radius:8px;padding:8px 10px">
<summary style="font-size:12px;font-weight:700;color:#1f9d55;cursor:pointer">📋 What to include for BEST auto-fill (click to see exactly what we read)</summary>
<div style="font-size:11px;color:#445;margin-top:8px;line-height:1.7">
<b>Best (100% exact, free):</b> typed schedule tables in any PDF — like these from your CAD set / Excel:
<table style="font-size:10.5px;margin-top:4px">
<tr><th style="padding:4px 6px">Schedule table</th><th style="padding:4px 6px">Columns we look for</th></tr>
{%for t in spec.tables%}{%if t.fields|length > 1%}
<tr style="background:{{'#f7faf8' if loop.index is divisibleby(2) else '#ffffff'}}"><td style="padding:3px 6px;font-weight:600">{{t.title}}</td>
<td style="padding:3px 6px;color:#567">{%for f in t.fields[:6]%}{{f.label}}{%if not loop.last%} · {%endif%}{%endfor%}{%if t.fields|length > 6%} …{%endif%}</td></tr>
{%endif%}{%endfor%}
</table>
<div style="margin-top:6px">
<b>Also good (free):</b> a dimensioned floor plan PDF (room sizes → walls, plaster &amp; paint auto-computed)<br>
<b>Fallback:</b> any drawing via AI → editable draft
</div>
</div>
</details>
<div class="upload"><input type="file" name="pdfs" accept="application/pdf,.json,.xlsx,.html" multiple>
<div style="margin-top:5px;font-size:11px;color:#7a8693">Upload one or many files: <b>PDF schedules</b> (door schedule in one PDF, windows in another — all combined!) · <b>PDF drawing</b> (dimensions read) · your filled <b>template .json/.xlsx/.html</b>.</div>
<div style="margin-top:7px;font-size:11.5px">
<a href="{{url_for('download_template', sid=spec.id, fmt='html')}}" target="_blank" rel="noopener" style="color:#1f9d55;font-weight:700">⬇ Fillable template (HTML)</a> &nbsp;·&nbsp;
<a href="{{url_for('download_template', sid=spec.id, fmt='xlsx')}}" target="_blank" rel="noopener" style="color:#1f9d55;font-weight:700">Excel template</a>
</div>
<div id="morepdfs"></div>
<div style="margin-top:8px"><button type="submit" class="add" style="margin-top:8px">⬆ Read PDF(s) &amp; auto-fill</button>
{%if ai_enabled()%}<button type="submit" formaction="{{url_for('sched_ai_template', sid=spec.id)}}" class="add" style="background:#8e44ad;margin-top:4px">🤖 AI reads ALL your PDFs → editable draft (HTML)</button>{%else%}<div style="background:#f0e6f6;border:1px dashed #8e44ad;border-radius:7px;padding:8px;margin-top:4px;text-align:center;font-size:11px;color:#8e44ad"><b>🤖 AI Drawing Reader</b> — <b>coming soon!</b> Upload all your PDFs at once; AI merges everything into <b>one editable HTML draft</b> — review, correct &amp; add items offline, then upload it back here (or its .json data file).</div>{%endif%}
</div></div></form>
<a href="{{url_for('sched', sid=spec.id)}}" class="add" style="background:#e74c3c;margin-top:6px;display:inline-block;text-decoration:none">🔄 Reset form (clear all auto-fill)</a>
<button type="button" class="add" style="background:#6c757d;margin-top:6px" onclick="addPdf()">+ Add another PDF slot</button>

{%if notes%}<div class="notes"><b>PDF result:</b><ul>{%for n in notes%}<li>{{n}}</li>{%endfor%}</ul></div>{%endif%}</div>
{% macro fld(f, tid, idx, val) %}
{% set nm = tid~'_'~f.name~'_'~idx %}
<div><label>{{f.label}}</label>
{% if f.type=='select' %}<select name="{{nm}}" onchange="mKindChanged(this,'{{tid}}')">{%for o in f.options%}<option {{'selected' if (val|string)==(o|string)}}>{{o}}</option>{%endfor%}</select>
{% elif f.type=='suggest' %}<div class="combo"><input name="{{nm}}" value="{{(val|clean) if val is not none else ''}}" placeholder="type or &#9662;">{%if f.options%}<select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in f.options%}<option>{{o}}</option>{%endfor%}</select>{%endif%}</div>
{% else %}<input name="{{nm}}" value="{{(val|clean) if val is not none else ''}}">
{% if f._dim=='A' %}<select name="{{nm}}_u" class="u">{%for u in ['m2','sqft']%}<option {{'selected' if u=='m2'}}>{{u}}</option>{%endfor%}</select>
{% elif f._dim=='L' %}<select name="{{nm}}_u" class="u">{%for u in ['m','ft','in','cm','mm']%}<option {{'selected' if u=='m'}}>{{u}}</option>{%endfor%}</select>{% endif %}{% endif %}</div>
{% endmacro %}
<form method="post" action="{{url_for('sched', sid=spec.id)}}">
<div class="card"><div class="sec">Project</div>
<div style="margin-bottom:8px"><label>📁 Project name — type once in any module: all other modules auto-fill with this name (edit if needed)</label><input name="proj_name" value="{{cur_proj if cur_proj is defined else last_proj()}}" placeholder="Type a name e.g. Sharma House" autocomplete="off" autocorrect="off" spellcheck="false" onfocus="this.select()" onblur="if(this.value.trim()){fetch('/set_proj',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'name='+encodeURIComponent(this.value.trim())}).catch(function(){})}" style="font-weight:700"></div>
<div class="row r4">
{%for s in spec.scalars%}<div><label>{{s.label}}</label>
{%if s.type=='select'%}<select name="{{s.name}}">{%set sv=sc.scalars[s.name]%}{%for o in s.options%}<option {{'selected' if o==sv}}>{{o}}</option>{%endfor%}</select>
{%else%}<input name="{{s.name}}" value="{{sc.scalars[s.name]}}">{%endif%}</div>{%endfor%}</div></div>

{%if spec.get('labour')%}
<div class="card"><div class="sec">👷 Labour Rates — per day (editable)</div>
<p class="hint">Set your own daily wages for the labour estimate. These only affect the planning sheet (labour is already included in the BOQ rates above).</p>
<div class="row r4">
{%for k in spec.get('labour', [])%}<div><label>{{LABOUR_LABELS.get(k, k.title())}}</label>
<input name="lr_{{k}}" value="{{(sc.get('labour_rates') or {}).get(k, '')}}" style="background:#fffdf3;border-color:#f0d479"></div>{%endfor%}
</div></div>
{%endif%}
{%for t in spec.tables%}
<div class="card"><div class="sec">{{t.title}}{%if t.hint%}<span style="font-size:10px;color:#7a8693;font-weight:400"> — {{t.hint}}</span>{%endif%}</div>
{%if t.auto_note%}<div style="background:#eafaf0;border:1px solid #9fdcb4;border-left:4px solid #1f9d55;border-radius:7px;padding:7px 10px;margin:0 0 8px;font-size:11.5px;color:#14532d"><b>⚡ AUTOMATIC:</b> {{t.auto_note}}</div>{%endif%}
<div id="tbl_{{t.id}}">{%for r in sc.tables[t.id]%}
{%set ridx = loop.index0%}
<div class="mem"><input type="hidden" name="{{t.id}}_row" value="{{ridx}}">
<button type="button" class="dup1" onclick="dupRow(this,'{{t.id}}')" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row {{fw_cols(t.fields|length)}}">{%for f in t.fields%}{{fld(f, t.id, ridx, r.get(f.name))}}{%endfor%}</div>
<div class="ratef"><label>Rate ({{ current_country().currency }}) — market rate, edit if needed</label>{%set mkt=spec.get('row_rate') and spec['row_rate'](t.id, r, sc.scalars) or ''%}<input name="{{t.id}}_rate_{{loop.index0}}" value="{{r.get('rate') if r.get('rate') not in (None,'') else mkt}}" {%if not r.get('rate') or r.get('rate')==mkt%}data-auto="1"{%endif%} placeholder="market"></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addRow('{{t.id}}')">+ {{t.add_label}}</button>
<button type="button" class="add" onclick="dupRows('{{t.id}}')" style="background:#8e44ad" title="Copy every row above">⧉ Duplicate all rows</button></div>
{%endfor%}
<div style="display:flex;gap:8px;margin-top:10px">
<button class="btn" name="action" value="calc" style="flex:2;width:auto">⚙ Calculate</button>
<button class="btn" name="action" value="save" style="flex:1;width:auto;background:#2E86ab">💾 Save</button>
</div>
</form></div>
<div>
{%if result%}
<div class="card"><div class="kpi"><div><div class="v">{{"{:,.0f}".format(result.grand_total)}}</div><div class="l">Total {{ current_country().currency }}</div></div>
{%for k in result.kpis%}<div><div class="v">{{k[1]}}</div><div class="l">{{k[0]}}</div></div>{%endfor%}</div>
<div style="text-align:right;margin-top:8px"><a class="pill" href="{{url_for('sched_export', sid=spec.id)}}" target="_blank" rel="noopener">⬇ Download Excel</a>
<a class="pill" href="{{url_for('sched_export_pdf', sid=spec.id)}}" target="_blank" rel="noopener" style="background:#c0392b">⬇ Download PDF</a>
{%if result.saved_ok%}<div style="font-size:12px;color:#1f9d55;margin-top:7px">💾 Saved as "{{result.saved_ok}}" — <a href="{{url_for('dashboard')}}">Dashboard</a></div>{%endif%}
{%if result.save_error%}<div style="font-size:12px;color:#c0392b;margin-top:7px">{{result.save_error}} — <a href="{{url_for('dashboard')}}">Upgrade</a></div>{%endif%}
{%if result.saved_file%}<div style="font-size:11px;color:#b8860b;margin-top:7px">📥 Excel also saved: {{result.saved_file}}</div>{%endif%}
</div></div>
{%if result.materials%}<div class="card"><h2>Material Summary</h2>
<table><tr><th>Material</th><th class="ctr">Qty</th><th class="ctr">Unit</th><th class="num">Value {{ current_country().currency }}</th></tr>
{%for m in result.materials%}<tr><td>{{m.label}}</td><td class="ctr">{{"{:,.1f}".format(m.qty)}}</td><td class="ctr">{{m.unit}}</td><td class="num">{{"{:,.0f}".format(m.value)}}</td></tr>{%endfor%}</table></div>{%endif%}

{%if result.labour%}<div class="card"><h2>👷 Labour Estimate</h2>
<p class="hint">Planning only — labour cost is already included in the BOQ rates. Day-rates come from the editable <b>Labour Rates</b> card above.</p>
{%set lr = result.labour_rates or {}%}
{%set tc = namespace(v=0)%}
<table><tr><th>Trade</th><th class="num">Days</th><th class="num">Rate/day</th><th class="num">Cost {{ current_country().currency }}</th></tr>
{%for key, days in result.labour.items()%}
{%if key not in ('note','total_days') and 'cost' not in key and days%}
{%set rk = key.replace('_days','')%}{%set rc = lr.get(rk, 1000)%}{%set tc.v = tc.v + days * rc%}
<tr><td>{{LABOUR_LABELS.get(rk, rk.replace('_',' ').title())}}</td><td class="num">{{days|int}}</td>
<td class="num">{{"{:,.0f}".format(rc)}}</td><td class="num">{{"{:,.0f}".format(days * rc)}}</td></tr>
{%endif%}
{%endfor%}
<tr style="background:#eef4f9;font-weight:700"><td>Total</td><td class="num">{{result.labour.get('total_days',0)|int}}</td><td></td><td class="num">{{"{:,.0f}".format(tc.v)}}</td></tr>
</table></div>{%endif%}
<div class="card"><h2>Bill of Quantities</h2>
{%for gname,info in result.groups.items()%}
<div class="sec" style="margin-top:8px">{{gname}} <span style="font-size:10px;color:#7a8693">{{ current_country().currency }} {{"{:,.0f}".format(info.subtotal)}}</span></div>
<table><tr><th>Item</th><th class="ctr">Unit</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr>
{%for it in info['items']%}<tr><td>{{it.desc}}</td><td class="ctr">{{it.unit}}</td><td class="num">{{"{:,.2f}".format(it.qty)}}</td><td class="num">{{"{:,.0f}".format(it.rate)}}</td><td class="num">{{"{:,.0f}".format(it.amount)}}</td></tr>{%endfor%}
</table>{%endfor%}<div class="tot">GRAND TOTAL: {{ current_country().currency }} {{"{:,.0f}".format(result.grand_total)}}</div></div>
{%else%}<div class="card"><h2>📋 Get started</h2><p class="hint">{{spec.intro}}</p>
<p class="hint">Enter any dimension in <b>m / ft / in / cm / mm</b> (auto-converts). Each item has an editable <b>Rate</b> box. Click <b>Calculate</b>.</p></div>{%endif%}
</div></div></div>
<script>function cbsel(s){ if(s.value){ s.previousElementSibling.value=s.value; } s.selectedIndex=0; }
const MKIND={'rolled':{field:'member',map:{'beam':'B','column':'C','rafter':'R','tie':'T','gantry':'G','other':'M'}},'builtup':{field:'type',map:{'plate girder':'PG','built-up I beam':'BI','castellated beam':'CB','hybrid girder':'HG','box girder':'BG'}}};
function mMaxStem(tid,stem){const tbl=document.getElementById('tbl_'+tid);if(!tbl)return 0;let mx=0;const su=stem.toUpperCase();tbl.querySelectorAll('input[name^="'+tid+'_id_"]').forEach(x=>{const v=(x.value||'').trim();if(v.toUpperCase().indexOf(su)===0){const rest=v.slice(stem.length);if(/^\d+$/.test(rest)){const n=parseInt(rest,10);if(n>mx)mx=n;}}});return mx;}
function tblPfx(tid){const tbl=document.getElementById('tbl_'+tid);if(tbl){const ins=tbl.querySelectorAll('input[name^="'+tid+'_id_"]');for(let i=0;i<ins.length;i++){const v=(ins[i].value||'').trim();const m=v.match(/^([A-Za-z]+)\d+$/);if(m)return m[1];}}return ({purlins:'P',sheeting:'SH'})[tid]||tid.slice(0,2).toUpperCase();}
function kindPfx(tid,cl){const kd=MKIND[tid];if(kd){const ks=cl.querySelector('select[name^="'+tid+'_'+kd.field+'_"]');if(ks&&kd.map[ks.value]){return kd.map[ks.value];}}return null;}
function mRenumber(tid,cl){const inp=cl.querySelector('input[name^="'+tid+'_id_"]');if(!inp)return;const v=(inp.value||'').trim();if(!v){const p=kindPfx(tid,cl)||tblPfx(tid);inp.value=p+(mMaxStem(tid,p)+1);inp.dataset.auto='1';return;}const m=v.match(/^(.*?)(\d+)$/);if(m){inp.value=m[1]+(Math.max(mMaxStem(tid,m[1]),parseInt(m[2],10))+1);}else{inp.value=v+(Math.max(mMaxStem(tid,v),1)+1);}}
function mKindChanged(sel,tid){const kd=MKIND[tid];if(!kd)return;const row=sel.closest('.mem');if(!row)return;const idIn=row.querySelector('input[name^="'+tid+'_id_"]');if(!idIn||!idIn.dataset.auto)return;const p=kd.map[sel.value];if(!p)return;idIn.value=p+(mMaxStem(tid,p)+1);}
const RCFG={{fw_rcfg(spec, sc.scalars)|tojson}};
function _rateFill(tid,tr){const cfg=RCFG[tid];if(!cfg)return;const inp=tr.querySelector('input[name^="'+tid+'_rate_"]');if(!inp||!inp.dataset.auto)return;let base;if(cfg.f){const drv=tr.querySelector('select[name^="'+tid+'_'+cfg.f+'_"],input[name^="'+tid+'_'+cfg.f+'_"]');if(!drv)return;base=cfg.m[drv.value];if(base==null)base=cfg.m['*'];}else{base=cfg.m['*'];}if(base==null)return;let f=1;(cfg.x||[]).forEach(x=>{const fn=x[0][0]==='#'?x[0].slice(1):x[0];let el;if(x[0][0]==='#'){el=document.querySelector('select[name="'+fn+'"]')||document.querySelector('input[name="'+fn+'"]');}else{el=tr.querySelector('select[name^="'+tid+'_'+fn+'_"],input[name^="'+tid+'_'+fn+'_"]');}if(el&&x[1][el.value]!=null){f*=x[1][el.value];}});inp.value=Math.round(base*f*100)/100;}
function _rateUpd(el){if(!el||!el.name)return;for(const tid in RCFG){if(el.name.indexOf(tid+'_')===0){const cfg=RCFG[tid];const fld=el.name.slice(tid.length+1).replace(/_(\d+|NEWIDX)$/,'');const isDrv=cfg.f&&fld===cfg.f;const isX=(cfg.x||[]).some(x=>fld===x[0]||'#'+fld===x[0]);if(isDrv||isX){_rateFill(tid,el.closest('.mem'));return;}}}for(const tid in RCFG){const cfg=RCFG[tid];if((cfg.x||[]).some(x=>'#'+el.name===x[0])){document.querySelectorAll('#tbl_'+tid+' .mem').forEach(tr=>_rateFill(tid,tr));}}}
document.addEventListener('input',e=>{const n=e.target&&e.target.name;if(!n)return;if(/_id_\d+$/.test(n)||/_rate_(\d+|NEWIDX)$/.test(n)){e.target.dataset.auto='';}if(!/_rate_(\d+|NEWIDX)$/.test(n)){_rateUpd(e.target);}});
function dupRow(btn,tid){
  const row=btn.closest('.mem');
  const cl=row.cloneNode(true);
  const ni=window['cnt_'+tid]++;
  cl.querySelectorAll('input,select').forEach(el=>{
    if(el.name){el.name=el.name.replace(/_(\d+)$/,'_'+ni);}
  });
  const hid=cl.querySelector('input[type="hidden"]');
  if(hid){hid.value=ni;}
  row.after(cl);
  mRenumber(tid,cl);
}
function dupRows(tid){const tbl=document.getElementById('tbl_'+tid);if(!tbl||!tbl.children.length)return;
[...tbl.querySelectorAll('.mem')].forEach(r=>{const cl=r.cloneNode(true);const ni=window['cnt_'+tid]++;
cl.querySelectorAll('input,select').forEach(el=>{if(el.name){el.name=el.name.replace(/_(\d+)$/,'_'+ni);}});
const hid=cl.querySelector('input[type="hidden"]');if(hid){hid.value=ni;}tbl.appendChild(cl);mRenumber(tid,cl);});}
function addRow(tid){const tpl=document.getElementById('tpl_'+tid);const cl=tpl.cloneNode(true);
cl.style.display='block';cl.removeAttribute('id');const c=window['cnt_'+tid]++;
cl.innerHTML=cl.innerHTML.replace(/NEWIDX/g,c);document.getElementById('tbl_'+tid).appendChild(cl);
const idIn=cl.querySelector('input[name^="'+tid+'_id_"]');if(idIn&&!idIn.value.trim()){const p=kindPfx(tid,cl)||tblPfx(tid);idIn.value=p+(mMaxStem(tid,p)+1);idIn.dataset.auto='1';}}
_rateFill(tid,cl);
function addPdf(){const d=document.createElement('div');d.style.cssText='margin-top:6px;display:flex;gap:6px;align-items:center';
d.innerHTML='<input type="file" name="pdfs" accept="application/pdf" multiple style="flex:1"><button type="button" style="background:#c0392b;color:#fff;border:none;border-radius:5px;padding:6px 10px;cursor:pointer;font-size:12px" onclick="this.parentElement.remove()">✕</button>';
document.getElementById('morepdfs').appendChild(d);}
</script>
{%for t in spec.tables%}
<div id="tpl_{{t.id}}" style="display:none"><div class="mem"><input type="hidden" name="{{t.id}}_row" value="NEWIDX">
<button type="button" class="dup1" onclick="dupRow(this,'{{t.id}}')" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row {{fw_cols(t.fields|length)}}">{%for f in t.fields%}{{fld(f, t.id, 'NEWIDX', '')}}{%endfor%}</div>
<div class="ratef"><label>Rate ({{ current_country().currency }}) — market rate, edit if needed</label><input name="{{t.id}}_rate_NEWIDX" data-auto="1" placeholder="market"></div></div></div>
<script>window['cnt_{{t.id}}']={{sc.tables[t.id]|length}};</script>
{%endfor%}
</body></html>
"""
