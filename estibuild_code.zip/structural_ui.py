"""Structural module form <-> HTML (detailed member schedule + BBS)."""
from modules.common import NUM


# unit conversion: user input -> mm (engine always works in mm)
DIM_CONV = {'mm': 1.0, 'cm': 10.0, 'm': 1000.0, 'ft': 304.8, 'in': 25.4, 'inch': 25.4}

# fields that are dimensions (in mm) — NOT counts, grades, rates, bar specs
DIM_FIELDS = {'L', 'W', 't', 'depth', 'soling_t', 'ped_b', 'ped_d', 'ped_h',
              'strap_len', 'strap_b', 'strap_d', 'pile_dia', 'pile_len',
              'cap_L', 'cap_W', 'cap_t', 'b', 'd', 'length',
              'stem_t', 'stem_h', 'base_b', 'base_t',
              'wall_t', 'base_t', 'cover_t', 'thickness',
              'side_wall_h', 'side_wall_t', 'core_height', 'pit_depth',
              'run', 'tread', 'riser', 'width', 'waist',
              'landing_L', 'landing_W', 'landing_t', 'floor_height',
              'confinement_lo', 'cover_footing', 'cover_column', 'cover_beam', 'cover_slab',
              # detailed slab-system inputs
              'L_s', 'W_s', 'count', 'open_L', 'open_W', 'open_count', 'support_zone',
              'drop_L', 'drop_W', 'drop_t', 'sunken_drop', 'rib_spacing', 'rib_w',
              'rib_d', 'topping_t', 'solid_band', 'edge_bar_len'}


BEAM_KINDS = ['plinth beam', 'tie beam', 'primary', 'secondary', 'grade beam', 'lintel band', 'lintel', 'plinth']


def _CUR_RATES():
    import structural.engine as _se
    return _se.DEFAULT_SCHEDULE.get('rates', {})


def _CUR_LABOUR():
    import structural.engine as _se
    return _se.LABOUR


def _CUR_STEELFAB():
    import structural.engine as _se
    return _se.DEFAULT_SCHEDULE.get('labour_rates', {}).get('steel_fab', 1400)



def _collect_columns(gl, form):
    """Column rows with per-floor main bars: visible inputs are c_mainf_<floor>_<idx>;
    they are joined into the classic comma string ('8-16,8-16,6-16') that the engine,
    templates and saved projects already understand."""
    import html as _html
    out = []
    numset = {'count', 'b', 'd'}
    for idx in gl('c_row'):
        d = {}
        for k in ('id', 'count', 'b', 'd', 'main', 'tie', 'grade'):
            v = form.get(f'c_{k}_{idx}')
            if v is not None and str(v).strip() != '':
                d[k] = NUM(v) if k in numset else _html.unescape(v)
        if not str(d.get('main', '') or '').strip():
            fl = [str(form.get(f'c_mainf_{f}_{idx}') or '').strip() for f in range(25)]
            fl = [x for x in fl if x]
            if fl:
                d['main'] = ','.join(fl)
        if d:
            out.append(d)
    return out



def _collect_staircases(gl, form):
    """Multiple staircases: each row sc_row_{i} gives a full staircase spec."""
    import html as _html
    out = []
    numset = {'flights', 'run', 'width', 'waist', 'tread', 'riser', 'landings', 'landing_L', 'landing_W', 'landing_t'}
    for idx in gl('sc_row'):
        d = {}
        for k in ('id', 'type', 'flights', 'run', 'width', 'waist', 'mesh', 'tread', 'riser',
                   'landings', 'landing_L', 'landing_W', 'landing_t'):
            v = form.get(f'sc_{k}_{idx}')
            if v is not None and str(v).strip() != '':
                d[k] = NUM(v) if k in numset else _html.unescape(v)
        if d.get('flights'):
            out.append(d)
    # backwards compat: if no sc_row entries, check old single-field format
    if not out:
        old = {'flights': int(NUM(form.get('sc_flights', 2))), 'run': NUM(form.get('sc_run', 3600)),
               'width': NUM(form.get('sc_width', 1200)), 'waist': NUM(form.get('sc_waist', 150)),
               'mesh': form.get('sc_mesh', '10-150'), 'type': form.get('sc_type', 'dog-legged'),
               'tread': NUM(form.get('sc_tread', 300)), 'riser': NUM(form.get('sc_riser', 150)),
               'landings': int(NUM(form.get('sc_landings', 0))),
               'landing_L': NUM(form.get('sc_landing_L', 1200)), 'landing_W': NUM(form.get('sc_landing_W', 1200)),
               'landing_t': NUM(form.get('sc_landing_t', 150))}
        if old.get('flights'):
            out.append(old)
    return out


def parse_form(form):
    import html as _html
    gl = lambda k: form.getlist(k)

    # NOTE: unit conversion is handled entirely by JavaScript (convDims)
    # — the parser always receives values already in mm

    def collect(marker, prefix, fields, numset):
        out = []
        for idx in gl(marker):
            def g(k):
                v = form.get(f'{prefix}_{k}_{idx}')
                return _html.unescape(v) if isinstance(v, str) else v
            d = {}
            for k in fields:
                v = g(k)
                if v is not None and str(v).strip() != '':
                    d[k] = NUM(v) if k in numset else v
            if d:
                out.append(d)
        return out

    sch = {
        'project_name': form.get('project_name', 'RCC Structural Estimate'),
        'location': form.get('location', 'Kathmandu'),
        'concrete_grade': form.get('concrete_grade', 'M25'), 'pcc_mix': form.get('pcc_mix', 'PCC 1:4:8'),
        'floor_height': NUM(form.get('floor_height', 3000)),
        'floors_above': min(25, max(1, int(NUM(form.get('floors_above', 3))))),
        'col_below_gl': NUM(form.get('col_below_gl', '')),
        'confinement_lo': NUM(form.get('confinement_lo', 450)),
        'tw_type': form.get('tw_type', 'none'), 'tw_length': NUM(form.get('tw_length', 0)),
        'tw_depth': NUM(form.get('tw_depth', 0)), 'tw_wall_t': NUM(form.get('tw_wall_t', 0)),
        'tw_plinth_h': NUM(form.get('tw_plinth_h') or 0.45),   # '' (offline empty) -> default; typed 0 stays 0
        'cover_footing': NUM(form.get('cover_footing', 50)), 'cover_column': NUM(form.get('cover_column', 40)),
        'cover_beam': NUM(form.get('cover_beam', 25)), 'cover_slab': NUM(form.get('cover_slab', 20)),
        # fallbacks read the COUNTRY-CURRENT engine rates (apply_rates refreshes
        # them every request) so API/template-upload paths scale correctly too
        'rates': {k: NUM(form.get('rate_' + k, _CUR_RATES().get(k, dv))) for k, dv in {
            'rcc_m3': 16500, 'pcc_m3': 9500, 'excavation_m3': 450, 'backfill_m3': 400,
            'soling_m3': 3500, 'shuttering_m2': 850, 'steel_kg': 150,
            'stone_masonry_m3': 7500, 'brick_masonry_m3': 9500}.items()},
        # per-grade RCC + per-mix PCC: blank box -> engine default for that grade/mix
        'grade_rates': {g: NUM(form.get(f'rate_rcc_{g}', '')) for g in ('M15', 'M20', 'M30', 'M35', 'M40')},
        'mix_rates': {mx: NUM(form.get(f'rate_pcc_{k}', '')) for mx, k in
                      (('1:5:10', '1_5_10'), ('1:3:6', '1_3_6'), ('1:2:4', '1_2_4'), ('1:1.5:3', '1_1_5_3'))},
        'labour_rates': {
            'mason': NUM(form.get('lr_mason', _CUR_LABOUR().get('rate_mason', 1200))),
            'mazdoor': NUM(form.get('lr_mazdoor', _CUR_LABOUR().get('rate_mazdoor', 800))),
            'steel_fab': NUM(form.get('lr_steel_fab', _CUR_STEELFAB()))},
        'footings': (
            # isolated / combined / strap (one card)
            collect('f_row', 'f', ['id', 'kind', 'count', 'L', 'W', 't', 'depth', 'soling_t', 'mesh', 'ped_b', 'ped_d', 'ped_h', 'ped_main', 'ped_tie', 'strap_b', 'strap_d', 'strap_len', 'strap_top', 'strap_bot', 'strap_tie', 'stub_b', 'stub_d', 'stub_main', 'stub_tie', 'grade', 'soil',
                                  'top_mesh', 'pile_dia', 'pile_len', 'pile_no', 'pile_main', 'spiral', 'cap_L', 'cap_W', 'cap_t', 'cap_mesh'],
                    {'count', 'L', 'W', 't', 'depth', 'soling_t', 'ped_b', 'ped_d', 'ped_h', 'strap_b', 'strap_d', 'strap_len',
                     'pile_dia', 'pile_len', 'pile_no', 'cap_L', 'cap_W', 'cap_t'})
            # raft (own card, double mesh: bottom + top)
            + [dict(r, kind='raft') for r in collect('rf_row', 'rf', ['id', 'count', 'L', 'W', 't', 'depth', 'mesh', 'top_mesh', 'grade', 'soil'],
                    {'count', 'L', 'W', 't', 'depth'})]
            # piles + pile caps (own card)
            + [dict(r, kind='pile') for r in collect('pf_row', 'pf', ['id', 'count', 'pile_dia', 'pile_len', 'pile_no', 'pile_main', 'spiral', 'cap_L', 'cap_W', 'cap_t', 'cap_mesh', 'grade', 'soil'],
                    {'count', 'pile_dia', 'pile_len', 'pile_no', 'cap_L', 'cap_W', 'cap_t'})]
            # strip footing (own card)
            + [dict(r, kind='strip') for r in collect('sf_row', 'sf', ['id', 'count', 'L', 'W', 't', 'depth', 'soling_t', 'mesh', 'grade', 'soil'],
                    {'count', 'L', 'W', 't', 'depth', 'soling_t'})]
        ),
        'columns': _collect_columns(gl, form),
        'beams': collect('b_row', 'b', ['id', 'kind', 'count', 'b', 'd', 'length', 'top', 'bottom', 'extra_top', 'side', 'tie', 'grade'], {'count', 'b', 'd', 'length'}),
        'slabs': collect('s_row', 's', [
            'id', 'area', 'L_s', 'W_s', 'count', 't', 'type', 'mesh', 'top_mesh', 'grade',
            'span_direction', 'support_condition',
            'bottom_x', 'bottom_y', 'top_x', 'top_y', 'support_top_x', 'support_top_y',
            'support_zone', 'open_L', 'open_W', 'open_count', 'edge_bar', 'edge_bar_len',
            'sunken_drop', 'drop_L', 'drop_W', 'drop_t', 'rib_dir', 'rib_spacing', 'rib_w',
            'rib_d', 'topping_t', 'solid_band', 'rib_main', 'rib_top', 'rib_stirrup'
        ], {'area', 'L_s', 'W_s', 'count', 't', 'support_zone', 'open_L', 'open_W', 'open_count',
            'edge_bar_len', 'sunken_drop', 'drop_L', 'drop_W', 'drop_t', 'rib_spacing', 'rib_w',
            'rib_d', 'topping_t', 'solid_band'}),
        'shearwalls': collect('w_row', 'w', ['id', 'length', 't', 'height', 'vertical', 'horizontal'], {'length', 't', 'height'}),
        'retwalls': collect('rw_row', 'rw', ['id', 'length', 'stem_t', 'stem_h', 'base_b', 'base_t', 'vert', 'horiz', 'base_mesh'], {'length', 'stem_t', 'stem_h', 'base_b', 'base_t'}),
        'tanks': collect('t_row', 't', ['id', 'kind', 'L', 'W', 'depth', 'wall_t', 'base_t', 'cover_t', 'wall_mesh', 'base_mesh', 'grade'],
                         {'L', 'W', 'depth', 'wall_t', 'base_t', 'cover_t'}),
        'ramps': collect('r_row', 'r', ['id', 'length', 'width', 'thickness', 'mesh', 'side_wall_h', 'side_wall_t', 'grade'],
                         {'length', 'width', 'thickness', 'side_wall_h', 'side_wall_t'}),
        'lifts': collect('l_row', 'l', ['id', 'L', 'W', 'pit_depth', 'core_height', 'wall_t', 'base_t', 'mesh', 'grade'],
                         {'L', 'W', 'pit_depth', 'core_height', 'wall_t', 'base_t'}),
        'others': collect('o_row', 'o', ['item', 'qty'], {'qty'}),
        'concrete_pumping': form.get('concrete_pumping', 'none'),
        'staircase': _collect_staircases(gl, form),
    }
    return sch


def auto_stub_note(s):
    """Green note under 'Column below plinth': the value the engine WILL
    auto-calculate (mirrors engine logic exactly)."""
    def _n(v, d=0.0):
        try:
            return float(v)
        except (TypeError, ValueError):
            return d
    cands = []
    for f in (s.get('footings') or []):
        v = _n(f.get('depth'), 1500) - _n(f.get('t'), 600) - _n(f.get('ped_h'), 0)
        if v > 0:
            cands.append(int(round(v)))
    base = max(cands) if cands else 0
    plinth = max(0, int(round(_n(s.get('tw_plinth_h'), 0.45) * 1000)))
    typed = _n(s.get('col_below_gl'), 0)
    if typed > 0:
        return 'your typed value is used'
    return 'auto-calculated WITH YOUR FOOTING ESTIMATE (footings + plinth height)'



HTML = r"""
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>RCC Structure - EstiBuild</title>
<style>
:root{--nav:#1F3B57;--bg:#f4f7fa;--card:#fff;--line:#d7e0ea;--green:#1f9d55}
*{box-sizing:border-box}body{margin:0;font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:#223}
.top{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:13px 24px;display:flex;justify-content:space-between;align-items:center}
.swd{position:relative;display:inline-block}
.swd summary{cursor:pointer;list-style:none;background:#ffffff;color:#1F3B57;font-weight:800;padding:6px 13px;border-radius:7px;margin-right:12px;display:inline-block;font-size:12px;user-select:none}
.swd summary::-webkit-details-marker{display:none}
.swd[open] summary{background:#eef3f8}
.swbox{position:absolute;right:0;top:calc(100% + 6px);background:#fff;border:1px solid #d7e0ea;border-radius:10px;box-shadow:0 10px 28px rgba(31,59,87,.25);min-width:245px;z-index:60;padding:5px}
.swh{font-size:10px;font-weight:800;color:#7a8693;text-transform:uppercase;padding:5px 9px 3px;letter-spacing:.5px}
.swd .swm{display:block;font-size:12.5px;font-weight:600;padding:7px 10px;color:#223;text-decoration:none;border-radius:6px}
.swd .swm:hover{background:#f1f6fb}
.swd .swm.cur{font-weight:700;color:#1F3B57;background:#f1f6fb}
.top a{color:#cfe8ff;text-decoration:none;font-size:13px}
.wrap{max-width:1320px;margin:0 auto;padding:14px 16px 60px}
.grid2{display:grid;grid-template-columns:1.3fr 1fr;gap:14px;align-items:start}
@media(max-width:1040px){.grid2{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin-bottom:13px}
.card h2{margin:0 0 3px;font-size:16px;color:var(--nav)} .lh{font-size:9px;color:#7a8693;margin-top:2px;line-height:1.25}
.hint{color:#7a8693;font-size:12px;margin:0 0 10px}
label{display:block;font-size:10px;font-weight:600;color:#556;margin:4px 0 1px;text-transform:uppercase}
input,select{width:100%;padding:6px 7px;border:1px solid var(--line);border-radius:6px;font-size:12px}
.sec{font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:var(--nav);font-weight:800;margin:0 0 8px;padding-bottom:5px;border-bottom:2px solid var(--line)}
.flrow{display:flex;flex-wrap:wrap;gap:6px;margin-top:2px}
.fcell label{font-size:10px;color:#567;margin-bottom:1px;display:block;text-align:center}
.fcell input{width:80px;padding:5px 6px;border:1px solid #cdd8e2;border-radius:5px}
.mainfloors{margin-top:6px}
.fbtn{height:34px;padding:0 12px;border:none;border-radius:7px;background:#1f9d55;color:#fff;font-weight:800;font-size:13px;cursor:pointer;margin-top:10px;box-shadow:0 2px 6px rgba(31,157,85,.35)}
.fbtn.minus{background:#6c757d;width:36px;padding:0;box-shadow:none}
.row{display:grid;gap:7px}.r2{grid-template-columns:1fr 1fr}.r3{grid-template-columns:1fr 1fr 1fr}
.r4{grid-template-columns:repeat(4,1fr)}.r5{grid-template-columns:repeat(5,1fr)}.r6{grid-template-columns:repeat(6,1fr)}
.mem{border:1px solid #e6edf4;border-left:4px solid var(--nav);border-radius:8px;padding:9px 11px;margin-bottom:7px;background:#fcfdff;position:relative}
.del{position:absolute;top:7px;right:9px;background:#c0392b;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}
.add{background:var(--nav);color:#fff;border:none;padding:7px 14px;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;margin-top:3px}
.btn{background:var(--green);color:#fff;border:none;padding:13px 26px;border-radius:9px;font-size:15px;font-weight:700;cursor:pointer;width:100%;margin-top:10px}
.kpi{display:flex;gap:8px;flex-wrap:wrap}.kpi div{flex:1;min-width:100px;background:#eef4f9;border:1px solid var(--line);border-radius:9px;padding:9px;text-align:center}
.kpi .v{font-size:17px;font-weight:800;color:var(--nav)}.kpi .l{font-size:10px;color:#7a8693}
table{width:100%;border-collapse:collapse;font-size:11.5px;margin-top:4px}
th{background:var(--nav);color:#fff;padding:6px;text-align:left}td{padding:4px 6px;border-bottom:1px solid var(--line)}
.num{text-align:right}.ctr{text-align:center}.tot{background:#fff3cf;font-weight:800;text-align:right;padding:9px;border-radius:6px;margin-top:8px}
.pill{display:inline-block;background:var(--green);color:#fff;padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;text-decoration:none}
.upload{border:2px dashed var(--nav);border-radius:10px;padding:13px;text-align:center;background:#f7fafd;margin-bottom:6px}
.guide{background:#f1f6fb;border:1px solid #cfe0ef;border-left:4px solid var(--nav);border-radius:8px;padding:10px 12px;margin:8px 0;font-size:11.5px}
.combo{display:flex;gap:3px;align-items:stretch}
.combo input{flex:1;min-width:0}
.cbs{width:34px;padding:0;border:1px solid #b9cadb;border-radius:6px;background:#e8f0f8;cursor:pointer;font-size:11px;color:#2E86ab;text-align:center;-webkit-appearance:none;appearance:none;flex:none}
.cbs:hover{background:#d8e6f2;border-color:#2E86ab}
.guide b{color:var(--nav)}.guide ul{margin:5px 0 5px 16px;padding:0;line-height:1.6}.guide i{color:#7a8693}
.bar{height:13px;border-radius:4px;background:linear-gradient(90deg,#1F3B57,#3a7ca5)}
.det{color:#5b7a99;font-size:10.5px}
</style></head><body>

{%set MAIN_O=['2-10','3-10','2-12','3-12','4-12','6-12','8-12','2-16','3-16','4-16','6-16','8-16','10-16','12-16','16-16','20-16','4-20','6-20','8-20','4-25','6-25']%}
{%set TIE_O=['6-150','8-100','8-100-150','8-100-200','8-125-150','8-150','8-200','10-100-150','10-100-200']%}
{%set MESH_O=['8-200','10-200','10-150','12-200','12-150','12-100','16-150','16-100','16-200']%}
{%set PED_O=['4-12','6-12','8-12','4-16','6-16','8-16','4-20','6-20','8-20']%}
{%set STIRRUP_O=['6-150','8-100','8-100-150','8-100-200','8-125-150','8-150','10-100-150']%}

<div class="top"><div><b>🏗️ RCC Structure Estimation</b> <span style="opacity:.8;font-size:12px">· {{SHORT}}</span></div><div><a href="{{url_for('new_estimate')}}" onclick="if(history.length>1){history.back();return false;}" style="background:#ffffff;color:#1F3B57;font-weight:800;padding:6px 13px;border-radius:7px;margin-right:12px">◀ Go Back</a>
<details class="swd"><summary>⇄ Switch Module ▾</summary><div class="swbox">
<div class="swh">Same project — continue in:</div>
<div class="swm cur">🏗️ RCC Structure · current</div>
<a class="swm" href="{{url_for('sched',sid='archfin')}}">🏛️ Architecture &amp; Finishing</a>
<a class="swm" href="{{url_for('sched',sid='sanitary')}}">🚿 Sanitary &amp; Plumbing</a>
<a class="swm" href="{{url_for('sched',sid='electrical')}}">⚡ Electrical</a>
<a class="swm" href="{{url_for('sched',sid='steel')}}">🏭 Steel Structure</a>
<a class="swm" href="{{url_for('sched',sid='roofing')}}">🏠 Roofing &amp; Truss</a>
</div></details>
<a href="{{url_for('landing')}}">🏠 Home</a></div></div>
<div class="wrap"><div class="grid2"><div>
<div class="card"><div class="sec">Upload Structural PDF / Drawings</div>
<div style="background:#eef6fb;border:1px solid #b9d9eb;border-radius:9px;padding:10px 12px;margin:10px 0;font-size:11.5px;color:#36556b;line-height:1.55"><b style="color:#1F3B57">⚡ Save hours of estimation work</b><br>Send the fillable EstiBuild HTML or Excel template to the engineer, architect, or designer who prepared the drawings. They can enter the dimensions and materials they already know; upload the completed template here and EstiBuild turns it into an editable estimate in minutes. This avoids duplicate data entry and can reduce preparation time from hours to minutes.</div>

<form method="post" action="{{url_for('structural_upload')}}" enctype="multipart/form-data">
<details style="margin-bottom:8px;background:#eef6f0;border:1px solid #b7dfc3;border-radius:8px;padding:8px 10px">
<summary style="font-size:12px;font-weight:700;color:#1f9d55;cursor:pointer">📋 What to include for BEST auto-fill (click to see exactly what we read)</summary>
<div style="font-size:11px;color:#445;margin-top:8px;line-height:1.7">
<b>Best (100% exact, free):</b> typed schedule tables in any PDF — one table per PDF is fine, all combined:
<table style="font-size:10.5px;margin-top:4px">
<tr><th style="padding:4px 6px">Schedule table</th><th style="padding:4px 6px">Columns we look for</th></tr>
<tr style="background:#f7faf8"><td style="padding:3px 6px;font-weight:600">Footing Schedule</td><td style="padding:3px 6px;color:#567">Mark · Type · Nos · L (mm) · W (mm) · t (mm) · Depth · Mesh · Grade</td></tr>
<tr><td style="padding:3px 6px;font-weight:600">Column Schedule</td><td style="padding:3px 6px;color:#567">Mark · Nos · b (mm) · d (mm) · Main bars PER FLOOR (8-16,8-16,6-16) · Tie · Grade</td></tr>
<tr style="background:#f7faf8"><td style="padding:3px 6px;font-weight:600">Beam Schedule</td><td style="padding:3px 6px;color:#567">Mark · Type · Nos · b · d · Length · Top · Bottom · Extra top @supports · Side bars · Stirrup · Grade</td></tr>
<tr><td style="padding:3px 6px;font-weight:600">Slab Schedule</td><td style="padding:3px 6px;color:#567">Mark · Area (m²) · t (mm) · Bottom mesh · Top mesh (double mesh) · Grade</td></tr>
</table>
<div style="margin-top:6px">✅ <b>BBS is always auto-generated</b> from whatever you fill — no bar schedule upload needed.<br>
<b>Fallback:</b> any drawing via AI → editable draft</div>
</div>
</details>
<div class="upload"><input type="file" name="pdfs" accept="application/pdf,.json,.xlsx,.html" multiple>
<div style="margin-top:5px;font-size:11px;color:#7a8693">Upload one or many files: <b>footing schedule PDF + column schedule PDF + beam PDF...</b> separately — all combined! Or your filled <b>template .json/.xlsx/.html</b>. BBS is auto-generated.</div>
<div style="margin-top:7px;font-size:11.5px">
<a href="{{url_for('download_template', sid='structural', fmt='html')}}" target="_blank" rel="noopener" style="color:#1f9d55;font-weight:700">⬇ Fillable template (HTML)</a> &nbsp;·&nbsp;
<a href="{{url_for('download_template', sid='structural', fmt='xlsx')}}" target="_blank" rel="noopener" style="color:#1f9d55;font-weight:700">Excel template</a>
</div>
<div id="morepdfs"></div>
<div style="margin-top:8px"><button class="add" type="submit">⬆ Read PDF(s) &amp; auto-fill</button>
{%if ai_enabled()%}<button type="submit" formaction="{{url_for('structural_ai_template')}}" class="add" style="background:#8e44ad;margin-top:4px;width:100%">🤖 AI reads ALL your PDFs → editable draft (HTML)</button>{%else%}<div style="background:#f0e6f6;border:1px dashed #8e44ad;border-radius:7px;padding:8px;margin-top:4px;text-align:center;font-size:11px;color:#8e44ad"><b>🤖 AI Drawing Reader</b> — <b>coming soon!</b> Upload all your PDFs at once; AI merges everything into <b>one editable HTML draft</b> — review, correct offline, then upload it back.</div>{%endif%}
</div></div></form>
<a href="{{url_for('structural')}}" class="add" style="background:#e74c3c;margin-top:6px;display:inline-block;text-decoration:none">🔄 Reset form (clear all auto-fill)</a>
<button type="button" class="add" style="background:#6c757d;margin-top:6px" onclick="addPdf()">+ Add another PDF slot</button>
{%if notes%}<div style="background:#fff8e1;border:1px solid #f0d479;border-radius:8px;padding:9px;font-size:12px;margin:8px 0"><b>PDF result:</b><ul style="margin:4px 0 0 16px;padding:0">{%for n in notes%}<li>{{n}}</li>{%endfor%}</ul></div>{%endif%}
</div>
<form method="post" action="{{url_for('structural')}}">
<div class="card"><div class="sec">Project & Design Parameters</div>
<div class="row r2"><div><label>📁 Project name — type once in any module: all others auto-fill (edit if needed)</label><input name="project_name" value="{{s.project_name if s.project_name and s.project_name not in ('RCC Structural Estimate', 'Detailed RCC Structural Estimate') else ('' if fresh is defined and fresh else last_proj())}}" placeholder="Type a new project name" autocomplete="off" autocorrect="off" spellcheck="false" onfocus="this.select()" onblur="if(this.value.trim()){fetch('/set_proj',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'name='+encodeURIComponent(this.value.trim())}).catch(function(){})}" style="font-weight:700"></div>
<div><label>Location</label><input name="location" value="{{s.location}}"></div></div>
<div class="row r5">
<div><label>Concrete grade</label><select name="concrete_grade">{%set cg=s.concrete_grade%}{%for x in ['M20','M25','M30','M35','M15','M40']%}<option {{'selected' if x==cg}}>{{x}}</option>{%endfor%}</select><div style="font-size:9px;color:#7a8693;margin-top:2px">rate scales by grade (M25 = base)</div></div>
<div><label>PCC mix</label><select name="pcc_mix">{%set pm=s.pcc_mix%}{%for x in ['PCC 1:5:10','PCC 1:4:8','PCC 1:3:6','PCC 1:2:4','PCC 1:1.5:3']%}<option {{'selected' if x==pm}}>{{x}}</option>{%endfor%}</select><div style="font-size:9px;color:#7a8693;margin-top:2px">rate scales by mix (1:4:8 = base)</div></div>
<div><label>Concrete pumping</label><select name="concrete_pumping">{%set cp=s.get('concrete_pumping','none')%}{%for x in ['none','boom pump','line pump']%}<option {{'selected' if x==cp}}>{{x}}</option>{%endfor%}</select></div>
<div><label>Floor height (mm)</label><input name="floor_height" value="{{s.floor_height}}"></div>
<div><label>Floors above gr. (max 25)</label><input name="floors_above" type="number" min="1" max="25" value="{{s.floors_above}}"></div>
<div><label>Column below plinth (mm)</label><input name="col_below_gl" value="{{s.get('col_below_gl','') if s.get('col_below_gl') else ''}}" placeholder="blank = auto: depth &#8722; t &#8722; ped + plinth"></div>
<div><label>📐 Dim unit (all sizes)</label><select name="dim_unit" id="dim_unit" onchange="convDims(this.value)"><option value="mm">mm (default)</option><option value="cm">cm</option><option value="m">m</option><option value="ft">ft (feet)</option><option value="in">in (inches)</option></select><div class="dimnote" style="font-size:10px;color:#7a8693;margin-top:2px">mm</div></div>
</div>
<div style="background:#eafaf0;border:1px solid #9fdcb4;border-left:4px solid #1f9d55;border-radius:7px;padding:8px 12px;margin:8px 0 0;font-size:12px;color:#14532d;font-weight:600" id="stubnote">&#9889; <b>Column below plinth:</b> {{stub_note(s)}}</div>
<details style="margin-top:8px"><summary style="font-size:11.5px;font-weight:700;color:#7a8693;cursor:pointer;user-select:none">&#128295; Advanced &#8212; covers &amp; seismic zone (defaults are correct for most jobs)</summary>
<div class="row r4" style="margin-top:6px">
<div><label>Confine zone (mm)</label><input name="confinement_lo" value="{{s.confinement_lo}}"><div class="lh">close-stirrup zone at column/beam ends (IS 13920)</div></div>
<div><label>Cover footing (mm)</label><input name="cover_footing" value="{{s.cover_footing}}"><div class="lh">used in every BBS bar length</div></div>
<div><label>Cover column (mm)</label><input name="cover_column" value="{{s.cover_column}}"><div class="lh">clear cover (IS 456)</div></div>
<div><label>Cover beam (mm)</label><input name="cover_beam" value="{{s.cover_beam}}"><div class="lh">clear cover (IS 456)</div></div>
<div><label>Cover slab (mm)</label><input name="cover_slab" value="{{s.cover_slab}}"><div class="lh">clear cover (IS 456)</div></div></div></details></div>

<div class="card" style="border-left:4px solid #b8860b"><div class="sec">⚙ Unit Rates — editable (drive the whole BOQ)</div>
<p class="hint">Change any rate to your own market rate — all amounts recalculate. Composite rates (material + labour included).</p>
{%set r=s.rates%}
<div class="sec" style="margin-top:4px">RCC by grade — your own rate per grade</div>
<div class="row r5">
<div><label>M15 /m³</label><input name="rate_rcc_M15" value="{{r.get('rcc_M15','')}}" placeholder="15,500" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>M20 /m³</label><input name="rate_rcc_M20" value="{{r.get('rcc_M20','')}}" placeholder="16,000" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>M25 /m³</label><input name="rate_rcc_m3" value="{{r.rcc_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>M30 /m³</label><input name="rate_rcc_M30" value="{{r.get('rcc_M30','')}}" placeholder="17,500" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>M35 /m³</label><input name="rate_rcc_M35" value="{{r.get('rcc_M35','')}}" placeholder="18,500" style="background:#fffdf3;border-color:#f0d479"></div></div>
<div class="sec" style="margin-top:10px">PCC by mix — your own rate per mix</div>
<div class="row r5">
<div><label>1:5:10 /m³</label><input name="rate_pcc_1_5_10" value="{{r.get('pcc_1_5_10','')}}" placeholder="8,200" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>1:4:8 /m³</label><input name="rate_pcc_m3" value="{{r.pcc_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>1:3:6 /m³</label><input name="rate_pcc_1_3_6" value="{{r.get('pcc_1_3_6','')}}" placeholder="11,000" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>1:2:4 /m³</label><input name="rate_pcc_1_2_4" value="{{r.get('pcc_1_2_4','')}}" placeholder="12,500" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>1:1.5:3 /m³</label><input name="rate_pcc_1_1_5_3" value="{{r.get('pcc_1_1_5_3','')}}" placeholder="13,500" style="background:#fffdf3;border-color:#f0d479"></div></div>
<div class="sec" style="margin-top:10px">Other rates</div>
<div class="row r4">
<div><label>Excavation /m³</label><input name="rate_excavation_m3" value="{{r.excavation_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Backfill /m³</label><input name="rate_backfill_m3" value="{{r.backfill_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Soling /m³</label><input name="rate_soling_m3" value="{{r.soling_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Shuttering /m²</label><input name="rate_shuttering_m2" value="{{r.shuttering_m2}}" style="background:#fffdf3;border-color:#f0d479"></div></div>
<div class="row r4" style="margin-top:8px">
<div><label>Steel /kg</label><input name="rate_steel_kg" value="{{r.steel_kg}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Stone masonry /m³</label><input name="rate_stone_masonry_m3" value="{{r.stone_masonry_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Brick masonry /m³</label><input name="rate_brick_masonry_m3" value="{{r.brick_masonry_m3}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div></div></div>

<div class="sec" style="margin-top:12px">👷 Labour Rates — per day (editable)</div>
<p class="hint">Your own daily wages. Used only in the labour planning sheet — labour is already inside the composite BOQ rates above.</p>
{%set lrv=s.get('labour_rates') or {'mason':1200,'mazdoor':800,'steel_fab':1400}%}
<div class="row r3">
<div><label>Mason /day</label><input name="lr_mason" value="{{lrv.get('mason',1200)}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Mazdoor /day</label><input name="lr_mazdoor" value="{{lrv.get('mazdoor',800)}}" style="background:#fffdf3;border-color:#f0d479"></div>
<div><label>Steel fabricator /day</label><input name="lr_steel_fab" value="{{lrv.get('steel_fab',1400)}}" style="background:#fffdf3;border-color:#f0d479"></div></div></div>

<div class="card"><div class="sec">A1 · Footings — Isolated / Combined / Strap</div>
<p class="hint">One row per footing type. Pedestal boxes: isolated/combined. Strap boxes: strap only (they show/hide by Type). Mesh "dia-spacing" — use the ▾ pickers.</p>
<div id="footings">{%for f in s.footings if f.kind not in ('raft','pile','strip')%}
<div class="mem"><input type="hidden" name="f_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="f_id_{{loop.index0}}" value="{{f.id}}"></div>
<div><label>Type</label><select name="f_kind_{{loop.index0}}" onchange="syncFootingKind(this);kindChanged(this,'f')">{%set k=f.kind%}{%for t in ['isolated','strap','combined']%}<option {{'selected' if t==k}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Count</label><input name="f_count_{{loop.index0}}" value="{{f.count}}"></div>
<div><label>L (mm)</label><input name="f_L_{{loop.index0}}" value="{{f.get('L','')}}"></div>
<div><label>W (mm)</label><input name="f_W_{{loop.index0}}" value="{{f.get('W','')}}"></div></div>
<div class="row r6">
<div><label>t (mm)</label><input name="f_t_{{loop.index0}}" value="{{f.get('t','')}}"><div class="lh">pad thickness</div></div>
<div><label>Depth GL</label><input name="f_depth_{{loop.index0}}" value="{{f.get('depth','')}}"><div class="lh">ground &#8594; footing base</div></div>
<div><label>Soling t</label><input name="f_soling_t_{{loop.index0}}" value="{{f.get('soling_t','')}}"><div class="lh">stone layer below, 0 = none</div></div>
<div><label>Mesh</label><div class="combo"><input name="f_mesh_{{loop.index0}}" onfocus="this.select()" value="{{f.get('mesh','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="f_grade_{{loop.index0}}">{%set gr=f.get('grade','M25')%}{%for t in ['M20','M25','M30','M35','M15','M40']%}<option {{'selected' if t==gr}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Soil</label><select name="f_soil_{{loop.index0}}">{%set so=f.get('soil','soft soil')%}{%for t in ['soft soil','hard soil','rock','mixed']%}<option {{'selected' if t==so}}>{{t}}</option>{%endfor%}</select></div></div>
<div class="row r6 fgrp" data-show="isolated,combined">
<div><label>Ped b</label><input name="f_ped_b_{{loop.index0}}" value="{{f.get('ped_b','')}}"></div>
<div><label>Ped d</label><input name="f_ped_d_{{loop.index0}}" value="{{f.get('ped_d','')}}"></div>
<div><label>Ped h</label><input name="f_ped_h_{{loop.index0}}" value="{{f.get('ped_h','')}}"><div class="lh">pedestal height above pad</div></div>
<div><label>Ped main</label><div class="combo"><input name="f_ped_main_{{loop.index0}}" onfocus="this.select()" value="{{f.get('ped_main','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in PED_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Ped tie</label><div class="combo"><input name="f_ped_tie_{{loop.index0}}" onfocus="this.select()" value="{{f.get('ped_tie','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in STIRRUP_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div></div></div>
<div class="row r6 fgrp" data-show="strap">
<div><label>Strap len</label><input name="f_strap_len_{{loop.index0}}" value="{{f.get('strap_len','')}}"><div class="lh">beam between the 2 pads</div></div>
<div><label>Strap b</label><input name="f_strap_b_{{loop.index0}}" value="{{f.get('strap_b','')}}"></div>
<div><label>Strap d</label><input name="f_strap_d_{{loop.index0}}" value="{{f.get('strap_d','')}}"></div>
<div><label>Strap top</label><div class="combo"><input name="f_strap_top_{{loop.index0}}" onfocus="this.select()" value="{{f.get('strap_top','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MAIN_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Strap bot</label><div class="combo"><input name="f_strap_bot_{{loop.index0}}" onfocus="this.select()" value="{{f.get('strap_bot','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MAIN_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Strap tie</label><div class="combo"><input name="f_strap_tie_{{loop.index0}}" onfocus="this.select()" value="{{f.get('strap_tie','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in STIRRUP_O%}<option>{{o}}</option>{%endfor%}</select></div></div></div>
{%set so_=f.get('stub_b') or f.get('stub_d') or f.get('stub_main') or f.get('stub_tie')%}
<details {{'open' if so_}} style="margin:3px 0"><summary style="font-size:11px;font-weight:700;color:#7a8693;cursor:pointer;user-select:none">&#65291; Starter column below plinth (advanced &#8212; leave closed = auto)</summary>
<div class="row r6" style="border-top:1px dashed #d7e0ea;padding-top:6px"><div><label>Stub b</label><input name="f_stub_b_{{loop.index0}}" value="{{f.get('stub_b','')}}" placeholder="blank=auto"><div class="lh">starter width</div></div><div><label>Stub d</label><input name="f_stub_d_{{loop.index0}}" value="{{f.get('stub_d','')}}" placeholder="blank=auto"><div class="lh">starter depth</div></div><div><label>Stub bars</label><div class="combo"><input name="f_stub_main_{{loop.index0}}" onfocus="this.select()" value="{{f.get('stub_main','')}}" placeholder="e.g. 8-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in PED_O%}<option>{{o}}</option>{%endfor%}</select></div><div class="lh">count-dia</div></div><div><label>Stub tie</label><div class="combo"><input name="f_stub_tie_{{loop.index0}}" onfocus="this.select()" value="{{f.get('stub_tie','')}}" placeholder="e.g. 8-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in STIRRUP_O%}<option>{{o}}</option>{%endfor%}</select></div><div class="lh">dia-spacing</div></div><div style="font-size:9px;color:#7a8693;align-self:end;padding-bottom:6px">hidden column piece: footing &#8594; plinth beam. Blank = auto from your column card.</div></div></details>
</div>
{%endfor%}</div>
<button type="button" class="add" onclick="addF()">+ Add footing type</button>
<button type="button" class="add" onclick="dupRows('f')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">A2 · Raft Foundation <span style="font-size:10px;color:#7a8693">double mesh — bottom + top</span></div>
<p class="hint">Whole raft slab: L x W x thickness. Bottom mesh AND top mesh entered separately (double mesh).</p>
<div id="rafts">{%for f in s.footings if f.kind=='raft'%}
<div class="mem"><input type="hidden" name="rf_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="rf_id_{{loop.index0}}" value="{{f.id}}"></div>
<div><label>Count</label><input name="rf_count_{{loop.index0}}" value="{{f.count}}"></div>
<div><label>L (mm)</label><input name="rf_L_{{loop.index0}}" value="{{f.get('L','')}}"></div>
<div><label>W (mm)</label><input name="rf_W_{{loop.index0}}" value="{{f.get('W','')}}"></div>
<div><label>t (mm)</label><input name="rf_t_{{loop.index0}}" value="{{f.get('t','')}}"></div></div>
<div class="row r5">
<div><label>Depth GL</label><input name="rf_depth_{{loop.index0}}" value="{{f.get('depth','')}}"></div>
<div><label>Bottom mesh</label><div class="combo"><input name="rf_mesh_{{loop.index0}}" onfocus="this.select()" value="{{f.get('mesh','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Top mesh</label><div class="combo"><input name="rf_top_mesh_{{loop.index0}}" onfocus="this.select()" value="{{f.get('top_mesh','')}}" placeholder="blank = same as bottom"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="rf_grade_{{loop.index0}}">{%set gr=f.get('grade','M25')%}{%for t in ['M20','M25','M30','M35','M15','M40']%}<option {{'selected' if t==gr}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Soil</label><select name="rf_soil_{{loop.index0}}">{%set so=f.get('soil','soft soil')%}{%for t in ['soft soil','hard soil','rock','mixed']%}<option {{'selected' if t==so}}>{{t}}</option>{%endfor%}</select></div></div>
</div>
{%endfor%}</div>
<button type="button" class="add" onclick="addRF()">+ Add raft</button>
<button type="button" class="add" onclick="dupRows('rf')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">A3 · Pile Foundation <span style="font-size:10px;color:#7a8693">piles + pile caps</span></div>
<p class="hint">Count = number of pile caps; Pile no = piles under one cap. Cap = the pile cap below column.</p>
<div id="piles">{%for f in s.footings if f.kind=='pile'%}
<div class="mem"><input type="hidden" name="pf_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="pf_id_{{loop.index0}}" value="{{f.id}}"></div>
<div><label>Caps (count)</label><input name="pf_count_{{loop.index0}}" value="{{f.count}}"></div>
<div><label>Pile dia (mm)</label><input name="pf_pile_dia_{{loop.index0}}" value="{{f.get('pile_dia','')}}"></div>
<div><label>Pile len (mm)</label><input name="pf_pile_len_{{loop.index0}}" value="{{f.get('pile_len','')}}"></div>
<div><label>Pile no / cap</label><input name="pf_pile_no_{{loop.index0}}" value="{{f.get('pile_no','')}}"></div>
<div><label>Pile main</label><div class="combo"><input name="pf_pile_main_{{loop.index0}}" onfocus="this.select()" value="{{f.get('pile_main','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in PED_O%}<option>{{o}}</option>{%endfor%}</select></div></div></div>
<div class="row r6">
<div><label>Spiral</label><div class="combo"><input name="pf_spiral_{{loop.index0}}" onfocus="this.select()" value="{{f.get('spiral','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Cap L (mm)</label><input name="pf_cap_L_{{loop.index0}}" value="{{f.get('cap_L','')}}"></div>
<div><label>Cap W (mm)</label><input name="pf_cap_W_{{loop.index0}}" value="{{f.get('cap_W','')}}"></div>
<div><label>Cap t (mm)</label><input name="pf_cap_t_{{loop.index0}}" value="{{f.get('cap_t','')}}"></div>
<div><label>Cap mesh</label><div class="combo"><input name="pf_cap_mesh_{{loop.index0}}" onfocus="this.select()" value="{{f.get('cap_mesh','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="pf_grade_{{loop.index0}}">{%set gr=f.get('grade','M25')%}{%for t in ['M25','M30','M35']%}<option {{'selected' if t==gr}}>{{t}}</option>{%endfor%}</select></div></div>
</div>
{%endfor%}</div>
<button type="button" class="add" onclick="addPF()">+ Add pile type</button>
<button type="button" class="add" onclick="dupRows('pf')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">A4 · Strip Footing <span style="font-size:10px;color:#7a8693">continuous wall footing</span></div>
<p class="hint">Continuous footing under walls: Length x Width x t. Mesh "dia-spacing".</p>
<div id="strips">{%for f in s.footings if f.kind=='strip'%}
<div class="mem"><input type="hidden" name="sf_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="sf_id_{{loop.index0}}" value="{{f.id}}"></div>
<div><label>Count</label><input name="sf_count_{{loop.index0}}" value="{{f.count}}"></div>
<div><label>Length (mm)</label><input name="sf_L_{{loop.index0}}" value="{{f.get('L','')}}"></div>
<div><label>Width (mm)</label><input name="sf_W_{{loop.index0}}" value="{{f.get('W','')}}"></div>
<div><label>t (mm)</label><input name="sf_t_{{loop.index0}}" value="{{f.get('t','')}}"></div></div>
<div class="row r5">
<div><label>Depth GL</label><input name="sf_depth_{{loop.index0}}" value="{{f.get('depth','')}}"></div>
<div><label>Soling t</label><input name="sf_soling_t_{{loop.index0}}" value="{{f.get('soling_t','')}}"></div>
<div><label>Mesh</label><div class="combo"><input name="sf_mesh_{{loop.index0}}" onfocus="this.select()" value="{{f.get('mesh','')}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="sf_grade_{{loop.index0}}">{%set gr=f.get('grade','M25')%}{%for t in ['M20','M25','M30']%}<option {{'selected' if t==gr}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Soil</label><select name="sf_soil_{{loop.index0}}">{%set so=f.get('soil','soft soil')%}{%for t in ['soft soil','hard soil','rock','mixed']%}<option {{'selected' if t==so}}>{{t}}</option>{%endfor%}</select></div></div>
</div>
{%endfor%}</div>
<button type="button" class="add" onclick="addSF()">+ Add strip footing</button>
<button type="button" class="add" onclick="dupRows('sf')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">A5 · Trench &amp; Plinth Wall <span style="font-size:10px;color:#7a8693">auto from plinth beams + footings</span></div>
<p class="hint">Pick the wall type — everything else auto-fills: length = plinth beam length (net of footing pits), depth = footing depth, thickness = plinth beam width. Wall rises from the trench PCC bed to plinth beam level. Override any box to use your own value.</p>
<div class="row r5">
<div><label>Trench wall type</label><select name="tw_type">{%set tw=s.get('tw_type','none')%}{%for t in ['none','stone masonry','brick masonry']%}<option {{'selected' if t==tw}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Trench length (m) <span style="color:#1f9d55">blank = auto</span></label><input name="tw_length" value="{{s.get('tw_length','') if s.get('tw_length') else ''}}" placeholder="auto = plinth beams"></div>
<div><label>Trench depth (m) <span style="color:#1f9d55">blank = auto</span></label><input name="tw_depth" value="{{s.get('tw_depth','') if s.get('tw_depth') else ''}}" placeholder="auto = footing depth"></div>
<div><label>Wall thickness (mm) <span style="color:#1f9d55">blank = auto</span></label><input name="tw_wall_t" value="{{s.get('tw_wall_t','') if s.get('tw_wall_t') else ''}}" placeholder="auto = plinth beam b"></div>
<div><label>Plinth height above GL (m)</label><input name="tw_plinth_h" value="{{s.get('tw_plinth_h',0.45)}}"></div></div>
<div style="background:#eafaf0;border:1px solid #9fdcb4;border-left:4px solid #1f9d55;border-radius:7px;padding:8px 12px;margin:8px 0 0;font-size:12px;color:#14532d;font-weight:600" id="stubnote2">&#9889; <b>This plinth height is auto-added to every column below plinth</b> &#8212; calculated with your Footing estimate</div>
</div>

<div class="card"><div class="sec">B · Columns <span style="font-size:10px;color:#7a8693">steel varies per floor + ductile ties</span></div>
<div id="columns">{%for c in s.columns%}
<div class="mem"><input type="hidden" name="c_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="c_id_{{loop.index0}}" value="{{c.id}}"></div>
<div><label>Count</label><input name="c_count_{{loop.index0}}" value="{{c.count}}"></div>
<div><label>b (mm)</label><input name="c_b_{{loop.index0}}" value="{{c.b}}"><div class="lh">column width</div></div>
<div><label>d (mm)</label><input name="c_d_{{loop.index0}}" value="{{c.d}}"></div>
<div><label>Tie</label><div class="combo"><input name="c_tie_{{loop.index0}}" onfocus="this.select()" value="{{c.tie}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in TIE_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="c_grade_{{loop.index0}}">{%set cg=c.get('grade','M25')%}{%for x in ['M15','M20','M25','M30','M35','M40']%}<option {{'selected' if x==cg}}>{{x}}</option>{%endfor%}</select></div></div>
{%set ridx = loop.index0%}<div class="mainfloors" data-idx="{{ridx}}"><label>Main bars per floor (GF first) — leave a floor empty to repeat the one before it</label>
<div class="flrow">{%set mparts=(c.main or '').split(',')%}{%for f in range(25)%}<div class="fcell" style="{{'' if f < s.floors_above else 'display:none'}}"><label>{{'GF' if f==0 else 'F' ~ f}}</label><div class="combo"><input name="c_mainf_{{f}}_{{ridx}}" onfocus="this.select()" value="{{mparts[f] if f < mparts|length else ''}}" oninput="syncMain({{ridx}})"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MAIN_O%}<option>{{o}}</option>{%endfor%}</select></div></div>{%endfor%}<div class="fcell"><label>&nbsp;</label><button type="button" class="fbtn" onclick="addFloor()" title="Add one more floor (updates 'Floors above gr.' for the whole building)">+ floor</button><button type="button" class="fbtn minus" onclick="delFloor()" title="Remove top floor">−</button></div></div>
<input type="hidden" name="c_main_{{ridx}}" value="{{c.main}}"></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addC()">+ Add column type</button>
<button type="button" class="add" onclick="dupRows('c')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">C · Beams (Primary + Secondary)</div>
<div id="beams">{%for b in s.beams%}
<div class="mem"><input type="hidden" name="b_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="b_id_{{loop.index0}}" value="{{b.id}}"></div>
<div><label>Type</label><select name="b_kind_{{loop.index0}}" onchange="kindChanged(this,'b')">{%set k=b.kind%}{%for t in BEAM_KINDS%}<option {{'selected' if t==k}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Count</label><input name="b_count_{{loop.index0}}" value="{{b.count}}"></div>
<div><label>b</label><input name="b_b_{{loop.index0}}" value="{{b.b}}"><div class="lh">beam width</div></div>
<div><label>d</label><input name="b_d_{{loop.index0}}" value="{{b.d}}"></div>
<div><label>Length</label><input name="b_length_{{loop.index0}}" value="{{b.length}}"></div></div>
<div class="row r5">
<div><label>Top</label><div class="combo"><input name="b_top_{{loop.index0}}" onfocus="this.select()" value="{{b.top}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MAIN_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Bottom</label><div class="combo"><input name="b_bottom_{{loop.index0}}" onfocus="this.select()" value="{{b.bottom}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MAIN_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Extra top @supports</label><div class="combo"><input name="b_extra_top_{{loop.index0}}" onfocus="this.select()" value="{{b.get('extra_top','')}}" placeholder="e.g. 1-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MAIN_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Side bars (deep>750mm)</label><div class="combo"><input name="b_side_{{loop.index0}}" onfocus="this.select()" value="{{b.get('side','')}}" placeholder="e.g. 2-12"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MAIN_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Stirrup</label><div class="combo"><input name="b_tie_{{loop.index0}}" onfocus="this.select()" value="{{b.tie}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in STIRRUP_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="b_grade_{{loop.index0}}">{%set bg=b.get('grade','M25')%}{%for x in ['M15','M20','M25','M30','M35','M40']%}<option {{'selected' if x==bg}}>{{x}}</option>{%endfor%}</select></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addB()">+ Add beam type</button>
<button type="button" class="add" onclick="dupRows('b')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">D · Slab Systems, Balconies &amp; Cantilevers</div>
<p class="hint"><b>Quantity/BBS workflow:</b> select the system and enter engineer-approved reinforcement. The app calculates quantities and cutting lengths; it does not replace structural design approval.</p>
<div id="slabs">{%for x in s.slabs%}
<div class="mem"><input type="hidden" name="s_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="s_id_{{loop.index0}}" value="{{x.id}}"></div>
<div><label>Type</label><select name="s_type_{{loop.index0}}" onchange="syncSlab(this)">{%set st=x.get('type','two-way slab')%}{%for t in ['one-way slab','two-way slab','sunken slab (toilet)','flat slab','waffle (ribbed)','cantilever / balcony / chajja']%}<option {{'selected' if t==st}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Panel L (mm)</label><input name="s_L_s_{{loop.index0}}" value="{{x.get('L_s','')}}" placeholder="recommended"></div>
<div><label>Panel W (mm)</label><input name="s_W_s_{{loop.index0}}" value="{{x.get('W_s','')}}" placeholder="recommended"></div>
<div><label>Repeat panels</label><input name="s_count_{{loop.index0}}" value="{{x.get('count',1)}}"></div>
<div><label>t (mm)</label><input name="s_t_{{loop.index0}}" value="{{x.t}}"><div class="lh">slab thickness</div></div>
<div><label>Grade</label><select name="s_grade_{{loop.index0}}">{%for g in ['M20','M25','M30','M35','M40']%}<option {{'selected' if x.get('grade','M25')==g}}>{{g}}</option>{%endfor%}</select></div></div>
<div class="row r6 slab-common"><div><label>Span / main direction</label><select name="s_span_direction_{{loop.index0}}"><option {{'selected' if x.get('span_direction')=='X'}}>X</option><option {{'selected' if x.get('span_direction')=='Y'}}>Y</option><option {{'selected' if x.get('span_direction','')=='both'}}>both</option></select></div><div><label>Support condition</label><select name="s_support_condition_{{loop.index0}}"><option {{'selected' if x.get('support_condition')=='beam supported'}}>beam supported</option><option {{'selected' if x.get('support_condition')=='continuous'}}>continuous</option><option {{'selected' if x.get('support_condition')=='cantilever'}}>cantilever</option><option {{'selected' if x.get('support_condition')=='flat slab columns'}}>flat slab columns</option></select></div><div><label>Bottom X</label><input name="s_bottom_x_{{loop.index0}}" value="{{x.get('bottom_x',x.get('mesh','10-150'))}}"></div><div><label>Bottom Y</label><input name="s_bottom_y_{{loop.index0}}" value="{{x.get('bottom_y',x.get('mesh','10-150'))}}"></div><div><label>Top X (full)</label><input name="s_top_x_{{loop.index0}}" value="{{x.get('top_x',x.get('top_mesh',''))}}"></div><div><label>Top Y (full)</label><input name="s_top_y_{{loop.index0}}" value="{{x.get('top_y',x.get('top_mesh',''))}}"></div></div>
<div class="row r4 slab-common"><div><label>Support zone (mm)</label><input name="s_support_zone_{{loop.index0}}" value="{{x.get('support_zone','')}}"></div><div><label>Extra edge bar</label><input name="s_edge_bar_{{loop.index0}}" value="{{x.get('edge_bar','')}}" placeholder="e.g. 2-12"></div></div>
<div class="row r5 slab-common"><div><label>Top support X</label><input name="s_support_top_x_{{loop.index0}}" value="{{x.get('support_top_x','')}}"></div><div><label>Top support Y</label><input name="s_support_top_y_{{loop.index0}}" value="{{x.get('support_top_y','')}}"></div><div><label>Opening L (mm)</label><input name="s_open_L_{{loop.index0}}" value="{{x.get('open_L','')}}"></div><div><label>Opening W (mm)</label><input name="s_open_W_{{loop.index0}}" value="{{x.get('open_W','')}}"></div><div><label>Opening count</label><input name="s_open_count_{{loop.index0}}" value="{{x.get('open_count',0)}}"></div></div>
<div class="row r5"><div><label>Irregular area (m²)</label><input name="s_area_{{loop.index0}}" value="{{x.get('area','')}}" placeholder="only if L/W unavailable"></div><div class="lh">Plan L/W governs when supplied. Openings are deducted from concrete, shuttering and panel reinforcement.</div></div>
<div class="row r5 slab-sunken" style="display:none"><div><label>Sunken drop (mm)</label><input name="s_sunken_drop_{{loop.index0}}" value="{{x.get('sunken_drop','')}}"></div><div><span class="lh">Add waterproofing in the Misc card when required.</span></div></div>
<div class="row r5 slab-flat" style="display:none"><div><label>Drop L (mm)</label><input name="s_drop_L_{{loop.index0}}" value="{{x.get('drop_L','')}}"></div><div><label>Drop W (mm)</label><input name="s_drop_W_{{loop.index0}}" value="{{x.get('drop_W','')}}"></div><div><label>Drop t (mm)</label><input name="s_drop_t_{{loop.index0}}" value="{{x.get('drop_t','')}}"></div><div><span class="lh">Punching shear is an engineer confirmation item.</span></div></div>
<div class="row r6 slab-waffle" style="display:none"><div><label>Rib direction</label><select name="s_rib_dir_{{loop.index0}}"><option {{'selected' if x.get('rib_dir')=='both ways'}}>both ways</option><option {{'selected' if x.get('rib_dir')=='one way'}}>one way</option></select></div><div><label>Rib spacing (mm)</label><input name="s_rib_spacing_{{loop.index0}}" value="{{x.get('rib_spacing','')}}"></div><div><label>Rib width (mm)</label><input name="s_rib_w_{{loop.index0}}" value="{{x.get('rib_w','')}}"></div><div><label>Rib depth (mm)</label><input name="s_rib_d_{{loop.index0}}" value="{{x.get('rib_d','')}}"></div><div><label>Topping t (mm)</label><input name="s_topping_t_{{loop.index0}}" value="{{x.get('topping_t','')}}"></div><div><label>Rib main bars</label><input name="s_rib_main_{{loop.index0}}" value="{{x.get('rib_main','')}}"></div></div>
<div class="row r4 slab-waffle" style="display:none"><div><label>Rib top bars</label><input name="s_rib_top_{{loop.index0}}" value="{{x.get('rib_top','')}}"></div><div><label>Rib stirrup</label><input name="s_rib_stirrup_{{loop.index0}}" value="{{x.get('rib_stirrup','')}}"></div><div><label>Solid edge band (mm)</label><input name="s_solid_band_{{loop.index0}}" value="{{x.get('solid_band','')}}"></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addS()">+ Add slab</button>
<button type="button" class="add" onclick="dupRows('s')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">E · Shear Walls</div>
<div id="walls" style="margin-top:8px">{%for w in s.shearwalls%}
<div class="mem"><input type="hidden" name="w_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="w_id_{{loop.index0}}" value="{{w.id}}"></div>
<div><label>Length</label><input name="w_length_{{loop.index0}}" value="{{w.length}}"></div>
<div><label>t</label><input name="w_t_{{loop.index0}}" value="{{w.t}}"></div>
<div><label>Height</label><input name="w_height_{{loop.index0}}" value="{{w.height}}"></div>
<div><label>Vert</label><div class="combo"><input name="w_vertical_{{loop.index0}}" onfocus="this.select()" value="{{w.vertical}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div></div>
<div class="row r2"><div><label>Horiz</label><div class="combo"><input name="w_horizontal_{{loop.index0}}" onfocus="this.select()" value="{{w.horizontal}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div><div></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addW()">+ Add shear wall</button>
<button type="button" class="add" onclick="dupRows('w')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card" style="border-left:4px solid #1f9d55"><div class="sec">F · Retaining / Trench Walls</div>
<p class="hint">Full auto-compute per wall: excavation, <b>100mm PCC bed</b> under base, stem + base RCC, shuttering both faces, steel (vertical + horizontal + base mesh) and backfill. Enter stem/base geometry + steel spacing.</p>
<div id="retwalls" style="margin-top:8px">{%for r in s.retwalls%}
<div class="mem"><input type="hidden" name="rw_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="rw_id_{{loop.index0}}" value="{{r.id}}"></div>
<div><label>Length</label><input name="rw_length_{{loop.index0}}" value="{{r.length}}"></div>
<div><label>Stem t</label><input name="rw_stem_t_{{loop.index0}}" value="{{r.stem_t}}"></div>
<div><label>Stem h</label><input name="rw_stem_h_{{loop.index0}}" value="{{r.stem_h}}"></div>
<div><label>Base b</label><input name="rw_base_b_{{loop.index0}}" value="{{r.base_b}}"></div></div>
<div class="row r5">
<div><label>Base t</label><input name="rw_base_t_{{loop.index0}}" value="{{r.base_t}}"></div>
<div><label>Vert</label><div class="combo"><input name="rw_vert_{{loop.index0}}" onfocus="this.select()" value="{{r.vert}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Horiz</label><div class="combo"><input name="rw_horiz_{{loop.index0}}" onfocus="this.select()" value="{{r.horiz}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Base mesh</label><div class="combo"><input name="rw_base_mesh_{{loop.index0}}" onfocus="this.select()" value="{{r.base_mesh}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div><div></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addRW()">+ Add retaining/trench wall</button>
<button type="button" class="add" onclick="dupRows('rw')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">G · Staircases (multiple OK — steps + landings auto-computed)</div>
<p class="hint">Add one row per staircase. A building can have a main stair + emergency exit + service spiral — each with its own dimensions.</p>
<div id="staircases">{% for sc in s.staircase %}
<div class="mem"><input type="hidden" name="sc_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="sc_id_{{loop.index0}}" value="{{sc.get('id','ST' ~ loop.index)}}"></div>
<div><label>Type</label><select name="sc_type_{{loop.index0}}">{%set tt=sc.get('type','dog-legged')%}{%for t in ['dog-legged','open-well','straight flight','spiral','cantilever']%}<option {{'selected' if t==tt}}>{{t}}</option>{%endfor%}</select></div>
<div><label>Flights</label><input name="sc_flights_{{loop.index0}}" value="{{sc.flights}}"></div>
<div><label>Run (mm)</label><input name="sc_run_{{loop.index0}}" value="{{sc.run}}"></div>
<div><label>Tread (mm)</label><input name="sc_tread_{{loop.index0}}" value="{{sc.get('tread',300)}}"></div>
<div><label>Riser (mm)</label><input name="sc_riser_{{loop.index0}}" value="{{sc.get('riser',150)}}"></div></div>
<div class="row r6" style="margin-top:8px">
<div><label>Width (mm)</label><input name="sc_width_{{loop.index0}}" value="{{sc.width}}"></div>
<div><label>Waist (mm)</label><input name="sc_waist_{{loop.index0}}" value="{{sc.waist}}"><div class="lh">waist slab thickness</div></div>
<div><label>Mesh</label><div class="combo"><input name="sc_mesh_{{loop.index0}}" onfocus="this.select()" value="{{sc.mesh}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Landings (nos)</label><input name="sc_landings_{{loop.index0}}" value="{{sc.get('landings',0)}}"></div>
<div><label>Landing L (mm)</label><input name="sc_landing_L_{{loop.index0}}" value="{{sc.get('landing_L',1200)}}"></div>
<div><label>Landing W (mm)</label><input name="sc_landing_W_{{loop.index0}}" value="{{sc.get('landing_W',1200)}}"></div></div></div>
{% endfor %}</div>
<button type="button" class="add" onclick="addSC()">+ Add staircase</button>
<button type="button" class="add" onclick="dupRows('sc')" style="background:#8e44ad">⧉ Duplicate rows</button>
<p class="hint" style="margin-top:8px">Steps (½×tread×riser×width) and landing slabs auto-add to concrete/steel. Unit &amp; labour rates editable in the ⚙ gold card at top.</p></div>

<div class="card" style="border-left:4px solid #2980b9"><div class="sec">H · Water Tanks &amp; Sumps (IS 3370 water-retaining)</div>
<p class="hint">Overhead tanks &amp; underground sumps: walls + base + cover slab, mesh both faces, full BBS. Sumps auto-add excavation + PCC + backfill.</p>
<div id="tanks">{%for t in s.tanks%}
<div class="mem"><input type="hidden" name="t_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="t_id_{{loop.index0}}" value="{{t.id}}"></div>
<div><label>Type</label><select name="t_kind_{{loop.index0}}" onchange="kindChanged(this,'t')">{%set tk=t.kind%}{%for k in ['overhead tank','underground sump']%}<option {{'selected' if k==tk}}>{{k}}</option>{%endfor%}</select></div>
<div><label>L int (mm)</label><input name="t_L_{{loop.index0}}" value="{{t.L}}"></div>
<div><label>W int (mm)</label><input name="t_W_{{loop.index0}}" value="{{t.W}}"></div>
<div><label>Depth (mm)</label><input name="t_depth_{{loop.index0}}" value="{{t.depth}}"></div></div>
<div class="row r6" style="margin-top:8px">
<div><label>Wall t</label><input name="t_wall_t_{{loop.index0}}" value="{{t.wall_t}}"></div>
<div><label>Base t</label><input name="t_base_t_{{loop.index0}}" value="{{t.base_t}}"></div>
<div><label>Cover t</label><input name="t_cover_t_{{loop.index0}}" value="{{t.cover_t}}"></div>
<div><label>Wall mesh</label><div class="combo"><input name="t_wall_mesh_{{loop.index0}}" onfocus="this.select()" value="{{t.wall_mesh}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Base mesh</label><div class="combo"><input name="t_base_mesh_{{loop.index0}}" onfocus="this.select()" value="{{t.base_mesh}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="t_grade_{{loop.index0}}">{%set tg=t.get('grade','M25')%}{%for x in ['M20','M25','M30','M35','M15','M40']%}<option {{'selected' if x==tg}}>{{x}}</option>{%endfor%}</select></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addT()">+ Add tank / sump</button>
<button type="button" class="add" onclick="dupRows('t')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">I · Ramps</div>
<p class="hint">Inclined slab + optional side walls — steps-free access &amp; parking ramps.</p>
<div id="ramps">{%for r in s.ramps%}
<div class="mem"><input type="hidden" name="r_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r6">
<div><label>ID</label><input name="r_id_{{loop.index0}}" value="{{r.id}}"></div>
<div><label>Length incl. (mm)</label><input name="r_length_{{loop.index0}}" value="{{r.length}}"></div>
<div><label>Width (mm)</label><input name="r_width_{{loop.index0}}" value="{{r.width}}"></div>
<div><label>Thickness (mm)</label><input name="r_thickness_{{loop.index0}}" value="{{r.thickness}}"></div>
<div><label>Mesh</label><div class="combo"><input name="r_mesh_{{loop.index0}}" onfocus="this.select()" value="{{r.mesh}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="r_grade_{{loop.index0}}">{%set rg=r.get('grade','M25')%}{%for x in ['M20','M25','M30']%}<option {{'selected' if x==rg}}>{{x}}</option>{%endfor%}</select></div></div>
<div class="row r2" style="margin-top:8px">
<div><label>Side wall h (mm, 0=none)</label><input name="r_side_wall_h_{{loop.index0}}" value="{{r.get('side_wall_h',0)}}"></div>
<div><label>Side wall t (mm)</label><input name="r_side_wall_t_{{loop.index0}}" value="{{r.get('side_wall_t',150)}}"></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addR()">+ Add ramp</button>
<button type="button" class="add" onclick="dupRows('r')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">J · Lift Pits &amp; Machine Rooms</div>
<p class="hint">Lift core: water-tight pit + shaft walls + machine-room slab. Excavation, PCC &amp; backfill auto.</p>
<div id="lifts">{%for l in s.lifts%}
<div class="mem"><input type="hidden" name="l_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r5">
<div><label>ID</label><input name="l_id_{{loop.index0}}" value="{{l.id}}"></div>
<div><label>Plan L (mm)</label><input name="l_L_{{loop.index0}}" value="{{l.L}}"></div>
<div><label>Plan W (mm)</label><input name="l_W_{{loop.index0}}" value="{{l.W}}"></div>
<div><label>Pit depth (mm)</label><input name="l_pit_depth_{{loop.index0}}" value="{{l.pit_depth}}"></div>
<div><label>Core height (mm)</label><input name="l_core_height_{{loop.index0}}" value="{{l.core_height}}"></div></div>
<div class="row r4" style="margin-top:8px">
<div><label>Wall t</label><input name="l_wall_t_{{loop.index0}}" value="{{l.wall_t}}"></div>
<div><label>Base t</label><input name="l_base_t_{{loop.index0}}" value="{{l.base_t}}"></div>
<div><label>Mesh</label><div class="combo"><input name="l_mesh_{{loop.index0}}" onfocus="this.select()" value="{{l.mesh}}"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>{%for o in MESH_O%}<option>{{o}}</option>{%endfor%}</select></div></div>
<div><label>Grade</label><select name="l_grade_{{loop.index0}}">{%set lg=l.get('grade','M30')%}{%for x in ['M25','M30','M35','M40']%}<option {{'selected' if x==lg}}>{{x}}</option>{%endfor%}</select></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addL()">+ Add lift core</button>
<button type="button" class="add" onclick="dupRows('l')" style="background:#8e44ad">⧉ Duplicate rows</button></div>

<div class="card"><div class="sec">K · Water Retaining &amp; Misc Items</div>
<p class="hint">Waterproofing, joints, water stops, dewatering, curing. Weep holes auto-added for retaining walls.</p>
<div id="others">{%for o in s.others%}
<div class="mem"><input type="hidden" name="o_row" value="{{loop.index0}}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>
<div class="row r2">
<div><label>Item</label><select name="o_item_{{loop.index0}}">{%set oi=o.item%}{%for k in ['cement-based waterproofing (sunken slab/toilet)','bitumen coat 2 coats (retaining wall backface)','expansion joint filler + sealant','PVC water stop 230mm (construction joints)','dewatering from foundations','curing compound (or ponding)']%}<option {{'selected' if k==oi}}>{{k}}</option>{%endfor%}</select></div>
<div><label>Qty (sqm/rmt/cum)</label><input name="o_qty_{{loop.index0}}" value="{{o.qty}}"></div></div></div>
{%endfor%}</div>
<button type="button" class="add" onclick="addO()">+ Add misc item</button>
<button type="button" class="add" onclick="dupRows('o')" style="background:#8e44ad">⧉ Duplicate rows</button></div>
<div style="display:flex;gap:8px;margin-top:10px">
<button class="btn" name="action" value="calc" style="flex:2;width:auto">⚙ Calculate</button>
<button class="btn" name="action" value="save" style="flex:1;width:auto;background:#2E86ab">💾 Save</button>
</div>
</form></div>

<div>
{%if result%}
<div class="card"><div class="kpi">
<div><div class="v">{{"{:,.0f}".format(result.grand_total)}}</div><div class="l">Total {{ current_country().currency }}</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.concrete_m3)}}</div><div class="l">Concrete m³</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.steel_kg)}}</div><div class="l">Steel kg</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.steel_kg/(result.totals.concrete_m3 or 1))}}</div><div class="l">kg/m³</div></div></div>
<div class="kpi" style="margin-top:8px">
<div><div class="v">{{"{:,.1f}".format(result.materials.cement_bags)}}</div><div class="l">Cement bags</div></div>
<div><div class="v">{{"{:,.1f}".format(result.materials.sand_m3)}}</div><div class="l">Sand m³</div></div>
<div><div class="v">{{"{:,.1f}".format(result.materials.aggregate_m3)}}</div><div class="l">Agg m³</div></div>
<div><div class="v">{{"{:,.0f}".format(result.totals.excavation_m3)}}</div><div class="l">Excav m³</div></div></div>
<div style="text-align:right;margin-top:8px"><a class="pill" href="{{url_for('structural_export')}}" target="_blank" rel="noopener">⬇ Download Excel</a>
<a class="pill" href="{{url_for('structural_export_pdf')}}" target="_blank" rel="noopener" style="background:#c0392b">⬇ Download PDF</a>
{%if result.saved_ok%}<div style="font-size:12px;color:#1f9d55;margin-top:7px">💾 Saved as "{{result.saved_ok}}" — <a href="{{url_for('dashboard')}}">Dashboard</a></div>{%endif%}
{%if result.save_error%}<div style="font-size:12px;color:#c0392b;margin-top:7px">{{result.save_error}} — <a href="{{url_for('dashboard')}}">Upgrade</a></div>{%endif%}
{%if result.saved_file%}<div style="font-size:11px;color:#b8860b;margin-top:7px">📥 Excel also saved: {{result.saved_file}}</div>{%endif%}
</div></div>

<div class="card"><h2>Steel Procurement by Diameter</h2>
<table><tr><th>Dia</th><th class="num">Weight (kg)</th><th>Share</th><th class="num">12m bars</th></tr>
{%set tots=(result.steel_by_dia.values()|sum) or 1%}
{%for d,v in result.steel_by_dia.items()%}<tr><td class="ctr">∅{{d}} mm</td><td class="num">{{"{:,.0f}".format(v)}}</td>
<td><div class="bar" style="width:{{(v/tots*100)|round}}%"></div> {{(v/tots*100)|round}}%</td>
<td class="num">{{result.steel_bars12.get(d, 0)}} nos</td></tr>{%endfor%}
<tr style="background:#eef4f9;font-weight:700"><td>Total</td><td class="num">{{"{:,.0f}".format(tots)}}</td><td></td><td class="num">12m bars</td></tr></table>
<p class="hint" style="margin-top:6px">Last column = 12m stock lengths to order per diameter (incl. laps).</p></div>


{%if result.bbs_table%}
<div class="card"><h2>📋 Bar Bending Schedule (BBS)</h2>
<p class="hint">{{result.bbs_table|length}} bar groups — hand this to your steel fabricator</p>
<table><tr><th>Mark</th><th>Member</th><th>Dia</th><th class="ctr">No.</th><th class="num">Cut Len (m)</th><th class="num">Total (m)</th><th class="num">kg/m</th><th class="num">Wt (kg)</th></tr>
{%for b in result.bbs_table%}<tr><td>{{b.mark}}</td><td>{{b.member}}</td><td class="ctr">∅{{b.dia}}</td><td class="ctr">{{b.count}}</td><td class="num">{{b.cut_len}}</td><td class="num">{{b.total_len}}</td><td class="num">{{b.unit_wt}}</td><td class="num">{{b.weight}}</td></tr>{%endfor%}
<tr style="background:#eef4f9;font-weight:700"><td colspan="7" style="text-align:right">Sub-total</td><td class="num">{{"{:,.0f}".format(result.bbs_table|sum(attribute='weight'))}}</td></tr></table></div>
{%endif%}

{%if result.rate_analysis%}
<div class="card"><h2>💰 Rate Analysis (per m³ RCC)</h2>
<table><tr><th>Component</th><th class="num">Qty/m³</th><th class="num">Rate</th><th class="num">{{ current_country().currency }}/m³</th></tr>
<tr><td>Cement</td><td class="num">{{"{:.0f}".format(result.materials.cement_bags/(result.totals.concrete_m3*1.05 or 1))}} bags</td><td class="num">950</td><td class="num">{{"{:,.0f}".format(result.materials.cement_bags/(result.totals.concrete_m3*1.05 or 1)*950)}}</td></tr>
<tr><td>Steel (incl 3% wastage)</td><td class="num">{{result.rate_analysis.steel_kg_per_m3|int}} kg</td><td class="num">{{result.rate_analysis.steel_rate}}</td><td class="num">{{"{:,.0f}".format(result.rate_analysis.steel_kg_per_m3*result.rate_analysis.steel_rate)}}</td></tr>
<tr><td>Shuttering</td><td class="num">{{"{:.1f}".format(result.totals.shuttering_m2/(result.totals.concrete_m3 or 1))}} m²</td><td class="num">{{result.rate_analysis.shutter_rate}}</td><td class="num">{{"{:,.0f}".format(result.totals.shuttering_m2/(result.totals.concrete_m3 or 1)*result.rate_analysis.shutter_rate)}}</td></tr>
<tr style="background:#fff3cf;font-weight:800"><td>Cost per m³ RCC</td><td colspan="2"></td><td class="num">{{ current_country().currency }} {{"{:,.0f}".format(result.rate_analysis.cost_per_m3_rcc)}}</td></tr></table></div>
{%endif%}

{%if result.labour%}
<div class="card"><h2>👷 Labour Estimate</h2>
<table><tr><th>Worker</th><th class="num">Days</th><th class="num">Rate/day</th><th class="num">Cost {{ current_country().currency }}</th></tr>
{%set lr=result.labour_rates or {}%}
<tr><td>Mason</td><td class="num">{{result.labour.mason_days|int}}</td><td class="num">{{"{:,.0f}".format(lr.get('mason',1200))}}</td><td class="num">{{"{:,.0f}".format(result.labour.mason_cost)}}</td></tr>
<tr><td>Mazdoor (labourer)</td><td class="num">{{result.labour.mazdoor_days|int}}</td><td class="num">{{"{:,.0f}".format(lr.get('mazdoor',800))}}</td><td class="num">{{"{:,.0f}".format(result.labour.mazdoor_cost)}}</td></tr>
<tr style="background:#eef4f9;font-weight:700"><td>Total</td><td class="num">{{(result.labour.mason_days+result.labour.mazdoor_days)|int}}</td><td></td><td class="num">{{"{:,.0f}".format(result.labour.mason_cost+result.labour.mazdoor_cost)}}</td></tr></table>
<p class="hint" style="margin-top:8px">Steel fabrication: ~{{result.labour.steel_fab_days|int}} person-days (cutting + bending + placing)</p></div>
{%endif%}

<div class="card"><h2>Bill of Quantities (by work type)</h2>
{%for gname,info in result.groups.items()%}
<div class="sec" style="margin-top:10px">{{gname}} <span style="font-size:10px;color:#7a8693">{{ current_country().currency }} {{"{:,.0f}".format(info.subtotal)}}</span></div>
<table><tr><th>Code</th><th>Item</th><th class="ctr">Unit</th><th class="num">Qty</th><th class="num">Rate</th><th class="num">Amount</th></tr>
{%for it in info['items']%}<tr><td>{{it.code}}</td><td>{{it.desc}}</td><td class="ctr">{{it.unit}}</td>
<td class="num">{{"{:,.2f}".format(it.qty)}}</td><td class="num">{{"{:,.0f}".format(it.rate)}}</td><td class="num">{{"{:,.0f}".format(it.amount)}}</td></tr>{%endfor%}</table>
{%endfor%}<div class="tot">GRAND TOTAL: {{ current_country().currency }} {{"{:,.0f}".format(result.grand_total)}}</div></div>

<div class="card"><h2>Member-wise Summary</h2>
{%for cat,ms in result.member_summary.items()%}
<div class="sec" style="margin-top:8px">{{cat}}</div>
<table><tr><th>ID</th><th>Type</th><th class="ctr">No</th><th class="num">Conc m³</th><th class="num">Steel kg</th><th class="num">Shutter m²</th><th>Steel detail</th></tr>
{%for m in ms%}<tr><td>{{m.id}}</td><td>{{m.kind}}</td><td class="ctr">{{m.count}}</td>
<td class="num">{{"{:,.2f}".format(m.conc)}}</td><td class="num">{{"{:,.0f}".format(m.steel)}}</td><td class="num">{{"{:,.1f}".format(m.shutter)}}</td>
<td class="det">{{m.detail}}</td></tr>{%endfor%}</table>
{%endfor%}</div>
{%else%}
<div class="card"><h2>📋 Get started</h2>
<p class="hint">A full member schedule is loaded (footings, columns with per-floor steel, beams, slabs, shear wall, retaining wall). Click <b>Calculate</b> for a professional work-type BOQ with BBS steel.</p>
<ul style="line-height:1.8;font-size:13px">
<li><b>Columns</b>: steel per floor (20-16,16-16,12-16); ductile ties (8-100-200)</li>
<li><b>Beams</b>: plinth / tie / primary / secondary with confined stirrups</li>
<li><b>Footings</b>: isolated/strap/combined/pile with excavation + soling + PCC</li>
<li>Output: <b>Earthwork · PCC · RCC Concrete · Steel · Shuttering</b> + steel by diameter</li>
</ul></div>
{%endif%}
</div></div></div>
<script>
const BK=[{%for k in BEAM_KINDS%}'{{k}}'{%if not loop.last%},{%endif%}{%endfor%}];
const C={f:{{s.footings|length if s.footings else 0}},rf:{{s.footings|selectattr('kind','equalto','raft')|list|length}},pf:{{s.footings|selectattr('kind','equalto','pile')|list|length}},sf:{{s.footings|selectattr('kind','equalto','strip')|list|length}},c:{{s.columns|length}},b:{{s.beams|length}},s:{{s.slabs|length}},w:{{s.shearwalls|length}},rw:{{s.retwalls|length}},t:{{s.tanks|length}},r:{{s.ramps|length}},l:{{s.lifts|length}},o:{{s.others|length}},sc:{{s.staircase|length}}};
const CARD={f:'footings',rf:'rafts',pf:'piles',sf:'strips',c:'columns',b:'beams',s:'slabs',w:'walls',rw:'retwalls',t:'tanks',r:'ramps',l:'lifts',o:'others',sc:'staircases'};
const DEF_PREFIX={f:'F',rf:'RAFT',pf:'PF',sf:'SF',c:'C',b:'B',s:'S',w:'SW',rw:'RW',t:'WT',r:'RMP',l:'LIFT',sc:'ST'};
function maxStem(k,stem){const cont=document.getElementById(CARD[k]);if(!cont)return 0;let mx=0;const su=stem.toUpperCase();cont.querySelectorAll('input[name^="'+k+'_id_"]').forEach(x=>{const v=(x.value||'').trim();if(v.toUpperCase().indexOf(su)===0){const rest=v.slice(stem.length);if(/^\d+$/.test(rest)){const n=parseInt(rest,10);if(n>mx)mx=n;}}});return mx;}
function nextAddId(k){const p=DEF_PREFIX[k]||'X';return p+(maxStem(k,p)+1);}
function renumberClone(k,cl){const inp=cl.querySelector('input[name^="'+k+'_id_"]');if(!inp)return;const v=(inp.value||'').trim();if(!v){inp.value=nextAddId(k);inp.dataset.auto='1';return;}const m=v.match(/^(.*?)(\d+)$/);if(m){inp.value=m[1]+(Math.max(maxStem(k,m[1]),parseInt(m[2],10))+1);}else{inp.value=v+(Math.max(maxStem(k,v),1)+1);}}
const KIND_PREFIX={f:{'isolated':'F','combined':'CF','strap':'SP'},b:{'plinth beam':'PB','plinth':'PB','tie beam':'TB','primary':'B','secondary':'SB','grade beam':'GB','lintel band':'LB','lintel':'LB'},t:{'overhead tank':'WT','underground sump':'SUMP'}};
function kindChanged(sel,k){const row=sel.closest('.mem');if(!row)return;const idIn=row.querySelector('input[name^="'+k+'_id_"]');if(!idIn||!idIn.dataset.auto)return;const km=KIND_PREFIX[k];if(!km)return;const p=km[sel.value];if(!p)return;idIn.value=p+(maxStem(k,p)+1);}
document.addEventListener('input',e=>{const n=e.target&&e.target.name;if(n&&/_id_\d+$/.test(n)){e.target.dataset.auto='';}});
function updStub(){
  const note=document.getElementById('stubnote');if(!note)return;
  const cb=document.querySelector('input[name="col_below_gl"]');
  const tv=(cb&&parseFloat(cb.value))||0;
  note.innerHTML='&#9889; <b>Column below plinth:</b> '+(tv>0?'your typed value is used'
    :'auto-calculated WITH YOUR FOOTING ESTIMATE (footings + plinth height)');
}
document.addEventListener('input',e=>{const n=e.target&&e.target.name;if(n&&(/^(f|rf|sf|pf)_(depth|t|ped_h)_\d+$/.test(n)||n==='tw_plinth_h'||n==='col_below_gl')){updStub();}});
function cbsel(s){ if(s.value){ s.previousElementSibling.value=s.value; } s.selectedIndex=0; }
const JO={main:['2-10','3-10','2-12','3-12','4-12','6-12','8-12','2-16','3-16','4-16','6-16','8-16','10-16','12-16','16-16','20-16','4-20','6-20','8-20','4-25','6-25'],
tie:['6-150','8-100','8-100-150','8-100-200','8-125-150','8-150','8-200','10-100-150','10-100-200'],
mesh:['8-200','10-200','10-150','12-200','12-150','12-100','16-150','16-100','16-200'],
ped:['4-12','6-12','8-12','4-16','6-16','8-16','4-20','6-20','8-20'],
stirrup:['6-150','8-100','8-100-150','8-100-200','8-125-150','8-150','10-100-150']};
const OPT=(a)=>a.map(x=>`<option>${x}</option>`).join('');
const DIM_FACTOR={'mm':1,'cm':10,'m':1000,'ft':304.8,'in':25.4};
const DIM_F=['L','W','t','depth','soling_t','ped_b','ped_d','ped_h','strap_len','strap_b','strap_d','pile_dia','pile_len','cap_L','cap_W','cap_t','b','d','length','stem_t','stem_h','base_b','wall_t','cover_t','thickness','side_wall_h','side_wall_t','core_height','pit_depth','run','tread','riser','width','waist','landing_L','landing_W','landing_t'];
let _pu='mm';
function convDims(nu){const fn=DIM_FACTOR[nu]||1,fo=DIM_FACTOR[_pu]||1;if(fn===fo)return;
document.querySelectorAll('input[name]').forEach(inp=>{const nm=inp.name;const p=nm.split('_');
const f=p[p.length-2];if(p[p.length-1]==='NEWIDX')return;
if(nm==='floor_height'||nm==='confinement_lo'||nm.startsWith('cover_')||DIM_F.includes(f)){
const v=parseFloat(inp.value);if(!isNaN(v)&&v!==0){inp.value=+(v*fo/fn).toFixed(3);}}});
_pu=nu;document.querySelectorAll('.dimnote').forEach(e=>e.textContent=nu);}

function syncMain(i){const w=document.querySelector('.mainfloors[data-idx="'+i+'"]');if(!w)return;
const vals=[...w.querySelectorAll('input[name^="c_mainf_"]')].map(v=>v.value.trim()).filter(Boolean);
w.querySelector('input[name="c_main_'+i+'"]').value=vals.join(',');}
function resizeFloors(){const n=Math.min(25,Math.max(1,parseInt(document.querySelector('input[name="floors_above"]')?.value)||1));
const floorInput=document.querySelector('input[name="floors_above"]');if(floorInput)floorInput.value=n;
document.querySelectorAll('.mainfloors').forEach(w=>{w.querySelectorAll('.fcell').forEach((c,f)=>{c.style.display=f<n?'':'none';});});}
document.querySelectorAll('input[name="floors_above"]').forEach(el=>el.addEventListener('input',resizeFloors));
function addFloor(){const el=document.querySelector('input[name="floors_above"]');el.value=Math.min(25,(parseInt(el.value)||1)+1);resizeFloors();}
function delFloor(){const el=document.querySelector('input[name="floors_above"]');el.value=Math.max(1,(parseInt(el.value)||1)-1);resizeFloors();}
resizeFloors();

function dupRow(btn,k){
  const cont=document.getElementById({f:'footings',rf:'rafts',pf:'piles',sf:'strips',c:'columns',b:'beams',s:'slabs',w:'walls',rw:'retwalls',t:'tanks',r:'ramps',l:'lifts',o:'others',sc:'staircases'}[k]);
  if(!cont)return;
  const row=btn.closest('.mem');
  const ni=C[k]++;
  const cl=row.cloneNode(true);
  cl.querySelectorAll('input,select').forEach(el=>{
    if(el.name){el.name=el.name.replace(/_(\d+)$/,'_'+ni);}
  });
  const hid=cl.querySelector('input[type="hidden"]');
  if(hid){hid.value=ni;}
  row.after(cl);
  renumberClone(k,cl);
}
function dupRows(k){const cont=document.getElementById({f:'footings',rf:'rafts',pf:'piles',sf:'strips',c:'columns',b:'beams',s:'slabs',w:'walls',rw:'retwalls',t:'tanks',r:'ramps',l:'lifts',o:'others',sc:'staircases'}[k]);
if(!cont||!cont.children.length)return;[...cont.querySelectorAll('.mem')].forEach(rw=>{const ni=C[k]++;
const cl=rw.cloneNode(true);cl.querySelectorAll('input,select').forEach(el=>{if(el.name){el.name=el.name.replace(/_(\d+)$/,'_'+ni);}});
const hid=cl.querySelector('input[type="hidden"]');if(hid){hid.value=ni;}cont.appendChild(cl);renumberClone(k,cl);});}
function box(k,i,html){const d=document.createElement('div');d.className='mem';d.innerHTML=`<input type="hidden" name="${k}_row" value="${i}"><button type="button" class="dup1" onclick="dupRow(this,this.parentElement.querySelector('input[type=hidden]').name.split('_row')[0])" title="Duplicate this row">⧉</button><button type="button" class="del" onclick="this.parentElement.remove()">✕</button>${html(i)}`;
document.getElementById(CARD[k]).appendChild(d);const idIn=d.querySelector('input[name^="'+k+'_id_"]');if(idIn&&!idIn.value.trim()){let p=DEF_PREFIX[k]||'X';const ks=d.querySelector('select[name^="'+k+'_kind_"]');if(ks&&KIND_PREFIX[k]&&KIND_PREFIX[k][ks.value]){p=KIND_PREFIX[k][ks.value];}idIn.value=p+(maxStem(k,p)+1);idIn.dataset.auto='1';}}
const FK=i=>`<div class="row r5"><div><label>ID</label><input name="f_id_${i}"></div><div><label>Type</label><select name="f_kind_${i}" onchange="syncFootingKind(this);kindChanged(this,'f')">${OPT(['isolated','strap','combined'])}</select></div><div><label>Count</label><input name="f_count_${i}" value="1"></div><div><label>L</label><input name="f_L_${i}" value="1500"></div><div><label>W</label><input name="f_W_${i}" value="1500"></div></div><div class="row r6"><div><label>t</label><input name="f_t_${i}" value="450"><div class="lh">pad thickness</div></div><div><label>Depth</label><input name="f_depth_${i}" value="1500"><div class="lh">ground &#8594; footing base</div></div><div><label>Soling t</label><input name="f_soling_t_${i}" value="75"><div class="lh">stone layer, 0 = none</div></div><div><label>Mesh</label><div class="combo"><input name="f_mesh_${i}" onfocus="this.select()" value="12-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Grade</label><select name="f_grade_${i}">${OPT(['M20','M25','M30','M35','M15','M40'])}</select></div><div><label>Soil</label><select name="f_soil_${i}">${OPT(['soft soil','hard soil','rock','mixed'])}</select></div></div><div class="row r6 fgrp" data-show="isolated,combined"><div><label>Ped b</label><input name="f_ped_b_${i}" value="300"></div><div><label>Ped d</label><input name="f_ped_d_${i}" value="450"></div><div><label>Ped h</label><input name="f_ped_h_${i}" value="600"><div class="lh">height above pad</div></div><div><label>Ped main</label><div class="combo"><input name="f_ped_main_${i}" onfocus="this.select()" value="8-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.ped)}</select></div></div><div><label>Ped tie</label><div class="combo"><input name="f_ped_tie_${i}" onfocus="this.select()" value="8-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.stirrup)}</select></div></div><div></div></div><div class="row r6 fgrp" data-show="strap" style="display:none"><div><label>Strap len</label><input name="f_strap_len_${i}"><div class="lh">beam between the 2 pads</div></div><div><label>Strap b</label><input name="f_strap_b_${i}"></div><div><label>Strap d</label><input name="f_strap_d_${i}"></div><div><label>Strap top</label><div class="combo"><input name="f_strap_top_${i}" onfocus="this.select()"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.main)}</select></div></div><div><label>Strap bot</label><div class="combo"><input name="f_strap_bot_${i}" onfocus="this.select()"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.main)}</select></div></div><div><label>Strap tie</label><div class="combo"><input name="f_strap_tie_${i}" onfocus="this.select()"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.stirrup)}</select></div></div></div><details style="margin:3px 0"><summary style="font-size:11px;font-weight:700;color:#7a8693;cursor:pointer;user-select:none">&#65291; Starter column below plinth (advanced &#8212; leave closed = auto)</summary><div class="row r6" style="border-top:1px dashed #d7e0ea;padding-top:6px"><div><label>Stub b</label><input name="f_stub_b_${i}" placeholder="blank=auto"><div class="lh">starter width</div></div><div><label>Stub d</label><input name="f_stub_d_${i}" placeholder="blank=auto"><div class="lh">starter depth</div></div><div><label>Stub bars</label><div class="combo"><input name="f_stub_main_${i}" onfocus="this.select()" placeholder="e.g. 8-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.ped)}</select></div><div class="lh">count-dia</div></div><div><label>Stub tie</label><div class="combo"><input name="f_stub_tie_${i}" onfocus="this.select()" placeholder="e.g. 8-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.stirrup)}</select></div><div class="lh">dia-spacing</div></div></div></details>`;
const RF=i=>`<div class="row r5"><div><label>ID</label><input name="rf_id_${i}" value=""></div><div><label>Count</label><input name="rf_count_${i}" value="1"></div><div><label>L (mm)</label><input name="rf_L_${i}" value="12000"></div><div><label>W (mm)</label><input name="rf_W_${i}" value="9000"></div><div><label>t (mm)</label><input name="rf_t_${i}" value="600"></div></div><div class="row r5"><div><label>Depth GL</label><input name="rf_depth_${i}" value="1800"></div><div><label>Bottom mesh</label><div class="combo"><input name="rf_mesh_${i}" onfocus="this.select()" value="16-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Top mesh</label><div class="combo"><input name="rf_top_mesh_${i}" onfocus="this.select()" placeholder="blank = same as bottom"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Grade</label><select name="rf_grade_${i}">${OPT(['M25','M30','M35'])}</select></div><div><label>Soil</label><select name="rf_soil_${i}">${OPT(['soft soil','hard soil','rock','mixed'])}</select></div></div>`;
const PF=i=>`<div class="row r6"><div><label>ID</label><input name="pf_id_${i}"></div><div><label>Caps (count)</label><input name="pf_count_${i}" value="1"></div><div><label>Pile dia (mm)</label><input name="pf_pile_dia_${i}" value="400"></div><div><label>Pile len (mm)</label><input name="pf_pile_len_${i}" value="6000"></div><div><label>Pile no / cap</label><input name="pf_pile_no_${i}" value="2"></div><div><label>Pile main</label><div class="combo"><input name="pf_pile_main_${i}" onfocus="this.select()" value="6-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.ped)}</select></div></div></div><div class="row r6"><div><label>Spiral</label><div class="combo"><input name="pf_spiral_${i}" onfocus="this.select()" value="8-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Cap L (mm)</label><input name="pf_cap_L_${i}" value="1500"></div><div><label>Cap W (mm)</label><input name="pf_cap_W_${i}" value="1200"></div><div><label>Cap t (mm)</label><input name="pf_cap_t_${i}" value="600"></div><div><label>Cap mesh</label><div class="combo"><input name="pf_cap_mesh_${i}" onfocus="this.select()" value="12-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Grade</label><select name="pf_grade_${i}">${OPT(['M25','M30','M35'])}</select></div></div>`;
const SF=i=>`<div class="row r5"><div><label>ID</label><input name="sf_id_${i}"></div><div><label>Count</label><input name="sf_count_${i}" value="1"></div><div><label>Length (mm)</label><input name="sf_L_${i}" value="12000"></div><div><label>Width (mm)</label><input name="sf_W_${i}" value="900"></div><div><label>t (mm)</label><input name="sf_t_${i}" value="300"></div></div><div class="row r5"><div><label>Depth GL</label><input name="sf_depth_${i}" value="1200"></div><div><label>Soling t</label><input name="sf_soling_t_${i}" value="75"></div><div><label>Mesh</label><div class="combo"><input name="sf_mesh_${i}" onfocus="this.select()" value="12-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Grade</label><select name="sf_grade_${i}">${OPT(['M20','M25','M30'])}</select></div><div><label>Soil</label><select name="sf_soil_${i}">${OPT(['soft soil','hard soil','rock','mixed'])}</select></div></div>`;
function syncFootingKind(sel){const row=sel.closest('.mem');const k=sel.value;row.querySelectorAll('.fgrp').forEach(g=>{g.style.display=g.dataset.show.split(',').includes(k)?'':'none';});}
const addF=()=>{const i=C.f++;box('f',i,FK);const row=document.getElementById('footings').lastElementChild;syncFootingKind(row.querySelector('select[name="f_kind_'+i+'"]'));}; const addRF=()=>box('rf',C.rf++,RF); const addPF=()=>box('pf',C.pf++,PF); const addSF=()=>box('sf',C.sf++,SF);
const FLR=i=>{let h='';for(let f=0;f<25;f++){h+=`<div class="fcell" style="display:none"><label>${f==0?'GF':'F'+f}</label><div class="combo"><input name="c_mainf_${f}_${i}" onfocus="this.select()" value="${f==0?'8-16':''}" oninput="syncMain(${i})"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.main)}</select></div></div>`;}return h+`<div class="fcell"><label>&nbsp;</label><button type="button" class="fbtn" onclick="addFloor()" title="Add one more floor">+ floor</button><button type="button" class="fbtn minus" onclick="delFloor()" title="Remove top floor">−</button></div>`;};
const CK=i=>`<div class="row r5"><div><label>ID</label><input name="c_id_${i}"></div><div><label>Count</label><input name="c_count_${i}" value="1"></div><div><label>b</label><input name="c_b_${i}" value="300"><div class="lh">width</div></div><div><label>d</label><input name="c_d_${i}" value="450"><div class="lh">depth</div></div><div><label>Tie</label><div class="combo"><input name="c_tie_${i}" onfocus="this.select()" value="8-100-200"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.tie)}</select></div></div></div><div><label>Grade</label><select name="c_grade_${i}">${OPT(['M15','M20','M25','M30','M35','M40'])}</select></div><div class="mainfloors" data-idx="${i}"><label>Main bars per floor (GF first)</label><div class="flrow">${FLR(i)}</div><input type="hidden" name="c_main_${i}"></div>`;
const BK2=i=>`<div class="row r6"><div><label>ID</label><input name="b_id_${i}"></div><div><label>Type</label><select name="b_kind_${i}" onchange="kindChanged(this,'b')">${OPT(BK)}</select></div><div><label>Count</label><input name="b_count_${i}" value="1"></div><div><label>b</label><input name="b_b_${i}" value="230"><div class="lh">width</div></div><div><label>d</label><input name="b_d_${i}" value="450"><div class="lh">depth</div></div><div><label>Length</label><input name="b_length_${i}" value="4000"><div class="lh">clear span</div></div></div><div class="row r6"><div><label>Top</label><div class="combo"><input name="b_top_${i}" onfocus="this.select()" value="3-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.main)}</select></div></div><div><label>Bottom</label><div class="combo"><input name="b_bottom_${i}" onfocus="this.select()" value="3-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.main)}</select></div></div><div><label>Extra top @supports</label><div class="combo"><input name="b_extra_top_${i}" onfocus="this.select()" placeholder="e.g. 1-16"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.main)}</select></div></div><div><label>Side bars (deep>750mm)</label><div class="combo"><input name="b_side_${i}" onfocus="this.select()" placeholder="e.g. 2-12"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.main)}</select></div></div><div><label>Stirrup</label><div class="combo"><input name="b_tie_${i}" onfocus="this.select()" value="8-100-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.stirrup)}</select></div></div><div><label>Grade</label><select name="b_grade_${i}">${OPT(['M15','M20','M25','M30','M35','M40'])}</select></div></div>`;
const SK=i=>`<div class="row r6"><div><label>ID</label><input name="s_id_${i}"></div><div><label>Type</label><select name="s_type_${i}" onchange="syncSlab(this)">${OPT(['one-way slab','two-way slab','sunken slab (toilet)','flat slab','waffle (ribbed)','cantilever / balcony / chajja'])}</select></div><div><label>Panel L (mm)</label><input name="s_L_s_${i}" value="5000"></div><div><label>Panel W (mm)</label><input name="s_W_s_${i}" value="4000"></div><div><label>Repeat panels</label><input name="s_count_${i}" value="1"></div><div><label>t (mm)</label><input name="s_t_${i}" value="125"></div></div><div class="row r6 slab-common"><div><label>Bottom X</label><input name="s_bottom_x_${i}" value="10-150"></div><div><label>Bottom Y</label><input name="s_bottom_y_${i}" value="10-150"></div><div><label>Top X</label><input name="s_top_x_${i}"></div><div><label>Top Y</label><input name="s_top_y_${i}"></div><div><label>Support zone mm</label><input name="s_support_zone_${i}"></div><div><label>Grade</label><select name="s_grade_${i}">${OPT(['M20','M25','M30','M35','M40'])}</select></div></div><div class="row r5 slab-common"><div><label>Top support X</label><input name="s_support_top_x_${i}"></div><div><label>Top support Y</label><input name="s_support_top_y_${i}"></div><div><label>Opening L</label><input name="s_open_L_${i}"></div><div><label>Opening W</label><input name="s_open_W_${i}"></div><div><label>Opening count</label><input name="s_open_count_${i}" value="0"></div></div><div class="row r5 slab-sunken" style="display:none"><div><label>Sunken drop</label><input name="s_sunken_drop_${i}"></div></div><div class="row r5 slab-flat" style="display:none"><div><label>Drop L</label><input name="s_drop_L_${i}"></div><div><label>Drop W</label><input name="s_drop_W_${i}"></div><div><label>Drop t</label><input name="s_drop_t_${i}"></div></div><div class="row r6 slab-waffle" style="display:none"><div><label>Rib dir</label><select name="s_rib_dir_${i}">${OPT(['both ways','one way'])}</select></div><div><label>Rib spacing</label><input name="s_rib_spacing_${i}"></div><div><label>Rib width</label><input name="s_rib_w_${i}"></div><div><label>Rib depth</label><input name="s_rib_d_${i}"></div><div><label>Topping t</label><input name="s_topping_t_${i}"></div><div><label>Rib main</label><input name="s_rib_main_${i}"></div></div><div class="row r4 slab-waffle" style="display:none"><div><label>Rib top</label><input name="s_rib_top_${i}"></div><div><label>Rib stirrup</label><input name="s_rib_stirrup_${i}"></div><div><label>Solid edge band</label><input name="s_solid_band_${i}"></div></div>`;
const WK=i=>`<div class="row r5"><div><label>ID</label><input name="w_id_${i}"></div><div><label>Length</label><input name="w_length_${i}" value="6000"></div><div><label>t</label><input name="w_t_${i}" value="200"></div><div><label>Height</label><input name="w_height_${i}" value="3000"></div><div><label>Vert</label><div class="combo"><input name="w_vertical_${i}" value="12-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div></div><div class="row r2"><div><label>Horiz</label><div class="combo"><input name="w_horizontal_${i}" value="10-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div></div></div>`;
const RK=i=>`<div class="row r5"><div><label>ID</label><input name="rw_id_${i}"></div><div><label>Length</label><input name="rw_length_${i}" value="6000"></div><div><label>Stem t</label><input name="rw_stem_t_${i}" value="250"></div><div><label>Stem h</label><input name="rw_stem_h_${i}" value="3000"></div><div><label>Base b</label><input name="rw_base_b_${i}" value="2000"></div></div><div class="row r5"><div><label>Base t</label><input name="rw_base_t_${i}" value="300"></div><div><label>Vert</label><div class="combo"><input name="rw_vert_${i}" value="12-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Horiz</label><div class="combo"><input name="rw_horiz_${i}" value="10-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Base mesh</label><div class="combo"><input name="rw_base_mesh_${i}" value="12-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div></div></div>`;
const TK=i=>`<div class="row r5"><div><label>ID</label><input name="t_id_${i}"></div><div><label>Type</label><select name="t_kind_${i}" onchange="kindChanged(this,'t')">${OPT(['overhead tank','underground sump'])}</select></div><div><label>L int (mm)</label><input name="t_L_${i}" value="1800"></div><div><label>W int (mm)</label><input name="t_W_${i}" value="1800"></div><div><label>Depth (mm)</label><input name="t_depth_${i}" value="1400"></div></div><div class="row r6" style="margin-top:8px"><div><label>Wall t</label><input name="t_wall_t_${i}" value="125"></div><div><label>Base t</label><input name="t_base_t_${i}" value="150"></div><div><label>Cover t</label><input name="t_cover_t_${i}" value="100"></div><div><label>Wall mesh</label><div class="combo"><input name="t_wall_mesh_${i}" onfocus="this.select()" value="10-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Base mesh</label><div class="combo"><input name="t_base_mesh_${i}" onfocus="this.select()" value="10-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Grade</label><select name="t_grade_${i}">${OPT(['M20','M25','M30','M35','M15','M40'])}</select></div></div>`;
const RMP=i=>`<div class="row r6"><div><label>ID</label><input name="r_id_${i}"></div><div><label>Length incl. (mm)</label><input name="r_length_${i}" value="6000"></div><div><label>Width (mm)</label><input name="r_width_${i}" value="3000"></div><div><label>Thickness (mm)</label><input name="r_thickness_${i}" value="150"></div><div><label>Mesh</label><div class="combo"><input name="r_mesh_${i}" onfocus="this.select()" value="10-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Grade</label><select name="r_grade_${i}">${OPT(['M20','M25','M30'])}</select></div></div><div class="row r2" style="margin-top:8px"><div><label>Side wall h (mm, 0=none)</label><input name="r_side_wall_h_${i}" value="300"></div><div><label>Side wall t (mm)</label><input name="r_side_wall_t_${i}" value="150"></div></div>`;
const LFT=i=>`<div class="row r5"><div><label>ID</label><input name="l_id_${i}"></div><div><label>Plan L (mm)</label><input name="l_L_${i}" value="2200"></div><div><label>Plan W (mm)</label><input name="l_W_${i}" value="2000"></div><div><label>Pit depth (mm)</label><input name="l_pit_depth_${i}" value="1800"></div><div><label>Core height (mm)</label><input name="l_core_height_${i}" value="9900"></div></div><div class="row r4" style="margin-top:8px"><div><label>Wall t</label><input name="l_wall_t_${i}" value="175"></div><div><label>Base t</label><input name="l_base_t_${i}" value="300"></div><div><label>Mesh</label><div class="combo"><input name="l_mesh_${i}" onfocus="this.select()" value="10-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Grade</label><select name="l_grade_${i}">${OPT(['M25','M30','M35','M40'])}</select></div></div>`;
const OTH=i=>`<div class="row r2"><div><label>Item</label><select name="o_item_${i}">${OPT(['cement-based waterproofing (sunken slab/toilet)','bitumen coat 2 coats (retaining wall backface)','expansion joint filler + sealant','PVC water stop 230mm (construction joints)','dewatering from foundations','curing compound (or ponding)'])}</select></div><div><label>Qty (sqm/rmt/cum)</label><input name="o_qty_${i}" value="20"></div></div>`;
function syncSlab(sel){const row=sel.closest('.mem');if(!row)return;const v=(sel.value||'').toLowerCase();row.querySelectorAll('.slab-sunken').forEach(e=>e.style.display=v.includes('sunken')?'':'none');row.querySelectorAll('.slab-flat').forEach(e=>e.style.display=v.includes('flat')?'':'none');row.querySelectorAll('.slab-waffle').forEach(e=>e.style.display=v.includes('waffle')?'':'none');}
document.querySelectorAll('select[name^="s_type_"]').forEach(syncSlab);
const addC=()=>{const i=C.c++;box('c',i,CK);resizeFloors();syncMain(i);};
const addB=()=>box('b',C.b++,BK2); const addS=()=>{const i=C.s++;box('s',i,SK);syncSlab(document.querySelector('select[name="s_type_'+i+'"]'));};
const addW=()=>box('w',C.w++,WK); const addRW=()=>box('rw',C.rw++,RK);
const SCK=i=>`<div class="row r6"><div><label>ID</label><input name="sc_id_${i}" value=""></div><div><label>Type</label><select name="sc_type_${i}">${OPT(['dog-legged','open-well','straight flight','spiral','cantilever'])}</select></div><div><label>Flights</label><input name="sc_flights_${i}" value="2"></div><div><label>Run (mm)</label><input name="sc_run_${i}" value="3600"></div><div><label>Tread (mm)</label><input name="sc_tread_${i}" value="300"></div><div><label>Riser (mm)</label><input name="sc_riser_${i}" value="150"></div></div><div class="row r6" style="margin-top:8px"><div><label>Width (mm)</label><input name="sc_width_${i}" value="1200"></div><div><label>Waist (mm)</label><input name="sc_waist_${i}" value="150"></div><div><label>Mesh</label><div class="combo"><input name="sc_mesh_${i}" onfocus="this.select()" value="10-150"><select class="cbs" tabindex="-1" onchange="cbsel(this)"><option value="">&#9662;</option>${OPT(JO.mesh)}</select></div></div><div><label>Landings (nos)</label><input name="sc_landings_${i}" value="0"></div><div><label>Landing L (mm)</label><input name="sc_landing_L_${i}" value="1200"></div><div><label>Landing W (mm)</label><input name="sc_landing_W_${i}" value="1200"></div></div>`;
const addSC=()=>box('sc',C.sc++,SCK);
const addT=()=>box('t',C.t++,TK); const addR=()=>box('r',C.r++,RMP);
const addL=()=>box('l',C.l++,LFT); const addO=()=>box('o',C.o++,OTH);
function addPdf(){const d=document.createElement('div');d.style.cssText='margin-top:6px;display:flex;gap:6px;align-items:center';d.innerHTML='<input type="file" name="pdfs" accept="application/pdf" multiple style="flex:1"><button type="button" style="background:#c0392b;color:#fff;border:none;border-radius:5px;padding:6px 10px;cursor:pointer;font-size:12px" onclick="this.parentElement.remove()">✕</button>';document.getElementById('morepdfs').appendChild(d);}
</script>
</body></html>
"""
