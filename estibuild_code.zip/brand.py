"""Central branding config — EstiBuild is its own company."""
COMPANY = "MM EstiPro"
SHORT = "MM EstiPro"
TAGLINE = "Smart Construction Estimation Platform"
CONTACT = "MM EstiPro — Smart Construction Estimation"
CLIENT = ""
LOGO = "logo.png"
LOGO_FAINT = "logo_faint.png"

# ---- International currency ----
CURRENCY = "NPR"
CURRENCY_SYMBOL = "Rs"
