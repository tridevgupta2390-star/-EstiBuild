"""
Enhanced Structural Engine — contractor-grade estimation.

Adds: BBS table (bar marks + cutting lengths), rate analysis per m³,
labour days, soil-type excavation, wastage factors, more element types.
"""
from . import bbs as B
from collections import OrderedDict

COVERS = {'footing': 50, 'column': 40, 'beam': 25, 'slab': 20, 'wall': 40, 'pile': 50}
LAP = 50
WASTE_STEEL = 1.03    # 3% steel wastage
WASTE_CONC = 1.05     # 5% concrete wastage

# labour norms (per m³ RCC): mason-days, mazdoor-days
LABOUR = {'mason_per_m3': 0.50, 'mazdoor_per_m3': 3.0, 'rate_mason': 1200, 'rate_mazdoor': 800}
# steel fabrication: person-days per 100 kg
STEEL_FAB = 0.08

MIX = {  # grade -> (a, b, c) nominal ratio (M35+ = design-mix basis for estimating)
    'M15': (1, 2, 4), 'M20': (1, 1.5, 3), 'M25': (1, 1, 2), 'M30': (1, 0.75, 1.5),
    'M35': (1, 0.6, 1.25), 'M40': (1, 0.5, 1),
}
# water retaining / misc items (global-standard additions)
OTHER = {
    'cement-based waterproofing (sunken slab/toilet)': ('sqm', 220),
    'bitumen coat 2 coats (retaining wall backface)': ('sqm', 180),
    'expansion joint filler + sealant': ('rmt', 850),
    'PVC water stop 230mm (construction joints)': ('rmt', 550),
    'dewatering from foundations': ('cum', 120),
    'curing compound (or ponding)': ('sqm', 45),
}
PUMP_RATE = {'boom pump': 450, 'line pump': 350}
WEEP_RATE = 60
CHAIR_RATE = None  # chairs are steel (counted in kg)
SOIL_RATE = {'soft soil': 450, 'hard soil': 650, 'rock': 1200, 'mixed': 550}
BAG = 0.0347
DRY = 1.54


class Steel:
    """Accumulates weight by diameter AND generates BBS rows."""
    def __init__(self):
        self.tot = 0.0
        self.dia = {}
        self.bbs = []

    def add(self, kg, d):
        if kg <= 0: return
        self.tot += kg
        self.dia[d] = self.dia.get(d, 0) + kg

    def bar(self, mark, member, count, length_m, d):
        """Add a bar group to BBS + weight."""
        uw = B.unit_weight(d)
        wt = count * length_m * uw
        self.bbs.append({
            'mark': mark, 'member': member, 'dia': d,
            'count': count, 'cut_len': round(length_m, 2),
            'total_len': round(count * length_m, 1),
            'unit_wt': round(uw, 3), 'weight': round(wt, 1),
        })
        self.add(wt, d)

    def stirrup(self, mark, member, cut_m, n, d):
        self.bar(mark, member, n, cut_m, d)

    def layer(self, L_mm, W_mm, cover, d, sp):
        return B.num_along(W_mm, cover, sp), (L_mm - 2 * cover) / 1000.0


def _m3(*dims):
    p = 1.0
    for d in dims: p *= d
    return p / 1e9


def _member(cat, id_, kind, count):
    return {'cat': cat, 'id': id_, 'kind': kind, 'count': count, 'label': f"{id_} ({kind})",
            'conc': 0, 'pcc': 0, 'exc': 0, 'backfill': 0, 'soling': 0, 'shutter': 0, 'masonry': 0,
            'steel': Steel(), 'detail': [], 'grade': 'M25', 'soil': 'soft soil'}


def _scale_bbs(rows, n):
    """Scale one member's BBS rows to `n` identical members.
    Row weights are rounded to 0.1 kg (cutting-list precision). Returns (rows, net)
    where `net` is the sum of those displayed weights, so every downstream figure
    (BOQ steel, materials, BBS grand total, steel-by-diameter) is built from the
    SAME rounded base and therefore ties out exactly."""
    out = []
    net = 0.0
    for b in rows:
        count = b['count'] * n
        total_len = count * b['cut_len']
        wt = round(total_len * b['unit_wt'], 1)
        net += wt
        out.append({
            'mark': b['mark'], 'member': b['member'], 'dia': b['dia'],
            'count': count, 'cut_len': b['cut_len'],
            'total_len': round(total_len, 1),
            'unit_wt': b['unit_wt'],
            'weight': wt,
        })
    return out, round(net, 1)


def _finalize(m, n):
    for k in ('conc', 'pcc', 'exc', 'backfill', 'soling', 'shutter', 'masonry'):
        m[k] = round(m[k] * n, 3)
    st = m.pop('_st', None)
    rows, net = _scale_bbs(st.bbs if isinstance(st, Steel) else [], n)
    m['bbs'] = rows                              # full-quantity BBS (net cutting weights)
    m['steel'] = round(net * WASTE_STEEL, 3)     # GROSS = net + 3% wastage -> drives BOQ line
    m['detail'] = '; '.join(m['detail'])
    return m


def _footing(f, cov):
    kind = f.get('kind', 'isolated'); n = int(f.get('count') or 0); mid = f.get('id') or 'F'
    if n <= 0:
        return None          # empty/partial row (user cleared it) - skip safely
    L = f.get('L', f.get('cap_L', 1500)); W = f.get('W', f.get('cap_W', 1500))
    t = f.get('t', f.get('cap_t', 600)); depth = f.get('depth', 1500); sol = f.get('soling_t', 0)
    soil = f.get('soil', 'soft soil'); grade = f.get('grade', 'M25')
    m = _member('Footings', mid, kind, n); st = Steel()
    m['grade'] = grade; m['soil'] = soil
    m['dims'] = (n, L/1000.0, W/1000.0, t/1000.0)
    m['exc_dims'] = (n, (L+300)/1000.0, (W+300)/1000.0, depth/1000.0)
    m['pcc_dims'] = (n, (L+150)/1000.0, (W+150)/1000.0, 0.075)

    if kind in ('isolated', 'strip'):
        m['conc'] = _m3(L, W, t); m['pcc'] = _m3(L + 150, W + 150, 75)
        m['exc'] = _m3(L + 300, W + 300, depth)
        if sol: m['soling'] = _m3(L, W, sol)
        m['shutter'] = 2 * (L + W) * t / 1e6
        ds = B.parse_diaspacing(f.get('mesh')) or (12, 150)
        # BBS: mesh both directions
        cntX, lenX = st.layer(L, W, cov, ds[0], ds[1])
        cntY, lenY = st.layer(W, L, cov, ds[0], ds[1])
        st.bar(f'{mid}-RX', mid, cntX, lenX, ds[0]); st.bar(f'{mid}-RY', mid, cntY, lenY, ds[0])
        if kind == 'isolated' and f.get('ped_h'):
            pb, pd, ph = f['ped_b'], f['ped_d'], f['ped_h']
            m['conc'] += _m3(pb, pd, ph); m['shutter'] += 2 * (pb + pd) * ph / 1e6
            m['exc'] += _m3(pb, pd, ph) * 0.5
            m['ped_dims'] = (n, pb/1000.0, pd/1000.0, ph/1000.0)
            for cnt, dia in (B.parse_nodia(f.get('ped_main')) or [(8, 16)]):
                st.bar(f'{mid}-PM', mid, cnt, (ph + LAP * dia) / 1000.0, dia)
            td, sc, sm = B.parse_tie(f.get('ped_tie'))
            cl = B.stirrup_length(pb, pd, cov, td)
            nt = B.num_stirrups(ph, sc)
            st.stirrup(f'{mid}-PT', mid, cl, nt, td)
    elif kind == 'strap':
        sl = f.get('strap_len') or 0; sb = f.get('strap_b') or 300; sd = f.get('strap_d') or 450
        m['conc'] = 2 * _m3(L, W, t) + _m3(sl, sb, sd)
        m['tk_note'] = '2 footings + strap beam'
        m['pcc'] = 2 * _m3(L + 150, W + 150, 75); m['exc'] = 2 * _m3(L + 300, W + 300, depth)
        if sol: m['soling'] = 2 * _m3(L, W, sol)
        m['shutter'] = 4 * (L + W) * t / 1e6
        ds = B.parse_diaspacing(f.get('mesh')) or (12, 150)
        cntX, lenX = st.layer(L, W, cov, ds[0], ds[1]); cntY, lenY = st.layer(W, L, cov, ds[0], ds[1])
        st.bar(f'{mid}-RX', mid, cntX, lenX, ds[0]); st.bar(f'{mid}-RY', mid, cntY, lenY, ds[0])
        for key, mk in (('strap_top', f'{mid}-ST'), ('strap_bot', f'{mid}-SB')):
            for cnt, dia in (B.parse_nodia(f.get(key)) or []):
                st.bar(mk, mid, cnt, (sl + LAP * dia) / 1000.0, dia)
        td, sc, sm = B.parse_tie(f.get('strap_tie'))
        st.stirrup(f'{mid}-SS', mid, B.stirrup_length(sb, sd, COVERS['beam'], td),
                   B.num_stirrups(sl, sc), td)
    elif kind in ('combined', 'raft'):
        m['conc'] = _m3(L, W, t); m['pcc'] = _m3(L + 150, W + 150, 75) if kind == 'combined' else _m3(L, W, 75)
        m['exc'] = _m3(L + 300, W + 300, depth); m['shutter'] = 2 * (L + W) * t / 1e6
        if kind == 'raft':
            # double mesh: separate bottom + top specs (top falls back to bottom if blank)
            m['tk_note'] = 'double mesh: bottom + top'
            for mk, spec in (('B', f.get('mesh')), ('T', f.get('top_mesh') or f.get('mesh'))):
                ds = B.parse_diaspacing(spec) or (16, 150)
                cntX, lenX = st.layer(L, W, cov, ds[0], ds[1]); cntY, lenY = st.layer(W, L, cov, ds[0], ds[1])
                st.bar(f'{mid}-R{mk}X', mid, cntX, lenX, ds[0]); st.bar(f'{mid}-R{mk}Y', mid, cntY, lenY, ds[0])
        else:
            ds = B.parse_diaspacing(f.get('mesh')) or (16, 150)
            cntX, lenX = st.layer(L, W, cov, ds[0], ds[1]); cntY, lenY = st.layer(W, L, cov, ds[0], ds[1])
            st.bar(f'{mid}-RX', mid, cntX, lenX, ds[0]); st.bar(f'{mid}-RY', mid, cntY, lenY, ds[0])
    elif kind == 'pile':
        # blank/missing fields never crash the estimate (offline rows, blanked boxes)
        pdia = f.get('pile_dia') or 0; plen = f.get('pile_len') or 0
        pno = int(f.get('pile_no') or 1)
        capL = f.get('cap_L') or L; capW = f.get('cap_W') or W; capT = f.get('cap_t') or t
        m['conc'] = (3.14159/4*pdia**2/1e6)*(plen/1000.0)*pno + _m3(capL, capW, capT)
        m['pcc'] = _m3(capL, capW, 75); m['exc'] = _m3(capL+300, capW+300, 1500)
        m['shutter'] = 2*(capL+capW)*capT/1e6
        for cnt, dia in (B.parse_nodia(f.get('pile_main')) or [(6, 16)]):
            st.bar(f'{mid}-PL', mid, cnt, (plen+LAP*dia)/1000.0*pno, dia)
        spd, spp = B.parse_diaspacing(f.get('spiral')) or (8, 150)
        st.add(B.spiral_length(pdia, plen, spp, COVERS['pile']) * B.unit_weight(spd) * pno, spd)
        ds = B.parse_diaspacing(f.get('cap_mesh')) or (12, 150)
        cntX, lenX = st.layer(capL, capW, COVERS['footing'], ds[0], ds[1])
        cntY, lenY = st.layer(capW, capL, COVERS['footing'], ds[0], ds[1])
        st.bar(f'{mid}-CX', mid, cntX, lenX, ds[0]); st.bar(f'{mid}-CY', mid, cntY, lenY, ds[0])
    m['backfill'] = max(m['exc'] - m['conc'] - m['pcc'] - m['soling'], 0)
    m['_st'] = st; m['detail'] = [f"grade {grade}, soil {soil}"]
    return _finalize(m, n)


def _trench(sch):
    """Trench & plinth wall - AUTO from the plinth beams + footings the estimator
    already entered. The trench runs along the wall line BETWEEN the footing pits;
    the wall (stone/brick) rises from the trench PCC bed to plinth beam bottom.
    User only picks the wall type - every length/depth/thickness can be overridden."""
    def NUM(v, d=0):
        try:
            return float(v)
        except (TypeError, ValueError):
            return d
    twt = str(sch.get('tw_type') or 'none').strip().lower()
    if twt in ('', 'none', 'no'):
        return None
    # plinth beams = the wall line
    pb = [b for b in (sch.get('beams') or []) if 'plinth' in str(b.get('kind', '')).lower()]
    pb_len_mm = sum(NUM(b.get('length'), 0) * (int(b.get('count') or 1)) for b in pb)
    pb_w = [NUM(b.get('b'), 230) for b in pb] or [230]
    wall_t = float(sch.get('tw_wall_t') or 0) or max(set(pb_w), key=pb_w.count)
    # trench length: user value (m) or auto = plinth beam length
    L = (float(sch.get('tw_length') or 0) * 1000) or pb_len_mm
    if L <= 0:
        return None
    # trench depth: user value (m) or auto = deepest footing
    fdep = [NUM(f.get('depth'), 1500) for f in (sch.get('footings') or []) if int(f.get('count') or 0) > 0]
    D = (float(sch.get('tw_depth') or 0) * 1000) or (max(fdep) if fdep else 1500)
    plinth_h = (float(sch.get('tw_plinth_h') or 0) or 0.45) * 1000
    # deduct the footing pits the trench crosses (excavation already counted there)
    pit_w = sum(NUM(f.get('W'), 0) * int(f.get('count') or 0)
                for f in (sch.get('footings') or [])
                if str(f.get('kind', '')).lower() in ('isolated', 'combined', 'strap') and int(f.get('count') or 0) > 0)
    netL = max(L - pit_w, L * 0.5)
    m = _member('Trench & Plinth Wall', 'TRENCH', twt.title(), 1)
    m['soil'] = 'trench'
    trench_w = wall_t + 300                       # wall + 150mm working space each side
    m['exc'] = netL / 1000.0 * trench_w / 1000.0 * D / 1000.0
    m['pcc'] = netL / 1000.0 * (wall_t + 150) / 1000.0 * 0.100      # 100mm PCC bed
    wall_h = max(D + plinth_h - 100, 0)           # trench bottom (+PCC) to plinth beam bottom
    m['masonry'] = netL / 1000.0 * wall_t / 1000.0 * wall_h / 1000.0
    m['backfill'] = max(m['exc'] - m['pcc'] - m['masonry'], 0)
    m['dims'] = (1, round(netL / 1000.0, 2), round(wall_t / 1000.0, 3), round(wall_h / 1000.0, 3))
    m['exc_dims'] = (1, round(netL / 1000.0, 2), round(trench_w / 1000.0, 3), round(D / 1000.0, 3))
    m['detail'] = [f"trench {trench_w:.0f}mm wide x {D:.0f}mm deep, wall {wall_t:.0f}mm up to plinth "
                   f"(+{plinth_h:.0f}mm above GL), length net of footing pits"]
    return _finalize(m, 1)


def _column(c, fh, nf, cov, lo):
    n = c['count']; b, d = c['b'], c['d']; mid = c['id']; grade = c.get('grade', 'M25')
    m = _member('Columns', mid, 'column', n); st = Steel(); m['grade'] = grade
    m['dims'] = (n, b/1000.0, d/1000.0, round(fh*nf/1000.0, 3))
    m['conc'] = _m3(b, d, fh * nf); m['shutter'] = 2 * (b + d) * fh * nf / 1e6
    floors = B.parse_nodia(c.get('main')) or [(8, 16)]
    while len(floors) < nf: floors.append(floors[-1])
    td, sc, sm = B.parse_tie(c.get('tie')); det = []
    for i, (cnt, dia) in enumerate(floors[:nf]):
        bar_len = (fh + LAP * dia) / 1000.0
        st.bar(f'{mid}-M{i}', mid, cnt, bar_len, dia)
        n_conf = int(2 * lo / sc) + 2; n_mid = max(0, int((fh - 2 * lo) / sm)) + 1
        cl = B.stirrup_length(b, d, cov, td)
        st.stirrup(f'{mid}-T{i}', mid, cl, n_conf + n_mid, td)
        det.append(f'F{i}:{cnt}T{dia}')
    m['detail'] = ['main ' + ', '.join(det) + f'; ties {td}T@{sc}/{sm}; grade {grade}']
    m['_st'] = st
    return _finalize(m, n)


def _beam(b, cov, lo):
    n = b['count']; bw, bd, L = b['b'], b['d'], b['length']; mid = b['id']
    grade = b.get('grade', 'M25')
    m = _member('Beams', mid, b.get('kind', 'beam'), n); st = Steel(); m['grade'] = grade
    m['dims'] = (n, bw/1000.0, bd/1000.0, L/1000.0)
    m['conc'] = _m3(bw, bd, L); m['shutter'] = (2 * bd + bw) * L / 1e6
    for key, mk in (('top', f'{mid}-T'), ('bottom', f'{mid}-B')):
        for cnt, dia in (B.parse_nodia(b.get(key)) or []):
            st.bar(mk, mid, cnt, (L + LAP * dia) / 1000.0, dia)
    # extra top bars at supports (curtailment) - extend L/5 each end ~ 0.5L bar
    for cnt, dia in (B.parse_nodia(b.get('extra_top')) or []):
        st.bar(f'{mid}-XT', mid, cnt, 0.5 * L / 1000.0, dia)
    # side face bars (IS 456: beams deeper than 750mm) - full length with lap
    for cnt, dia in (B.parse_nodia(b.get('side')) or []):
        st.bar(f'{mid}-SF', mid, cnt, (L + LAP * dia) / 1000.0, dia)
    td, sc, sm = B.parse_tie(b.get('tie'))
    n_conf = int(2 * lo / sc) + 2; n_mid = max(0, int((L - 2 * lo) / sm)) + 1
    st.stirrup(f'{mid}-S', mid, B.stirrup_length(bw, bd, cov, td), n_conf + n_mid, td)
    m['detail'] = [f"top {b.get('top')}/bot {b.get('bottom')}/stir {td}T@{sc}/{sm}; grade {grade}"]
    m['_st'] = st
    return _finalize(m, n)


def _slab(s, cov):
    mid = s['id']; grade = s.get('grade', 'M25')
    stype = s.get('type', 'two-way slab')
    m = _member('Slabs', mid, stype, 1); st = Steel(); m['grade'] = grade
    m['dims'] = (1, s['area'], s['t']/1000.0, None)
    m['tk_note'] = 'area (m²) x slab thickness'
    m['conc'] = s['area'] * s['t'] / 1000.0; m['shutter'] = s['area']
    ds = B.parse_diaspacing(s.get('mesh')) or (10, 150)
    bpm = 1000.0 / ds[1]  # bars per m
    cnt = int(bpm * s['area'])
    st.bar(f'{mid}-RX', mid, cnt, 1.0, ds[0]); st.bar(f'{mid}-RY', mid, cnt, 1.0, ds[0])
    top = B.parse_diaspacing(s.get('top_mesh'))
    if top:  # second (top) layer - required for t > 125mm / cantilevers / sunken
        cnt2 = int((1000.0 / top[1]) * s['area'])
        st.bar(f'{mid}-TX', mid, cnt2, 1.0, top[0]); st.bar(f'{mid}-TY', mid, cnt2, 1.0, top[0])
    det = f"{stype}, {s.get('mesh')} both ways"
    if top:
        det += f" + top {s.get('top_mesh')}"
    m['detail'] = [f"{det}; grade {grade}"]
    m['_st'] = st
    return _finalize(m, 1)


def _shearwall(w, cov):
    mid = w['id']; grade = w.get('grade', 'M25')
    m = _member('Shear Walls', mid, 'shear wall', 1); st = Steel(); m['grade'] = grade
    L, t, H = w['length'], w['t'], w['height']
    m['dims'] = (1, L/1000.0, t/1000.0, H/1000.0)
    m['conc'] = _m3(L, t, H); m['shutter'] = 2 * L * H / 1e6
    vd, vsp = B.parse_diaspacing(w.get('vertical')) or (12, 150)
    hd, hsp = B.parse_diaspacing(w.get('horizontal')) or (10, 150)
    nv = B.num_along(L, cov, vsp); nh = B.num_along(H, cov, hsp)
    st.bar(f'{mid}-V', mid, nv, H/1000.0, vd); st.bar(f'{mid}-H', mid, nh, L/1000.0, hd)
    m['detail'] = [f"vert {vd}T@{vsp}/horiz {hd}T@{hsp}; grade {grade}"]; m['_st'] = st
    return _finalize(m, 1)


def _retwall(rw, cov):
    mid = rw['id']
    m = _member('Retaining / Trench Walls', mid, 'retaining wall', 1); st = Steel()
    L = rw['length']; st_t = rw['stem_t']; st_h = rw['stem_h']; bb = rw['base_b']; bt = rw['base_t']
    m['conc'] = _m3(L, st_t, st_h) + _m3(L, bb, bt)
    m['pcc'] = _m3(L, bb, 100)          # 100mm PCC bed under the base
    m['shutter'] = 2 * L * st_h / 1e6 + 2 * (bb + bt) * L / 1e6; m['exc'] = _m3(L + 300, bb + 300, st_h + bt)
    vd, vsp = B.parse_diaspacing(rw.get('vert')) or (12, 150)
    hd, hsp = B.parse_diaspacing(rw.get('horiz')) or (10, 150)
    nv = B.num_along(L, cov, vsp); nh = B.num_along(st_h, cov, hsp)
    st.bar(f'{mid}-V', mid, nv, (st_h+bt)/1000.0, vd); st.bar(f'{mid}-H', mid, nh, L/1000.0, hd)
    ds = B.parse_diaspacing(rw.get('base_mesh')) or (12, 150)
    cntX, lenX = st.layer(bb, L, cov, ds[0], ds[1]); cntY, lenY = st.layer(L, bb, cov, ds[0], ds[1])
    st.bar(f'{mid}-BX', mid, cntX, lenX, ds[0]); st.bar(f'{mid}-BY', mid, cntY, lenY, ds[0])
    m['backfill'] = max(m['exc'] - m['conc'] - m['pcc'], 0)
    m['weep_area'] = L * st_h / 1e6   # backface area -> auto weep holes
    m['detail'] = [f'stem {st_t}mm + base {bb}x{bt}, PCC bed 100mm, vert {vd}T@{vsp}/horiz {hd}T@{hsp}']
    m['_st'] = st
    return _finalize(m, 1)




def _staircases(sch):
    """Return a list of staircase dicts — supports multiple staircases per building.
    Backwards compatible: if 'staircase' is a single dict (old format), wraps it in a list."""
    sc = sch.get('staircase')
    if isinstance(sc, list):
        return sc
    if isinstance(sc, dict):
        return [sc]
    return [sch.get('staircases_list') or {'flights': 2, 'run': 3600, 'width': 1200,
            'waist': 150, 'mesh': '10-150', 'type': 'dog-legged'}]


def _staircase(sc, cov):
    sid = sc.get('id', 'ST')
    m = _member('Staircase', sid, sc.get('type', 'dog-legged'), 1); st = Steel()
    run, w, waist = sc['run'], sc['width'], sc['waist']
    fl = sc['flights']
    tread = sc.get('tread', 300) or 300; riser = sc.get('riser', 150) or 150
    m['conc'] = _m3(run, w, waist) * fl
    # steps (triangle concrete): 0.5 x tread x riser x width per step
    nsteps = int(run / tread) * fl
    m['conc'] += nsteps * 0.5 * (tread / 1000.0) * (riser / 1000.0) * (w / 1000.0)
    # landings
    ldn = int(sc.get('landings', 0) or 0)
    spc_g = sc.get('spacing')
    ldL = sc.get('landing_L', 1200); ldW = sc.get('landing_W', 1200); ldt = sc.get('landing_t', 150)
    if ldn:
        m['conc'] += _m3(ldL, ldW, ldt) * ldn
    m['shutter'] = (run * w) / 1e6 * fl + (2 * run * waist) / 1e6 * fl + (ldn * ldL * ldW / 1e6 if ldn else 0)
    ds = B.parse_diaspacing(sc.get('mesh')) or (10, 150)
    area = run * w / 1e6 * fl
    cnt = int((1000.0 / ds[1]) * area)
    st.bar('ST-RX', 'ST', cnt, 1.0, ds[0]); st.bar('ST-RY', 'ST', cnt, 1.0, ds[0])
    if ldn:
        c2 = int((1000.0 / ds[1]) * (ldL * ldW / 1e6) * ldn)
        st.bar('ST-LX', 'ST', c2, 1.0, ds[0]); st.bar('ST-LY', 'ST', c2, 1.0, ds[0])
    m['detail'] = [f"{sc.get('type', 'dog-legged')}: {fl} flights, {nsteps} steps ({tread}/{riser}), {ldn} landings"]
    m['_st'] = st
    return _finalize(m, 1)


def _tank(t, cov):
    """Water tank / underground sump - water-retaining RCC (IS 3370 basis)."""
    mid = t['id']; kind = t.get('kind', 'overhead tank')
    L = t.get('L', 1800); W = t.get('W', 1800); dep = t.get('depth', 1400)
    wt = t.get('wall_t', 125); bt = t.get('base_t', 150); ct = t.get('cover_t', 100)
    m = _member('Water Tanks & Sumps', mid, kind, 1); st = Steel(); m['grade'] = t.get('grade', 'M25')
    m['dims'] = (1, L/1000.0, W/1000.0, dep/1000.0)
    m['tk_note'] = 'walls + base slab + cover slab (IS 3370) - dims shown are internal size'
    walls = 2 * (L + W) * dep * wt
    base = (L + 2 * wt) * (W + 2 * wt) * bt
    cover = (L + 2 * wt) * (W + 2 * wt) * ct
    m['conc'] = (walls + base + cover) / 1e9
    m['shutter'] = (2 * (L + W) * dep + L * W + 2 * (L + W) * bt) / 1e6
    if kind == 'underground sump':
        m['exc'] = (L + 2 * wt + 300) * (W + 2 * wt + 300) * (dep + bt + 100) / 1e9
        m['pcc'] = (L + 2 * wt) * (W + 2 * wt) * 100 / 1e9
    d, sp = B.parse_diaspacing(t.get('wall_mesh')) or (10, 150)
    nv = B.num_along(dep, cov, sp); nhL = B.num_along(L, cov, sp); nhW = B.num_along(W, cov, sp)
    st.bar(f'{mid}-LWV', mid, nv * 4, dep / 1000.0, d)
    st.bar(f'{mid}-LWH', mid, nhL * 4, L / 1000.0, d)
    st.bar(f'{mid}-SWV', mid, nv * 4, dep / 1000.0, d)
    st.bar(f'{mid}-SWH', mid, nhW * 4, W / 1000.0, d)
    bd, bs = B.parse_diaspacing(t.get('base_mesh')) or (10, 150)
    Lo, Wo = L + 2 * wt, W + 2 * wt
    cX, lX = st.layer(Lo, Wo, cov, bd, bs); cY, lY = st.layer(Wo, Lo, cov, bd, bs)
    st.bar(f'{mid}-BX', mid, cX, lX, bd); st.bar(f'{mid}-BY', mid, cY, lY, bd)
    st.bar(f'{mid}-CX', mid, cX, lX, bd); st.bar(f'{mid}-CY', mid, cY, lY, bd)
    if kind == 'underground sump':
        m['backfill'] = max(m['exc'] - m['conc'] - m['pcc'], 0)
    m['detail'] = [f'{kind} {L}x{W}x{dep}mm int., walls {wt}mm, IS 3370 W/C 0.45, '
                   f'grade {m["grade"]}; cover {ct}mm']
    m['_st'] = st
    return _finalize(m, 1)


def _ramp(r, cov):
    """Ramp slab + optional side walls (parking / accessibility ramps)."""
    mid = r['id']; L = r['length']; w = r['width']; th = r['thickness']
    m = _member('Ramps', mid, 'ramp', 1); st = Steel(); m['grade'] = r.get('grade', 'M25')
    m['dims'] = (1, r.get('length',6000)/1000.0, r.get('width',3000)/1000.0, r.get('thickness',150)/1000.0)
    m['tk_note'] = 'ramp slab + side walls (if any)'
    m['conc'] = _m3(L, w, th)
    wh = r.get('side_wall_h', 0) or 0; wtt = r.get('side_wall_t', 150)
    if wh:
        m['conc'] += _m3(L, wh, wtt) * 2
    m['shutter'] = (L * w + 2 * L * th + (4 * L * wh if wh else 0)) / 1e6
    d, sp = B.parse_diaspacing(r.get('mesh')) or (10, 150)
    cX, lX = st.layer(L, w, cov, d, sp); cY, lY = st.layer(w, L, cov, d, sp)
    st.bar(f'{mid}-RX', mid, cX, lX, d); st.bar(f'{mid}-RY', mid, cY, lY, d)
    if wh:
        nv = B.num_along(wh, cov, sp); nh = B.num_along(L, cov, sp)
        st.bar(f'{mid}-WV', mid, nv * 4, wh / 1000.0, d)
        st.bar(f'{mid}-WH', mid, nh * 4, L / 1000.0, d)
    m['detail'] = [f'inclined {L}mm x {w}mm, {th}mm thick; grade {m["grade"]}']
    m['_st'] = st
    return _finalize(m, 1)


def _lift(l, cov):
    """Lift core: pit + shaft walls + machine room slab (water-tight pit)."""
    mid = l['id']; L = l['L']; W = l['W']; pd = l['pit_depth']; ch = l.get('core_height', 0) or 0
    wt = l['wall_t']; bt = l['base_t']
    m = _member('Lift Cores', mid, 'lift core', 1); st = Steel(); m['grade'] = l.get('grade', 'M30')
    m['dims'] = (1, L/1000.0, W/1000.0, (pd + ch)/1000.0)
    m['tk_note'] = 'pit + core walls + machine-room slab'
    H = pd + ch
    per = 2 * (L + W)
    m['conc'] = per * H * wt / 1e9 + L * W * bt / 1e9 + L * W * 150 / 1e9
    m['pcc'] = L * W * 100 / 1e9
    m['exc'] = (L + 300) * (W + 300) * pd / 1e9
    m['shutter'] = (per * H + L * W + 2 * per * bt / 1000.0) / 1e6
    d, sp = B.parse_diaspacing(l.get('mesh')) or (10, 150)
    nv = B.num_along(per, cov, sp)
    st.bar(f'{mid}-V', mid, nv, H / 1000.0, d)
    nh = B.num_along(H, cov, sp)
    st.bar(f'{mid}-H', mid, nh, per / 1000.0, d)
    cX, lX = st.layer(L, W, cov, d, sp); cY, lY = st.layer(W, L, cov, d, sp)
    st.bar(f'{mid}-BX', mid, cX, lX, d); st.bar(f'{mid}-BY', mid, cY, lY, d)
    st.bar(f'{mid}-TX', mid, cX, lX, d); st.bar(f'{mid}-TY', mid, cY, lY, d)
    m['backfill'] = max(m['exc'] - m['conc'] - m['pcc'], 0)
    m['detail'] = [f'pit {pd}mm + core {ch}mm, walls {wt}mm, water-tight; grade {m["grade"]}']
    m['_st'] = st
    return _finalize(m, 1)


# ---- DIRECT per-grade / per-mix rates (user types their own; defaults if blank) ----
# RCC defaults per grade (NPR/cum); M25 uses the editable rate_rcc_m3 box
GRADE_DEFAULT = {'M15': 15500, 'M20': 16000, 'M30': 17500, 'M35': 18500, 'M40': 19500}
# PCC defaults per mix (NPR/cum); 1:4:8 uses the editable rate_pcc_m3 box
PCC_MIX_DEFAULT = {'1:5:10': 8200, '1:3:6': 11000, '1:2:4': 12500, '1:1.5:3': 13500}


def _grade_rate(grade, rates, grade_rates):
    """User's typed rate for this grade > default > M25 base rate."""
    g = str(grade or 'M25').strip().upper()
    if g == 'M25' or g not in GRADE_DEFAULT:
        return rates.get('rcc_m3', 16500)
    ur = (grade_rates or {}).get(g)
    if ur and ur > 0:
        return ur
    return GRADE_DEFAULT.get(g, rates.get('rcc_m3', 16500))


def _pcc_mix_rate(mix_str, rates, mix_rates):
    """User's typed rate for this mix > default > 1:4:8 base rate."""
    import re as _re
    m = _re.search(r'(\d+(?:\.\d+)?\s*:\s*\d+(?:\.\d+)?\s*:\s*\d+(?:\.\d+)?)', str(mix_str or ''))
    if not m:
        return rates.get('pcc_m3', 9500)
    key = ''.join(m.group(1).split())
    if key == '1:4:8':
        return rates.get('pcc_m3', 9500)
    ur = (mix_rates or {}).get(key)
    if ur and ur > 0:
        return ur
    return PCC_MIX_DEFAULT.get(key, rates.get('pcc_m3', 9500))


def _mix_breakup(vol, grade):
    a, b, c = MIX.get(grade, (1, 1, 2)); s = a + b + c; dry = vol * DRY
    return (a/s)*dry/BAG, (b/s)*dry, (c/s)*dry


def estimate_structural(sch):
    cov_f, cov_c, cov_b, cov_s = sch['cover_footing'], sch['cover_column'], sch['cover_beam'], sch['cover_slab']
    lo = sch.get('confinement_lo', 450)
    grade_default = sch.get('concrete_grade') or 'M25'
    pcc_mix = sch.get('pcc_mix', 'PCC 1:4:8')
    rates = sch['rates']
    members = ([x for x in (_footing(f, cov_f) for f in sch['footings']) if x] +
               [x for x in [_trench(sch)] if x] +
               [_column(c, sch['floor_height'], sch['floors_above'], cov_c, lo) for c in sch['columns']] +
               [_beam(b, cov_b, lo) for b in sch['beams']] + [_slab(s, cov_s) for s in sch['slabs']] +
               [_shearwall(w, cov_f) for w in sch['shearwalls']] + [_retwall(rw, cov_f) for rw in sch['retwalls']] +
               [_tank(t, cov_s) for t in sch.get('tanks', [])] +
               [_ramp(r, cov_s) for r in sch.get('ramps', [])] +
               [_lift(l, cov_s) for l in sch.get('lifts', [])] +
               [_staircase(sc, cov_s) for sc in _staircases(sch)])
    # ---- column stub below plinth (foundation package). TWO modes:
    #   A. EXPLICIT: Stub b/d/bars/tie filled on a footing row -> exact per-footing stubs
    #      (steel-structure case: RCC ends at plinth, no column card needed)
    #   B. AUTO: stub fields blank + column card filled -> GF column bars, deepest footing
    def _n(v, d=0.0):
        try:
            return float(v)
        except (TypeError, ValueError):
            return d
    stub_mm = _n(sch.get('col_below_gl'), 0)
    plinth_mm = max(0, int(round(_n(sch.get('tw_plinth_h'), 0.45) * 1000)))
    per_rows = [f for f in sch.get('footings', [])
                if _n(f.get('stub_b'), 0) > 0 and _n(f.get('stub_d'), 0) > 0]
    if per_rows:
        sm = _member('Footings', 'STUB', 'column below plinth (foundation)', 1)
        sst = Steel()
        conc = shutter = 0.0
        det = []
        for f in per_rows:
            n = int(_n(f.get('count'), 0) or 0)
            if n <= 0:
                continue
            sb, sd = _n(f.get('stub_b')), _n(f.get('stub_d'))
            ln = stub_mm if stub_mm > 0 else max(0.0, _n(f.get('depth'), 1500) - _n(f.get('t'), 600) - _n(f.get('ped_h'), 0)) + plinth_mm
            if ln < 50:
                continue
            conc += _m3(sb, sd, ln) * n
            shutter += 2 * (sb + sd) * ln / 1e6 * n
            fid = f.get('id') or 'F'
            for cnt, dia in (B.parse_nodia(f.get('stub_main')) or [(8, 16)]):
                sst.bar(f'{fid}-SM', fid, cnt * n, (ln + LAP * dia) / 1000.0, dia)
            td, sc, _smm = B.parse_tie(f.get('stub_tie'))
            sst.stirrup(f'{fid}-ST', fid, B.stirrup_length(sb, sd, cov_c, td), (int(ln / sc) + 1) * n, td)
            det.append('{}: {} x {}x{} x {}mm'.format(fid, n, int(sb), int(sd), int(round(ln))))
        if conc > 0 or sst.tot > 0:
            sm['conc'] = round(conc, 3)
            sm['shutter'] = round(shutter, 2)
            sm['grade'] = sch.get('concrete_grade') or 'M25'
            sm['tk_note'] = 'stub columns from footing rows (pedestal/footing top to plinth)'
            sm['detail'] = ['foundation package: column stubs to plinth - ' + '; '.join(det)]
            sm['_st'] = sst
            _fin = _finalize(sm, 1)
            _ci = next((k for k, _m in enumerate(members) if _m['cat'] == 'Columns'), len(members))
            members.insert(_ci, _fin)
    else:
        ssrc = 'typed'
        base_stub = 0
        if stub_mm <= 0:
            cands = []
            for f in sch.get('footings', []):
                v = _n(f.get('depth'), 1500) - _n(f.get('t'), 600) - _n(f.get('ped_h'), 0)
                if v > 0:
                    cands.append(int(round(v)))
            base_stub = max(cands) if cands else 0
            stub_mm = base_stub + plinth_mm
            ssrc = 'auto'
        if stub_mm >= 50 and sch.get('columns'):
            sm = _member('Footings', 'STUB', 'column below plinth (foundation)', 1)
            sst = Steel()
            conc = shutter = 0.0
            for c in sch['columns']:
                n = int(_n(c.get('count'), 0) or 0)
                if n <= 0:
                    continue
                b, dd = _n(c.get('b'), 300), _n(c.get('d'), 450)
                conc += _m3(b, dd, stub_mm) * n
                shutter += 2 * (b + dd) * stub_mm / 1e6 * n
                fl0 = (B.parse_nodia(c.get('main')) or [(8, 16)])[0]
                sst.bar(f"{c['id']}-SM", c['id'], fl0[0] * n, (stub_mm + LAP * fl0[1]) / 1000.0, fl0[1])
                td, sc, _smm = B.parse_tie(c.get('tie'))
                sst.stirrup(f"{c['id']}-ST", c['id'], B.stirrup_length(b, dd, cov_c, td), (int(stub_mm / sc) + 1) * n, td)
            sm['conc'] = round(conc, 3)
            sm['shutter'] = round(shutter, 2)
            sm['grade'] = sch.get('concrete_grade') or 'M25'
            sm['tk_note'] = 'all columns x {}mm below plinth ({}: footing part {} + plinth {})'.format(stub_mm, ssrc, base_stub, plinth_mm)
            sm['detail'] = ['foundation package: pedestal/footing top to plinth level, {}mm ({}: depth-t-ped {} + plinth {}); floor columns start at plinth'.format(stub_mm, ssrc, base_stub, plinth_mm)]
            sm['_st'] = sst
            _fin = _finalize(sm, 1)
            _ci = next((k for k, _m in enumerate(members) if _m['cat'] == 'Columns'), len(members))
            members.insert(_ci, _fin)   # sits with the footings = foundation package

    # chairs / spacers: 1 no per m2 of slab area (10mm, 0.55m long, ~0.35 kg each)
    slab_area = sum(m['shutter'] for m in members if m['cat'] == 'Slabs')
    if slab_area > 0:
        ch = _member('Chairs & Spacers', 'CHAIR', 'chairs (auto)', 1)
        chst = Steel()
        chst.bar('CH-10', 'MISC', int(slab_area), 0.55, 10)
        ch['_st'] = chst; ch['detail'] = ['1 no/m2 of slab (auto), 10mm @ 0.55m']
        members.append(_finalize(ch, 1))
    summary = OrderedDict()
    for m in members: summary.setdefault(m['cat'], []).append(m)

    def item(code, desc, unit, qty, rk, rate=None):
        r = rates.get(rk, 0) if rate is None else rate
        return {'code': code, 'desc': desc, 'unit': unit, 'qty': round(qty, 3),
                'rate': r, 'amount': round(qty * r, 2)}

    tot_conc_tmp = sum(m['conc'] for m in members)
    groups = OrderedDict([('1. Earthwork', []), ('2. PCC & Soling', []), ('2A. Trench Wall Masonry', []), ('3. RCC Concrete', []),
                          ('4. TMT Steel (BBS)', []), ('5. Shuttering', []),
                          ('6. Water Retaining & Misc', [])])
    takeoff = []
    def _tk(group, desc, unit, qty, take=None, note=''):
        takeoff.append({'group': group, 'desc': desc, 'nos': (take or (None,))[0] if take else None,
                        'L': take[1] if take else None, 'B': take[2] if take and len(take) > 2 else None,
                        'D': take[3] if take and len(take) > 3 else None,
                        'unit': unit, 'qty': round(qty, 3), 'note': note})
    for m in members:
        sr = SOIL_RATE.get(m.get('soil', 'soft soil'), 450)
        dm = m.get('dims')
        if m['exc'] > 0:
            it = item('', f"Excavation ({m.get('soil','soft soil')}) - {m['label']}", 'cum', m['exc'], 'excavation_m3')
            groups['1. Earthwork'].append(it)
            _tk('1. Earthwork', f"Excavation - {m['label']}", 'cum', m['exc'],
                m.get('exc_dims') or dm,
                ('plan + 300mm working space x depth'
                 + (' + pedestal excavation' if m.get('ped_dims') else '')) if m.get('exc_dims')
                else ('plan size + 300mm working space each side x depth' if dm else ''))
            it['tk'] = [len(takeoff) - 1]
        if m['backfill'] > 0: groups['1. Earthwork'].append(item('', f"Refilling - {m['label']}", 'cum', m['backfill'], 'backfill_m3'))
        if m['pcc'] > 0:
            _pr = _pcc_mix_rate(pcc_mix, rates, sch.get('mix_rates'))
            it = item('', f"{pcc_mix} - {m['label']}", 'cum', m['pcc'], 'pcc_m3', rate=_pr)
            if _pr != rates.get('pcc_m3', 9500):
                it['note'] = f'your rate for {pcc_mix}'
            groups['2. PCC & Soling'].append(it)
            _tk('2. PCC & Soling', f"PCC 75mm bed - {m['label']}", 'cum', m['pcc'],
                m.get('pcc_dims') or dm, 'footprint + 150mm offset x 75mm bed' if dm and not m.get('pcc_dims') else '')
            it['tk'] = [len(takeoff) - 1]
        if m['soling'] > 0: groups['2. PCC & Soling'].append(item('', f"Soling - {m['label']}", 'cum', m['soling'], 'soling_m3'))
        if m.get('masonry', 0) > 0:
            rk = 'stone_masonry_m3' if 'stone' in str(m['kind']).lower() else 'brick_masonry_m3'
            it = item('', f"{m['kind']} - trench wall up to plinth - {m['label']}", 'cum', m['masonry'], rk)
            groups['2A. Trench Wall Masonry'].append(it)
            dm_ = m.get('dims')
            _tk('2A. Trench Wall Masonry', f"Trench wall - {m['label']}", 'cum', m['masonry'], dm_,
                'length net of footing pits x wall thickness x height (trench bottom to plinth beam)')
            it['tk'] = [len(takeoff) - 1]
        if m['conc'] > 0:
            _g = m.get('grade', grade_default)
            _gr = _grade_rate(_g, rates, sch.get('grade_rates'))
            it = item('', f"RCC {_g} - {m['label']}", 'cum', m['conc'], 'rcc_m3', rate=_gr)
            if _gr != rates.get('rcc_m3', 16500):
                it['note'] = f'your rate for grade {_g}'
            groups['3. RCC Concrete'].append(it)
            if dm and m.get('ped_dims'):
                pd_ = m['ped_dims']
                _tk('3. RCC Concrete', f"Footing slab - {m['label']}", 'cum',
                    round(dm[0]*dm[1]*dm[2]*dm[3], 3), dm, 'nos x L x B x thickness')
                _tk('3. RCC Concrete', f"Pedestal - {m['label']}", 'cum',
                    round(pd_[0]*pd_[1]*pd_[2]*pd_[3], 3), pd_, 'nos x b x d x height')
                it['tk'] = [len(takeoff) - 2, len(takeoff) - 1]
            else:
                _tk('3. RCC Concrete', f"RCC {m.get('grade',grade_default)} - {m['label']}", 'cum', m['conc'], dm,
                    m.get('tk_note') or ('nos x L x B x D (member size)' if dm else ''))
                it['tk'] = [len(takeoff) - 1]
        if m['steel'] > 0:
            it = item('', f"Steel (incl 3% wastage) - {m['label']}", 'kg', m['steel'], 'steel_kg')
            groups['4. TMT Steel (BBS)'].append(it)
            _tk('4. TMT Steel (BBS)', f"Steel - {m['label']}", 'kg', m['steel'], None, 'from BBS cutting list + 3% wastage - see BBS sheet')
            it['tk'] = [len(takeoff) - 1]
        if m['shutter'] > 0:
            it = item('', f"Shuttering - {m['label']}", 'sqm', m['shutter'], 'shuttering_m2')
            groups['5. Shuttering'].append(it)
            _tk('5. Shuttering', f"Shuttering - {m['label']}", 'sqm', m['shutter'], None,
                'contact surface of member (sides + soffit)')
            it['tk'] = [len(takeoff) - 1]
        # auto weep holes for retaining / trench walls @ 1.5m c/c both ways
        if m['cat'] == 'Retaining / Trench Walls' and m.get('weep_area', 0) > 0:
            import math as _math
            n_w = int(_math.ceil(m['weep_area'] / 2.25))
            groups['6. Water Retaining & Misc'].append(
                item('', f"Weep holes 50mm PVC @1.5m c/c (auto) - {m['label']}", 'nos', n_w, None, rate=WEEP_RATE))
    # water retaining / misc items from the form
    for r in sch.get('others', []):
        q = float(r.get('qty', 0) or 0)
        if q <= 0:
            continue
        it = r.get('item', '')
        for k, (unit, rt) in OTHER.items():
            if k in it or it in k:
                groups['6. Water Retaining & Misc'].append(item('', k, unit, q, None, rate=rt))
                break
    # concrete pumping (RMC) as an adder over the composite rate
    pump = (sch.get('concrete_pumping') or 'none').strip().lower()
    if pump in PUMP_RATE and tot_conc_tmp > 0:
        groups['6. Water Retaining & Misc'].append(
            item('', f"Concrete pumping - {pump} (RMC adder)", 'cum', tot_conc_tmp, None, rate=PUMP_RATE[pump]))
    grand = 0.0
    for gi, (gname, items) in enumerate(groups.items(), 1):
        for i, it in enumerate(items, 1): it['code'] = f"{gi}.{i}"
        sub = sum(it['amount'] for it in items); grand += sub
        groups[gname] = {'items': items, 'subtotal': round(sub, 2)}

    # ---- BBS table (built first: it is the single source of truth for steel) ----
    bbs_rows = []
    for m in members:
        for b in m.get('bbs', []):
            bbs_rows.append(b)

    tot = {k: round(sum(m.get(k, 0) for m in members), 2) for k in ('conc', 'pcc', 'exc', 'backfill', 'soling', 'shutter', 'masonry')}
    # Steel: BBS is the single source of truth. Net = sum of all cutting-list row
    # weights; gross = net x 3% wastage. This guarantees BOQ == materials == BBS total.
    bbs_net = round(sum(b['weight'] for b in bbs_rows), 1)
    tot['steel'] = round(bbs_net * WASTE_STEEL, 1)

    # ---- steel by diameter (net from full-quantity BBS, +3% wastage for ordering) ----
    bydia = {}
    bylen = {}
    for b in bbs_rows:
        bydia[b['dia']] = bydia.get(b['dia'], 0) + b['weight']
        bylen[b['dia']] = bylen.get(b['dia'], 0) + b['total_len']
    bydia = {d: round(v * WASTE_STEEL, 1) for d, v in sorted(bydia.items())}
    # 12m stock lengths to order per diameter
    import math as _m2
    bars12 = {d: int(_m2.ceil(v / 12.0)) for d, v in sorted(bylen.items())}

    # ---- rate analysis (per m³ RCC) ----
    cem, sand, agg = _mix_breakup(tot['conc'] * WASTE_CONC, grade_default)
    rate_analysis = {
        'cement_bags': round(cem, 1), 'sand_m3': round(sand, 2), 'agg_m3': round(agg, 2),
        'steel_kg_per_m3': round(tot['steel'] / (tot['conc'] or 1), 0),
        'rcc_rate': rates.get('rcc_m3', 16500), 'steel_rate': rates.get('steel_kg', 150),
        'shutter_rate': rates.get('shuttering_m2', 850),
        'cost_per_m3_rcc': round(rates.get('rcc_m3', 16500) + (tot['steel']/(tot['conc'] or 1))*rates.get('steel_kg',150)
                                  + (tot['shutter']/(tot['conc'] or 1))*rates.get('shuttering_m2',850), 0),
        'cost_per_sqft': 0,
    }

    # ---- labour estimate (day-rates editable via sch['labour_rates']) ----
    lr = sch.get('labour_rates') or {}
    rm = lr.get('mason') or LABOUR['rate_mason']
    rz = lr.get('mazdoor') or LABOUR['rate_mazdoor']
    sf = lr.get('steel_fab') or 1400
    md = round(tot['conc'] * LABOUR['mason_per_m3'], 0)
    zd = round(tot['conc'] * LABOUR['mazdoor_per_m3'], 0)
    labour = {
        'mason_days': md, 'mazdoor_days': zd,
        'steel_fab_days': round(tot['steel'] / 100 * STEEL_FAB, 0),
        'mason_cost': round(md * rm, 0), 'mazdoor_cost': round(zd * rz, 0),
    }
    labour_rates = {'mason': rm, 'mazdoor': rz, 'steel_fab': sf}

    from estimation.norms import CONCRETE_GRADES, PCC_MIXES as NPM
    pc, ps, pa = _mix_breakup(tot['pcc'] * WASTE_CONC, grade_default)

    return {
        'project': {'name': sch['project_name'], 'location': sch['location']},
        'params': {k: sch[k] for k in ('concrete_grade', 'pcc_mix', 'floor_height', 'floors_above')},
        'groups': groups, 'member_summary': summary,
        'totals': {'concrete_m3': tot['conc'], 'pcc_m3': tot['pcc'], 'excavation_m3': tot['exc'],
                   'backfill_m3': tot['backfill'], 'soling_m3': tot['soling'], 'shuttering_m2': tot['shutter'],
                   'steel_kg': tot['steel']},
        'bbs_table': bbs_rows,
        'steel_by_dia': bydia,
        'steel_bars12': bars12,
        'rate_analysis': rate_analysis,
        'labour': labour,
        'labour_rates': labour_rates,
        'materials': {'cement_bags': round(cem + pc, 1), 'sand_m3': round(sand + ps, 2),
                      'aggregate_m3': round(agg + pa, 2), 'steel_kg': tot['steel'],
                      'waste_steel_pct': 3, 'waste_conc_pct': 5},
        'grand_total': round(grand, 2),
        'takeoff': takeoff,
    }


DEFAULT_SCHEDULE = {
    'project_name': 'Detailed RCC Structural Estimate', 'location': 'Kathmandu',
    'concrete_grade': 'M25', 'pcc_mix': 'PCC 1:4:8', 'floor_height': 3000, 'floors_above': 3, 'col_below_gl': 0,
    'confinement_lo': 450, 'cover_footing': 50, 'cover_column': 40, 'cover_beam': 25, 'cover_slab': 20,
    'tw_type': 'none', 'tw_length': 0, 'tw_depth': 0, 'tw_wall_t': 0, 'tw_plinth_h': 0.45,
    'grade_rates': {}, 'mix_rates': {},
    'rates': {'rcc_m3': 16500, 'pcc_m3': 9500, 'excavation_m3': 450, 'backfill_m3': 400,
              'soling_m3': 3500, 'shuttering_m2': 850, 'steel_kg': 150,
              'stone_masonry_m3': 7500, 'brick_masonry_m3': 9500},
    'labour_rates': {'mason': 1200, 'mazdoor': 800, 'steel_fab': 1400},
    'footings': [
        {'id': 'F1', 'kind': 'isolated', 'count': 10, 'L': 1800, 'W': 1800, 't': 450, 'depth': 1500,
         'soling_t': 75, 'soil': 'soft soil', 'grade': 'M25', 'mesh': '12-150',
         'ped_b': 300, 'ped_d': 450, 'ped_h': 600, 'ped_main': '8-16', 'ped_tie': '8-150'},
        {'id': 'F2', 'kind': 'isolated', 'count': 4, 'L': 1500, 'W': 1500, 't': 450, 'depth': 1500,
         'soling_t': 75, 'soil': 'hard soil', 'grade': 'M25', 'mesh': '12-150',
         'ped_b': 300, 'ped_d': 375, 'ped_h': 600, 'ped_main': '6-16', 'ped_tie': '8-150'},
        {'id': 'CF1', 'kind': 'combined', 'count': 1, 'L': 4500, 'W': 2200, 't': 600, 'depth': 1800,
         'soling_t': 75, 'soil': 'soft soil', 'grade': 'M25', 'mesh': '16-150'},
    ],
    'columns': [
        {'id': 'C1', 'count': 6, 'b': 300, 'd': 450, 'main': '20-16, 16-16, 12-16', 'tie': '8-100-200', 'grade': 'M25'},
        {'id': 'C2', 'count': 10, 'b': 300, 'd': 375, 'main': '12-16, 10-16, 8-16', 'tie': '8-100-200', 'grade': 'M25'},
    ],
    'beams': [
        {'id': 'PB1', 'kind': 'plinth beam', 'count': 14, 'b': 230, 'd': 350, 'length': 4000,
         'top': '2-12', 'bottom': '2-12', 'tie': '8-150', 'grade': 'M20'},
        {'id': 'B1', 'kind': 'primary', 'count': 14, 'b': 230, 'd': 450, 'length': 4000,
         'top': '3-16', 'bottom': '3-16', 'extra_top': '1-16', 'tie': '8-100-150', 'grade': 'M25'},
        {'id': 'SB1', 'kind': 'secondary', 'count': 10, 'b': 230, 'd': 300, 'length': 3000,
         'top': '2-12', 'bottom': '2-12', 'tie': '8-125-150', 'grade': 'M25'},
        {'id': 'LB1', 'kind': 'lintel', 'count': 20, 'b': 230, 'd': 200, 'length': 1500,
         'top': '2-10', 'bottom': '2-10', 'tie': '8-150', 'grade': 'M20'},
    ],
    'slabs': [{'id': 'S1', 'area': 108, 't': 125, 'type': 'two-way slab', 'mesh': '10-150',
               'top_mesh': '', 'grade': 'M25'},
              {'id': 'S2', 'area': 18, 't': 150, 'type': 'sunken slab (toilet)', 'mesh': '10-150',
               'top_mesh': '10-200', 'grade': 'M25'}],
    'shearwalls': [{'id': 'SW1', 'length': 6000, 't': 200, 'height': 9000, 'vertical': '12-150', 'horizontal': '10-150', 'grade': 'M25'}],
    'retwalls': [{'id': 'RW1', 'length': 12000, 'stem_t': 250, 'stem_h': 3000, 'base_b': 2000, 'base_t': 300, 'vert': '12-150', 'horiz': '10-150', 'base_mesh': '12-150', 'grade': 'M25'}],
    'staircase': [{'id': 'ST1', 'flights': 3, 'run': 3600, 'width': 1200, 'waist': 150, 'mesh': '10-150',
                  'type': 'dog-legged', 'tread': 300, 'riser': 150,
                  'landings': 2, 'landing_L': 1200, 'landing_W': 2400, 'landing_t': 150}],
    'tanks': [
        {'id': 'WT1', 'kind': 'overhead tank', 'L': 1800, 'W': 1800, 'depth': 1400,
         'wall_t': 125, 'base_t': 150, 'cover_t': 100, 'wall_mesh': '10-150',
         'base_mesh': '10-150', 'grade': 'M25'},
        {'id': 'SUMP1', 'kind': 'underground sump', 'L': 3000, 'W': 2000, 'depth': 1500,
         'wall_t': 150, 'base_t': 200, 'cover_t': 125, 'wall_mesh': '10-150',
         'base_mesh': '10-150', 'grade': 'M25'},
    ],
    'ramps': [
        {'id': 'RMP1', 'length': 6000, 'width': 3000, 'thickness': 150, 'mesh': '10-150',
         'side_wall_h': 300, 'side_wall_t': 150, 'grade': 'M25'},
    ],
    'lifts': [
        {'id': 'LIFT1', 'L': 2200, 'W': 2000, 'pit_depth': 1800, 'core_height': 9900,
         'wall_t': 175, 'base_t': 300, 'mesh': '10-150', 'grade': 'M30'},
    ],
    'others': [
        {'item': 'cement-based waterproofing (sunken slab/toilet)', 'qty': 36},
        {'item': 'bitumen coat 2 coats (retaining wall backface)', 'qty': 36},
    ],
    'concrete_pumping': 'none',
}


if __name__ == '__main__':
    import json
    res = estimate_structural(DEFAULT_SCHEDULE)
    print('GRAND TOTAL NPR', f"{res['grand_total']:,.0f}")
    print('Concrete:', res['totals']['concrete_m3'], 'm³ | Steel:', res['totals']['steel_kg'], 'kg')
    print('BBS rows:', len(res['bbs_table']))
    print('Labour: mason', res['labour']['mason_days'], 'days, mazdoor', res['labour']['mazdoor_days'], 'days')
    print('Rate analysis: cost/m³ NPR', f"{res['rate_analysis']['cost_per_m3_rcc']:,.0f}")
    print('\nBBS sample (first 8):')
    for b in res['bbs_table'][:8]:
        print(f"  {b['mark']:8} {b['member']:4} ∅{b['dia']:2} x{b['count']:3} cut={b['cut_len']:6.2f}m  wt={b['weight']:7.1f}kg")
