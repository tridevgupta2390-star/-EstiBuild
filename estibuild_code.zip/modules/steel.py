"""Steel Structure module — complete fabrication-grade estimation.

Sections: hot-rolled (ISMB/ISHB/ISMC/ISA), built-up & plated girders (computed from
plate geometry + stiffener %), hollow (SHS/RHS/CHS), cold-formed (Z/C/lipped).
Plus: metal decking, bracing, connection plates, HSFG/black/anchor bolts, welds,
surface protection (primer/epoxy/galvanizing/fireproofing), and services.
All rates composite (material + fabrication + erection) per kg unless noted.
"""
from modules.common import NUM, ro, Estimate

# ---------------------------------------------------------------- section library (kg/m)
SECTION_UW = {
    # British UB/UC + European HEB (UAE/Gulf standard sections)
    'UB 254x146x31': 31.1, 'UB 305x165x40': 40.3, 'UB 356x171x45': 45.0,
    'UB 406x178x60': 59.5, 'UB 457x191x67': 67.1, 'UB 533x210x82': 82.2,
    'UC 203x203x46': 46.1, 'UC 254x254x63': 63.0, 'UC 305x305x97': 97.0,
    'HEB 200': 61.3, 'HEB 250': 82.3, 'HEB 300': 117.0, 'HEB 400': 155.0,

    # ISMB medium beams
    'ISMB 100': 11.5, 'ISMB 125': 12.7, 'ISMB 150': 14.9, 'ISMB 175': 19.6,
    'ISMB 200': 24.2, 'ISMB 225': 31.2, 'ISMB 250': 37.3, 'ISMB 300': 46.0,
    'ISMB 350': 52.4, 'ISMB 400': 61.6, 'ISMB 450': 72.4, 'ISMB 500': 86.9,
    'ISMB 550': 103.0, 'ISMB 600': 122.6,
    # ISHB heavy beams / columns
    'ISHB 150': 33.0, 'ISHB 200': 63.2, 'ISHB 250': 85.6, 'ISHB 300': 117.9,
    'ISHB 350': 137.3, 'ISHB 400': 157.5, 'ISHB 450': 172.6,
    # ISMC channels
    'ISMC 75': 6.8, 'ISMC 100': 9.6, 'ISMC 125': 12.7, 'ISMC 150': 16.4,
    'ISMC 175': 19.6, 'ISMC 200': 22.1, 'ISMC 225': 25.9, 'ISMC 250': 30.4,
    'ISMC 300': 36.3, 'ISMC 350': 42.5, 'ISMC 400': 49.4,
    # ISA equal angles
    'ISA 40x40x5': 3.0, 'ISA 50x50x6': 4.5, 'ISA 60x60x6': 5.4, 'ISA 65x65x6': 5.8,
    'ISA 70x70x6': 6.3, 'ISA 75x75x6': 6.8, 'ISA 75x75x8': 9.0, 'ISA 80x80x8': 9.7,
    'ISA 90x90x8': 10.9, 'ISA 100x100x8': 12.1, 'ISA 100x100x10': 15.0,
    'ISA 120x120x10': 18.1, 'ISA 130x130x10': 19.7, 'ISA 150x150x12': 27.2,
    # ISA unequal angles
    'ISA 75x50x6': 5.7, 'ISA 100x75x8': 10.6, 'ISA 125x75x8': 12.0,
    'ISA 150x75x8': 13.9, 'ISA 150x75x10': 17.2, 'ISA 200x100x12': 29.0,
    # SHS square hollow
    'SHS 40x40x2': 2.3, 'SHS 50x50x2': 2.9, 'SHS 60x60x3': 5.1, 'SHS 80x80x3': 7.2,
    'SHS 100x100x3': 8.9, 'SHS 100x100x4': 11.7, 'SHS 120x120x4': 14.1,
    'SHS 150x150x4': 17.8, 'SHS 150x150x5': 21.9, 'SHS 200x200x5': 30.2,
    'SHS 200x200x6': 35.8, 'SHS 250x250x6': 45.1,
    # RHS rectangular hollow
    'RHS 60x40x2': 2.9, 'RHS 80x40x3': 5.2, 'RHS 100x50x3': 6.5, 'RHS 100x50x4': 8.4,
    'RHS 120x60x4': 10.4, 'RHS 150x100x4': 14.4, 'RHS 150x100x5': 17.8,
    'RHS 200x100x5': 21.9, 'RHS 200x120x6': 28.5,
    # CHS circular hollow
    'CHS 48.3x3.2': 3.6, 'CHS 60.3x3.6': 5.0, 'CHS 76.1x4': 7.1, 'CHS 88.9x4': 8.3,
    'CHS 114.3x4': 10.9, 'CHS 139.7x5': 16.6, 'CHS 168.3x5': 19.8,
    # cold-formed purlin sections
    'Z 150x2.0': 4.9, 'C 150x2.0': 4.7, 'Z 200x2.5': 7.7, 'C 200x2.5': 7.4,
    'Z 250x3.0': 11.5, 'C 250x3.0': 11.0, 'Lipped C 200x2': 7.2, 'Hat 200x2': 7.0,
}
SECTION_LIST = sorted(SECTION_UW.keys())

# ---------------------------------------------------------------- rates (NPR base, composite)
ROLLED = 185      # /kg hot-rolled fabricated+erected
BUILTUP = 195     # /kg built-up plated girders
HOLLOW = 200      # /kg tubular
COLD = 175        # /kg cold-formed
BRACE = 190       # /kg bracing rods/angles
PLATE = 165       # /kg connection plates
DECK = {'composite deck 50mm': 1150, 'composite deck 60mm': 1290,
        'trapezoidal deck 1.0mm': 950, 'trapezoidal deck 1.2mm': 1120,
        'corrugated GI 0.5mm': 720, 'corrugated GI 0.63mm': 860}   # /sqm fixed
DECK_WT = {'composite deck 50mm': 12.5, 'composite deck 60mm': 14.8,
           'trapezoidal deck 1.0mm': 12.0, 'trapezoidal deck 1.2mm': 14.4,
           'corrugated GI 0.5mm': 4.4, 'corrugated GI 0.63mm': 5.5}  # kg/sqm
BOLT = {'HSFG bolt M16 (kit)': 280, 'HSFG bolt M20 (kit)': 350, 'HSFG bolt M24 (kit)': 480,
        'Black bolt M16': 60, 'Black bolt M20': 85, 'Black bolt M24': 120,
        'Anchor/foundation bolt M20': 180, 'Anchor/foundation bolt M24': 260,
        'Shear stud 19mm': 120, 'Fillet weld 6mm': 85, 'Fillet weld 8mm': 110,
        'Butt weld (per m)': 150, 'non-shrink base grout (25kg bag)': 1850}   # per set / per rmt for welds
PROT = {'red oxide primer 2 coats': 6.0, 'epoxy zinc-rich 2 coats': 12.0,
        'PU top coat (3-coat system)': 8.0, 'hot-dip galvanizing': 28.0,
        'intumescent fireproofing': 40.0}    # per kg of steel
SVC = {'shop & erection drawings': 25000, 'trial assembly': 15000,
       'testing & QA (NDT, torque)': 20000, 'site painting touch-up': 8000}  # lump sum

BU_KINDS = ['plate girder', 'built-up I beam', 'castellated beam', 'hybrid girder', 'box girder']


def _uw(sec, row=None):
    if row is not None and NUM(row.get('uw')) > 0:
        return NUM(row.get('uw'))
    return SECTION_UW.get(str(sec).strip(), 25.0)


def estimate(sched):
    T = sched['tables']
    est = Estimate({})
    tot_kg = 0.0

    # ---- 1. hot-rolled ----
    for r in T['rolled']:
        L, n = NUM(r.get('length')), NUM(r.get('count'))
        if not (L and n):
            continue
        sec = r.get('section', 'ISMB 300')
        w = _uw(sec, r) * L * n
        est.item('1. Hot-Rolled Sections', f"{sec} - {r.get('id','')} ({L}m x {n} nos)", 'kg', round(w, 1),
                 rate=ro(r, ROLLED), take=(n, L, None, None, round(_uw(sec, r), 2)), note='nos x length x unit wt (kg/m) = kg')
        est.mat('steel_kg', 'Structural Steel (total)', w, 'kg', 185)
        tot_kg += w

    # ---- 2. built-up & plated ----
    for r in T['builtup']:
        L, n = NUM(r.get('length')), NUM(r.get('count'))
        if not (L and n):
            continue
        wd, wt = NUM(r.get('web_d'), 1000), NUM(r.get('web_t'), 8)
        fw, ft = NUM(r.get('flange_w'), 300), NUM(r.get('flange_t'), 16)
        area = wd * wt + 2 * fw * ft            # mm2
        kgm = area * 7.85e-3 * 1.12             # +12% stiffeners/bearing
        w = kgm * L * n
        est.item('2. Built-Up & Plated Beams',
                 f"{r.get('type','plate girder')} (web {wd}x{wt}, flange {fw}x{ft}) - {r.get('id','')} ({L}m x {n})",
                 'kg', round(w, 1), rate=ro(r, BUILTUP),
                 take=(n, L, None, None, round(kgm, 1)), note='nos x length x unit wt (kg/m, built-up incl. 12% stiffeners) = kg')
        est.mat('steel_kg', 'Structural Steel (total)', w, 'kg', 185)
        tot_kg += w

    # ---- 3. hollow ----
    for r in T['hollow']:
        L, n = NUM(r.get('length')), NUM(r.get('count'))
        if not (L and n):
            continue
        sec = r.get('section', 'SHS 100x100x4')
        w = _uw(sec, r) * L * n
        est.item('3. Hollow Sections (Tubular)', f"{sec} - {r.get('id','')} ({L}m x {n} nos)", 'kg', round(w, 1),
                 rate=ro(r, HOLLOW), take=(n, L, None, None, round(_uw(sec, r), 2)), note='nos x length x unit wt (kg/m) = kg')
        est.mat('steel_kg', 'Structural Steel (total)', w, 'kg', 185)
        tot_kg += w

    # ---- 4. cold-formed ----
    for r in T['coldformed']:
        L, n = NUM(r.get('length')), NUM(r.get('count'))
        if not (L and n):
            continue
        sec = r.get('section', 'Z 200x2.5')
        w = _uw(sec, r) * L * n
        est.item('4. Cold-Formed Sections', f"{sec} - {r.get('id','')} ({L}m x {n} nos)", 'kg', round(w, 1),
                 rate=ro(r, COLD), take=(n, L, None, None, round(_uw(sec, r), 2)), note='nos x length x unit wt (kg/m) = kg')
        est.mat('steel_kg', 'Structural Steel (total)', w, 'kg', 185)
        tot_kg += w

    # ---- 5. decking ----
    for r in T['decking']:
        a = NUM(r.get('area'))
        if not a:
            continue
        prof = r.get('profile', 'composite deck 50mm')
        est.item('5. Metal Decking', f"{prof} - {r.get('id','')} (incl. fixing)", 'sqm', a, rate=ro(r, DECK.get(prof, 950)),
                 take=((NUM(r.get('count'),1) or 1), NUM(r.get('length')), NUM(r.get('width')), None))
        est.mat('deck_m2', 'Metal Decking', a, 'sqm', DECK.get(prof, 950))
        tot_kg += a * DECK_WT.get(prof, 12.0)

    # ---- 6. bracing ----
    for r in T['bracing']:
        L, n = NUM(r.get('length')), NUM(r.get('count'))
        if not (L and n):
            continue
        sec = r.get('section', 'ISA 100x100x10')
        w = _uw(sec, r) * L * n
        est.item('6. Bracing & Ties', f"{r.get('type','cross bracing')} - {sec} ({L}m x {n})", 'kg', round(w, 1),
                 rate=ro(r, BRACE), take=(n, L, None, None, round(_uw(sec, r), 2)), note='nos x length x unit wt (kg/m) = kg')
        est.mat('steel_kg', 'Structural Steel (total)', w, 'kg', 185)
        tot_kg += w

    # ---- 7. connection plates ----
    for r in T['connections']:
        q = NUM(r.get('qty'))
        if not q:
            continue
        est.item('7. Connections & Plates', f"{r.get('type','gusset plate')} - {r.get('spec','')}".strip(' -'),
                 'kg', q, rate=ro(r, PLATE), take=(q, None, None, None), note='plate weight as entered (thk x L x B x 7850)')
        est.mat('steel_kg', 'Structural Steel (total)', q, 'kg', 185)
        tot_kg += q

    # ---- 8. bolts & welds ----
    for r in T['fasteners']:
        q = NUM(r.get('qty'))
        if not q:
            continue
        t = r.get('type', 'HSFG bolt M20 (kit)')
        unit = 'rmt' if 'weld' in t else 'nos'
        est.item('8. Bolts, Welds & Fasteners', t, unit, q, rate=ro(r, BOLT.get(t, 100)), take=(q, None, None, None), note='quantity')

    # ---- 9. protection ----
    for r in T['protection']:
        q = NUM(r.get('qty'))
        if not q:
            continue
        sysname = r.get('system', 'red oxide primer 2 coats')
        est.item('9. Surface Protection', f"{sysname} (on {q:,.0f} kg steel)", 'kg', q,
                 rate=ro(r, PROT.get(sysname, 6.0)), take=(q, None, None, None), note='kg of steel treated')

    # ---- 11. steel staircases ----
    for r in T.get('staircases', []):
        nr = NUM(r.get('risers'))
        cnt = NUM(r.get('count'), 1) or 1
        w = NUM(r.get('width'), 1.0)
        if nr:
            it_type = r.get('type', 'spiral steel staircase')
            if 'ladder' in it_type.lower():
                q = nr * cnt
                est.item('11. Steel Staircases', f"{it_type} ({nr}m x {cnt} nos)",
                         'rmt', q, rate=ro(r, STEEL_STAIR.get(it_type, 3800)),
                         take=(cnt, nr, None, None), note='count x height (m)')
            else:
                q = nr * cnt
                est.item('11. Steel Staircases', f"{it_type} ({nr} risers x {cnt} nos, {w}m wide)",
                         'riser', q, rate=ro(r, STEEL_STAIR.get(it_type, 3000)),
                         take=(cnt, nr, None, None), note='count x risers')

    # ---- 10. services ----
    for r in T['services']:
        q = NUM(r.get('qty'), 1)
        if not q:
            continue
        it = r.get('item', 'testing & QA (NDT, torque)')
        est.item('10. Services & QA', it, 'job', q, rate=ro(r, SVC.get(it, 15000)), take=(q, None, None, None), note='jobs/quantity')

    # ---- labour (per tonne norms) ----
    tn = tot_kg / 1000.0
    fab_d = round(tn * 3, 0); weld_d = round(tn * 2, 0); erect_d = round(tn * 2.5, 0)
    paint_d = round(tn * 1.2, 0); help_d = round((fab_d + weld_d + erect_d + paint_d) * 1.2, 0)
    kpis = [('Total steel', f"{tot_kg/1000:,.2f} t"), ('Total weight', f"{tot_kg:,.0f} kg")]
    if T['decking']:
        kpis.append(('Decking', f"{sum(NUM(r.get('area'),0) for r in T['decking']):,.0f} m²"))
    proj = {'name': sched['scalars'].get('project_name', ''), 'location': sched['scalars'].get('location', '')}
    res = est.result(project=proj, kpis=kpis)
    from modules.common import LABOUR_RATES as _LR
    _lrd = sched.get('labour_rates') or {}
    res['labour_rates'] = {k: _lrd.get(k) or _LR[k] for k in ['steel_fab', 'welder', 'erector', 'painter', 'helper']}
    res['labour'] = {
        'steel_fab_days': int(fab_d), 'welder_days': int(weld_d), 'erector_days': int(erect_d),
        'painter_days': int(paint_d), 'helper_days': int(help_d),
        'total_days': int(fab_d + weld_d + erect_d + paint_d + help_d),
    }
    return res



# ---- steel staircases ----
STEEL_STAIR = {
    'spiral steel staircase': 3800,
    'straight flight (stringer + chequered plate)': 2500,
    'dog-leg with mid-landing': 3000,
    'fire escape (with cage + platform)': 4200,
    'cat ladder / ship ladder': 8500,
    'steel stair with grating treads': 2800,
}

SPEC = {
    'id': 'steel', 'title': 'Steel Structure', 'color': '#5d6d7e', 'icon': '🏭',
    'intro': ('Complete steel structure estimation: hot-rolled sections (ISMB/ISHB/ISMC/ISA), '
              'built-up plated girders, hollow & cold-formed sections, metal decking, bracing, '
              'gussets & base plates, HSFG bolts & welds, galvanizing/painting, fabrication & erection.'),
    'upload_guide': [
        'Steel member schedule (section, length, count) from your GA drawings',
        'Truss/bracing layout + section sizes',
        'Connection details: base plates, gussets, bolt grades (HSFG/black/anchor)',
        'Spec: steel grade (Fe410/E250), bolt grade (8.8/10.9), paint or galvanizing system',
    ],
    'upload_note': 'Section weights auto-lookup from IS tables — override any row with your own kg/m.',
    'labour': ['steel_fab', 'welder', 'erector', 'painter', 'helper'],
    'scalars': [
        {'name': 'project_name', 'label': 'Project name', 'type': 'text', 'default': 'Steel Structure Estimate'},
        {'name': 'location', 'label': 'Location', 'type': 'text', 'default': 'Kathmandu'},
        {'name': 'steel_grade', 'label': 'Steel grade', 'type': 'select', 'default': 'Fe410 (E250)',
         'options': ['Fe410 (E250)', 'Fe490 (E350)', 'A36', 'S275', 'S355']},
        {'name': 'bolt_grade', 'label': 'Bolt grade', 'type': 'select', 'default': '8.8 HSFG',
         'options': ['8.8 HSFG', '10.9 HSFG', '4.6 black', '8.8 black']},
    ],
    'tables': [
        {'id': 'rolled', 'title': '1. Hot-Rolled Sections',
         'hint': 'weight auto from IS section tables', 'add_label': 'add section',
         'fields': [
             {'name': 'id', 'label': 'Mark', 'type': 'text'},
             {'name': 'section', 'label': 'Section', 'type': 'suggest', 'options': SECTION_LIST},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
             {'name': 'uw', 'label': 'kg/m (blank=auto)', 'type': 'number'},
             {'name': 'member', 'label': 'Use', 'type': 'select', 'default': 'beam',
              'options': ['beam', 'column', 'rafter', 'tie', 'gantry', 'other']},
         ],
         'default_rows': [
             {'id': 'C1', 'section': 'ISHB 200', 'length': 4.5, 'count': 8, 'member': 'column'},
             {'id': 'B1', 'section': 'ISMB 300', 'length': 6, 'count': 10, 'member': 'beam'},
             {'id': 'B2', 'section': 'ISMB 250', 'length': 4, 'count': 14, 'member': 'beam'},
             {'id': 'CH1', 'section': 'ISMC 200', 'length': 6, 'count': 12, 'member': 'tie'},
             {'id': 'BR1', 'section': 'ISA 75x75x8', 'length': 3.5, 'count': 24, 'member': 'other'},
         ]},
        {'id': 'builtup', 'title': '2. Built-Up & Plated Beams',
         'hint': 'weight computed from web + flange plates + 12% stiffeners', 'add_label': 'add built-up beam',
         'fields': [
             {'name': 'id', 'label': 'Mark', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select', 'default': 'plate girder', 'options': BU_KINDS},
             {'name': 'web_d', 'label': 'Web depth (mm)', 'type': 'number'},
             {'name': 'web_t', 'label': 'Web thk (mm)', 'type': 'number'},
             {'name': 'flange_w', 'label': 'Flange width (mm)', 'type': 'number'},
             {'name': 'flange_t', 'label': 'Flange thk (mm)', 'type': 'number'},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
         ],
         'default_rows': [
             {'id': 'PG1', 'type': 'plate girder', 'web_d': 1200, 'web_t': 10,
              'flange_w': 350, 'flange_t': 20, 'length': 12, 'count': 2},
         ]},
        {'id': 'hollow', 'title': '3. Hollow Sections — SHS / RHS / CHS',
         'hint': 'for tubular trusses, columns, braces', 'add_label': 'add hollow section',
         'fields': [
             {'name': 'id', 'label': 'Mark', 'type': 'text'},
             {'name': 'section', 'label': 'Section', 'type': 'suggest',
              'options': [s for s in SECTION_LIST if s[:3] in ('SHS', 'RHS', 'CHS')]},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
             {'name': 'uw', 'label': 'kg/m (blank=auto)', 'type': 'number'},
         ],
         'default_rows': [
             {'id': 'T1', 'section': 'SHS 100x100x4', 'length': 5, 'count': 16},
             {'id': 'T2', 'section': 'CHS 114.3x4', 'length': 6, 'count': 8},
         ]},
        {'id': 'coldformed', 'title': '4. Cold-Formed Sections',
         'hint': 'secondary members, purlin-line', 'add_label': 'add cold-formed',
         'fields': [
             {'name': 'id', 'label': 'Mark', 'type': 'text'},
             {'name': 'section', 'label': 'Section', 'type': 'suggest',
              'options': [s for s in SECTION_LIST if s[:1] in 'ZC' or 'Lipped' in s or 'Hat' in s]},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
             {'name': 'uw', 'label': 'kg/m (blank=auto)', 'type': 'number'},
         ],
         'default_rows': [
             {'id': 'P1', 'section': 'Z 200x2.5', 'length': 6, 'count': 40},
         ]},
        {'id': 'decking', 'title': '5. Metal Decking Sheets',
         'hint': 'composite or trapezoidal deck — rate per sqm incl. fixing', 'add_label': 'add decking',
         'fields': [
             {'name': 'id', 'label': 'Zone', 'type': 'text'},
             {'name': 'profile', 'label': 'Profile', 'type': 'select', 'default': 'composite deck 50mm',
              'options': sorted(DECK.keys())},
             {'name': 'area', 'label': 'Area (m²)', 'type': 'number'},
         ],
         'default_rows': [
             {'id': 'D1', 'profile': 'composite deck 50mm', 'area': 350},
         ]},
        {'id': 'bracing', 'title': '6. Bracing & Ties',
         'add_label': 'add bracing',
         'fields': [
             {'name': 'type', 'label': 'Type', 'type': 'select', 'default': 'cross bracing',
              'options': ['cross bracing', 'tie rod', 'sag rod', 'kicker brace', 'portal brace']},
             {'name': 'section', 'label': 'Section', 'type': 'suggest', 'options': SECTION_LIST},
             {'name': 'length', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
             {'name': 'uw', 'label': 'kg/m (blank=auto)', 'type': 'number'},
         ],
         'default_rows': [
             {'type': 'cross bracing', 'section': 'ISA 100x100x10', 'length': 8, 'count': 6},
         ]},
        {'id': 'connections', 'title': '7. Connections & Plates',
         'hint': 'enter plate weight in kg (plate area m² x thk mm x 7.85)', 'add_label': 'add plate/connection',
         'fields': [
             {'name': 'type', 'label': 'Type', 'type': 'select', 'default': 'base plate',
              'options': ['base plate', 'gusset plate', 'cleat angle', 'stiffener plate',
                          'end plate', 'splice plate', 'haunch bracket', 'shoe angle', 'chequered plate cover']},
             {'name': 'spec', 'label': 'Size (e.g. 500x400x20)', 'type': 'text'},
             {'name': 'qty', 'label': 'Weight (kg)', 'type': 'number'},
         ],
         'default_rows': [
             {'type': 'base plate', 'spec': '500x400x20mm', 'qty': 450},
             {'type': 'gusset plate', 'spec': 'various 10-12mm', 'qty': 600},
         ]},
        {'id': 'fasteners', 'title': '8. Bolts, Welds & Fasteners',
         'hint': 'welds measured in rmt (run metres), bolts in nos', 'add_label': 'add fastener/weld',
         'fields': [
             {'name': 'type', 'label': 'Item', 'type': 'suggest', 'options': sorted(BOLT.keys())},
             {'name': 'qty', 'label': 'Qty (nos or rmt)', 'type': 'number'},
         ],
         'default_rows': [
             {'type': 'HSFG bolt M20 (kit)', 'qty': 320},
             {'type': 'Fillet weld 6mm', 'qty': 180},
             {'type': 'Anchor/foundation bolt M24', 'qty': 32},
         ]},
        {'id': 'protection', 'title': '9. Surface Protection',
         'hint': 'qty = kg of steel treated', 'add_label': 'add protection',
         'fields': [
             {'name': 'system', 'label': 'System', 'type': 'select', 'default': 'red oxide primer 2 coats',
              'options': sorted(PROT.keys())},
             {'name': 'qty', 'label': 'Steel wt (kg)', 'type': 'number'},
         ],
         'default_rows': [
             {'system': 'red oxide primer 2 coats', 'qty': 12000},
         ]},
        {'id': 'staircases', 'title': '11. Steel Staircases',
         'add_label': 'Add steel staircase',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(STEEL_STAIR)},
                    {'name': 'risers', 'label': 'No. of risers (or m for ladder)', 'type': 'number'},
                    {'name': 'width', 'label': 'Width (m)', 'type': 'number'},
                    {'name': 'count', 'label': 'Nos', 'type': 'number'}],
         'default_rows': [{'type': 'spiral steel staircase', 'risers': 18, 'width': 1.2, 'count': 1}]},
                {'id': 'services', 'title': '10. Services & QA',
         'hint': 'lump-sum jobs', 'add_label': 'add service',
         'fields': [
             {'name': 'item', 'label': 'Item', 'type': 'suggest', 'options': sorted(SVC.keys())},
             {'name': 'qty', 'label': 'Jobs (1 normally)', 'type': 'number'},
         ],
         'default_rows': [
             {'item': 'shop & erection drawings', 'qty': 1},
             {'item': 'testing & QA (NDT, torque)', 'qty': 1},
         ]},
    ],
}

PDF_KEYWORDS = ['steel', 'truss', 'beam', 'column', 'girder', 'gusset', 'bolt', 'weld',
                'decking', 'purlin', 'bracing', 'galvaniz', 'ISHB', 'ISMB', 'ISMC', 'SHS', 'RHS']


# ---- market-rate resolver (pre-fills Rate boxes; same formula as calc) ----
from modules.common import make_row_rate as _mrr

def _stair_rr(r):
    t = r.get('type', 'spiral steel staircase')
    return STEEL_STAIR.get(t, 3800 if 'ladder' in str(t).lower() else 3000)

SPEC['row_rate'] = _mrr({
    'rolled': lambda r, s: ROLLED,
    'builtup': lambda r, s: BUILTUP,
    'hollow': lambda r, s: HOLLOW,
    'coldformed': lambda r, s: COLD,
    'decking': lambda r, s: DECK.get(r.get('profile'), 950),
    'bracing': lambda r, s: BRACE,
    'connections': lambda r, s: PLATE,
    'fasteners': lambda r, s: BOLT.get(r.get('type'), 100),
    'protection': lambda r, s: PROT.get(r.get('system'), 6.0),
    'staircases': lambda r, s: _stair_rr(r),
    'services': lambda r, s: SVC.get(r.get('item'), 15000),
})
SPEC['rate_cfg'] = {'decking': {}, 'fasteners': {}, 'protection': {}, 'staircases': {}, 'services': {}}
