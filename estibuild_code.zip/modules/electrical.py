"""Electrical - points, wiring by size, switchgear, fixtures, earthing, backup, LV."""
from modules.common import Estimate, NUM, ro

# ---- conduit accessories ----
CONDACC = {'junction box (PVC)': 80, 'junction box (metal)': 150, 'bend/concealed': 40, 'PVC saddle': 15, 'GI saddle': 25, 'adapter/bushing': 20, 'coupler': 15, 'cable lug (Cu)': 45, 'cable gland': 80, 'wire ferrule (per pt)': 5, 'cable tie': 3, 'GI flexible conduit (per m)': 120, 'cable marker/sleeve': 8}
# ---- motor control & automation ----
MOTOR = {'contactor (25A)': 2500, 'contactor (40A)': 4500, 'thermal overload relay': 1800, 'timer (staircase/lighting)': 1500, 'dimmer module 1CH': 3500, 'APFC relay': 8000, 'MCC (motor control center)': 45000, 'star-delta starter': 6500, 'VFD drive (small)': 12000, 'door controller (access)': 5000, 'relay module (8CH)': 2500}

# ---- switch/module brand tiers (like sanitary brands) ----
SWITCH_BRAND = {'Anchor': 0.85, 'Polycab': 0.90, 'Havells': 1.0, 'Legrand (Mylinc)': 1.3,
                'Crabtree': 1.5, 'Schneider (Livia)': 1.4, 'Simon': 1.6}
FIXT_BRAND = {'Local': 0.7, 'Havells': 1.0, 'Philips': 1.1, 'Wipro': 1.05, 'Bajaj': 0.9,
              'Crompton': 1.0, 'Osram': 1.2, 'Syska (LED)': 1.0}
POINT = {'light': 1800, 'fan / regulator': 2000, '5A socket': 1500, '15A socket': 2200, '20A socket': 2600,
         'AC point': 4500, 'geyser point': 2800, 'TV point': 1200, 'telephone point': 1000,
         'data / LAN point': 1500, 'exhaust fan point': 2000, 'door bell': 800, 'water pump point': 3500, 'EV charging point': 8000, 'smart home sensor': 3000, 'solar grid-tie point': 5000, 'door access (card)': 6000}
WIRE = {'conduit 20mm': 220, 'conduit 25mm': 280, 'conduit 32mm': 360, 'FRLS wire 1.5 sqmm': 70,
        'FRLS wire 2.5 sqmm': 110, 'FRLS wire 4 sqmm': 170, 'FRLS wire 6 sqmm': 250, 'FRLS wire 10 sqmm': 420, 'busbar trunking': 1500, 'cable tray (galvanized)': 800, 'LT cable 4core 10sqmm': 420, 'LT cable 4core 16sqmm': 560, 'LT cable 4core 25sqmm': 650, 'LT cable 4core 35sqmm': 950, 'LT cable 4core 50sqmm': 1250, 'LT cable 4core 70sqmm': 1650, 'LT cable 4core 95sqmm': 2200, 'coaxial cable (RG6)': 85, 'LAN cable (Cat6)': 120, 'telephone cable (2-pair)': 55}
SWITCH = {'MCB (single pole)': 700, 'RCCB': 2500, 'DP isolator': 1800, 'TP isolator': 4000, 'changeover (auto)': 12000,
          'main distribution board': 35000, 'sub distribution board': 12000, 'busbar chamber': 15000, 'surge protector': 6000}
FIXT = {'LED panel': 1500, 'LED downlight': 900, 'LED tube': 1200, 'ceiling fan': 3500, 'wall light': 1200,
        'chandelier': 25000, 'spotlight': 800, 'strip light': 600, 'pendant light': 3000, 'external flood light': 4000, 'emergency light': 2500}
EARTH = {'pipe earthing': 4500, 'plate earthing': 6000, 'chemical earthing': 9000, 'lightning arrestor': 18000, 'earthing strip (GI 25x4) per m': 180, 'earth pit cover (CI)': 800, 'surge protection device (SPD)': 6000, 'lightning down conductor': 250}
BACKUP = {'inverter + battery': 55000, 'online UPS': 80000, 'diesel generator (per kW)': 60000, 'solar PV (per kW)': 90000, 'battery bank (per unit)': 18000, 'solar charge controller (MPPT)': 12000, 'sync panel (dual gen)': 35000, 'net metering arrangement': 8000,
          'passenger lift 6-person (supply+install)': 2200000, 'passenger lift 8-person (supply+install)': 2900000,
          'service/stretcher lift (supply+install)': 2600000, 'DG set 82 kVA (with canopy)': 1500000,
          'DG set 125 kVA (with canopy)': 2200000, 'DG set 250 kVA (with canopy)': 4000000}
LV = {'CCTV camera + DVR': 8000, 'intercom / EPABX point': 4000, 'fire alarm detector': 3500,
       'fire alarm panel + detectors (per floor)': 80000, 'CCTV + video door phone (per floor)': 60000,
       'public address system': 250000,
      'access control (biometric)': 15000, 'network / patch panel point': 2500, 'public address speaker': 4000, 'video door phone': 12000, 'fire alarm control panel': 45000, 'smoke/heat detector': 2500, 'manual call point': 1500, 'BMS (building mgmt system) point': 8000, 'public address hooter': 3000, 'gas leak detector': 3500}

SPEC = {
    'id': 'electrical', 'title': 'Electrical', 'icon': '⚡', 'color': '#e67e22',
    'intro': 'Points, wiring (by conduit & wire size), switchgear & DBs, fixtures, earthing, backup & low-voltage systems.',
    'upload_guide': [
        'Electrical single-line diagram (SLD) / load schedule',
        'Lighting layout - ALL light point locations per floor',
        'Power layout - 5A/15A sockets, AC, geyser, exhaust points',
        'Switchboard / DB schedule - MCB, RCCB, DB counts',
        'Conduit and wiring schedule - sizes, lengths, FRLS wire specs',
        'Fixture schedule - LED panel, downlight, ceiling fan',
        'Earthing layout - pipe/plate/chemical earthing stations',
        'Fire alarm system layout - detectors, call points, control panel',
        'Cable tray / busbar routing - for commercial',
        'EV charging layout - if applicable',
        'Solar PV system layout - panels, inverter, grid-tie',
        'CCTV / intercom / access control / BMS layout',
        'Generator / DG set schedule - capacity, changeover',
    ],
    'upload_note': 'Upload as many PDFs as needed. Point/fixture counts auto-extract from typed schedules. For high-rise: include the EQUIPMENT/PLANT schedule (lifts, DG sets, fire alarm) — Power Backup, Lifts & Plant table reads it.',
        'upload_note': 'Point & fixture counts auto-extracted from typed schedules & SLDs. For high-rise: include the EQUIPMENT/PLANT schedule (lifts, DG sets, fire alarm) — the Power Backup, Lifts & Plant table reads it.',
    'labour': ['electrician', 'wireman', 'fixture', 'helper'],
    'scalars': [{'name': 'project_name', 'label': 'Project name', 'type': 'text', 'default': 'Electrical Estimate'},
                {'name': 'location', 'label': 'Location', 'type': 'text', 'default': 'Kathmandu'}],
    'tables': [
        {'id': 'points', 'title': '1. Points', 'add_label': 'Add point type',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(POINT)},
                    {'name': 'switch_brand', 'label': 'Switch brand', 'type': 'select', 'options': list(SWITCH_BRAND)},
                    {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'light', 'count': 60, 'switch_brand': 'Anchor'}, {'type': 'fan / regulator', 'count': 18, 'switch_brand': 'Anchor'}, {'type': '5A socket', 'count': 50, 'switch_brand': 'Anchor'},
                          {'type': '15A socket', 'count': 16, 'switch_brand': 'Anchor'}, {'type': 'AC point', 'count': 8, 'switch_brand': 'Anchor'}, {'type': 'TV point', 'count': 6, 'switch_brand': 'Anchor'}]},
        {'id': 'wire', 'title': '2. Conduit & Wiring', 'add_label': 'Add wiring run',
         'hint': 'leave lengths at 0 = AUTO from your Points table (standard m-per-point references)',
         'hint': 'leave lengths at 0 = AUTO from your Points table (standard m-per-point references)',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(WIRE)}, {'name': 'length', 'label': 'Length (rmt)', 'type': 'number'}],
         'default_rows': [{'type': 'conduit 25mm', 'length': 600}, {'type': 'FRLS wire 2.5 sqmm', 'length': 1200}, {'type': 'FRLS wire 1.5 sqmm', 'length': 900}]},
        {'id': 'switch', 'title': '3. Switchgear & Boards', 'add_label': 'Add switchgear',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(SWITCH)}, {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'main distribution board', 'count': 1, 'switch_brand': 'Anchor'}, {'type': 'sub distribution board', 'count': 3, 'switch_brand': 'Anchor'}, {'type': 'MCB (single pole)', 'count': 36, 'switch_brand': 'Anchor'}]},
        {'id': 'fixt', 'title': '4. Fixtures', 'add_label': 'Add fixture',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(FIXT)},
                    {'name': 'brand', 'label': 'Brand', 'type': 'select', 'options': list(FIXT_BRAND)},
                    {'name': 'wattage', 'label': 'Wattage (W)', 'type': 'suggest', 'options': ['9W','12W','15W','18W','24W','36W','50W','75W','100W']},
                    {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'LED panel', 'count': 60, 'switch_brand': 'Anchor', 'brand': 'Local'}, {'type': 'ceiling fan', 'count': 18, 'switch_brand': 'Anchor', 'brand': 'Local'}]},
        {'id': 'earth', 'title': '5. Earthing & Protection', 'add_label': 'Add earthing',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(EARTH)}, {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'pipe earthing', 'count': 2, 'switch_brand': 'Anchor'}]},
        {'id': 'backup', 'title': '6. Power Backup, Lifts & Plant', 'add_label': 'Add plant/equipment',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(BACKUP)}, {'name': 'qty', 'label': 'Qty / kW', 'type': 'number'}],
         'default_rows': [{'type': 'inverter + battery', 'qty': 1}]},
        {'id': 'lv', 'title': '7. Low Voltage / Smart', 'add_label': 'Add LV system',
         'fields': [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(LV)}, {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'CCTV camera + DVR', 'count': 6, 'switch_brand': 'Anchor'}, {'type': 'intercom / EPABX point', 'count': 6, 'switch_brand': 'Anchor'}]},
        {'id': 'condacc', 'title': '8. Conduit Accessories & Cable Fittings', 'hint': 'junction boxes, bends, lugs, saddles', 'add_label': 'Add accessory',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(CONDACC)},
                    {'name': 'spec', 'label': 'Where', 'type': 'suggest', 'options': ['all points', 'main riser', 'floor circuits', 'staircase', 'corridor', 'lobby', 'toilet exhaust']},
                    {'name': 'count', 'label': 'Count/rmt', 'type': 'number'}],
         'default_rows': [{'type': 'junction box (PVC)', 'spec': 'all points', 'count': 120}, {'type': 'PVC saddle', 'spec': 'conduit fixing', 'count': 300}]},
        {'id': 'motor', 'title': '9. Motor Control & Automation', 'hint': 'contactors, relays, starters, VFD, timers', 'add_label': 'Add control item',
         'fields': [{'name': 'type', 'label': 'Item', 'type': 'select', 'options': list(MOTOR)},
                    {'name': 'spec', 'label': 'For which load', 'type': 'suggest', 'options': ['water pump', 'fire pump', 'elevator', 'AC compressor', 'sewage pump', 'STP plant']},
                    {'name': 'count', 'label': 'Count', 'type': 'number'}],
         'default_rows': [{'type': 'contactor (25A)', 'spec': 'water pump', 'count': 2}]},
    ],
}


def estimate(sched):
    est = Estimate({}); T = sched['tables']
    for r in T['points']:
        c = NUM(r.get('count'))
        if c:
            sb = SWITCH_BRAND.get(r.get('switch_brand','Havells'), 1.0)
            est.item('1. Points', f"{r.get('type')} point ({r.get('switch_brand','Havells')} switch)", 'nos', c, rate=ro(r, POINT.get(r.get('type'), 1800) * sb), take=(c, None, None, None), note='point numbers')
    # ---- AUTO wiring from Points (when no manual wire lengths are given) ----
    # Standard estimating reference: metres of conductor per point (avg run +
    # switch drop + slack); sockets/power points on heavier sqmm; conduit per class.
    PT_WIRE = {'light': ('FRLS wire 1.5 sqmm', 8), 'fan / regulator': ('FRLS wire 1.5 sqmm', 8),
               'exhaust fan point': ('FRLS wire 1.5 sqmm', 7), 'door bell': ('FRLS wire 1.5 sqmm', 5),
               '5A socket': ('FRLS wire 1.5 sqmm', 9),
               '15A socket': ('FRLS wire 2.5 sqmm', 10), '20A socket': ('FRLS wire 2.5 sqmm', 10),
               'geyser point': ('FRLS wire 2.5 sqmm', 11), 'water pump point': ('FRLS wire 2.5 sqmm', 15),
               'AC point': ('FRLS wire 4 sqmm', 13), 'EV charging point': ('FRLS wire 4 sqmm', 15),
               'solar grid-tie point': ('FRLS wire 6 sqmm', 15),
               'TV point': ('coaxial cable (RG6)', 10), 'telephone point': ('telephone cable (2-pair)', 9),
               'data / LAN point': ('LAN cable (Cat6)', 11), 'smart home sensor': ('LAN cable (Cat6)', 8),
               'door access (card)': ('LAN cable (Cat6)', 10)}
    CONDUIT20 = ('light', 'fan / regulator', '5A socket', 'exhaust fan point', 'door bell',
                 'TV point', 'telephone point', 'data / LAN point', 'smart home sensor', 'door access (card)')
    CONDUIT25 = ('15A socket', '20A socket', 'geyser point', 'water pump point', 'AC point', 'EV charging point')
    manual_wire = any(NUM(r.get('length')) for r in T['wire'])
    if not manual_wire and T['points']:
        pt_tot = {}
        for r in T['points']:
            c = NUM(r.get('count'))
            if c:
                pt_tot[r.get('type')] = pt_tot.get(r.get('type'), 0) + int(c)
        wire_tot = {}
        for pt, n in pt_tot.items():
            wt, fac = PT_WIRE.get(pt, (None, 0))
            if wt:
                wire_tot[wt] = wire_tot.get(wt, 0) + n * fac
        c20 = sum(n for pt, n in pt_tot.items() if pt in CONDUIT20) * 3.5
        c25 = sum(n for pt, n in pt_tot.items() if pt in CONDUIT25) * 4.5
        if c20:
            est.item('2. Conduit & Wiring', 'conduit 20mm (auto from points)', 'rmt', round(c20, 1), rate=WIRE['conduit 20mm'],
                     note='points x 3.5 m avg run incl. drops (auto - type any length to override)')
        if c25:
            est.item('2. Conduit & Wiring', 'conduit 25mm (auto from points)', 'rmt', round(c25, 1), rate=WIRE['conduit 25mm'],
                     note='power points x 4.5 m avg run (auto - type any length to override)')
        for wt, L in sorted(wire_tot.items()):
            est.item('2. Conduit & Wiring', f'{wt} (auto from points)', 'rmt', round(L, 1), rate=WIRE.get(wt, 220),
                     note='points x standard m-per-point reference (auto - type any length to override)')
    for r in T['wire']:
        L = NUM(r.get('length'))
        if L:
            est.item('2. Conduit & Wiring', str(r.get('type')), 'rmt', L, rate=ro(r, WIRE.get(r.get('type'), 220)), take=((NUM(r.get('count'),1) or 1), L, None, None), note='wire/conduit run length')
    for r in T['switch']:
        c = NUM(r.get('count'))
        if c:
            est.item('3. Switchgear & Boards', str(r.get('type')), 'nos', c, rate=ro(r, SWITCH.get(r.get('type'), 700)), take=(c, None, None, None), note='numbers')
    for r in T['fixt']:
        c = NUM(r.get('count'))
        if c:
            fb = FIXT_BRAND.get(r.get('brand','Havells'), 1.0)
            w = r.get('wattage','')
            d = f"{r.get('type')} ({r.get('brand','Havells')}, {w})" if w else f"{r.get('type')} ({r.get('brand','Havells')})"
            est.item('4. Fixtures', d, 'nos', c, rate=ro(r, FIXT.get(r.get('type'), 1500) * fb), take=(c, None, None, None), note='numbers')
    for r in T['earth']:
        c = NUM(r.get('count'))
        if c:
            est.item('5. Earthing & Protection', str(r.get('type')), 'nos', c, rate=ro(r, EARTH.get(r.get('type'), 4500)), take=(c, None, None, None), note='numbers')
    for r in T['backup']:
        q = NUM(r.get('qty'))
        if q:
            est.item('6. Power Backup, Lifts & Plant', str(r.get('type')), 'kW' if 'kW' in r.get('type', '') else 'nos', q, rate=ro(r, BACKUP.get(r.get('type'), 55000)), take=(q, None, None, None), note='capacity/quantity')
    for r in T['lv']:
        c = NUM(r.get('count'))
        if c:
            est.item('7. Low Voltage / Smart', str(r.get('type')), 'nos', c, rate=ro(r, LV.get(r.get('type'), 4000)), take=(c, None, None, None), note='numbers')
    for r in T['condacc']:
        c = NUM(r.get('count'))
        if c:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('8. Conduit Accessories', d, 'nos', c, rate=ro(r, CONDACC.get(r.get('type'), 50)), take=(c, None, None, None), note='numbers')
    for r in T['motor']:
        c = NUM(r.get('count'))
        if c:
            d = f"{r.get('type')} ({r.get('spec','')})" if r.get('spec') else str(r.get('type'))
            est.item('9. Motor Control & Automation', d, 'nos', c, rate=ro(r, MOTOR.get(r.get('type'), 3000)), take=(c, None, None, None), note='numbers')

    el_elec_days = round(sum(NUM(r.get('count',0)) for r in T['points']) / 12, 0)
    el_wire_days = round(sum(NUM(r.get('length',0)) for r in T['wire']) / 100, 0)
    el_fix_days = round(sum(NUM(r.get('count',0)) for r in T['fixt']) * 0.3, 0)
    el_helper_days = round((el_elec_days + el_wire_days + el_fix_days) * 1.0, 0)
    el_total = int(el_elec_days + el_wire_days + el_fix_days + el_helper_days)

    kpis = [('Points', f"{sum(NUM(r.get('count')) for r in T['points']):.0f}"), ('Wiring', f"{sum(NUM(r.get('length')) for r in T['wire']):.0f} m")]
    proj = {'name': sched['scalars'].get('project_name', ''), 'location': sched['scalars'].get('location', '')}
    res = est.result(project=proj, kpis=kpis)
    from modules.common import LABOUR_RATES as _LR
    _lrd = sched.get('labour_rates') or {}
    res['labour_rates'] = {k: _lrd.get(k) or _LR[k] for k in ['electrician', 'wireman', 'fixture', 'helper']}
    res['labour'] = {
        'electrician_days': int(el_elec_days), 'wireman_days': int(el_wire_days),
        'fixture_days': int(el_fix_days), 'helper_days': int(el_helper_days),
        'total_days': el_total,
    }
    return res


PDF_KEYWORDS = ['electrical', 'light', 'socket', 'switch', 'mcb', 'conduit', 'wiring', 'cctv', 'earthing']


# ---- market-rate resolver (pre-fills Rate boxes; same formula as calc) ----
from modules.common import make_row_rate as _mrr

SPEC['row_rate'] = _mrr({
    'points': lambda r, s: POINT.get(r.get('type'), 1800) * SWITCH_BRAND.get(r.get('switch_brand', 'Havells'), 1.0),
    'wire': lambda r, s: WIRE.get(r.get('type'), 220),
    'switch': lambda r, s: SWITCH.get(r.get('type'), 700),
    'fixt': lambda r, s: FIXT.get(r.get('type'), 1500) * FIXT_BRAND.get(r.get('brand', 'Havells'), 1.0),
    'earth': lambda r, s: EARTH.get(r.get('type'), 4500),
    'backup': lambda r, s: BACKUP.get(r.get('type'), 55000),
    'lv': lambda r, s: LV.get(r.get('type'), 4000),
    'condacc': lambda r, s: CONDACC.get(r.get('type'), 50),
    'motor': lambda r, s: MOTOR.get(r.get('type'), 3000),
})
SPEC['rate_cfg'] = {
    'points': {'x': [('switch_brand', dict(SWITCH_BRAND))], 'ad': {'switch_brand': ''}},
    'fixt': {'x': [('brand', dict(FIXT_BRAND))], 'ad': {'brand': ''}},
}
