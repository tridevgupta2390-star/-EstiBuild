"""Shared helpers for all estimation modules."""
from collections import OrderedDict

BAG = 0.0347  # 50kg cement bag ~ 0.0347 m3

# Default labour day-rates (NPR base). Scaled per country by country_rates.apply_rates.
# User-editable in every module's form ("Labour Rates" card) and carried into
# result['labour_rates'] so Excel/PDF exports use exactly what the user set.
LABOUR_RATES = {
    'mason': 1200, 'mazdoor': 800, 'tile_mason': 1400, 'painter': 1300,
    'plumber': 1500, 'electrician': 1500, 'wireman': 1200, 'helper': 800,
    'fixture': 1200, 'fixture_install': 1300, 'steel_fab': 1400,
    'welder': 1500, 'erector': 1400, 'roofer': 1400,
}
LABOUR_LABELS = {
    'mason': 'Mason', 'mazdoor': 'Mazdoor (Helper)', 'tile_mason': 'Tile Mason',
    'painter': 'Painter', 'plumber': 'Plumber', 'electrician': 'Electrician',
    'wireman': 'Wireman', 'helper': 'Helper', 'fixture': 'Fixture Installer',
    'fixture_install': 'Fixture Installer', 'steel_fab': 'Steel Fabricator',
    'welder': 'Welder', 'erector': 'Erector / Rigger', 'roofer': 'Roofer / Sheeter',
}


def NUM(v, d=0):
    if v is None:
        return d
    s = str(v).strip()
    if s == '' or s.lower() == 'none':
        return d
    try:
        return float(s)
    except ValueError:
        return d


def make_row_rate(table_rates):
    """Build SPEC['row_rate'](tid, row, scalars) -> market rate for a row's PRIMARY
    BOQ item (same formula the calc uses when the rate box is blank)."""
    def row_rate(tid, row, scal=None):
        fn = table_rates.get(tid)
        if not fn:
            return None
        try:
            v = fn(row or {}, scal or {})
            return round(float(v), 2) if v is not None else None
        except Exception:
            return None
    return row_rate


def ro(r, market):
    """use the row's editable rate if provided, else the market default."""
    o = r.get('rate')
    if o is not None and str(o).strip() != '':
        return NUM(o)
    return market


def ratio_t(s):
    return tuple(float(x) for x in str(s).split(':'))


def masonry_breakup(volume, blocks_per_m3=500, ratio='1:6'):
    a, b = ratio_t(ratio)
    s = a + b
    mortar = volume * 0.30 * 1.33
    cement = (a / s) * mortar / BAG
    sand = (b / s) * mortar
    nos = volume * 0.70 * blocks_per_m3
    return nos, cement, sand


def plaster_breakup(area, thk_mm, ratio='1:4'):
    a, b = ratio_t(ratio)
    s = a + b
    dry = area * (thk_mm / 1000.0) * 1.54
    return (a / s) * dry / BAG, (b / s) * dry


class Estimate:
    def __init__(self, rates):
        self.rates = rates
        self.groups = OrderedDict()
        self.materials = OrderedDict()
        self.takeoff = []
        self.grand = 0.0

    def _fmt_take(self, t):
        t = (list(t) + [None] * 5)[:5]
        return {'nos': t[0], 'L': t[1], 'B': t[2], 'D': t[3], 'wt': t[4]}

    def take(self, group, desc, unit, qty, take=None, note=''):
        """Record a measurement line for the Quantity Takeoff sheet (no BOQ item)."""
        if take:
            d = self._fmt_take(take)
            d.update({'group': group, 'desc': desc, 'unit': unit,
                      'qty': round(qty, 3), 'note': note})
            self.takeoff.append(d)
        elif note or qty:
            self.takeoff.append({'group': group, 'desc': desc, 'nos': None, 'L': None,
                                 'B': None, 'D': None, 'wt': None, 'unit': unit,
                                 'qty': round(qty, 3), 'note': note})

    def item(self, group, desc, unit, qty, rate_key=None, rate=None, take=None, note='', tk=None):
        r = self.rates.get(rate_key, 0) if rate is None else rate
        qty = round(qty, 3)
        self.groups.setdefault(group, []).append({
            'desc': desc, 'unit': unit, 'qty': qty, 'rate': round(r, 2),
            'amount': round(qty * r, 2)})
        self.grand += qty * r
        if take:
            self.take(group, desc, unit, qty, take, note)
            self.groups[group][-1]['tk'] = [len(self.takeoff) - 1]
        elif tk:
            self.groups[group][-1]['tk'] = list(tk)
        return self

    def mat(self, key, label, qty, unit, rate):
        if qty <= 0:
            return self
        e = self.materials.get(key, {'label': label, 'unit': unit, 'rate': rate, 'qty': 0.0})
        e['qty'] += qty
        self.materials[key] = e
        return self

    def result(self, project=None, kpis=None):
        groups = OrderedDict()
        for g, items in self.groups.items():
            groups[g] = {'items': items, 'subtotal': round(sum(i['amount'] for i in items), 2)}
        materials = []
        for k, e in self.materials.items():
            materials.append({'key': k, 'label': e['label'], 'qty': round(e['qty'], 2),
                              'unit': e['unit'], 'rate': e['rate'], 'value': round(e['qty'] * e['rate'], 2)})
        # If a module tracks no bulk materials (e.g. sanitary/electrical, where every BOQ
        # line IS a discrete product), derive a procurement list from the BOQ items so the
        # Materials sheet is never empty.
        if not materials:
            for g, info in groups.items():
                for it in info['items']:
                    materials.append({'key': it['desc'], 'label': it['desc'], 'qty': it['qty'],
                                      'unit': it['unit'], 'rate': it['rate'], 'value': it['amount']})
        return {'project': project or {}, 'groups': groups, 'materials': materials,
                'grand_total': round(self.grand, 2), 'kpis': kpis or [],
                'takeoff': self.takeoff}
