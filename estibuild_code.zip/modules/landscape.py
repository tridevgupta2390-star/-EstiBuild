"""Landscape & Exterior Works module - world-scope coverage.
Site prep, softscape (lawns/plants/trees), hardscape, decks, swimming pools,
water features, shade structures (gazebos/pergolas/sails), children play zones,
sports, irrigation, garden lighting, furniture, fencing, maintenance."""
from modules.common import Estimate, NUM, ro

# ---- Nepal base rates (NPR) - editable per row in the app ----
SITEPREP = {'land clearing/grubbing (m2)': 60, 'tree removal (small)': 2000, 'tree removal (large)': 6000,
            'cut & fill (m3)': 450, 'grading/leveling (m2)': 120, 'import topsoil (m3)': 900,
            'compost/soil amendment (m3)': 2200, 'mulching (m2)': 350}
LAWN = {'carpet grass roll': 150, 'korean grass': 220, 'fescue seeding': 90, 'hydroseeding': 180,
        'ground cover (creeping/jasmine)': 140, 'artificial turf (landscape grade)': 1500}
PLANT = {'shrub (1-2 gal pot)': 350, 'shrub (5 gal pot)': 900, 'hedge plant (per rmt row)': 250,
         'tree sapling': 700, 'tree small (5-8ft)': 3500, 'tree medium (8-12ft)': 9000,
         'tree large/mature (12ft+)': 25000, 'palm (4-6ft)': 6000, 'palm (6-10ft)': 15000,
         'palm (10-15ft)': 35000, 'fruit tree': 1800, 'flowering tree (gulmohar/jacaranda)': 2500,
         'bamboo cluster': 1500, 'vertical garden/green wall (m2)': 6500, 'green roof (m2)': 5500}
PAVE = {'concrete paver': 1200, 'interlocking paver': 1100, 'natural stone (granite/sandstone)': 2600,
        'crazy paving (stone)': 1600, 'exposed aggregate': 1800, 'stamped concrete': 2200,
        'outdoor porcelain tile': 2800, 'permeable paver': 1600, 'gravel/decorative stone': 900,
        'kerb/edging stone (rmt)': 900, 'aluminum/steel edging (rmt)': 750, 'garden step (stone, nos)': 3500,
        'boulder/rockery (per ton)': 5500, 'timber/WPC deck (m2)': 4500}
POOL = {'RCC swimming pool (m2 water area, incl. basic filtration)': 55000,
        'vinyl-lined pool (m2)': 42000, 'fiberglass shell pool (set, medium)': 850000,
        'infinity edge upgrade (rmt)': 35000, 'kids splash pad (m2)': 12000,
        'jacuzzi/hot tub (set)': 450000, 'koi/ornamental pond (m2)': 15000,
        'pool mosaic/tile finish (m2)': 3500, 'coping stone (rmt)': 2800,
        'sand/DE/cartridge filter set': 120000, 'salt chlorinator': 90000,
        'ozone/UV dosing system': 150000, 'heat pump': 220000, 'solar pool heating': 140000,
        'pool cover - manual': 45000, 'pool cover - automatic': 180000,
        'niche LED pool light': 15000, 'pool ladder/rail (set)': 18000}
WF_BUILD = {'RCC fountain basin': 16500, 'RCC water wall structure': 16500,
            'fountain pump + piping (per set)': 85000, 'fountain nozzles (per set)': 25000,
            'fountain LED lights (per set)': 35000, 'pond liner EPDM 1.5mm (m2)': 850,
            'geotextile underlay (m2)': 250, 'pond filtration (set)': 65000,
            'koi fish grade (set of 5)': 15000, 'water feature stone cladding (m2)': 3500}
WATER = {'architectural fountain (civil+pump, set)': 250000, 'wall spout feature (set)': 35000,
         'water curtain/wall (rmt)': 22000, 'reflecting pool (m2)': 9000,
         'stream/waterfall (rmt)': 18000, 'musical/dancing fountain (set)': 1200000}
POOL_EQ = {'sand/DE/cartridge filter set': 120000, 'salt chlorinator': 90000,
            'ozone/UV dosing system': 150000, 'heat pump': 220000, 'solar pool heating': 140000,
            'pool cover - manual': 45000, 'pool cover - automatic': 180000,
            'niche LED pool light': 15000, 'pool ladder/rail (set)': 18000,
            'pool pump 1HP': 45000, 'skimmer (nos)': 12000, 'inlet fitting (nos)': 3500,
            'main drain (nos)': 8000, 'pool vacuum robot': 250000}
POOL_FIN = {'glass mosaic': 3800, 'ceramic tile': 2800, 'PVC liner': 2200, 'pebble/aggregate': 2500}
DECK = {'timber deck - teak (m2)': 5500, 'timber deck - pine treated (m2)': 3800,
        'WPC composite deck (m2)': 4200, 'deck substructure joists (m2)': 1200}
EDGE = {'kerb/edging stone (rmt)': 900, 'aluminum/steel edging (rmt)': 750,
        'garden step - stone (nos)': 3500, 'boulder/rockery (per ton)': 5500,
        'stepping stones (nos)': 1200}
FLOWER_PLANT = {'annuals (seasonal)': 150, 'perennials': 350, 'roses': 600,
                'ground cover': 120, 'ornamental grass': 400, 'tulip bulbs': 80,
                'orchids (shade)': 1200, 'succulents': 250, 'herbs': 180, 'mixed border': 300}
BED_EDGE = {'stone': 1200, 'brick': 900, 'steel': 850, 'aluminum': 1500, 'timber': 700}
HEDGE_PLANT = {'duranta gold': 180, 'ficus': 150, 'ixora': 200, 'hibiscus': 250,
               'buxus (boxwood)': 450, 'podocarpus': 300, 'photinia red': 350,
               'bamboo screen': 220, 'thuja': 400, 'privet': 160}
TREE_PLANT = {' sapling (1-2m)': {'pit': 0.5, 'soil': 0.3, 'rate': 800},
              'small (2-3m)': {'pit': 0.8, 'soil': 0.8, 'rate': 3500},
              'medium (3-5m)': {'pit': 1.2, 'soil': 1.5, 'rate': 9000},
              'large (5-8m)': {'pit': 1.5, 'soil': 2.5, 'rate': 25000},
              'mature (8m+)': {'pit': 2.0, 'soil': 4.0, 'rate': 60000}}
TREE_RATE = {' flowering tree (gulmohar/jacaranda)': 2500, 'fruit tree (mango/lychee)': 3000,
             'shade tree (peepal/siris)': 2200, 'palm - royal': 8000, 'palm - areca': 3500,
             'conifer (pine/deodar)': 4500, 'magnolia': 5500, 'olive': 6000,
             'crepe myrtle': 2800, 'ornamental (maple/ginkgo)': 7000}
MARBLE = {'marble white (Italian)': 8500, 'marble green (Pakistan)': 5500,
          'granite (polished)': 4500, 'granite (flamed)': 3800,
          'sandstone': 2800, 'limestone': 3200, 'travertine': 5000,
          'quartzite': 4200, 'slate': 3500, 'basalt (black stone)': 3000}
DIM_RATES = {'excavation': 450, 'pcc': 6000, 'rcc_m25': 16500, 'rcc_m20': 16000,
             'steel_kg': 150, 'waterproof': 450, 'render': 350, 'coping': 2800,
             'pcc_bed': 6000, 'render_15mm': 350, 'paving_exc': 350, 'subbase': 2800,
             'bedding_sand': 3200, 'pad_exc': 450, 'rcc_pad': 16000, 'paving_floor': 1400,
             'drainage_gravel': 2800, 'drainage_pipe': 850, 'weep_hole': 350,
             'geo_grid': 1200, 'post_exc': 1200, 'rail': 450, 'post_cap': 350,
             'saddle': 4500, 'drip_lateral': 85, 'dripper': 45, 'sprinkler': 2800,
             'soil_exc': 450, 'soil_mix': 2500, 'mulch': 350, 'compost': 2200,
             'bed_exc': 450, 'trench_exc': 450, 'tree_stake': 450, 'tree_guard': 350,
             'mortar_bed': 3500, 'marble_polish': 400, 'sub_base_crusher': 2800,
             'pvc_main_32': 220, 'pvc_main_50': 350, 'zone_valve': 3500,
             'xfmr_300va': 18000, 'main_cable': 420, 'lv_cable': 180,
             'conduit_25': 90, 'cable_trench': 350, 'jbox_ip68': 1200,
             'timer': 4500, 'mcb_db': 2500, 'earth_rod': 1800}
SUBBASE = {'excavation for paving (m3)': 350, 'crusher run sub-base 150mm (m3)': 2800,
           'bedding sand 50mm (m3)': 3200}
GAZ_MAT = {'timber': {'col_rate': 8500, 'frame_rate': 7200},
           'steel': {'col_rate': 6500, 'frame_rate': 6000},
           'aluminum': {'col_rate': 11000, 'frame_rate': 9500}}
GAZ_ROOF = {'tile': 2400, 'metal sheet': 1600, 'polycarbonate': 2800, 'fabric': 1800, 'thatch': 1200}
RETAIN = {'gabion wall (m3 cage + stone)': 5500, 'stone masonry retaining (m3)': 7500,
            'crib wall (m2 face)': 4500, 'timber sleeper wall (m2 face)': 3800,
            'concrete block retaining (m3)': 6800, 'geo-grid reinforcement (m2)': 1200,
            'weep hole 50mm PVC (nos)': 350, 'drainage gravel behind wall (m3)': 2800,
            'drainage pipe 110mm (rmt)': 850}
SHADE = {'gazebo - wooden (m2 footprint)': 12000, 'gazebo - steel (m2)': 9500,
         'gazebo - aluminum (m2)': 14000, 'pergola - timber (m2)': 8500,
         'pergola - steel (m2)': 7000, 'bioclimatic/louvre pergola, motorized (m2)': 22000,
         'shade sail (triangle/square, m2)': 2500, 'cantilever umbrella (nos)': 45000,
         'market umbrella (nos)': 15000, 'retractable awning (rmt)': 12000,
         'tension membrane structure (m2)': 7500, 'car shade port (per car)': 95000,
         'bamboo/thatch shade (m2)': 3500}
PLAY = {'EPDM rubber flooring 20mm (m2)': 1800, 'EPDM rubber flooring 30mm (m2)': 2400,
        'EPDM rubber flooring 45mm (m2)': 3400, 'rubber tiles (m2)': 1600,
        'sand pit + washed sand (m2)': 900, 'multi-play combo (medium, set)': 250000,
        'multi-play combo (large, set)': 550000, 'slide (medium, nos)': 45000,
        'swing (2-seat, nos)': 35000, 'seesaw (nos)': 25000, 'merry-go-round (nos)': 55000,
        'climber/monkey bars (nos)': 60000, 'spring rider (nos)': 12000,
        'playhouse (nos)': 85000, 'trampoline in-ground (nos)': 120000,
        'inclusive/accessible play unit (set)': 350000, 'play-zone safety fence (rmt)': 2200}
SPORT = {'basketball court - acrylic finish (m2)': 2200, 'basketball hoop (set)': 25000,
         'futsal artificial turf (m2)': 1600, 'tennis/badminton court (m2)': 2000,
         'cricket practice net (set)': 85000, 'skating rink (m2)': 2400,
         'outdoor gym station (nos)': 55000, 'jogging track - rubber (m2)': 2000,
         'volleyball court set': 120000}
IRRIG = {'drip irrigation (m2 coverage)': 450, 'pop-up sprinkler zone (m2)': 600,
         'tap/hose bib point (nos)': 3500, 'controller + rain sensor (set)': 45000,
         'irrigation pump (set)': 65000}
IRRIG_ZONE = {'drip lateral 16mm (rmt)': 85, 'dripper 4L/hr (nos)': 45,
              'sprinkler pop-up (nos)': 2800, 'spray head (nos)': 1200,
              'PVC mainline 32mm (rmt)': 220, 'PVC mainline 50mm (rmt)': 350,
              'zone valve 1in (nos)': 3500, 'controller 6-zone (set)': 45000,
              'rain sensor (nos)': 12000, 'filter + fertilizer injector (set)': 18000,
              'quick coupling valve (nos)': 2500, 'saddle clamp + fittings (per zone)': 4500}
LIGHT = {'bollard light (nos)': 7500, 'spike/spot light (nos)': 4500,
         'in-ground uplight (nos)': 6500, 'pathway light kit (rmt)': 2200,
         'string/festoon light (rmt)': 900, 'transformer + cabling (per point)': 2500,
         'solar garden light (nos)': 3500, 'timer/photocell (set)': 4500,
         'transformer 300VA 12V (nos)': 18000, 'main cable 3Cx2.5mm2 armoured (rmt)': 420,
         'LV cable 2Cx2.5mm2 (rmt)': 180, 'conduit 25mm (rmt)': 90,
         'IP68 junction box (nos)': 1200, 'cable trench 450x200mm (rmt)': 350,
         'MCB 6A + DB connection (nos)': 2500, 'earth rod 16mm x 1.5m (nos)': 1800}
# fixture LED wattage (sizing only - not a cost)
LIGHT_W = {'bollard light': 8, 'spike/spot light': 7, 'in-ground uplight': 9,
           'pathway light': 5, 'wall/step light': 5, 'underwater light': 12,
           'garden flood 30W': 30}
LIGHT_FIX = {'bollard light (nos)': 7500, 'spike/spot light (nos)': 4500,
             'in-ground uplight (nos)': 6500, 'pathway light (nos)': 5500,
             'wall/step light (nos)': 4500, 'underwater light (nos)': 12000,
             'garden flood 30W (nos)': 9500}
DRAIN = {'French drain 300x300 w/ perforated pipe (rmt)': 1800,
         'channel/strip drain w/ grating (rmt)': 3200,
         'catch basin / gully pit (nos)': 8500, 'soak-away pit (nos)': 15000,
         'swale / vegetated drain (rmt)': 550, 'perforated PVC 110mm in trench (rmt)': 850,
         'geotextile filter wrap (m2)': 250, 'rainwater harvesting tank 5000L (set)': 150000}
GATE = {'driveway gate - steel, manual (m2)': 6500, 'driveway gate - sliding + motor (set)': 250000,
        'pedestrian gate (nos)': 35000, 'gate automation retrofit kit (set)': 120000,
        'gate pillar - masonry + coping (nos)': 25000}
FURN = {'outdoor sofa set - rattan (set)': 85000, 'outdoor set - teak (set)': 150000,
        'bench - cast iron/wood (nos)': 12000, 'bench - concrete (nos)': 9000,
        'picnic table set (nos)': 28000, 'trash bin (nos)': 6500,
        'planter - fiberglass (nos)': 4500, 'planter - concrete (nos)': 3500,
        'planter - corten steel (nos)': 12000, 'garden sculpture/art (nos)': 45000,
        'bird bath (nos)': 8500, 'flag pole (nos)': 35000, 'privacy screen (m2)': 5500,
        'fire pit (nos)': 45000, 'BBQ grill built-in (set)': 85000,
        'outdoor kitchen counter (rmt)': 45000}
FENCE = {'live hedge boundary (rmt)': 550, 'bamboo fencing (rmt)': 1200,
         'wooden picket/privacy fence (rmt)': 2800, 'steel palisade fence (rmt)': 3500,
         'chain-link fence (rmt)': 1300}
FENCE_CALC = {'post excavation + concrete (per post)': 1200,
               'timber post 100x100 (per post)': 1800, 'steel post 60x60 (per post)': 2200,
               'aluminum post (per post)': 3500, 'concrete post (per post)': 1500,
               'picket 100mm (m2 face)': 1800, 'palisade steel (m2 face)': 2800,
               'bamboo (m2 face)': 950, 'chain-link mesh (m2 face)': 750,
               'rail horizontal (per rmt)': 450, 'tension wire (rmt)': 120,
               'post cap + fixtures (per post)': 350}
MAINT = {'gardener visits (per month)': 18000, 'pool cleaning + chemicals (per month)': 12000,
         'annual replanting program (per annum)': 60000, 'irrigation winterizing (per annum)': 15000}

T = lambda d: [{'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(d)},
               {'name': 'qty', 'label': 'Qty', 'type': 'number'},
               {'name': 'spec', 'label': 'Spec / note', 'type': 'text'}]

SPEC = {
    'id': 'landscape', 'title': 'Landscape & Exterior Works', 'icon': '🌳', 'color': '#2e7d32',
    'intro': 'Complete landscape estimation: site prep, plants, paving, swimming pools, water features, '
             'shade structures, children play zones, sports, irrigation, lighting, furniture and maintenance.',
    'scalars': [],
    'tables': [
        {'id': 'siteprep', 'title': '1. Site Preparation', 'add_label': 'add item',
         'hint': 'clearing, cut & fill, grading, topsoil', 'fields': T(SITEPREP),
         'default_rows': [{'type': 'grading/leveling (m2)', 'qty': 500}]},
        {'id': 'drain', 'title': '1B. Landscape Drainage', 'add_label': 'add drain',
         'hint': 'French drains, channel drains, catch basins, soak pits, rainwater harvesting',
         'fields': T(DRAIN),
         'default_rows': [{'type': 'French drain 300x300 w/ perforated pipe (rmt)', 'qty': 40}]},
        {'id': 'lawn', 'title': '2. Lawn (dimension-driven)', 'add_label': 'add lawn',
         'hint': 'enter L x W - soil prep 150mm, seeding/rolls, initial fertilizer ALL auto',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select',
              'options': ['carpet grass roll', 'korean grass', 'fescue seeding', 'bermuda seeding', 'artificial turf']},
             {'name': 'L', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'W', 'label': 'Width (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos of areas', 'type': 'number'},
         ],
         'default_rows': [{'id': 'L1', 'type': 'carpet grass roll', 'L': 20, 'W': 15, 'count': 1}]},
        {'id': 'flowerbed', 'title': '2B. Flower Beds (dimension-driven)', 'add_label': 'add bed',
         'hint': 'enter L x W + plant spacing - excavation 300mm, soil/compost mix, edging, mulch, plant count ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'L', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'W', 'label': 'Width (m)', 'type': 'number'},
             {'name': 'spacing', 'label': 'Plant spacing (cm)', 'type': 'number'},
             {'name': 'plant_type', 'label': 'Plant type', 'type': 'select',
              'options': ['annuals (seasonal)', 'perennials', 'roses', 'ground cover', 'ornamental grass',
                          'tulip bulbs', 'orchids (shade)', 'succulents', 'herbs', 'mixed border']},
             {'name': 'edge', 'label': 'Edging', 'type': 'select',
              'options': ['stone', 'brick', 'steel', 'aluminum', 'timber', 'none']},
             {'name': 'count', 'label': 'Nos of beds', 'type': 'number'},
         ],
         'default_rows': [{'id': 'FB1', 'L': 5, 'W': 2, 'spacing': 30, 'plant_type': 'annuals (seasonal)',
                           'edge': 'stone', 'count': 2},
                          {'id': 'FB2', 'L': 8, 'W': 1.5, 'spacing': 40, 'plant_type': 'roses',
                           'edge': 'brick', 'count': 1}]},
        {'id': 'hedge', 'title': '2C. Hedge Rows (dimension-driven)', 'add_label': 'add hedge',
         'hint': 'enter LENGTH + height + spacing - trench excavation, soil mix, plant count, first-year trim ALL auto',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'L', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'H', 'label': 'Hedge height (m)', 'type': 'select',
              'options': ['0.5', '0.75', '1.0', '1.5', '2.0']},
             {'name': 'spacing', 'label': 'Plant spacing (cm)', 'type': 'number'},
             {'name': 'type', 'label': 'Hedge type', 'type': 'select',
              'options': ['duranta gold', 'ficus', 'ixora', 'hibiscus', 'buxus (boxwood)',
                          'podocarpus', 'photinia red', 'bamboo screen', 'thuja', 'privet']},
             {'name': 'count', 'label': 'Nos of rows', 'type': 'number'},
         ],
         'default_rows': [{'id': 'H1', 'L': 30, 'H': '1.0', 'spacing': 40, 'type': 'duranta gold', 'count': 1}]},
        {'id': 'trees', 'title': '2D. Tree Planting (pit-driven)', 'add_label': 'add tree type',
         'hint': 'enter count + tree size - pit excavation, soil mix, stake, guard, first-year care ALL auto per tree',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Tree type', 'type': 'select',
              'options': [' flowering tree (gulmohar/jacaranda)', 'fruit tree (mango/lychee)',
                          'shade tree (peepal/siris)', 'palm - royal', 'palm - areca',
                          'conifer (pine/deodar)', 'magnolia', 'olive', 'crepe myrtle',
                          'ornamental (maple/ginkgo)']},
             {'name': 'size', 'label': 'Size', 'type': 'select',
              'options': ['sapling (1-2m)', 'small (2-3m)', 'medium (3-5m)', 'large (5-8m)', 'mature (8m+)']},
             {'name': 'qty', 'label': 'Nos', 'type': 'number'},
         ],
         'default_rows': [{'id': 'T1', 'type': ' flowering tree (gulmohar/jacaranda)', 'size': 'small (2-3m)', 'qty': 6},
                          {'id': 'T2', 'type': 'palm - royal', 'size': 'medium (3-5m)', 'qty': 4}]},
        {'id': 'plants', 'title': '3. Plants & Trees', 'add_label': 'add plant',
         'hint': 'shrubs by pot size, trees by maturity, palms by height, green walls',
         'fields': T(PLANT), 'default_rows': [{'type': 'shrub (1-2 gal pot)', 'qty': 60},
                                              {'type': 'tree small (5-8ft)', 'qty': 8}]},
        {'id': 'paving', 'title': '4. Paving (with sub-base auto)', 'add_label': 'add paving',
         'hint': 'enter AREA - excavation 200mm, sub-base 150mm, bedding sand 50mm and the paving itself ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select', 'options': list(PAVE)},
             {'name': 'area', 'label': 'Area (m2)', 'type': 'number'},
             {'name': 'thk', 'label': 'Paving thk (mm)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos of areas', 'type': 'number'},
         ],
         'default_rows': [{'id': 'PV1', 'type': 'interlocking paver', 'area': 250, 'thk': 60, 'count': 1}]},
        {'id': 'deck', 'title': '4B. Decks', 'add_label': 'add deck',
         'hint': 'timber/WPC deck by m2 - substructure joists auto-added',
         'fields': T(DECK), 'default_rows': []},
        {'id': 'edges', 'title': '4C. Edging & Steps', 'add_label': 'add item', 'fields': T(EDGE),
         'default_rows': []},
        {'id': 'marble', 'title': '4D. Marble / Granite / Stone Finish (dimension-driven)', 'add_label': 'add finish area',
         'hint': 'enter L x W - sub-base, bedding mortar, marble/granite slabs, polishing ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Material', 'type': 'select',
              'options': ['marble white (Italian)', 'marble green (Pakistan)', 'granite (polished)',
                          'granite (flamed)', 'sandstone', 'limestone', 'travertine',
                          'quartzite', 'slate', 'basalt (black stone)']},
             {'name': 'L', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'W', 'label': 'Width (m)', 'type': 'number'},
             {'name': 'thk', 'label': 'Slab thk (mm)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos of areas', 'type': 'number'},
         ],
         'default_rows': [{'id': 'M1', 'type': 'granite (polished)', 'L': 6, 'W': 4, 'thk': 20, 'count': 1}]},
        {'id': 'pool', 'title': '5. Swimming Pool (dimension-driven RCC)', 'add_label': 'add pool',
         'hint': 'enter pool DIMENSIONS - excavation, PCC, RCC floor + walls, steel, waterproofing, plaster, tile finish and coping ALL auto-compute with visible formulas',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'L', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'W', 'label': 'Width (m)', 'type': 'number'},
             {'name': 'd1', 'label': 'Depth shallow (m)', 'type': 'number'},
             {'name': 'd2', 'label': 'Depth deep (m)', 'type': 'number'},
             {'name': 'wall_t', 'label': 'Wall thk (mm)', 'type': 'number'},
             {'name': 'floor_t', 'label': 'Floor thk (mm)', 'type': 'number'},
             {'name': 'finish', 'label': 'Finish', 'type': 'select',
              'options': ['glass mosaic', 'ceramic tile', 'PVC liner', 'pebble/aggregate']},
             {'name': 'type', 'label': 'Type', 'type': 'select',
              'options': ['skimmer pool', 'infinity edge', 'splash pad', 'jacuzzi', 'koi pond']},
         ],
         'default_rows': [{'id': 'P1', 'L': 8, 'W': 4, 'd1': 1.2, 'd2': 1.8, 'wall_t': 200, 'floor_t': 200, 'finish': 'glass mosaic', 'type': 'skimmer pool'}]},
        {'id': 'pool_eq', 'title': '5B. Pool Equipment', 'add_label': 'add equipment',
         'hint': 'filtration, heating, covers, lights, ladders - pick what your spec includes',
         'fields': T(POOL_EQ), 'default_rows': [{'type': 'sand/DE/cartridge filter set', 'qty': 1},
                                                {'type': 'niche LED pool light', 'qty': 2}]},
        {'id': 'wf', 'title': '6. Water Features (dimension-driven)', 'add_label': 'add feature',
         'hint': 'enter DIMENSIONS - RCC basin/wall, waterproofing, cladding, pump, nozzles, lights ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select',
              'options': ['fountain basin', 'water wall', 'koi pond', 'reflecting pool', 'stream']},
             {'name': 'L', 'label': 'L (m)', 'type': 'number'},
             {'name': 'W', 'label': 'W / width (m)', 'type': 'number'},
             {'name': 'D', 'label': 'Depth (m)', 'type': 'number'},
             {'name': 't', 'label': 'RCC thk (mm)', 'type': 'number'},
             {'name': 'pump', 'label': 'Pump set', 'type': 'select',
              'options': ['yes', 'no']},
             {'name': 'lights', 'label': 'LED set', 'type': 'select',
              'options': ['yes', 'no']},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
         ],
         'default_rows': [{'id': 'WF1', 'type': 'fountain basin', 'L': 3, 'W': 3, 'D': 0.6, 't': 150, 'pump': 'yes', 'lights': 'yes', 'count': 1}]},
        {'id': 'gazebo', 'title': '7. Gazebo / Pavilion (dimension-driven)', 'add_label': 'add gazebo',
         'hint': 'enter dimensions - foundation pads, columns, roof frame, roofing and flooring ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select',
              'options': ['rectangular', 'hexagonal', 'octagonal']},
             {'name': 'L', 'label': 'L / dia (m)', 'type': 'number'},
             {'name': 'W', 'label': 'Width (m)', 'type': 'number'},
             {'name': 'h_col', 'label': 'Column ht (m)', 'type': 'number'},
             {'name': 'mat', 'label': 'Material', 'type': 'select',
              'options': ['timber', 'steel', 'aluminum']},
             {'name': 'roof', 'label': 'Roofing', 'type': 'select',
              'options': ['tile', 'metal sheet', 'polycarbonate', 'fabric', 'thatch']},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
         ],
         'default_rows': [{'id': 'G1', 'type': 'hexagonal', 'L': 4, 'W': 0, 'h_col': 2.7, 'mat': 'timber', 'roof': 'tile', 'count': 1}]},
        {'id': 'shade', 'title': '7B. Other Shade Structures', 'add_label': 'add shade',
         'hint': 'pergolas by m2, sails by m2, umbrellas by nos, car ports per car',
         'fields': T(SHADE), 'default_rows': [{'type': 'pergola - timber (m2)', 'qty': 18}]},
        {'id': 'play', 'title': '8. Children Play Zone', 'add_label': 'add play item',
         'hint': 'safety flooring by m2, structures by nos/set; fence the zone, shade it (see Shade)',
         'fields': T(PLAY), 'default_rows': [{'type': 'EPDM rubber flooring 30mm (m2)', 'qty': 60},
                                             {'type': 'multi-play combo (medium, set)', 'qty': 1},
                                             {'type': 'swing (2-seat, nos)', 'qty': 2}]},
        {'id': 'sports', 'title': '9. Sports & Fitness', 'add_label': 'add sport item', 'fields': T(SPORT),
         'default_rows': []},
        {'id': 'irrig', 'title': '10. Irrigation (zone-driven)', 'add_label': 'add zone',
         'hint': 'enter ZONE AREA - laterals, drippers/sprinklers, mainline, valves, controller ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'Zone ID', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select',
              'options': ['drip - shrubs/trees', 'drip - lawn edge', 'pop-up spray - lawn', 'pop-up rotor - lawn']},
             {'name': 'area', 'label': 'Area (m2)', 'type': 'number'},
             {'name': 'dist', 'label': 'Dist to controller (m)', 'type': 'number'},
             {'name': 'count', 'label': 'Nos of zones', 'type': 'number'},
         ],
         'default_rows': [{'id': 'Z1', 'type': 'drip - shrubs/trees', 'area': 200, 'dist': 15, 'count': 2},
                          {'id': 'Z2', 'type': 'pop-up spray - lawn', 'area': 150, 'dist': 20, 'count': 1}]},
        {'id': 'light', 'title': '11. Garden Lighting (circuit-driven)', 'add_label': 'add circuit',
         'hint': 'enter fixtures + area + dist to DB - fixtures, transformer by load, main + LV cable runs, '
                 'conduit, trench, junction boxes, timer, MCB, earthing ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'Circuit ID', 'type': 'text'},
             {'name': 'type', 'label': 'Fixture type', 'type': 'select',
              'options': ['bollard light', 'spike/spot light', 'in-ground uplight', 'pathway light',
                          'wall/step light', 'underwater light', 'garden flood 30W']},
             {'name': 'fixtures', 'label': 'Nos of light points', 'type': 'number'},
             {'name': 'area', 'label': 'Area covered (m2)', 'type': 'number'},
             {'name': 'dist', 'label': 'Dist to DB/panel (m)', 'type': 'number'},
             {'name': 'voltage', 'label': 'Voltage', 'type': 'select',
              'options': ['12V low-voltage', '230V mains']},
             {'name': 'protection', 'label': 'Cable protection', 'type': 'select',
              'options': ['direct burial', 'in conduit']},
             {'name': 'count', 'label': 'Nos of identical circuits', 'type': 'number'},
         ],
         'default_rows': [{'id': 'C1', 'type': 'bollard light', 'fixtures': 10, 'area': 300, 'dist': 25,
                           'voltage': '12V low-voltage', 'protection': 'direct burial', 'count': 1}]},
        {'id': 'lightx', 'title': '11B. Extra Lighting Items', 'add_label': 'add item',
         'hint': 'solar lights, festoon strings, spare cables/boxes - circuit items are in table 11',
         'fields': T(LIGHT),
         'default_rows': [{'type': 'string/festoon light (rmt)', 'qty': 30}]},
        {'id': 'furn', 'title': '12. Furniture & Decor', 'add_label': 'add furniture', 'fields': T(FURN),
         'default_rows': [{'type': 'bench - cast iron/wood (nos)', 'qty': 4}]},
        {'id': 'retain', 'title': '13. Retaining & Terrace Walls (dimension-driven)', 'add_label': 'add wall',
         'hint': 'enter DIMENSIONS - wall concrete/stone, drainage, weep holes, geo-grid ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Type', 'type': 'select',
              'options': ['gabion', 'stone masonry', 'concrete block', 'timber sleeper', 'crib']},
             {'name': 'L', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'H', 'label': 'Height (m)', 'type': 'number'},
             {'name': 't', 'label': 'Base thk (m)', 'type': 'number'},
             {'name': 'geo', 'label': 'Geo-grid', 'type': 'select',
              'options': ['no', 'yes (H>1.5m)']},
             {'name': 'count', 'label': 'Nos', 'type': 'number'},
         ],
         'default_rows': []},
        {'id': 'fence', 'title': '14. Fencing (with posts auto)', 'add_label': 'add fence',
         'hint': 'enter LENGTH + height - posts every 2m, excavation, concrete, rails, mesh ALL auto-compute',
         'fields': [
             {'name': 'id', 'label': 'ID', 'type': 'text'},
             {'name': 'type', 'label': 'Material', 'type': 'select',
              'options': ['timber', 'steel', 'aluminum', 'concrete']},
             {'name': 'L', 'label': 'Length (m)', 'type': 'number'},
             {'name': 'H', 'label': 'Height (m)', 'type': 'number'},
             {'name': 'style', 'label': 'Style', 'type': 'select',
              'options': ['picket', 'palisade', 'privacy panel', 'chain-link', 'bamboo']},
             {'name': 'count', 'label': 'Nos of runs', 'type': 'number'},
         ],
         'default_rows': [{'id': 'F1', 'type': 'steel', 'L': 40, 'H': 1.8, 'style': 'palisade', 'count': 1}]},
        {'id': 'gate', 'title': '14B. Gates', 'add_label': 'add gate',
         'hint': 'driveway gates by m2 or motorized set, pedestrian gates, pillars',
         'fields': T(GATE), 'default_rows': []},
        {'id': 'maint', 'title': '15. Maintenance (recurring)', 'add_label': 'add maintenance',
         'hint': 'optional annual packages - usually quoted separately', 'fields': T(MAINT),
         'default_rows': []},
    ],
}

_UNIT = {'siteprep': {'land clearing/grubbing (m2)': 'sqm', 'cut & fill (m3)': 'cum',
                      'grading/leveling (m2)': 'sqm', 'import topsoil (m3)': 'cum',
                      'compost/soil amendment (m3)': 'cum', 'mulching (m2)': 'sqm'},
         'lawn': None, 'paving': None, 'pool': None, 'irrig': None}


def _unit_for(tid, typ):
    u = _UNIT.get(tid)
    if u and typ in u:
        return u[typ]
    t = typ.lower()
    if '(m2' in t or 'm2)' in t or 'flooring' in t or 'turf' in t:
        return 'sqm'
    if '(m3)' in t:
        return 'cum'
    if '(rmt)' in t or 'edging' in t or 'fence' in t and 'picket' in t:
        return 'rmt'
    if '(nos)' in t or '(set)' in t or '(per ' in t:
        return 'nos'
    return 'sqm' if tid in ('lawn', 'paving', 'plants') and 'pot' not in t else 'nos'


def _pool(p, est, notes):
    """Dimension-driven swimming pool: every layer computed with visible formulas."""
    pid = p.get('id') or 'POOL'
    L, W = NUM(p.get('L')), NUM(p.get('W'))
    d1, d2 = NUM(p.get('d1'), 1.2), NUM(p.get('d2'))
    if not (L and W and d2):
        return
    n = int(NUM(p.get('count'), 1) or 1)
    d_avg = (d1 + d2) / 2.0
    wt = NUM(p.get('wall_t'), 200) / 1000.0
    ft = NUM(p.get('floor_t'), 200) / 1000.0
    fin = p.get('finish', 'glass mosaic')
    g = '5. Swimming Pool'
    wa = 2 * (L + W) * d_avg                       # wall face area
    fl = L * W                                      # floor area
    per = 2 * (L + W)
    # 1. excavation (plan + 600mm working space x avg depth)
    exc = (L + 0.6) * (W + 0.6) * (d_avg + 0.3)
    est.item(g, f'Excavation incl. 300mm working space - {pid}', 'cum', round(exc * n, 2), rate=DIM_RATES.get('excavation', 450),
             take=(n, L + 0.6, W + 0.6, d_avg + 0.3), note='(L+0.6) x (W+0.6) x (depth+0.3 PCC bed)')
    # 2. PCC bed 100mm
    pcc = (L + 0.3) * (W + 0.3) * 0.10
    est.item(g, f'PCC bed 100mm - {pid}', 'cum', round(pcc * n, 2), rate=DIM_RATES.get('pcc', 6000),
             take=(n, L + 0.3, W + 0.3, 0.10), note='plan + 150mm offset x 100mm')
    # 3. RCC floor slab
    rcc_f = fl * ft
    est.item(g, f'RCC floor slab {int(ft*1000)}mm M25 - {pid}', 'cum', round(rcc_f * n, 2), rate=DIM_RATES.get('rcc_m25', 16500),
             take=(n, L, W, ft), note='L x W x floor thk')
    # 4. RCC walls
    rcc_w = per * d_avg * wt
    est.item(g, f'RCC walls {int(wt*1000)}mm M25 - {pid}', 'cum', round(rcc_w * n, 2), rate=DIM_RATES.get('rcc_m25', 16500),
             take=(n, per, d_avg, wt), note='2(L+W) x avg depth x wall thk')
    # 5. steel ~90 kg/m3 (water-retaining)
    st_kg = (rcc_f + rcc_w) * 90
    est.item(g, f'TMT steel @90 kg/m3 - {pid}', 'kg', round(st_kg * n, 1), rate=DIM_RATES.get('steel_kg', 150),
             take=(n, None, None, None), note='(floor + wall concrete) x 90 kg/m3 - water-retaining spec')
    # 6. waterproofing (floor + walls both faces)
    wp = fl + 2 * wa
    est.item(g, f'Waterproofing membrane - {pid}', 'sqm', round(wp * n, 1), rate=DIM_RATES.get('waterproof', 450),
             take=(n, None, None, None), note='floor + walls both faces')
    # 7. render/plaster
    est.item(g, f'Cement render 15mm - {pid}', 'sqm', round(wp * n, 1), rate=DIM_RATES.get('render', 350),
             take=(n, None, None, None), note='floor + wall faces')
    # 8. finish (mosaic/tile)
    fin_rate = POOL_FIN.get(fin, 3200)
    est.item(g, f'Finish: {fin} - {pid}', 'sqm', round(wp * n, 1), rate=fin_rate,
             take=(n, None, None, None), note='floor + wall faces')
    # 9. coping
    est.item(g, f'Pool coping stone - {pid}', 'rmt', round(per * n, 1), rate=DIM_RATES.get('coping', 2800),
             take=(n, per, None, None), note='pool perimeter 2 x (L+W)')
    notes.append(f'{pid}: {L:g}x{W:g}m, avg depth {d_avg:.2f}m - 9 work items auto-computed')


def _gazebo(gz, est, notes):
    """Dimension-driven gazebo: foundation, columns, roof frame, roofing, flooring."""
    gid = gz.get('id') or 'GZ'
    typ = gz.get('type', 'rectangular')
    L, W = NUM(gz.get('L')), NUM(gz.get('W'))
    hc = NUM(gz.get('h_col'), 2.7)
    n = int(NUM(gz.get('count'), 1) or 1)
    if not L:
        return
    mat = gz.get('mat', 'timber')
    roof = gz.get('roof', 'tile')
    g = '7. Gazebo / Pavilion'
    if typ == 'rectangular':
        area = L * (W or L)
        per = 2 * (L + (W or L))
        ncol = 4
    else:  # hex/oct: L = diameter
        area = 3.14159 * (L / 2) ** 2 * (0.87 if typ == 'hexagonal' else 0.96)
        per = 3.14159 * L
        ncol = 6 if typ == 'hexagonal' else 8
    mr = GAZ_MAT.get(mat, GAZ_MAT['timber'])
    # 1. foundation pads (excavation + PCC + RCC pad 600x600x300 each)
    est.item(g, f'Excavation for column pads x{ncol} - {gid}', 'cum', round(ncol * 0.9 * 1.2 * n, 2), rate=DIM_RATES.get('pad_exc', 450),
             take=(ncol * n, 0.9, 1.2, None), note=f'{ncol} pads x 900x1200mm pit')
    est.item(g, f'RCC pad 600x600x300 M20 x{ncol} - {gid}', 'cum', round(ncol * 0.6 * 0.6 * 0.3 * n, 3), rate=DIM_RATES.get('rcc_pad', 16000),
             take=(ncol * n, 0.6, 0.6, 0.3), note=f'{ncol} pads x 600x600x300mm')
    # 2. columns
    est.item(g, f'Columns {mat} x{ncol} @ {hc:g}m ht - {gid}', 'rmt', round(ncol * hc * n, 1), rate=mr['col_rate'],
             take=(ncol * n, hc, None, None), note=f'{ncol} columns x {hc:g}m height')
    # 3. roof frame (rafters + ring beam) by roof area
    _rect = (typ == 'rectangular')
    est.item(g, f'Roof frame {mat} - {gid}', 'sqm', round(area * n, 1), rate=mr['frame_rate'],
             take=((n, L, (W or L)) if _rect else (n, None, None, None)),
             note=f'rafters + ring beams over {area:.1f} m2 roof')
    # 4. roofing material
    est.item(g, f'Roofing: {roof} - {gid}', 'sqm', round(area * 1.15 * n, 1), rate=GAZ_ROOF.get(roof, 1800),
             take=((n, L, (W or L), 1.15) if _rect else (n, area, 1.15, None)), note='plan area x 1.15 pitch')
    # 5. flooring (paving under gazebo)
    est.item(g, f'Floor paving under gazebo - {gid}', 'sqm', round(area * n, 1), rate=DIM_RATES.get('paving_floor', 1400),
             take=((n, L, (W or L)) if _rect else (n, None, None, None)), note='footprint area')
    notes.append(f'{gid}: {typ} {L:g}{("x" + str(W)) if W and typ == "rectangular" else "m dia"}, {ncol} {mat} cols, {roof} roof - 5 work items')


def _paving(pv, est, notes):
    """Paving with full sub-base build-up from area."""
    pid = pv.get('id') or 'PV'
    a = NUM(pv.get('area'))
    if not a:
        return
    n = int(NUM(pv.get('count'), 1) or 1)
    typ = pv.get('type') or 'interlocking paver'
    thk = NUM(pv.get('thk'), 60)
    g = '4. Paving (with sub-base auto)'
    A = a * n
    est.item(g, f'Excavation 200mm - {pid}', 'cum', round(A * 0.20, 2), rate=DIM_RATES.get('paving_exc', 350),
             take=(n, a, 0.20, None), note='area x 200mm depth')
    est.item(g, f'Crusher run sub-base 150mm - {pid}', 'cum', round(A * 0.15, 2), rate=DIM_RATES.get('subbase', 2800),
             take=(n, a, 0.15, None), note='area x 150mm compacted')
    est.item(g, f'Bedding sand 50mm - {pid}', 'cum', round(A * 0.05, 2), rate=DIM_RATES.get('bedding_sand', 3200),
             take=(n, a, 0.05, None), note='area x 50mm')
    est.item(g, f'{typ} {thk:.0f}mm - {pid}', 'sqm', round(A, 1), rate=PAVE.get(typ, 1200),
             take=(n, a, None, None), note='finished surface')


def _waterfeature(wf, est, notes):
    """Dimension-driven water feature: basin, waterproofing, cladding, pump, lights."""
    wid = wf.get('id') or 'WF'
    typ = wf.get('type') or 'fountain basin'
    L, W = NUM(wf.get('L')), NUM(wf.get('W'))
    D = NUM(wf.get('D'), 0.6)
    t = NUM(wf.get('t'), 150) / 1000.0
    n = int(NUM(wf.get('count'), 1) or 1)
    if not (L and W):
        return
    g = '6. Water Features'
    area = L * W
    # excavation
    exc = (L + 0.3) * (W + 0.3) * (D + 0.1)
    est.item(g, f'Excavation - {wid} ({typ})', 'cum', round(exc * n, 2), rate=DIM_RATES.get('excavation', 450),
             take=(n, L + 0.3, W + 0.3, D + 0.1), note='(L+0.3) x (W+0.3) x (D+0.1)')
    # PCC
    est.item(g, f'PCC bed 75mm - {wid}', 'cum', round((L+0.15)*(W+0.15)*0.075*n, 3), rate=DIM_RATES.get('pcc', 6000),
             take=(n, L + 0.15, W + 0.15, 0.075), note='(L+0.15) x (W+0.15) x 75mm')
    # RCC basin (floor + walls)
    rcc = area * t + 2*(L+W)*D*t
    est.item(g, f'RCC basin {int(t*1000)}mm M25 - {wid}', 'cum', round(rcc*n, 3), rate=DIM_RATES.get('rcc_m25', 16500),
             take=(n, None, None, None), note='floor + wall concrete (water-retaining)')
    # waterproofing
    wa = area + 2*(L+W)*D
    est.item(g, f'Waterproofing - {wid}', 'sqm', round(wa*n, 1), rate=DIM_RATES.get('waterproof', 450),
             take=(n, None, None, None), note='floor + inner wall faces')
    # stone cladding
    est.item(g, f'Stone cladding - {wid}', 'sqm', round(wa*n, 1), rate=WF_BUILD.get('water feature stone cladding (m2)', 3500),
             take=(n, None, None, None), note='floor + inner wall faces')
    # pump + nozzles
    if wf.get('pump') == 'yes':
        est.item(g, f'Pump + piping set - {wid}', 'set', n, rate=WF_BUILD.get('fountain pump + piping (per set)', 85000),
                 take=(n, None, None, None), note='recirculation pump + piping')
        est.item(g, f'Nozzles - {wid}', 'set', n, rate=WF_BUILD.get('fountain nozzles (per set)', 25000),
                 take=(n, None, None, None), note='nozzle set per feature')
    if wf.get('lights') == 'yes':
        est.item(g, f'LED light set - {wid}', 'set', n, rate=WF_BUILD.get('fountain LED lights (per set)', 35000),
                 take=(n, None, None, None), note='underwater LED set')
    notes.append(f'{wid}: {typ} {L:g}x{W:g}m x{D:g}D - 6-8 items auto')


def _retaining(rw, est, notes):
    """Dimension-driven retaining wall: wall body, drainage, weep holes, geo-grid."""
    rid = rw.get('id') or 'RW'
    typ = rw.get('type') or 'stone masonry'
    L, H = NUM(rw.get('L')), NUM(rw.get('H'))
    t = NUM(rw.get('t'), max(0.3, H * 0.4))
    n = int(NUM(rw.get('count'), 1) or 1)
    if not (L and H):
        return
    g = '13. Retaining & Terrace Walls'
    # average thickness = base/2 (trapezoidal)
    t_avg = t / 2.0 if t > H * 0.25 else t  # batter wall
    vol = L * H * t_avg
    key = {'gabion': 'gabion wall (m3 cage + stone)', 'stone masonry': 'stone masonry retaining (m3)',
           'concrete block': 'concrete block retaining (m3)', 'timber sleeper': 'timber sleeper wall (m2 face)',
           'crib': 'crib wall (m2 face)'}[typ]
    face = L * H
    if 'm2' in key:
        est.item(g, f'{typ} wall - {rid}', 'sqm', round(face * n, 1), rate=RETAIN.get(key, 4000),
                 take=(n, L, H, None), note=f'L x H = {L:g} x {H:g} face area')
    else:
        est.item(g, f'{typ} wall - {rid}', 'cum', round(vol * n, 2), rate=RETAIN.get(key, 6000),
                 take=(n, L, H, t_avg), note=f'L x H x avg thk ({t_avg:.2f}m)')
    # drainage behind wall
    est.item(g, f'Drainage gravel 300mm behind - {rid}', 'cum', round(L * H * 0.3 * n, 2), rate=DIM_RATES.get('drainage_gravel', 2800),
             take=(n, L, H, 0.30), note='L x H x 300mm gravel blanket')
    est.item(g, f'Drainage pipe 110mm - {rid}', 'rmt', round(L * n, 1), rate=DIM_RATES.get('drainage_pipe', 850),
             take=(n, L, None, None), note='along wall base')
    # weep holes @1.5m c/c
    nw = int(L / 1.5) + 1
    est.item(g, f'Weep holes 50mm @1.5m c/c - {rid}', 'nos', nw * n, rate=DIM_RATES.get('weep_hole', 350),
              take=(nw * n, None, None, None), note=f'L/1.5m + 1 = {nw} per run')
    if 'geo' in str(rw.get('geo', '')):
        est.item(g, f'Geo-grid reinforcement - {rid}', 'sqm', round(face * n, 1), rate=DIM_RATES.get('geo_grid', 1200),
                 take=(n, L, H, None), note='L x H reinforced face')
    notes.append(f'{rid}: {typ} {L:g}x{H:g}m - 4-5 items auto')


def _fence(fn, est, notes):
    """Dimension-driven fencing: posts @2m, excavation+concrete, rails, infill, caps."""
    fid = fn.get('id') or 'FE'
    typ = fn.get('type') or 'steel'
    L, H = NUM(fn.get('L')), NUM(fn.get('H'))
    style = fn.get('style') or 'picket'
    n = int(NUM(fn.get('count'), 1) or 1)
    if not (L and H):
        return
    g = '14. Fencing (with posts auto)'
    tot = L * n
    npost = int(tot / 2.0) + 1
    post_key = {'timber': 'timber post 100x100 (per post)', 'steel': 'steel post 60x60 (per post)',
                'aluminum': 'aluminum post (per post)', 'concrete': 'concrete post (per post)'}[typ]
    # posts
    est.item(g, f'Post excavation + concrete - {fid}', 'nos', npost, rate=DIM_RATES.get('post_exc', 1200),
             take=(npost, None, None, None), note=f'posts @2m c/c = L/2 + 1 = {npost}')
    est.item(g, f'{typ} posts - {fid}', 'nos', npost, rate=FENCE_CALC.get(post_key, 2000),
             take=(npost, None, None, None), note='one post per 2m run')
    # rails
    est.item(g, f'Horizontal rails - {fid}', 'rmt', round(tot * 2, 1), rate=DIM_RATES.get('rail', 450),
             take=(n, tot, 2, None), note='run length x 2 rails')
    # infill by face area
    face = tot * H
    style_key = {'picket': 'picket 100mm (m2 face)', 'palisade': 'palisade steel (m2 face)',
                 'privacy panel': 'palisade steel (m2 face)', 'chain-link': 'chain-link mesh (m2 face)',
                 'bamboo': 'bamboo (m2 face)'}[style]
    est.item(g, f'{style} infill - {fid}', 'sqm', round(face, 1), rate=FENCE_CALC.get(style_key, 1800),
             take=(n, tot, H, None), note=f'run {tot:g}m x height {H:g}m')
    est.item(g, f'Post caps + fixtures - {fid}', 'nos', npost, rate=DIM_RATES.get('post_cap', 350),
             take=(npost, None, None, None), note='1 per post')
    notes.append(f'{fid}: {typ} {style} {L:g}m x {H:g}m - {npost} posts + 5 items auto')


def _irrigation(ir, est, notes):
    """Zone-driven irrigation: laterals, emitters, mainline, valves, controller share."""
    zid = ir.get('id') or 'Z'
    typ = ir.get('type') or 'drip - shrubs/trees'
    a = NUM(ir.get('area'))
    dist = NUM(ir.get('dist'), 10)
    n = int(NUM(ir.get('count'), 1) or 1)
    if not a:
        return
    g = '10. Irrigation (zone-driven)'
    is_spray = 'pop-up' in typ
    if is_spray:
        # sprinklers @ 4m triangular spacing = 1 per ~12 m2
        ns = int(a / 12) + 1
        est.item(g, f'Pop-up sprinklers - {zid} ({typ})', 'nos', ns * n, rate=DIM_RATES.get('sprinkler', 2800),
                 take=(ns * n, None, None, None), note=f'area/12 + 1 = {ns} (4m triangular)')
        est.item(g, f'PVC mainline 32mm - {zid}', 'rmt', round(dist * n, 1), rate=DIM_RATES.get('pvc_main_32', 220),
                 take=(n, dist, None, None), note='controller to zone')
    else:
        # drip: lateral grid @0.5m rows, drippers @0.5m
        lat = int(a / 0.5) * 0.5 * 2  # approximate: rows both directions
        est.item(g, f'Drip lateral 16mm - {zid} ({typ})', 'rmt', round(lat * n, 1), rate=DIM_RATES.get('drip_lateral', 85),
                 take=(n, round(lat, 1), None, None), note='laterals @0.5m row spacing both ways')
        nd = int(a * 2)  # 2 drippers per m2
        est.item(g, f'Drippers 4L/hr - {zid}', 'nos', nd * n, rate=DIM_RATES.get('dripper', 45),
                 take=(nd * n, None, None, None), note=f'area x 2 per m2 = {nd}')
        est.item(g, f'PVC mainline 32mm - {zid}', 'rmt', round(dist * n, 1), rate=DIM_RATES.get('pvc_main_32', 220),
                 take=(n, dist, None, None), note='controller to zone')
    # per-zone items
    est.item(g, f'Zone valve - {zid}', 'nos', n, rate=DIM_RATES.get('zone_valve', 3500),
             take=(n, None, None, None), note='1 per zone')
    est.item(g, f'Saddle + fittings - {zid}', 'zone', n, rate=DIM_RATES.get('saddle', 4500),
             take=(n, None, None, None), note='clamps + fittings per zone')
    notes.append(f'{zid}: {typ} {a:g}m2 - 4-5 items auto')


def _lighting(c, est, notes):
    """Circuit-driven garden lighting: fixtures, transformer sized by load,
    main + LV cable runs, conduit, trench, junction boxes, timer, MCB, earthing."""
    cid = c.get('id') or 'LT'
    typ = c.get('type') or 'bollard light'
    nf = NUM(c.get('fixtures'))
    if not nf:
        return
    n = int(NUM(c.get('count'), 1) or 1)
    a = NUM(c.get('area'))
    dist = NUM(c.get('dist'), 10)
    lv = '12V' in str(c.get('voltage', '12V low-voltage'))
    conduit = 'conduit' in str(c.get('protection', 'direct burial'))
    g = '11. Garden Lighting (circuit-driven)'
    w = LIGHT_W.get(typ, 8)                       # LED watts per fixture
    spine = 2 * (a ** 0.5) if a else nf * 2.0     # distribution runs across the area
    branches = nf * 6.0                           # avg 6m cable run per fixture
    # 1. fixtures (LED, incl. install)
    est.item(g, f'{typ} LED {w}W - {cid}', 'nos', int(nf) * n, rate=LIGHT_FIX.get(typ + ' (nos)', 5000),
             take=(int(nf) * n, None, None, None), note=f'LED {w}W fixture incl. install')
    # 2. transformer sized by load x1.25 (12V systems)
    if lv:
        tw = nf * w * 1.25
        nt = int(tw / 300) + (1 if tw % 300 else 0)
        est.item(g, f'Transformer 300VA 12V - {cid}', 'nos', nt * n, rate=DIM_RATES.get('xfmr_300va', 18000),
                 take=(nt * n, None, None, None), note=f'{nf:g} x {w}W x 1.25 = {tw:.0f}W -> {nt} x 300VA')
    # 3. cable runs (+10% slack)
    if lv:
        est.item(g, f'Main cable 3Cx2.5mm2 armoured - {cid}', 'rmt', round(dist * 1.10 * n, 1),
                 rate=DIM_RATES.get('main_cable', 420), take=(n, dist, 1.10, None), note=f'dist {dist:g}m + 10% slack')
        est.item(g, f'LV cable 2Cx2.5mm2 - {cid}', 'rmt', round((spine + branches) * 1.10 * n, 1),
                 rate=DIM_RATES.get('lv_cable', 180), take=(n, round(spine + branches, 1), 1.10, None),
                 note=f'spine 2xsqrt(area)={spine:.1f}m + {nf:g}x6m branches, +10% slack')
    else:
        est.item(g, f'Armoured cable 3Cx2.5mm2 (all runs) - {cid}', 'rmt',
                 round((dist + spine + branches) * 1.10 * n, 1), rate=DIM_RATES.get('main_cable', 420),
                 take=(n, round(dist + spine + branches, 1), 1.10, None),
                 note=f'dist {dist:g}m + spine {spine:.1f}m + {nf:g}x6m branches, +10% slack')
    # 4. conduit protection (optional)
    if conduit:
        est.item(g, f'Conduit 25mm PVC - {cid}', 'rmt', round((spine + branches) * 1.10 * n, 1),
                 rate=DIM_RATES.get('conduit_25', 90), take=(n, round(spine + branches, 1), 1.10, None),
                 note='full in-ground run protected')
    # 5. trench along full route
    est.item(g, f'Cable trench 450x200mm - {cid}', 'rmt', round((dist + spine + branches) * n, 1),
             rate=DIM_RATES.get('cable_trench', 350), take=(n, round(dist + spine + branches, 1), None, None),
             note='main + spine + branch runs, 450mm deep')
    # 6. junction boxes (1 per 4 fixtures)
    nj = int(nf / 4) + (1 if nf % 4 else 0)
    est.item(g, f'IP68 junction boxes - {cid}', 'nos', nj * n, rate=DIM_RATES.get('jbox_ip68', 1200),
             take=(nj * n, None, None, None), note=f'fixtures/4 = {nj} per circuit')
    # 7-9. controls, protection, earthing
    est.item(g, f'Timer/photocell control - {cid}', 'set', n, rate=DIM_RATES.get('timer', 4500),
             take=(n, None, None, None), note='1 control per circuit')
    est.item(g, f'MCB 6A + DB connection - {cid}', 'nos', n, rate=DIM_RATES.get('mcb_db', 2500),
             take=(n, None, None, None), note='1 way per circuit')
    est.item(g, f'Earth rod 16mm x 1.5m + lug - {cid}', 'nos', n, rate=DIM_RATES.get('earth_rod', 1800),
             take=(n, None, None, None), note='1 per circuit')
    notes.append(f'{cid}: {typ} x{int(nf)} {"12V" if lv else "230V"} - '
                 f'fixtures, transformer, cables, trench, boxes, MCB, earth auto')



def _flowerbed(fb, est, notes):
    """Dimension-driven flower bed: excavation, soil mix, edging, mulch, plant count by spacing."""
    bid = fb.get('id') or 'FB'
    L, W = NUM(fb.get('L')), NUM(fb.get('W'))
    sp = NUM(fb.get('spacing'), 30) / 100.0  # cm to m
    pt = fb.get('plant_type') or 'annuals (seasonal)'
    edge = fb.get('edge') or 'stone'
    n = int(NUM(fb.get('count'), 1) or 1)
    if not (L and W):
        return
    g = '2B. Flower Beds'
    area = L * W
    per = 2 * (L + W)
    # 1. excavation 300mm
    est.item(g, f'Excavation 300mm - {bid}', 'cum', round(area * 0.30 * n, 2), rate=DIM_RATES.get('bed_exc', 450),
             take=(n, L, W, 0.30), note='L x W x 300mm depth')
    # 2. soil + compost mix (backfill 250mm)
    est.item(g, f'Soil + compost mix 250mm - {bid}', 'cum', round(area * 0.25 * n, 2), rate=DIM_RATES.get('soil_mix', 2500),
             take=(n, L, W, 0.25), note='L x W x 250mm backfill')
    # 3. edging
    if edge != 'none':
        est.item(g, f'Edging ({edge}) - {bid}', 'rmt', round(per * n, 1), rate=BED_EDGE.get(edge, 900),
                 take=(n, per, None, None), note=f'2 x (L+W) = {per:g}m perimeter')
    # 4. mulch 50mm
    est.item(g, f'Mulch 50mm - {bid}', 'cum', round(area * 0.05 * n, 2), rate=DIM_RATES.get('mulch', 350),
             take=(n, L, W, 0.05), note='L x W x 50mm top dressing')
    # 5. plants by spacing grid
    np_ = int((L / sp) + 1) * int((W / sp) + 1)
    est.item(g, f'Plants: {pt} @{int(sp*100)}cm - {bid}', 'nos', np_ * n, rate=FLOWER_PLANT.get(pt, 200),
             take=(np_ * n, None, None, None), note=f'({int(L/sp)+1}) x ({int(W/sp)+1}) grid = {np_} per bed')
    notes.append(f'{bid}: {L:g}x{W:g}m, {pt}, {np_} plants/bed - 5 items auto')


def _hedge(hg, est, notes):
    """Dimension-driven hedge: trench, soil, plant count @spacing, first trim."""
    hid = hg.get('id') or 'H'
    L = NUM(hg.get('L'))
    H = float(hg.get('H') or 1.0)
    sp = NUM(hg.get('spacing'), 40) / 100.0
    typ = hg.get('type') or 'duranta gold'
    n = int(NUM(hg.get('count'), 1) or 1)
    if not L:
        return
    g = '2C. Hedge Rows'
    # 1. trench 400x400mm
    est.item(g, f'Trench 400x400mm - {hid} ({typ})', 'cum', round(L * 0.4 * 0.4 * n, 2), rate=DIM_RATES.get('trench_exc', 450),
             take=(n, L, 0.4, 0.4), note='L x 400mm x 400mm trench')
    # 2. soil + compost backfill
    est.item(g, f'Soil + compost backfill - {hid}', 'cum', round(L * 0.4 * 0.4 * 0.8 * n, 2), rate=DIM_RATES.get('soil_mix', 2500),
             take=(n, L, 0.4, 0.32), note='trench x 80% planting backfill')
    # 3. plants @spacing
    np_ = int(L / sp) + 1
    est.item(g, f'Plants: {typ} @{int(sp*100)}cm - {hid}', 'nos', np_ * n, rate=HEDGE_PLANT.get(typ, 200),
             take=(np_ * n, None, None, None), note=f'L/{sp:g}m + 1 = {np_} per row')
    notes.append(f'{hid}: {typ} {L:g}m @{int(sp*100)}cm = {np_} plants/row - 3 items auto')


def _trees(tr, est, notes):
    """Pit-driven tree planting: pit excavation, soil mix, stake, guard per tree."""
    tid = tr.get('id') or 'T'
    typ = tr.get('type') or ' flowering tree (gulmohar/jacaranda)'
    size = tr.get('size') or 'small (2-3m)'
    n = int(NUM(tr.get('qty'), 0) or 0)
    if not n:
        return
    g = '2D. Tree Planting'
    spec = TREE_PLANT.get(size, TREE_PLANT['small (2-3m)'])
    pit = spec['pit']  # pit side (m)
    soil = spec['soil']  # soil volume (m3)
    # 1. pit excavation (square pit)
    pit_vol = pit ** 2 * (pit * 0.8)  # approx depth = 80% of side
    est.item(g, f'Pit excavation {int(pit*100)}x{int(pit*100)}x{int(pit*80)}cm - {tid}', 'cum',
             round(pit_vol * n, 2), rate=DIM_RATES.get('soil_exc', 450),
             take=(n, pit, pit, round(pit * 0.8, 3)), note=f'{n} pits x {pit}x{pit}x{pit*0.8:.1f}m')
    # 2. soil + compost mix
    est.item(g, f'Soil + compost mix - {tid}', 'cum', round(soil * n, 2), rate=DIM_RATES.get('soil_mix', 2500),
             take=(n, soil, None, None), note=f'{soil} m3 planting mix per tree ({size})')
    # 3. tree (supply + plant)
    rate = TREE_RATE.get(typ, 3000) + spec['rate'] * 0.3  # tree cost + planting labor share
    est.item(g, f'{typ.strip()} ({size}) - {tid}', 'nos', n, rate=int(rate),
             take=(n, None, None, None), note='supply + plant')
    # 4. stake + guard (for saplings and small only)
    if 'sapling' in size or 'small' in size:
        est.item(g, f'Bamboo stake + tree guard - {tid}', 'nos', n, rate=DIM_RATES.get('tree_stake', 450) + DIM_RATES.get('tree_guard', 350),
                 take=(n, None, None, None), note='1 set per tree')
    notes.append(f'{tid}: {n}x {typ.strip()} ({size}) - 3-4 items auto per tree')


def _marble(mb, est, notes):
    """Dimension-driven marble/granite finish: sub-base, mortar bed, slabs, polishing."""
    mid = mb.get('id') or 'M'
    typ = mb.get('type') or 'granite (polished)'
    L, W = NUM(mb.get('L')), NUM(mb.get('W'))
    thk = NUM(mb.get('thk'), 20)
    n = int(NUM(mb.get('count'), 1) or 1)
    if not (L and W):
        return
    g = '4D. Marble / Stone Finish'
    area = L * W
    # 1. crusher-run sub-base 100mm
    est.item(g, f'Crusher-run sub-base 100mm - {mid}', 'cum', round(area * 0.10 * n, 2), rate=DIM_RATES.get('sub_base_crusher', 2800),
             take=(n, L, W, 0.10), note='L x W x 100mm')
    # 2. cement-sand mortar bed 30mm
    est.item(g, f'Mortar bed 1:4, 30mm - {mid}', 'cum', round(area * 0.03 * n, 3), rate=DIM_RATES.get('mortar_bed', 3500),
             take=(n, L, W, 0.03), note='L x W x 30mm bed')
    # 3. slabs by area + 10% cutting waste
    est.item(g, f'{typ} {thk:.0f}mm slabs - {mid}', 'sqm', round(area * 1.10 * n, 1), rate=MARBLE.get(typ, 3500),
             take=(n, L, W, 1.10), note=f'L x W x 1.10 (10% cutting waste)')
    # 4. polishing (if polished type)
    if 'polished' in typ or 'marble' in typ.lower():
        est.item(g, f'Polishing - {mid}', 'sqm', round(area * n, 1), rate=DIM_RATES.get('marble_polish', 400),
                 take=(n, L, W, None), note='L x W polished face')
    notes.append(f'{mid}: {typ} {L:g}x{W:g}m = {area:.1f} m2 + sub-base + mortar - 4 items auto')


def _lawn(lw, est, notes):
    """Dimension-driven lawn: soil prep, seeding/rolls, fertilizer."""
    lid = lw.get('id') or 'L'
    typ = lw.get('type') or 'carpet grass roll'
    L, W = NUM(lw.get('L')), NUM(lw.get('W'))
    n = int(NUM(lw.get('count'), 1) or 1)
    if not (L and W):
        return
    g = '2. Lawn'
    area = L * W
    est.item(g, f'Soil prep + leveling 150mm - {lid}', 'cum', round(area * 0.15 * n, 2), rate=DIM_RATES.get('soil_exc', 450),
             take=(n, L, W, 0.15), note='L x W x 150mm rotary hoe + level')
    est.item(g, f'{typ} - {lid}', 'sqm', round(area * n, 1), rate=LAWN.get(typ, 150),
             take=(n, L, W, None), note='lawn area L x W')
    est.item(g, f'Starter fertilizer - {lid}', 'kg', round(area * 0.03 * n, 1), rate=800,
             take=(n, L, W, 0.03), note='L x W x 30g per m2')
    notes.append(f'{lid}: {typ} {L:g}x{W:g}m = {area:.1f} m2 - 3 items auto')


def estimate(sched):
    T2 = sched['tables']
    est = Estimate({})
    notes = []
    # dimension-driven tables first
    for p in T2.get('pool', []):
        _pool(p, est, notes)
    for gz in T2.get('gazebo', []):
        _gazebo(gz, est, notes)
    for pv in T2.get('paving', []):
        _paving(pv, est, notes)
    for lw in T2.get('lawn', []):
        _lawn(lw, est, notes)
    for fb in T2.get('flowerbed', []):
        _flowerbed(fb, est, notes)
    for hg in T2.get('hedge', []):
        _hedge(hg, est, notes)
    for tr in T2.get('trees', []):
        _trees(tr, est, notes)
    for mb in T2.get('marble', []):
        _marble(mb, est, notes)
    for wf in T2.get('wf', []):
        _waterfeature(wf, est, notes)
    for rw in T2.get('retain', []):
        _retaining(rw, est, notes)
    for fn in T2.get('fence', []):
        _fence(fn, est, notes)
    for ir in T2.get('irrig', []):
        _irrigation(ir, est, notes)
    for cl in T2.get('light', []):
        _lighting(cl, est, notes)
    _skip = ('pool', 'gazebo', 'paving', 'wf', 'retain', 'fence', 'irrig', 'lawn', 'flowerbed', 'hedge', 'trees', 'marble', 'light')
    for tid, title in [(t['id'], t['title']) for t in SPEC['tables'] if t['id'] not in _skip]:
        d = {'siteprep': SITEPREP, 'plants': PLANT,
             'pool_eq': POOL_EQ, 'shade': SHADE, 'deck': DECK, 'edges': EDGE,
             'play': PLAY, 'sports': SPORT, 'lightx': LIGHT, 'furn': FURN,
             'drain': DRAIN, 'gate': GATE, 'maint': MAINT}[tid]
        for r in T2.get(tid, []):
            q = NUM(r.get('qty'))
            if not q:
                continue
            typ = r.get('type') or list(d)[0]
            u = _unit_for(tid, typ)
            note = (' | ' + str(r.get('spec'))) if r.get('spec') else ''
            est.item(title, typ + note, u, q, rate=ro(r, d.get(typ, 1000)),
                     take=((q, None, None, None) if u == 'nos' else (None, None, None, None)), note=note or 'as entered')
    proj = {'name': sched['scalars'].get('project_name', ''), 'location': sched['scalars'].get('location', '')}
    n_items = sum(len(v) for v in est.groups.values())
    kpis = [('Landscape items', '%d' % n_items)]
    return est.result(project=proj, kpis=kpis)


# ---- market-rate resolver (pre-fills Rate boxes; same formula as calc) ----
from modules.common import make_row_rate as _mrr

_ALL_TABLES = {'siteprep': SITEPREP, 'lawn': LAWN, 'plants': PLANT,
               'pool_eq': POOL_EQ, 'water': WATER, 'shade': SHADE, 'deck': DECK, 'edges': EDGE,
               'play': PLAY, 'sports': SPORT, 'irrig': IRRIG, 'lightx': LIGHT, 'furn': FURN,
               'fence': FENCE, 'drain': DRAIN, 'gate': GATE, 'maint': MAINT}

SPEC['row_rate'] = _mrr({tid: (lambda r, s, _d=d: _d.get(r.get('type'), 1000)) for tid, d in _ALL_TABLES.items()})
