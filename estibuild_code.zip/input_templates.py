import io, json, re

def _sc(D):
    """Staircase from DEFAULT_SCHEDULE — handles both list and dict formats."""
    sc = D.get('staircase', {})
    if isinstance(sc, list):
        return sc[0] if sc else {}
    return sc


"""Fillable input templates (HTML + Excel) for every module + parsers for uploads.

Flow:
  1. User downloads a fillable HTML/Excel template from the app (or gets an AI-drafted
     pre-filled HTML from the AI reader).
  2. User fills it offline in any browser - with add-row buttons for extra items.
  3. User clicks 'Download Data File' -> gets a .json.
  4. User uploads the .json (or the filled .xlsx) to the module -> form auto-fills
     exactly (zero AI cost, deterministic).

The exported JSON mirrors the app's internal schedule structure.
"""
import io
import json

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

HDR_FILL = PatternFill('solid', fgColor='1F3B57')
HDR_FONT = Font(color='FFFFFF', bold=True)


# ------------------------------------------------------------------ HTML templates
def _inp(name, val, typ='text', options=None, extra='', suggest=False):
    v = _esc('' if val is None else str(val))
    if options and suggest:
        # combo: typeable input + click-to-pick dropdown (same UX as the web app)
        pick = ''.join(f'<option>{_esc(o)}</option>' for o in options)
        return (f'<div class="combo"><input type="text" name="{name}" value="{v}" {extra}>'
                f'<select class="cbs" tabindex="-1" onchange="cbsel(this)">'
                f'<option value="">&#9662;</option>{pick}</select></div>')
    if options:
        opts = ''.join(f'<option{" selected" if str(o) == v else ""}>{_esc(o)}</option>' for o in options)
        return f'<select name="{name}" onchange="oKindChanged(this)" {extra}>{opts}</select>'
    return f'<input type="{typ}" name="{name}" value="{v}" {extra}>'


def _offline_schedule_field(field, value):
    """A schedule input matching the live module cards, including units."""
    name = field['name']
    if field['type'] == 'select':
        control = _inp(name, value, options=field.get('options'))
    elif field['type'] == 'suggest':
        control = _inp(name, value, options=field.get('options'), suggest=True)
    else:
        control = _inp(name, value)
    dimension = field.get('_dim')
    if not dimension:
        return control
    units = ['m2', 'sqft'] if dimension == 'A' else ['m', 'ft', 'in', 'cm', 'mm']
    options = ''.join(f'<option value="{unit}">{unit}</option>' for unit in units)
    return (f'<div class="dimfield">{control}'
            f'<select class="dimunit" name="{name}__unit">{options}</select></div>')


def _esc(s):
    return str(s if s is not None else '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


OFFLINE_JS = r'''<script>
const OKIND={'footings':{field:'kind',map:{'isolated':'F','combined':'CF','strap':'SP'}},'beams':{field:'kind',map:{'plinth beam':'PB','plinth':'PB','tie beam':'TB','primary':'B','secondary':'SB','grade beam':'GB','lintel band':'LB','lintel':'LB'}},'tanks':{field:'kind',map:{'overhead tank':'WT','underground sump':'SUMP'}},'rolled':{field:'member',map:{'beam':'B','column':'C','rafter':'R','tie':'T','gantry':'G','other':'M'}},'builtup':{field:'type',map:{'plate girder':'PG','built-up I beam':'BI','castellated beam':'CB','hybrid girder':'HG','box girder':'BG'}}};
const OFPFX={footings:'F',rafts:'RAFT',piles:'PF',strips:'SF',columns:'C',beams:'B',slabs:'S',shearwalls:'SW',retwalls:'RW',tanks:'WT',ramps:'RMP',lifts:'LIFT',staircase:'ST',walls:'W',doors:'D',windows:'WN',vents:'V',balcony:'B',partitions:'P',trusses:'T',purlins:'P',sheeting:'SH',hollow:'T',coldformed:'P',decking:'D',rolled:'S',builtup:'PG'};
function oMax(tb,stem){let mx=0;const su=stem.toUpperCase();tb.querySelectorAll('input[name="id"]').forEach(x=>{const v=(x.value||'').trim();if(v.toUpperCase().indexOf(su)===0){const rest=v.slice(stem.length);if(/^\d+$/.test(rest)){const n=parseInt(rest,10);if(n>mx)mx=n;}}});return mx;}
function oPfx(tid,tb){const ins=tb.querySelectorAll('input[name="id"]');for(let i=0;i<ins.length;i++){const v=(ins[i].value||'').trim();const m=v.match(/^([A-Za-z]+)\d+$/);if(m)return m[1];}return OFPFX[tid]||tid.slice(0,2).toUpperCase();}
function oKindPfx(tid,tr){const kd=OKIND[tid];if(kd){const ks=tr.querySelector('select[name="'+kd.field+'"]');if(ks&&kd.map[ks.value]){return kd.map[ks.value];}}return null;}
function oFillId(tid,tr){const inp=tr.querySelector('input[name="id"]');if(!inp||inp.value.trim())return;const tb=tr.closest('table');const p=oKindPfx(tid,tr)||oPfx(tid,tb);inp.value=p+(oMax(tb,p)+1);inp.dataset.auto='1';}
function oDup(btn){const tr=btn.closest('tr');const tb=tr.closest('table');const tid=tb.dataset.table;const cl=tr.cloneNode(true);tr.after(cl);const inp=cl.querySelector('input[name="id"]');if(!inp)return;const v=(inp.value||'').trim();if(!v){oFillId(tid,cl);return;}const m=v.match(/^(.*?)(\d+)$/);if(m){inp.value=m[1]+(Math.max(oMax(tb,m[1]),parseInt(m[2],10))+1);}else{inp.value=v+(Math.max(oMax(tb,v),1)+1);}}
function oFKind(sel){const tr=sel.closest('tr');if(!tr)return;const k=sel.value;tr.querySelectorAll('td.g-ped').forEach(td=>{td.style.display=(k==='isolated'||k==='combined')?'':'none';});tr.querySelectorAll('td.g-strap').forEach(td=>{td.style.display=k==='strap'?'':'none';});}
function oKindChanged(sel){if(!sel.name)return;const tb=sel.closest('table');if(!tb)return;const tid=tb.dataset.table;if(sel.name==='kind'&&tid==='footings'){oFKind(sel);}const kd=OKIND[tid];if(!kd||kd.field!==sel.name)return;const tr=sel.closest('tr');const inp=tr.querySelector('input[name="id"]');if(!inp||!inp.dataset.auto)return;const p=kd.map[sel.value];if(!p)return;inp.value=p+(oMax(tb,p)+1);}
document.addEventListener('input',e=>{if(e.target&&e.target.name==='id'){e.target.dataset.auto='';}});
function addRow(tid){const tpl=document.getElementById('tpl_'+tid);const tb=document.querySelector('table[data-table="'+tid+'"] tbody');tb.appendChild(tpl.content.cloneNode(true));oFillId(tid,tb.lastElementChild);if(typeof resizeTemplateFloors==='function')resizeTemplateFloors();}
document.querySelectorAll('table[data-table="footings"] select[name="kind"]').forEach(oFKind);
</script>'''


def module_html(spec, prefill=None):
    """Standalone fillable HTML for a schedule module. prefill = dict with
    scalars/tables (e.g. AI draft) - defaults from the spec otherwise."""
    prefill = prefill or {}
    pf_tables = prefill.get('tables') or {}
    pf_scal = prefill.get('scalars') or {}
    # Use the same field classification as the live cards for their unit menus.
    from schedule_fw import annotate
    annotate(spec)
    sid = spec['id']
    title = spec['title']
    parts = []
    parts.append(f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>{_esc(title)} - EstiBuild Input</title>
<style>
*{{box-sizing:border-box;font-family:'Segoe UI',Arial,sans-serif}}
body{{margin:0;background:#f4f7fa;color:#223}}
.top{{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:16px 22px}}
.top h1{{margin:0;font-size:19px}} .top p{{margin:4px 0 0;font-size:12px;opacity:.85}}
.wrap{{max-width:1250px;margin:16px auto;padding:0 14px}}
.card{{background:#fff;border:1px solid #d7e0ea;border-radius:10px;padding:14px 16px;margin-bottom:14px}}
h2{{font-size:14px;color:#1F3B57;margin:0 0 10px;text-transform:uppercase;letter-spacing:.4px}}
label{{display:block;font-size:10px;font-weight:600;color:#556;margin:4px 0 1px;text-transform:uppercase}}
input,select{{width:100%;padding:6px 7px;border:1px solid #d7e0ea;border-radius:6px;font-size:12px;background:#fffdf8}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
th{{background:#1F3B57;color:#fff;padding:6px;text-align:left;font-size:10.5px}}
td{{padding:4px 5px;border-bottom:1px solid #e6edf4}}
.add{{background:#2E86ab;color:#fff;border:none;padding:7px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;margin-top:6px}}
.del{{background:#c0392b;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}}
.dup{{background:#8e44ad;color:#fff;border:none;border-radius:5px;padding:2px 7px;cursor:pointer;font-size:11px;margin-right:3px}}
table.cards{{display:block}}
table.cards thead{{display:none}}
table.cards tbody{{display:block}}
table.cards tr{{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:7px;border:1px solid #c9d6e4;border-radius:9px;margin:0 0 10px;padding:9px;background:#fbfdff}}
table.cards td{{display:block;border:none;padding:0}}
table.cards td[data-label]::before{{content:attr(data-label);display:block;font-size:9px;font-weight:700;color:#4a5b6e;text-transform:uppercase;letter-spacing:.3px;margin:0 0 2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
table.cards td.act{{grid-column:1/-1;display:flex;gap:6px;align-items:center;padding:0 0 6px;margin-bottom:5px;border-bottom:1px solid #e2eaf3}}
table.cards td.g-ped,table.cards td.g-strap{{background:#f4f0fa;border-radius:6px;padding:5px 5px 4px}}
.export{{display:block;width:100%;background:#1f9d55;color:#fff;border:none;padding:15px;border-radius:10px;font-size:16px;font-weight:800;cursor:pointer;margin:8px 0 30px}}
.savehtml{{display:block;width:100%;background:#2E86ab;color:#fff;border:none;padding:11px;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;margin:8px 0}}
.note{{background:#fff8e1;border:1px solid #f0d479;border-radius:8px;padding:10px;font-size:12px;color:#7a6411}}
.row{{display:grid;gap:8px}} .cols{{display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(170px,1fr))}}
.combo{{display:flex;gap:3px;align-items:stretch}}
.combo input{{flex:1;min-width:0}}
.cbs{{width:30px;padding:0 2px;border:1px solid #b9cadb;border-radius:6px;background:#e8f0f8;cursor:pointer;font-size:11px;color:#2E86ab;text-align:center;-webkit-appearance:none;appearance:none;flex:none}}
.cbs:hover{{background:#d8e6f2;border-color:#2E86ab}}
.dimfield{{display:grid;grid-template-columns:minmax(0,1fr) 54px;gap:3px}}
.dimunit{{padding:4px 2px;font-size:10px;color:#4a5b6e;background:#edf4fa}}
</style></head><body>
<div class="top"><h1>🏗️ EstiBuild - {_esc(title)} Input Form</h1>
<p>Fill the schedules below, then download either the data file or a completed HTML file. Upload it in EstiBuild → Auto-fill → Calculate.</p></div>
<div class="wrap">
<div class="note"><b>How it works:</b> fill in your browser (no internet needed) → download the <b>.json data file</b> or <b>completed HTML</b> below → in EstiBuild open this module → upload the file and press <b>Auto-fill</b>. Lengths and areas retain their selected units.</div>
""")

    # scalars card
    parts.append('<div class="card"><h2>Project Details</h2><div class="cols">')
    for s in spec['scalars']:
        val = pf_scal.get(s['name'], s.get('default', ''))
        if s['type'] == 'select':
            parts.append(f'<div><label>{_esc(s["label"])}</label>{_inp(s["name"], val, options=s.get("options"))}</div>')
        else:
            parts.append(f'<div><label>{_esc(s["label"])}</label>{_inp(s["name"], val)}</div>')
    parts.append('</div>')
    # labour rates
    if spec.get('labour'):
        from modules.common import LABOUR_RATES, LABOUR_LABELS
        parts.append('<h2 style="margin-top:12px">Labour Rates (per day)</h2><div class="cols">')
        for k in spec['labour']:
            val = (prefill.get('labour_rates') or {}).get(k, LABOUR_RATES.get(k, ''))
            parts.append(f'<div><label>{_esc(LABOUR_LABELS.get(k, k))}</label>{_inp("lr_" + k, val)}</div>')
        parts.append('</div>')
    parts.append('</div>')

    # tables
    for t in spec['tables']:
        tid = t['id']
        rows = pf_tables.get(tid) or t.get('default_rows') or []
        parts.append(f'<div class="card"><h2>{_esc(t["title"])}</h2>')
        if t.get('auto_note'):
            parts.append(f'<p style="font-size:11px;color:#14532d;background:#eafaf0;border:1px solid #9fdcb4;border-left:4px solid #1f9d55;border-radius:7px;padding:6px 10px;margin:0 0 8px">⚡ AUTOMATIC: {_esc(t["auto_note"])}</p>')
        if t.get('hint'):
            parts.append(f'<p style="font-size:11px;color:#7a8693;margin:0 0 8px">{_esc(t["hint"])}</p>')
        wide = ' class="cards"' if len(t['fields']) >= 7 else ''
        parts.append(f'<table data-table="{tid}"{wide}><thead><tr>')
        parts.append('<th style="width:60px"></th>')
        for f in t['fields']:
            parts.append(f'<th>{_esc(f["label"])}</th>')
        parts.append('<th>Rate override</th>')
        parts.append('</tr></thead><tbody>')
        for r in rows:
            parts.append('<tr>')
            parts.append('<td class="act"><button class="dup" onclick="oDup(this)" title="Duplicate this row">⧉</button><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
            for f in t['fields']:
                val = r.get(f['name'], '')
                dl = _esc(f['label'])
                parts.append(f'<td data-label="{dl}">{_offline_schedule_field(f, val)}</td>')
            rate = _esc(r.get('rate', ''))
            parts.append(f'<td data-label="Rate override"><input type="number" name="rate" value="{rate}" placeholder="market rate"></td>')
            parts.append('</tr>')
        parts.append('</tbody></table>')
        parts.append(f'<button class="add" onclick="addRow(\'{tid}\')">+ { _esc(t.get("add_label", "Add row"))}</button></div>')

    # hidden row templates + JS
    parts.append(f'<div id="tpls" style="display:none">')
    for t in spec['tables']:
        tid = t['id']
        parts.append(f'<template id="tpl_{tid}"><tr>')
        parts.append('<td class="act"><button class="dup" onclick="oDup(this)" title="Duplicate this row">⧉</button><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
        for f in t['fields']:
            val = ''
            dl = _esc(f['label'])
            parts.append(f'<td data-label="{dl}">{_offline_schedule_field(f, val)}</td>')
        parts.append('<td data-label="Rate override"><input type="number" name="rate" value="" placeholder="market rate"></td>')
        parts.append('</tr></template>')
    parts.append('</div>')

    parts.append(f"""
<button class="export" onclick="exportData()">⬇ Download Data File for EstiBuild (.json)</button>
<button class="savehtml" onclick="downloadCompletedHtml()">💾 Save Completed HTML (upload it back to Auto-fill)</button>
</div>
<script>
const MODULE = "{sid}";
function addRow(tid) {{
  const tpl = document.getElementById('tpl_' + tid);
  document.querySelector('table[data-table="' + tid + '"] tbody').appendChild(tpl.content.cloneNode(true));
}}
function cbsel(s) {{ if (s.value) {{ s.previousElementSibling.value = s.value; }} s.selectedIndex = 0; }}
function exportData() {{
  const data = {{module: MODULE, scalars: {{}}, labour_rates: {{}}, tables: {{}}}};
  document.querySelectorAll('.card').forEach(card => {{
    card.querySelectorAll('[name]').forEach(inp => {{
      const n = inp.name;
      if (n.startsWith('lr_')) data.labour_rates[n.slice(3)] = inp.value;
      else if (!inp.closest('table')) data.scalars[n] = inp.value;
    }});
  }});
  document.querySelectorAll('table[data-table]').forEach(tb => {{
    const tid = tb.dataset.table;
    data.tables[tid] = [];
    tb.querySelectorAll('tbody tr').forEach(tr => {{
      const row = {{}};
      tr.querySelectorAll('[name]').forEach(inp => row[inp.name] = inp.value);
      if (Object.values(row).some(v => String(v).trim() !== '')) data.tables[tid].push(row);
    }});
  }});
  const blob = new Blob([JSON.stringify(data, null, 2)], {{type: 'application/json'}});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = MODULE + '_input.json';
  document.body.appendChild(a); a.click(); a.remove();
}}
function downloadCompletedHtml() {{
  // Make browser-edited values part of the saved HTML source, so the app can
  // read this file later exactly like the JSON data file.
  document.querySelectorAll('input').forEach(input => {{
    if (input.type === 'checkbox' || input.type === 'radio') {{
      input.checked ? input.setAttribute('checked', '') : input.removeAttribute('checked');
    }} else {{ input.setAttribute('value', input.value); }}
  }});
  document.querySelectorAll('select').forEach(select => {{
    [...select.options].forEach(option => {{
      option.selected ? option.setAttribute('selected', '') : option.removeAttribute('selected');
    }});
  }});
  const blob = new Blob(['<!DOCTYPE html>\n' + document.documentElement.outerHTML], {{type: 'text/html'}});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = MODULE + '_completed_input.html';
  document.body.appendChild(a); a.click(); a.remove();
}}
</script>""")
    parts.append(OFFLINE_JS + '</body></html>')
    return ''.join(parts)


# ------------------------------------------------------------------ structural template
STRUCT_TABLES = [
    ('footings', 'Isolated / Combined / Strap Footings',
     [('id', 'Mark'), ('kind', 'Type (isolated/strap/combined)'), ('count', 'Nos'),
      ('L', 'L (mm)'), ('W', 'W (mm)'), ('t', 't (mm)'), ('depth', 'Depth GL (mm)'),
      ('soling_t', 'Soling t'), ('mesh', 'Mesh'),
      ('ped_b', 'Ped b (isol/comb)'), ('ped_d', 'Ped d'), ('ped_h', 'Ped h'), ('ped_main', 'Ped main'), ('ped_tie', 'Ped tie'),
      ('strap_len', 'Strap len (strap)'), ('strap_b', 'Strap b'), ('strap_d', 'Strap d'),
      ('strap_top', 'Strap top'), ('strap_bot', 'Strap bot'), ('strap_tie', 'Strap tie'),
     ('stub_b', 'Stub b (blank=auto)'), ('stub_d', 'Stub d (blank=auto)'),
     ('stub_main', 'Stub bars e.g. 8-16'), ('stub_tie', 'Stub tie e.g. 8-150'),
      ('grade', 'Grade'), ('soil', 'Soil')]),
    ('rafts', 'Raft Foundation (double mesh)',
     [('id', 'Mark'), ('count', 'Nos'), ('L', 'L (mm)'), ('W', 'W (mm)'), ('t', 't (mm)'),
      ('depth', 'Depth GL (mm)'), ('mesh', 'Bottom mesh'), ('top_mesh', 'Top mesh'),
      ('grade', 'Grade'), ('soil', 'Soil')]),
    ('piles', 'Pile Foundation (piles + caps)',
     [('id', 'Mark'), ('count', 'Caps (count)'), ('pile_dia', 'Pile dia (mm)'), ('pile_len', 'Pile len (mm)'),
      ('pile_no', 'Pile no / cap'), ('pile_main', 'Pile main'), ('spiral', 'Spiral'),
      ('cap_L', 'Cap L (mm)'), ('cap_W', 'Cap W (mm)'), ('cap_t', 'Cap t (mm)'), ('cap_mesh', 'Cap mesh'),
      ('grade', 'Grade'), ('soil', 'Soil')]),
    ('strips', 'Strip Footing',
     [('id', 'Mark'), ('count', 'Nos'), ('L', 'Length (mm)'), ('W', 'Width (mm)'), ('t', 't (mm)'),
      ('depth', 'Depth GL (mm)'), ('soling_t', 'Soling t'), ('mesh', 'Mesh'),
      ('grade', 'Grade'), ('soil', 'Soil')]),
    ('columns', 'Columns',
     [('id', 'Mark'), ('count', 'Nos'), ('b', 'b (mm)'), ('d', 'd (mm)'),
      ('main', 'Main bars/floor'), ('tie', 'Tie'), ('grade', 'Grade')]),
    ('beams', 'Beams',
     [('id', 'Mark'), ('kind', 'Type'), ('count', 'Nos'), ('b', 'b (mm)'), ('d', 'd (mm)'),
      ('length', 'Length (mm)'), ('top', 'Top'), ('bottom', 'Bottom'), ('extra_top', 'Extra top'), ('side', 'Side bars (opt)'),
      ('tie', 'Stirrup'), ('grade', 'Grade')]),
    ('slabs', 'Slabs',
     [('id', 'Mark'), ('area', 'Area m²'), ('t', 't (mm)'), ('type', 'Type'),
      ('mesh', 'Bottom mesh'), ('top_mesh', 'Top mesh (optional)'), ('grade', 'Grade')]),
    ('shearwalls', 'Shear Walls',
     [('id', 'Mark'), ('length', 'Length (mm)'), ('t', 't (mm)'), ('height', 'Height (mm)'),
      ('vertical', 'Vertical'), ('horizontal', 'Horizontal')]),
    ('retwalls', 'Retaining / Trench Walls',
     [('id', 'Mark'), ('length', 'Length (mm)'), ('stem_t', 'Stem t'), ('stem_h', 'Stem h'),
      ('base_b', 'Base b'), ('base_t', 'Base t'), ('vert', 'Vert'), ('horiz', 'Horiz'), ('base_mesh', 'Base mesh')]),
    ('tanks', 'Water Tanks & Sumps',
     [('id', 'Mark'), ('kind', 'Type (overhead tank/underground sump)'), ('L', 'L int (mm)'),
      ('W', 'W int (mm)'), ('depth', 'Depth (mm)'), ('wall_t', 'Wall t'), ('base_t', 'Base t'),
      ('cover_t', 'Cover t'), ('wall_mesh', 'Wall mesh'), ('base_mesh', 'Base mesh'), ('grade', 'Grade')]),
    ('ramps', 'Ramps',
     [('id', 'Mark'), ('length', 'Length incl (mm)'), ('width', 'Width (mm)'), ('thickness', 'Thickness (mm)'),
      ('mesh', 'Mesh'), ('side_wall_h', 'Side wall h (0=none)'), ('side_wall_t', 'Side wall t'), ('grade', 'Grade')]),
    ('lifts', 'Lift Pits & Machine Rooms',
     [('id', 'Mark'), ('L', 'Plan L (mm)'), ('W', 'Plan W (mm)'), ('pit_depth', 'Pit depth (mm)'),
      ('core_height', 'Core height (mm)'), ('wall_t', 'Wall t'), ('base_t', 'Base t'),
      ('mesh', 'Mesh'), ('grade', 'Grade')]),
    ('others', 'Water Retaining & Misc Items',
     [('item', 'Item (waterproofing/bitumen/expansion joint/water stop/dewatering/curing)'),
      ('qty', 'Qty (sqm/rmt/cum)')]),
    ('staircase', 'Staircases',
     [('id', 'Mark'), ('type', 'Type (dog-legged/open-well/straight flight/spiral/cantilever)'),
      ('flights', 'Flights'), ('run', 'Run (mm)'), ('width', 'Width (mm)'), ('waist', 'Waist (mm)'),
      ('mesh', 'Mesh'), ('tread', 'Tread (mm)'), ('riser', 'Riser (mm)'), ('landings', 'Landings (nos)'),
      ('landing_L', 'Landing L (mm)'), ('landing_W', 'Landing W (mm)'), ('landing_t', 'Landing t (mm)')]),
]

# choice fields rendered as strict dropdowns (same lists as the web app)
STRUCT_OPTS = {
    ('footings', 'kind'): ['isolated', 'strap', 'combined'],
    ('rafts', 'grade'): ['M20', 'M25', 'M30', 'M35'],
    ('rafts', 'soil'): ['soft soil', 'hard soil', 'rock', 'mixed'],
    ('piles', 'grade'): ['M25', 'M30', 'M35'],
    ('strips', 'grade'): ['M20', 'M25', 'M30'],
    ('strips', 'soil'): ['soft soil', 'hard soil', 'rock', 'mixed'],
    ('footings', 'grade'): ['M15', 'M20', 'M25', 'M30', 'M35'],
    ('footings', 'soil'): ['soft soil', 'hard soil', 'rock', 'mixed'],
    ('columns', 'grade'): ['M15', 'M20', 'M25', 'M30', 'M35'],
    ('beams', 'kind'): ['plinth beam', 'tie beam', 'primary', 'secondary', 'grade beam', 'lintel band', 'lintel'],
    ('beams', 'grade'): ['M15', 'M20', 'M25', 'M30', 'M35'],
    ('slabs', 'type'): ['one-way slab', 'two-way slab', 'sunken slab (toilet)', 'flat slab', 'waffle (ribbed)'],
    ('slabs', 'grade'): ['M15', 'M20', 'M25', 'M30', 'M35'],
    ('tanks', 'kind'): ['overhead tank', 'underground sump'],
    ('tanks', 'grade'): ['M15', 'M20', 'M25', 'M30'],
    ('ramps', 'grade'): ['M15', 'M20', 'M25', 'M30'],
    ('lifts', 'grade'): ['M25', 'M30', 'M35'],
    ('staircase', 'type'): ['dog-legged', 'open-well', 'straight flight', 'spiral', 'cantilever'],
}

# steel specification suggestions (same option lists as the live form)
STEEL_DL = {
    'mesh': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'top_mesh': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'base_mesh': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'wall_mesh': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'cap_mesh': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'spiral': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'vertical': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'horizontal': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'vert': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'horiz': ['8-200', '10-200', '10-150', '12-200', '12-150', '12-100', '16-150', '16-100', '16-200'],
    'tie': ['6-150', '8-100', '8-100-150', '8-100-200', '8-125-150', '8-150', '10-100-150'],
    'ped_tie': ['6-150', '8-100', '8-100-150', '8-100-200', '8-125-150', '8-150', '10-100-150'],
    'strap_tie': ['6-150', '8-100', '8-100-150', '8-100-200', '8-125-150', '8-150', '10-100-150'],
    'top': ['2-10', '3-10', '2-12', '3-12', '4-12', '6-12', '8-12', '2-16', '3-16', '4-16', '6-16', '8-16', '10-16', '12-16', '16-16', '20-16', '4-20', '6-20', '8-20', '4-25', '6-25'],
    'bottom': ['2-10', '3-10', '2-12', '3-12', '4-12', '6-12', '8-12', '2-16', '3-16', '4-16', '6-16', '8-16', '10-16', '12-16', '16-16', '20-16', '4-20', '6-20', '8-20', '4-25', '6-25'],
    'extra_top': ['2-10', '3-10', '2-12', '3-12', '4-12', '6-12', '8-12', '2-16', '3-16', '4-16', '6-16', '8-16', '10-16', '12-16', '16-16', '20-16', '4-20', '6-20', '8-20', '4-25', '6-25'],
    'side': ['2-10', '3-10', '2-12', '3-12', '4-12', '6-12', '8-12', '2-16', '3-16', '4-16', '6-16', '8-16', '10-16', '12-16', '16-16', '20-16', '4-20', '6-20', '8-20', '4-25', '6-25'],
    'strap_top': ['2-10', '3-10', '2-12', '3-12', '4-12', '6-12', '8-12', '2-16', '3-16', '4-16', '6-16', '8-16', '10-16', '12-16', '16-16', '20-16', '4-20', '6-20', '8-20', '4-25', '6-25'],
    'strap_bot': ['2-10', '3-10', '2-12', '3-12', '4-12', '6-12', '8-12', '2-16', '3-16', '4-16', '6-16', '8-16', '10-16', '12-16', '16-16', '20-16', '4-20', '6-20', '8-20', '4-25', '6-25'],
    'main': ['2-10', '3-10', '2-12', '3-12', '4-12', '6-12', '8-12', '2-16', '3-16', '4-16', '6-16', '8-16', '10-16', '12-16', '16-16', '20-16', '4-20', '6-20', '8-20', '4-25', '6-25'],
    'ped_main': ['4-12', '6-12', '8-12', '4-16', '6-16', '8-16', '4-20', '6-20', '8-20'],
    'pile_main': ['4-12', '6-12', '8-12', '4-16', '6-16', '8-16', '4-20', '6-20', '8-20'],
}

# what auto-generates after upload - shown on every offline table card
STRUCT_HINTS = {
    'footings': 'excavation / PCC bed / soling / backfill ALL auto from L x W x t x depth',
    'rafts': 'double mesh (bottom + top) auto in BBS; excavation + PCC auto',
    'piles': 'pile concrete + spiral + cap + cap mesh auto in BBS',
    'strips': 'excavation / PCC / backfill auto; mesh both directions in BBS',
    'columns': 'BBS auto: main bars per floor, ductile confined ties',
    'beams': 'BBS auto: top/bottom/extra-top bars + confined stirrups; PLINTH beams feed the Trench auto below',
    'slabs': 'BBS auto: bottom mesh + optional top mesh (double mesh)',
    'shearwalls': 'vert + horiz mesh auto in BBS',
    'retwalls': 'stem + base RCC, PCC bed, excavation, mesh - all auto',
    'tanks': 'walls + base + cover, mesh both faces, full BBS auto; sump adds excavation + backfill',
    'ramps': 'slab + side walls + mesh auto',
    'lifts': 'pit + core walls + base auto',
    'others': 'priced per sqm/rmt/cum as entered',
    'staircase': 'waist slab + steps + landings + mesh auto in BBS',
}

STRUCT_SCALARS = [
    ('project_name', 'Project name', 'text'), ('location', 'Location', 'text'),
    ('concrete_grade', 'Concrete grade', 'select', ['M20', 'M25', 'M30', 'M35', 'M40', 'M15']),
    ('pcc_mix', 'PCC mix', 'text'), ('floor_height', 'Floor height (mm)', 'number'),
    ('floors_above', 'Floors above ground', 'number'), ('col_below_gl', 'Column below plinth mm (blank=auto)', 'number'),
    ('confinement_lo', 'Confinement zone lo (mm)', 'number'),
    ('cover_footing', 'Cover footing', 'number'), ('cover_column', 'Cover column', 'number'),
    ('cover_beam', 'Cover beam', 'number'), ('cover_slab', 'Cover slab', 'number'),
    ('concrete_pumping', 'Concrete pumping', 'select', ['none', 'boom pump', 'line pump']),
    ('rate_rcc_m3', 'RCC rate /m³', 'number'), ('rate_pcc_m3', 'PCC rate /m³', 'number'),
    ('rate_excavation_m3', 'Excavation rate /m³', 'number'), ('rate_backfill_m3', 'Backfill rate /m³', 'number'),
    ('tw_type', 'Trench wall type (none/stone masonry/brick masonry)', 'select', ['none', 'stone masonry', 'brick masonry']),
    ('tw_length', 'Trench length m (blank=auto plinth beams)', 'number'),
    ('tw_depth', 'Trench depth m (blank=auto footing depth)', 'number'),
    ('tw_wall_t', 'Wall thickness mm (blank=auto beam width)', 'number'),
    ('tw_plinth_h', 'Plinth height above GL (m)', 'number'),
    ('rate_rcc_M15', 'RCC M15 rate /m³ (blank=default)', 'number'),
    ('rate_rcc_M20', 'RCC M20 rate /m³ (blank=default)', 'number'),
    ('rate_rcc_m3', 'RCC M25 rate /m³', 'number'),
    ('rate_rcc_M30', 'RCC M30 rate /m³ (blank=default)', 'number'),
    ('rate_rcc_M35', 'RCC M35 rate /m³ (blank=default)', 'number'),
    ('rate_pcc_1_5_10', 'PCC 1:5:10 rate /m³ (blank=default)', 'number'),
    ('rate_pcc_m3', 'PCC 1:4:8 rate /m³', 'number'),
    ('rate_pcc_1_3_6', 'PCC 1:3:6 rate /m³ (blank=default)', 'number'),
    ('rate_pcc_1_2_4', 'PCC 1:2:4 rate /m³ (blank=default)', 'number'),
    ('rate_soling_m3', 'Soling rate /m³', 'number'), ('rate_shuttering_m2', 'Shuttering rate /m²', 'number'),
    ('rate_steel_kg', 'Steel rate /kg', 'number'),
    ('lr_mason', 'Mason /day', 'number'), ('lr_mazdoor', 'Mazdoor /day', 'number'),
    ('lr_steel_fab', 'Steel fabricator /day', 'number'),
]


def _column_floor_editor(value):
    """Render the offline template's per-floor column reinforcement editor.

    The hidden ``main`` field is the same comma-separated format accepted by
    the structural importer.  The visible inputs deliberately have no name so
    only that canonical value is included in the downloaded JSON file.
    """
    values = [item.strip() for item in str(value or '').split(',')]
    cells = []
    for floor in range(25):
        label = 'GF' if floor == 0 else f'F{floor}'
        item = _esc(values[floor] if floor < len(values) else '')
        cells.append(
            f'<div class="floorbar" data-floor="{floor}"><label>{label}</label>'
            f'<input type="text" data-floor-main value="{item}" '
            f'oninput="syncTemplateFloorBars(this)"></div>'
        )
    hidden = _esc(str(value or ''))
    return (
        '<td data-label="Main bars per floor (GF–F24)" class="floorcellwrap">'
        '<div class="floorbars">' + ''.join(cells) +
        '<div class="floortools"><button type="button" class="add" '
        'onclick="addTemplateFloor()" title="Add one floor">+ floor</button>'
        '<button type="button" class="del" onclick="removeTemplateFloor()" '
        'title="Remove the top floor">&minus;</button>'
        '<span>Leave a floor empty to repeat the previous bar specification.</span></div>'
        f'</div><input type="hidden" name="main" value="{hidden}"></td>'
    )


def structural_html(prefill=None):
    """Fillable HTML for the RCC Structure module."""
    prefill = prefill or {}
    pf_tables = prefill.get('tables') or {}
    pf_scal = {k: v for k, v in (prefill.get('scalars') or {}).items()}
    from structural.engine import DEFAULT_SCHEDULE as D
    defaults = {
        'project_name': D['project_name'], 'location': D['location'], 'concrete_grade': D['concrete_grade'],
        'pcc_mix': D['pcc_mix'], 'floor_height': D['floor_height'], 'floors_above': D['floors_above'],
        'confinement_lo': D['confinement_lo'], 'cover_footing': D['cover_footing'],
        'cover_column': D['cover_column'], 'cover_beam': D['cover_beam'], 'cover_slab': D['cover_slab'],
        'concrete_pumping': 'none',
        'sc_type': _sc(D).get('type', 'dog-legged'), 'sc_flights': _sc(D)['flights'],
        'sc_run': _sc(D)['run'], 'sc_tread': _sc(D).get('tread', 300),
        'sc_riser': _sc(D).get('riser', 150), 'sc_width': _sc(D)['width'],
        'sc_waist': _sc(D)['waist'], 'sc_mesh': _sc(D)['mesh'],
        'sc_landings': _sc(D).get('landings', 0), 'sc_landing_L': _sc(D).get('landing_L', 1200),
        'sc_landing_W': _sc(D).get('landing_W', 1200), 'sc_landing_t': _sc(D).get('landing_t', 150),
        'lr_mason': 1200, 'lr_mazdoor': 800, 'lr_steel_fab': 1400,
    }
    for k, v in D['rates'].items():
        defaults['rate_' + k] = v
    defaults.update(pf_scal)
    parts = []
    parts.append(f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>RCC Structure - EstiBuild Input</title>
<style>
*{{box-sizing:border-box;font-family:'Segoe UI',Arial,sans-serif}}
body{{margin:0;background:#f4f7fa;color:#223}}
.top{{background:linear-gradient(120deg,#1F3B57,#2E86ab);color:#fff;padding:16px 22px}}
.top h1{{margin:0;font-size:19px}} .top p{{margin:4px 0 0;font-size:12px;opacity:.85}}
.wrap{{max-width:1250px;margin:16px auto;padding:0 14px}}
.card{{background:#fff;border:1px solid #d7e0ea;border-radius:10px;padding:14px 16px;margin-bottom:14px}}
h2{{font-size:14px;color:#1F3B57;margin:0 0 10px;text-transform:uppercase;letter-spacing:.4px}}
label{{display:block;font-size:10px;font-weight:600;color:#556;margin:4px 0 1px;text-transform:uppercase}}
input,select{{width:100%;padding:6px 7px;border:1px solid #d7e0ea;border-radius:6px;font-size:12px;background:#fffdf8}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
th{{background:#1F3B57;color:#fff;padding:6px;text-align:left;font-size:10.5px}}
td{{padding:4px 5px;border-bottom:1px solid #e6edf4}}
.add{{background:#2E86ab;color:#fff;border:none;padding:7px 14px;border-radius:7px;font-size:12px;font-weight:600;cursor:pointer;margin-top:6px}}
.del{{background:#c0392b;color:#fff;border:none;border-radius:5px;padding:2px 8px;cursor:pointer;font-size:11px}}
.dup{{background:#8e44ad;color:#fff;border:none;border-radius:5px;padding:2px 7px;cursor:pointer;font-size:11px;margin-right:3px}}
table.cards{{display:block}}
table.cards thead{{display:none}}
table.cards tbody{{display:block}}
table.cards tr{{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:7px;border:1px solid #c9d6e4;border-radius:9px;margin:0 0 10px;padding:9px;background:#fbfdff}}
table.cards td{{display:block;border:none;padding:0}}
table.cards td[data-label]::before{{content:attr(data-label);display:block;font-size:9px;font-weight:700;color:#4a5b6e;text-transform:uppercase;letter-spacing:.3px;margin:0 0 2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
table.cards td.act{{grid-column:1/-1;display:flex;gap:6px;align-items:center;padding:0 0 6px;margin-bottom:5px;border-bottom:1px solid #e2eaf3}}
table.cards td.g-ped,table.cards td.g-strap{{background:#f4f0fa;border-radius:6px;padding:5px 5px 4px}}
.export{{display:block;width:100%;background:#1f9d55;color:#fff;border:none;padding:15px;border-radius:10px;font-size:16px;font-weight:800;cursor:pointer;margin:8px 0 30px}}
.savehtml{{display:block;width:100%;background:#2E86ab;color:#fff;border:none;padding:11px;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;margin:8px 0}}
.note{{background:#fff8e1;border:1px solid #f0d479;border-radius:8px;padding:10px;font-size:12px;color:#7a6411}}
.cols{{display:grid;gap:8px;grid-template-columns:repeat(auto-fit,minmax(160px,1fr))}}
.combo{{display:flex;gap:3px;align-items:stretch}}
.combo input{{flex:1;min-width:0}}
.cbs{{width:30px;padding:0 2px;border:1px solid #b9cadb;border-radius:6px;background:#e8f0f8;cursor:pointer;font-size:11px;color:#2E86ab;text-align:center;-webkit-appearance:none;appearance:none;flex:none}}
.cbs:hover{{background:#d8e6f2;border-color:#2E86ab}}
.floorcellwrap{{grid-column:1/-1;background:#f5f9fd;border:1px solid #d8e4ef;border-radius:7px;padding:7px!important}}
.floorbars{{display:grid;grid-template-columns:repeat(auto-fill,minmax(72px,1fr));gap:5px}}
.floorbar{{padding:4px;background:#fff;border:1px solid #d8e4ec;border-radius:6px}}
.floorbar label{{font-size:8.5px;text-align:center;margin:0 0 2px}}
.floorbar input{{padding:5px;font-size:10.5px;text-align:center}}
.floortools{{grid-column:1/-1;display:flex;gap:5px;align-items:center;flex-wrap:wrap;padding-top:2px;font-size:10px;color:#536577}}
.floortools .add{{margin:0;padding:4px 8px;font-size:10px}}
.floortools .del{{padding:4px 8px}}
</style></head><body>
<div class="top"><h1>🏗️ EstiBuild - RCC Structure Input Form</h1>
<p>Fill the member schedules, '+ Add' for more items, then download the data file or completed HTML and upload it in EstiBuild.</p></div>
<div class="wrap">
<div class="note">BBS is auto-generated from these inputs. Dimensions in mm, areas in m².</div>
<div class="card"><h2>Project & Parameters (incl. rates, staircase)</h2><div class="cols">""")
    for s in STRUCT_SCALARS:
        name, label, typ = s[0], s[1], s[2]
        if name.startswith('tw_'):
            continue          # trench fields render in their own card below
        val = defaults.get(name, '')
        if typ == 'select':
            parts.append(f'<div><label>{_esc(label)}</label>{_inp(name, val, options=s[3])}</div>')
        else:
            parts.append(f'<div><label>{_esc(label)}</label>{_inp(name, val, typ="number" if typ == "number" else "text")}</div>')
    parts.append('</div></div>')
    # ---- Trench & Plinth Wall (auto) card ----
    parts.append('<div class="card"><h2>Trench &amp; Plinth Wall</h2>'
                 '<p style="font-size:11px;color:#14532d;background:#eafaf0;border:1px solid #9fdcb4;border-left:4px solid #1f9d55;border-radius:7px;padding:6px 10px;margin:0 0 8px">'
                 '⚡ AUTOMATIC: pick the wall type ONLY - length auto = plinth beam length (net of footing pits), '
                 'depth auto = footing depth, thickness auto = plinth beam width. Trench excavation, PCC bed, '
                 'wall masonry and refilling all generate on upload. Leave the other boxes BLANK for auto.</p><div class="cols">')
    for s in STRUCT_SCALARS:
        name, label, typ = s[0], s[1], s[2]
        if not name.startswith('tw_'):
            continue
        val = defaults.get(name, '')
        if typ == 'select':
            parts.append(f'<div><label>{_esc(label)}</label>{_inp(name, val, options=s[3])}</div>')
        else:
            parts.append(f'<div><label>{_esc(label)}</label>{_inp(name, val, typ="number" if typ == "number" else "text")}</div>')
    parts.append('</div></div>')

    from structural.engine import DEFAULT_SCHEDULE as D
    for tid, ttitle, fields in STRUCT_TABLES:
        rows = pf_tables.get(tid)
        if rows is None:
            rows = D.get(tid, [])
            if not isinstance(rows, list):
                rows = []
        parts.append(f'<div class="card"><h2>{_esc(ttitle)}</h2>')
        if tid in STRUCT_HINTS:
            parts.append(f'<p style="font-size:11px;color:#14532d;background:#eafaf0;border:1px solid #9fdcb4;border-left:4px solid #1f9d55;border-radius:7px;padding:6px 10px;margin:0 0 8px">⚡ AUTOMATIC after upload: {STRUCT_HINTS[tid]}</p>')
        wide = ' class="cards"' if len(fields) >= 7 else ''
        parts.append(f'<table data-table="{tid}"{wide}><thead><tr><th style="width:60px"></th>')
        for fname, flabel in fields:
            parts.append(f'<th>{_esc(flabel)}</th>')
        parts.append('</tr></thead><tbody>')
        for r in rows:
            parts.append('<tr><td class="act"><button class="dup" onclick="oDup(this)" title="Duplicate this row">⧉</button><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
            for fname, flabel in fields:
                if tid == 'columns' and fname == 'main':
                    parts.append(_column_floor_editor(r.get('main', '')))
                    continue
                sopts = STRUCT_OPTS.get((tid, fname))
                opts = STEEL_DL.get(fname)
                grp = ' class="g-ped"' if (tid == 'footings' and fname.startswith('ped_')) else (' class="g-strap"' if (tid == 'footings' and fname.startswith('strap_')) else '')
                if sopts:
                    parts.append(f'<td data-label="{_esc(flabel)}"{grp}>{_inp(fname, r.get(fname, ""), options=sopts)}</td>')
                elif opts:
                    parts.append(f'<td data-label="{_esc(flabel)}"{grp}>{_inp(fname, r.get(fname, ""), options=opts, suggest=True)}</td>')
                else:
                    parts.append(f'<td data-label="{_esc(flabel)}"{grp}>{_inp(fname, r.get(fname, ""))}</td>')
            parts.append('</tr>')
        parts.append('</tbody></table>')
        parts.append(f'<button class="add" onclick="addRow(\'{tid}\')">+ Add</button></div>')

    parts.append('<div id="tpls" style="display:none">')
    for tid, ttitle, fields in STRUCT_TABLES:
        parts.append(f'<template id="tpl_{tid}"><tr><td class="act"><button class="dup" onclick="oDup(this)" title="Duplicate this row">⧉</button><button class="del" onclick="this.closest(\'tr\').remove()">✕</button></td>')
        for fname, flabel in fields:
            if tid == 'columns' and fname == 'main':
                parts.append(_column_floor_editor(''))
                continue
            sopts = STRUCT_OPTS.get((tid, fname))
            opts = STEEL_DL.get(fname)
            grp = ' class="g-ped"' if (tid == 'footings' and fname.startswith('ped_')) else (' class="g-strap"' if (tid == 'footings' and fname.startswith('strap_')) else '')
            if sopts:
                parts.append(f'<td data-label="{_esc(flabel)}"{grp}>{_inp(fname, "", options=sopts)}</td>')
            elif opts:
                parts.append(f'<td data-label="{_esc(flabel)}"{grp}>{_inp(fname, "", options=opts, suggest=True)}</td>')
            else:
                parts.append(f'<td data-label="{_esc(flabel)}"{grp}>{_inp(fname, "")}</td>')
        parts.append('</tr></template>')
    parts.append('</div>')
    parts.append("""
<button class="export" onclick="exportData()">⬇ Download Data File for EstiBuild (.json)</button>
<button class="savehtml" onclick="downloadCompletedHtml()">💾 Save Completed HTML (upload it back to Auto-fill)</button>
</div>
<script>
const MODULE = "structural";
function syncTemplateFloorBars(input) {
  const td = input.closest('td');
  if (!td) return;
  const values = [...td.querySelectorAll('input[data-floor-main]')]
    .map(item => item.value.trim()).filter(Boolean);
  const hidden = td.querySelector('input[name="main"]');
  if (hidden) hidden.value = values.join(',');
}
function resizeTemplateFloors() {
  const floorInput = document.querySelector('input[name="floors_above"]');
  const count = Math.min(25, Math.max(1, parseInt(floorInput?.value) || 1));
  if (floorInput) floorInput.value = count;
  document.querySelectorAll('.floorbars').forEach(box => {
    box.querySelectorAll('.floorbar').forEach(cell => {
      cell.style.display = Number(cell.dataset.floor) < count ? '' : 'none';
    });
  });
}
function addTemplateFloor() {
  const field = document.querySelector('input[name="floors_above"]');
  if (field) { field.value = Math.min(25, (parseInt(field.value) || 1) + 1); resizeTemplateFloors(); }
}
function removeTemplateFloor() {
  const field = document.querySelector('input[name="floors_above"]');
  if (field) { field.value = Math.max(1, (parseInt(field.value) || 1) - 1); resizeTemplateFloors(); }
}
document.addEventListener('input', event => {
  if (event.target && event.target.name === 'floors_above') resizeTemplateFloors();
});
function addRow(tid) {
  const tpl = document.getElementById('tpl_' + tid);
  document.querySelector('table[data-table="' + tid + '"] tbody').appendChild(tpl.content.cloneNode(true));
}
function cbsel(s) { if (s.value) { s.previousElementSibling.value = s.value; } s.selectedIndex = 0; }
function exportData() {
  const data = {module: MODULE, scalars: {}, tables: {}};
  document.querySelectorAll('.card [name]').forEach(inp => {
    if (!inp.closest('table')) data.scalars[inp.name] = inp.value;
  });
  document.querySelectorAll('table[data-table]').forEach(tb => {
    const tid = tb.dataset.table;
    data.tables[tid] = [];
    tb.querySelectorAll('tbody tr').forEach(tr => {
      const row = {};
      tr.querySelectorAll('[name]').forEach(inp => row[inp.name] = inp.value);
      if (Object.values(row).some(v => String(v).trim() !== '')) data.tables[tid].push(row);
    });
  });
  const blob = new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'structural_input.json';
  document.body.appendChild(a); a.click(); a.remove();
}
function downloadCompletedHtml() {
  // Persist browser-edited values into the downloadable HTML source so the
  // upload route can restore this form exactly through Auto-fill.
  document.querySelectorAll('input').forEach(input => {
    if (input.type === 'checkbox' || input.type === 'radio') {
      input.checked ? input.setAttribute('checked', '') : input.removeAttribute('checked');
    } else { input.setAttribute('value', input.value); }
  });
  document.querySelectorAll('select').forEach(select => {
    [...select.options].forEach(option => {
      option.selected ? option.setAttribute('selected', '') : option.removeAttribute('selected');
    });
  });
  const blob = new Blob(['<!DOCTYPE html>\n' + document.documentElement.outerHTML], {type: 'text/html'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = 'structural_completed_input.html';
  document.body.appendChild(a); a.click(); a.remove();
}
resizeTemplateFloors();
</script>""")
    parts.append(OFFLINE_JS + '</body></html>')
    return ''.join(parts)


# ------------------------------------------------------------------ Excel templates
def module_xlsx(spec):
    """Excel input template: headers + example rows + DROPDOWN LISTS on every
    select/suggest column (options live on a hidden OPTIONS sheet so users
    offline always know the valid spellings that unlock the right rates)."""
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet('READ ME')
    ws['A1'] = f'{spec["title"]} - EstiBuild Input Template'
    ws['A1'].font = Font(bold=True, size=13)
    lines = ['Fill each sheet (one row per item). Sheet name = table.',
             'Columns with choices have DROPDOWNS - pick from the list so the',
             'correct rate applies. Typing a different spelling may use default rates.',
             'Save and upload this .xlsx in EstiBuild - the form auto-fills.',
             'Lengths in metres, areas in m², thickness in mm.']
    for i, ln in enumerate(lines, 3):
        ws.cell(row=i, column=1).value = ln
    hints = [(t['title'], t.get('hint')) for t in spec['tables'] if t.get('hint')]
    if hints:
        r = 3 + len(lines) + 1
        ws.cell(row=r, column=1).value = 'SHEET GUIDE'
        ws.cell(row=r, column=1).font = Font(bold=True)
        for title, hint in hints:
            r += 1
            ws.cell(row=r, column=1).value = f'{title}: {hint}'
            ws.cell(row=r, column=1).font = Font(size=9, color='555555')
    ws.column_dimensions['A'].width = 90
    opt_ws = None
    opt_col = 0
    for t in spec['tables']:
        ws = wb.create_sheet(t['id'][:31])
        for c, f in enumerate(t['fields'], 1):
            cell = ws.cell(row=1, column=c)
            cell.value = f['label']
            cell.fill = HDR_FILL
            cell.font = HDR_FONT
        for r, row in enumerate(t.get('default_rows') or [], 2):
            for c, f in enumerate(t['fields'], 1):
                ws.cell(row=r, column=c).value = row.get(f['name'], '')
        for c in range(1, len(t['fields']) + 1):
            ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = 16
        # dropdowns for choice columns (select = strict, suggest = warning only)
        for c, f in enumerate(t['fields'], 1):
            opts = f.get('options') or []
            if not opts or f.get('type') not in ('select', 'suggest'):
                continue
            if opt_ws is None:
                opt_ws = wb.create_sheet('OPTIONS')
                opt_ws.sheet_state = 'hidden'
            opt_col += 1
            ol = get_column_letter(opt_col)
            opt_ws.cell(row=1, column=opt_col, value=f"{t['id']}.{f['name']}")
            for i, o in enumerate(opts, 2):
                opt_ws.cell(row=i, column=opt_col, value=str(o))
            dv = DataValidation(type='list',
                                formula1=f"OPTIONS!${ol}$2:${ol}${len(opts) + 1}",
                                allow_blank=True)
            if f.get('type') == 'suggest':
                dv.errorStyle = 'warning'   # suggestions, not restrictions
            ws.add_data_validation(dv)
            fl = ws.cell(row=1, column=c).column_letter
            dv.add(f'{fl}2:{fl}400')
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def structural_xlsx():
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet('READ ME')
    ws['A1'] = 'RCC Structure - EstiBuild Input Template'
    ws['A1'].font = Font(bold=True, size=13)
    for i, ln in enumerate(['Fill each sheet (one row per member type).',
                            'Dimensions in mm, areas in m².',
                            'Steel columns have DROPDOWN suggestions: mesh/ties "dia-spacing" or "dia-closed-mid", bars "no-dia" (e.g. 12-150, 8-100-150, 3-16).',
                            'Upload this .xlsx in EstiBuild RCC Structure.'], 3):
        ws.cell(row=i, column=1).value = ln
    ws.column_dimensions['A'].width = 100
    opt_ws = wb.create_sheet('OPTIONS')
    opt_ws.sheet_state = 'hidden'
    opt_col = 0
    from structural.engine import DEFAULT_SCHEDULE as D
    for tid, ttitle, fields in STRUCT_TABLES:
        ws = wb.create_sheet(tid[:31])
        for c, (fname, flabel) in enumerate(fields, 1):
            cell = ws.cell(row=1, column=c)
            cell.value = flabel
            cell.fill = HDR_FILL
            cell.font = HDR_FONT
        # example/default rows so users see the expected format
        for r, row in enumerate(D.get(tid, []) if isinstance(D.get(tid, []), list) else [], 2):
            for c, (fname, flabel) in enumerate(fields, 1):
                v = row.get(fname, '')
                ws.cell(row=r, column=c).value = v if v is not None else ''
        for c in range(1, len(fields) + 1):
            ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = 15
        # dropdowns on steel-spec + choice columns
        for c, (fname, flabel) in enumerate(fields, 1):
            opts = STEEL_DL.get(fname)
            if fname == 'kind' and tid == 'footings':
                # pile/raft have their OWN sheets with the right columns -
                # keep this dropdown to kinds whose inputs exist on this sheet
                opts = ['isolated', 'strap', 'combined']
            elif fname == 'kind' and tid == 'beams':
                opts = ['plinth', 'tie', 'primary', 'secondary']
            elif fname == 'kind' and tid == 'tanks':
                opts = ['overhead tank', 'underground sump']
            elif fname == 'type' and tid == 'staircase':
                opts = ['dog-legged', 'open-well', 'straight flight', 'spiral', 'cantilever']
            elif fname == 'type' and tid == 'slabs':
                opts = ['one-way slab', 'two-way slab', 'sunken slab (toilet)', 'flat slab', 'waffle (ribbed)']
            elif fname == 'grade':
                opts = ['M15', 'M20', 'M25', 'M30', 'M35']
            elif fname == 'soil':
                opts = ['soft soil', 'hard soil', 'rock', 'mixed']
            if not opts:
                continue
            opt_col += 1
            ol = get_column_letter(opt_col)
            opt_ws.cell(row=1, column=opt_col, value=f"{tid}.{fname}")
            for rr, o in enumerate(opts, 2):
                opt_ws.cell(row=rr, column=opt_col).value = o
            dv = DataValidation(type='list', formula1=f'=OPTIONS!${ol}$2:${ol}${len(opts) + 1}',
                                allow_blank=True, errorStyle='warning')
            ws.add_data_validation(dv)
            dv.add(f'{get_column_letter(c)}2:{get_column_letter(c)}500')
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ------------------------------------------------------------------ upload parsers
class FormDict(dict):
    def getlist(self, key):
        v = self.get(key)
        return v if isinstance(v, list) else ([v] if v is not None else [])


def html_to_data(html_text):
    """Parse our fillable HTML template server-side (works for AI drafts and any
    saved template where values are in the value= attributes). Mirrors the
    browser's exportData() JS: returns the same dict as the .json export."""
    import re as _re
    import html as _htmlmod

    def _val(tag):
        m = _re.search(r'value="([^"]*)"', tag)
        return _htmlmod.unescape(m.group(1)) if m else ''

    data = {'scalars': {}, 'labour_rates': {}, 'tables': {}}
    # tables: table[data-table=X] -> rows
    for tm in _re.finditer(r'<table data-table="(\w+)"[^>]*>(.*?)</table>', html_text, _re.S):
        tid, inner = tm.group(1), tm.group(2)
        tbody = inner.split('<tbody>')[1].split('</tbody>')[0] if '<tbody>' in inner else inner
        rows = []
        for rm in _re.finditer(r'<tr>(.*?)</tr>', tbody, _re.S):
            rec = {}
            for im in _re.finditer(r'<(input|select)\b([^>]*)>', rm.group(1)):
                nm = _re.search(r'name="([^"]+)"', im.group(2))
                if nm:
                    rec[nm.group(1)] = _val(im.group(2))
            for sm in _re.finditer(r'<select name="([^"]+)"[^>]*>(.*?)</select>', rm.group(1), _re.S):
                mm = _re.search(r'<option selected>([^<]*)</option>', sm.group(2)) or _re.search(r'<option>([^<]*)</option>', sm.group(2))
                if mm:
                    rec[sm.group(1)] = _htmlmod.unescape(mm.group(1))
            if any(str(v).strip() for v in rec.values()):
                rows.append(rec)
        data['tables'][tid] = rows
    # scalars + labour: named inputs outside tables (before the first data-table)
    head = html_text.split('<table data-table=')[0]
    for im in _re.finditer(r'<(input|select)\b([^>]*)>', head):
        nm = _re.search(r'name="([^"]+)"', im.group(2))
        if not nm:
            continue
        name = nm.group(1)
        if name.startswith('lr_'):
            data['labour_rates'][name[3:]] = _val(im.group(2))
        else:
            data['scalars'][name] = _val(im.group(2))
    # selects in the head section (selected option)
    for sm in _re.finditer(r'<select name="([^"]+)"[^>]*>(.*?)</select>', head, _re.S):
        mm = _re.search(r'<option selected>([^<]*)</option>', sm.group(2)) or _re.search(r'<option>([^<]*)</option>', sm.group(2))
        if mm:
            name = sm.group(1)
            v = _htmlmod.unescape(mm.group(1))
            if name.startswith('lr_'):
                data['labour_rates'][name[3:]] = v
            else:
                data['scalars'][name] = v
    return data


def json_to_schedule(data, spec):
    """Template JSON -> schedule dict (reuses the app's own parse for validation)."""
    import schedule_fw
    form = FormDict()
    for k, v in (data.get('scalars') or {}).items():
        form[k] = str(v)
    for k, v in (data.get('labour_rates') or {}).items():
        form['lr_' + k] = str(v)
    for t in spec['tables']:
        rows = (data.get('tables') or {}).get(t['id']) or []
        form[t['id'] + '_row'] = [str(i) for i in range(len(rows))]
        for i, r in enumerate(rows):
            for f in t['fields']:
                if f['name'] in r and r[f['name']] is not None and str(r[f['name']]).strip() != '':
                    form[f"{t['id']}_{f['name']}_{i}"] = str(r[f['name']])
                unit = r.get(f"{f['name']}__unit")
                if unit and str(unit).strip():
                    form[f"{t['id']}_{f['name']}_{i}_u"] = str(unit)
            if r.get('rate') is not None and str(r.get('rate')).strip() != '':
                form[f"{t['id']}_rate_{i}"] = str(r['rate'])
    return schedule_fw.parse(form, spec)


def json_to_structural(data):
    """Template JSON -> structural schedule dict (reuses parse_struct_form)."""
    import structural_ui
    form = FormDict()
    for k, v in (data.get('scalars') or {}).items():
        form[k] = str(v)
    for tid, _t, fields in STRUCT_TABLES:
        rows = (data.get('tables') or {}).get(tid) or []
        prefix = {'footings': 'f', 'rafts': 'rf', 'piles': 'pf', 'strips': 'sf',
                  'columns': 'c', 'beams': 'b', 'slabs': 's',
                  'shearwalls': 'w', 'retwalls': 'rw', 'tanks': 't', 'ramps': 'r',
                  'lifts': 'l', 'others': 'o', 'staircase': 'sc'}[tid]
        form[prefix + '_row'] = [str(i) for i in range(len(rows))]
        for i, r in enumerate(rows):
            for fname, _fl in fields:
                if fname in r and r[fname] is not None and str(r[fname]).strip() != '':
                    form[f'{prefix}_{fname}_{i}'] = str(r[fname])
    return structural_ui.parse_form(form)


def xlsx_to_schedule(bytes_data, spec):
    """Filled Excel template -> schedule dict."""
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(bytes_data))
    data = {'module': spec['id'], 'scalars': {}, 'tables': {}}
    label_to_name = {}
    for t in spec['tables']:
        label_to_name[t['id']] = {f['label'].lower(): f['name'] for f in t['fields']}
    for ws in wb.worksheets:
        name = ws.title.lower()
        tid = None
        for t in spec['tables']:
            if t['id'] == name or t['title'].lower() == name:
                tid = t['id']
                break
        if not tid:
            continue
        headers = {}
        for c in range(1, ws.max_column + 1):
            v = ws.cell(row=1, column=c).value
            if v:
                headers[c] = label_to_name[tid].get(str(v).lower())
        rows = []
        for r in range(2, ws.max_row + 1):
            rec = {}
            empty = True
            for c, fname in headers.items():
                if not fname:
                    continue
                v = ws.cell(row=r, column=c).value
                if v is not None and str(v).strip() != '':
                    rec[fname] = v
                    empty = False
            if not empty:
                rows.append(rec)
        if rows:
            data['tables'][tid] = rows
    return json_to_schedule(data, spec)


def xlsx_to_structural(bytes_data):
    from openpyxl import load_workbook
    wb = load_workbook(io.BytesIO(bytes_data))
    data = {'module': 'structural', 'scalars': {}, 'tables': {}}
    for ws in wb.worksheets:
        name = ws.title.lower()
        tid = None
        fields = None
        for tid_, _t, fields_ in STRUCT_TABLES:
            if tid_ == name:
                tid, fields = tid_, fields_
                break
        if not tid:
            continue
        headers = {}
        for c in range(1, ws.max_column + 1):
            v = ws.cell(row=1, column=c).value
            if v:
                for fname, flabel in fields:
                    if flabel.lower() == str(v).lower():
                        headers[c] = fname
                        break
        rows = []
        for r in range(2, ws.max_row + 1):
            rec = {}
            empty = True
            for c, fname in headers.items():
                if not fname:
                    continue
                v = ws.cell(row=r, column=c).value
                if v is not None and str(v).strip() != '':
                    rec[fname] = v
                    empty = False
            if not empty:
                rows.append(rec)
        if rows:
            data['tables'][tid] = rows
    return json_to_structural(data)
